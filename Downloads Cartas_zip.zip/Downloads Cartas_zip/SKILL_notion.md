---
name: notion-knowledge-base
description: >
  Processa documentos (PDF, PPT, transcrições de Zoom, texto) e os indexa no
  Repositório de Conhecimento do Notion seguindo um fluxo padronizado: extração
  de conteúdo em markdown, geração de keypoints estruturados e criação de nota
  no database com metadados completos. Use este skill sempre que o usuário
  mencionar: "adicionar ao Notion", "processar esse PDF/relatório/transcrição",
  "criar nota no repositório", "indexar documento", enviar um arquivo para ser
  armazenado, ou qualquer fluxo de captura de conhecimento para o Notion.
  Também se aplica quando o usuário mencionar pastas específicas como Gavekal,
  Geopolítica, Política Monetária, etc.
---

# Notion Knowledge Base — Skill de Processamento e Indexação

## Visão geral do fluxo

```
Documento recebido (PDF / PPT / transcrição / texto)
        ↓
1. Extrair conteúdo e identificar metadados
        ↓
2. Gerar nota estruturada em markdown (keypoints + conteúdo completo)
        ↓
3. Criar entrada no database do Notion com propriedades preenchidas
        ↓
4. Mover para a pasta correta (se aplicável)
        ↓
5. Confirmar link e lembrar o usuário de anexar o PDF original na pasta
```

---

## Infraestrutura do Notion

### Database central
- **Nome:** 📚 Repositório de Conhecimento
- **data_source_id:** `adbce1b0-2102-40f7-8fb1-b05839183af1`
- Toda nota em markdown vai aqui — é o que alimenta buscas de IA

### Pastas (repositório de arquivos originais)
Usadas para guardar PDFs, PPTs e docs originais. O arquivo original é anexado manualmente pelo usuário na pasta correta. A nota .md no database referencia o arquivo via campo `PDF Original` (URL).

| Pasta | ID da página | Conteúdo |
|---|---|---|
| 🌍 Geopolítica | `36ea8a2f-677c-8130-987c-f8ab0e8b0a83` | Relatórios e análises geopolíticas |
| 🏛️ Política Nacional | `36ea8a2f-677c-8195-94c3-e07dbca014ea` | Política doméstica brasileira |
| 🗽 Eleições | `36ea8a2f-677c-81d0-9857-c392f6e9717a` | Subpasta de Política Nacional |
| 🏩 Congresso / Legislativo | `36ea8a2f-677c-815d-b72c-d5d3eb8194ee` | Subpasta de Política Nacional |
| 📉 Política Monetária | `36ea8a2f-677c-81a2-8ccb-e23200ec353d` | BC, juros, comunicados |
| 📝 Atas | `36ea8a2f-677c-81bb-be43-f86d7fb35494` | Subpasta de Política Monetária |
| 📣 Comunicados | `36ea8a2f-677c-8101-bdc9-c7d74ffe9ea1` | Subpasta de Política Monetária |
| 🗂️ Diversos | `36ea8a2f-677c-8183-b418-f4724ee7f4c2` | Subpasta de Política Monetária |
| ✉️ Cartas de Gestão | `36ea8a2f-677c-8198-bc0d-c7d5a4e9d0d2` | Cartas de gestores de fundos |
| 🔬 Gavekal | `36ea8a2f-677c-81fc-9e0d-ec35f3c173d1` | Relatórios diretos da Gavekal |
| 📊 Relatórios - BR | `36ea8a2f-677c-81b1-b710-e4ce0f78e526` | Relatórios de casas brasileiras |
| 🌐 Relatórios - Internacionais | `36ea8a2f-677c-816d-bba8-cbda838df221` | Relatórios internacionais |
| 📈 Mercado | `36ea8a2f-677c-815a-858e-ce262f654223` | Análises de mercado geral |
| 📁 Macro Global | `36ea8a2f-677c-812b-b9ec-e56c14f95687` | Macro internacional |

### Schema do database

```
Título         TITLE
Data           DATE
Tipo           SELECT  → ver opções abaixo
Fonte          MULTI_SELECT → ver opções abaixo
Participantes  RICH_TEXT
Temas          MULTI_SELECT → ver opções abaixo
Mercados       MULTI_SELECT → ver opções abaixo
Ativos         MULTI_SELECT → ver opções abaixo
PDF Original   URL  (campo a ser adicionado quando necessário)
```

**Tipo (SELECT):**
`Transcrição de Reunião Externa · Transcrição de Reunião Interna · Entrevista · Relatório · Carta de Gestão · Ata · Comunicado · Notícia · Podcast`

**Fonte (MULTI_SELECT):**
`XP Research · Itaú BBA · BTG Pactual · Goldman Sachs · Morgan Stanley · JP Morgan · BlackRock · Eurasia Group · Gavekal · Dragonomics · Ministério da Fazenda · Banco Central · FMI · Interno · Verde Asset · Gaveá Investimentos · Adam Capital · Bahia Asset · Legacy Capital · Armor Capital · Sparta · JGP · Azimut · Dynamo · Guepardo · Ibiuña Investimentos · Kadima · Persevera`

**Temas (MULTI_SELECT):**
`Macro Global · Política Monetária · Fiscal Brasil · Geopolítica · Eleições Brasil · Eleições EUA · Mercado de Crédito · Renda Variável · Commodities · Energia · China · Europa · Emergentes · Câmbio · Japão`

**Mercados (MULTI_SELECT):**
`Brasil · EUA · China · Europa · Emergentes · Global`

**Ativos mencionados (MULTI_SELECT):**
`BRL · Juros · Petróleo · Commodities · Renda Variável · Câmbio · Ouro · Crédito`

> Se um valor necessário não existir no schema, usar `notion-update-data-source` para adicioná-lo antes de criar a nota.

---

## Passo 1 — Identificar tipo de documento e metadados

Antes de processar, identificar:

| Campo | Como identificar |
|---|---|
| **Tipo** | PDF de relatório → Relatório; transcrição Zoom → Transcrição de Reunião Externa/Interna; carta de gestor → Carta de Gestão |
| **Fonte** | Organização/empresa que produziu o conteúdo (não a plataforma técnica) |
| **Data** | Data de publicação ou da reunião, não de processamento |
| **Pasta de destino** | Baseado no tema principal — consultar tabela acima |
| **Participantes** | Para transcrições: nomes dos falantes; para relatórios: autor(es) |

---

## Passo 2 — Estrutura da nota markdown

Toda nota segue esta estrutura. Adaptar seções conforme o tipo de documento.

```markdown
# 📎 Documento Original
`nome-do-arquivo.pdf` — anexar manualmente na pasta [NOME DA PASTA]
[Link: ](url quando disponível)

---

# 📋 Metadados
| Campo | Valor |
|---|---|
| Publicação / Organização | ... |
| Data | ... |
| Autor / Participantes | ... |

---

# 🎯 Keypoints

## Tese central
[Argumento principal em 2-4 linhas. Direto, sem introdução.]

## 🔺 Pontos fora da curva
[Apenas o que é distinto do conhecimento geral. Mínimo de introdução, máximo de substância.]

## 📐 Frameworks e regras de bolso
[Modelos analíticos, heurísticas, regras de bolso citados. Com fonte quando possível.]

## 📅 Prazos, números e projeções
[Tabela com dados quantitativos relevantes.]

## ⚡ Condicionais: se X então Y
[Lista de relações causais explícitas ou implícitas no documento.]

---

# 📄 Conteúdo Completo (MD)
[Texto completo do documento convertido para markdown limpo.
Gráficos → descrição textual + dados quando legíveis.
Tabelas → converter para markdown.
Seções de disclaimer → omitir.]
```

### Instruções para keypoints

- Começar pela tese central — não pela introdução do documento
- Não destacar o óbvio ou o que está no título
- Priorizar: pontos contraintuitivos, frameworks nomeados, regras de bolso, quotes fortes, projeções numéricas, acordos/combinados, relações causais condicionais
- Para gráficos: descrever o que o gráfico mostra + extrair os dados visíveis + indicar a fonte do gráfico

---

## Passo 3 — Criar nota no Notion

```python
# Usar Notion:notion-create-pages com parent = data_source_id do database
parent = {"data_source_id": "adbce1b0-2102-40f7-8fb1-b05839183af1", "type": "data_source_id"}

# Propriedades obrigatórias
properties = {
    "Título": "...",
    "date:Data:start": "YYYY-MM-DD",
    "date:Data:is_datetime": 0,
    "Tipo": "...",           # SELECT — valor único
    "Fonte": '["..."]',      # MULTI_SELECT — JSON array
    "Temas": '["..."]',      # MULTI_SELECT — JSON array
    "Mercados": '["..."]',   # MULTI_SELECT — JSON array
    "Ativos mencionados": '["..."]',  # MULTI_SELECT — JSON array
    "Participantes": "...",  # texto livre
}
```

> ATENÇÃO: Não mover a nota para pastas de arquivos — isso a remove do database. As pastas são apenas para arquivos originais (PDF/PPT). A nota .md fica sempre no database.

---

## Passo 4 — Adicionar campo PDF Original (quando aplicável)

Se o usuário indicar que vai anexar o PDF original numa pasta, adicionar o campo URL na nota após receber o link:

```python
# Usar Notion:notion-update-page command="update_properties"
properties = {"PDF Original": "https://notion.so/..."}
```

Se o campo `PDF Original` ainda não existir no schema do database:
```sql
-- Usar notion-update-data-source
ADD COLUMN "PDF Original" URL
```

---

## Passo 5 — Confirmação final

Ao concluir, entregar:
1. Link direto para a nota no Notion
2. Lembrete para o usuário anexar o PDF original na pasta correta
3. Resumo das tags aplicadas (para o usuário validar ou corrigir)

Formato de confirmação:
```
✅ Nota criada: [título](link)
📁 PDF original: anexar manualmente em [nome da pasta]
🏷️ Tags: Tipo · Fonte · Temas · Mercados
```

---

## Casos especiais

### Transcrições do Zoom
- Buscar via `Zoom for Claude:search_meetings` com o nome da reunião
- Obter transcrição via `Zoom for Claude:get_meeting_assets`
- Identificar falantes pelo prefixo `Nome: texto` na transcrição
- Se a reunião tiver mais de ~45min ou for claramente cortada em dois arquivos, criar Parte 1 e Parte 2 separadas

### PDFs com gráficos
- Descrever cada gráfico com: título, fonte, tipo de visualização, séries presentes, valores aproximados visíveis, tendência geral
- Incluir nota: `[Gráfico — ver PDF original para visualização]`

### Documentos em inglês
- Processar em português (keypoints, metadados, estrutura)
- Conteúdo completo: manter no idioma original com título de seção em português

### Novo valor de tag necessário
Se um tema, fonte, mercado ou ativo não existir no schema:
1. Usar `notion-update-data-source` para adicionar o novo valor
2. Só então criar a nota com o novo valor

### Fonte não identificada claramente
- Priorizar a organização intelectual (quem produziu as ideias), não a plataforma técnica
- Se não identificável: usar `Interno`
