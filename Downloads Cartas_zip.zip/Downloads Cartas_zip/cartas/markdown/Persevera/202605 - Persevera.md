top of page

Ir para o conteúdo principal

Material Informativo

Confira abaixo o material informativo 

referente à Julho/20 do fundo Persevera Compass FIC FIM. 

Acesse sua plataforma de investimentos e comece a investir! 

[](https://www.persevera.com.br/_files/ugd/056676_c77bf06ade654fd3bc4aa8a0d43a208b.pdf)

[](https://www.persevera.com.br)

  * [HOME](https://www.persevera.com.br)

  * [PERSEVERA](https://www.persevera.com.br/persevera)

    * [QUEM SOMOS](https://www.persevera.com.br/persevera)

    * [EQUIPE](https://www.persevera.com.br/persevera)

    * [IMPRENSA](https://www.persevera.com.br/imprensa)

  * [FUNDOS](https://www.persevera.com.br/fundos)

  * [CARTA TRIMESTRAL](https://www.persevera.com.br/carta-mensal)

  * [REGULATÓRIO](https://www.persevera.com.br/regulatório)

    * [TRANSPARÊNCIA INFORMACIONAL](https://www.persevera.com.br/transparencia-informacional)

  * [CONTATO](https://www.persevera.com.br/contato)




PT

EN

  * [Todos posts](https://www.persevera.com.br/carta-mensal)
  * [2025](https://www.persevera.com.br/carta-mensal/categories/2025)
  * [2024](https://www.persevera.com.br/carta-mensal/categories/2024)
  * [2023](https://www.persevera.com.br/carta-mensal/categories/2023)
  * [2022](https://www.persevera.com.br/carta-mensal/categories/2022)
  * [2021](https://www.persevera.com.br/carta-mensal/categories/2021)
  * [2020](https://www.persevera.com.br/carta-mensal/categories/2020)
  * [2019](https://www.persevera.com.br/carta-mensal/categories/2019)
  * [2018](https://www.persevera.com.br/carta-mensal/categories/2018)
  * [Whitepaper](https://www.persevera.com.br/carta-mensal/categories/whitepaper)
  * [2026](https://www.persevera.com.br/carta-mensal/categories/2026)



Buscar

# Contracorrente

  * Thales Carmo
  * 7 de nov. de 2025
  * 11 min de leitura



“O verdadeiro desafio não é desenvolver novas ideias, mas escapar das antigas”

**John Maynard Keynes**

  


  


#### **Sumário executivo**

  


** _Mercado Global_**

  


  * Em outubro, o Federal Reserve (Fed) deu continuidade ao ciclo de cortes, reduzindo em 0,25 p.p. a taxa básica de juros americana, e anunciou o fim do aperto quantitativo (QT), abrindo uma nova etapa de recomposição de liquidez global.

  * O acúmulo de caixa do Tesouro americano durante o _shutdown_  e seu provável esvaziamento nos próximos meses, aliado ao fim do QT, podem gerar um impulso de liquidez relevante, com impacto positivo sobre ativos de risco.

  





**_Mercado Local_**

  


  * A política monetária brasileira permanece excessivamente restritiva apesar da desinflação e da desaceleração da atividade, ampliando o desalinhamento em relação ao ciclo global de afrouxamento monetário (cortes de juros).

  * No campo político, o governo tem buscado reconstruir popularidade com medidas de apelo social e tom mais pragmático, enquanto o arcabouço fiscal e o Congresso limitam expansões de gasto. Ainda assim, a popularidade de Lula permanece majoritariamente negativa.

  





**_Nossas Visões e Posições_**

  


  * Mantemos preferência por prefixados longos na renda fixa e postura cautelosa em crédito privado, diante dos níveis apertados dos _spreads_  e da reprecificação gradual de risco.

  * Seguimos confiantes na resiliência estrutural do real, que tende a se beneficiar da fraqueza do dólar e do diferencial de juros ainda elevado. Também adotamos postura seletiva em renda variável no curto prazo, com menor exposição a ativos domésticos e foco em oportunidades globais.




  


 

  


#### Estados Unidos: Um corte, dois recados

  


O ambiente internacional em outubro continuou orbitando a política monetária americana. Como amplamente antecipado, o Federal Reserve (Fed) deu continuidade ao ciclo de cortes e reduziu a taxa básica de juros em 0,25 p.p., levando o intervalo-alvo para 3,75%–4,00%. A decisão, embora esperada, ganhou novo peso diante do discurso mais duro do presidente Jerome Powell, que fez questão de sinalizar que a trajetória de queda de juros não será linear. Esse tom mais restritivo reduziu as apostas em novos cortes na reunião de dezembro e reforçou a percepção de que o caminho da política monetária daqui em diante será mais cauteloso do que o mercado esperava.

  


Essa combinação de corte efetivo e retórica conservadora traduz bem a ambiguidade do momento macro dos Estados Unidos. A inflação segue em trajetória de convergência — com o CPI e o PCE abaixo das expectativas —, mas os núcleos permanecem levemente acima da meta, especialmente em serviços e habitação.

  


  


O mercado de trabalho tem mostrado sinais peculiares. Como o próprio presidente do Fed descreveu, o mercado de trabalho atual segue em um “equilíbrio curioso”. O prolongamento da paralisação de alguns serviços do governo americano (_shutdown_) tem impedido a divulgação dos dados econômicos oficiais, adicionando incerteza à leitura do atual estado do mercado de trabalho. Até então, os dados disponíveis indicam que os Estados Unidos vivem um momento de baixa contratação e baixa demissão (_low-hire, low-fire_), enquanto o crescimento salarial desacelera gradualmente e a criação de empregos permanece quase estagnada. Entretanto, com a taxa de desemprego subindo apenas marginalmente e, portanto, com baixo risco de recessão, o Fed tem se pautado no argumento de normalização.

  


  


O Fed parece reconhecer que a batalha contra a inflação está avançando, mas teme que uma postura excessivamente branda reacenda pressões de preços antes que a desaceleração da atividade se consolide. Ao mesmo tempo, os indicadores de confiança e manufatura apontam que a economia se move em direção a um pouso suave — sustentada pelo consumo, mas com fôlego cada vez menor.

  


Em nossa leitura, o corte de outubro foi menos um gesto de estímulo e mais um ajuste tático: uma tentativa de calibrar a política antes que o aperto se transforme em restrição excessiva.

  


#### Estados Unidos: O outro lado do ciclo

  


O segundo movimento relevante do mês foi o anúncio do fim do programa de aperto quantitativo (QT), com encerramento formal previsto para 1º de dezembro. Depois de dois anos drenando cerca de US$ 60 bilhões mensais do sistema financeiro — o equivalente a US$ 1,4 trilhão de redução de balanço —, o Fed encerra o processo de contração e entra em uma nova fase de gestão da liquidez.

  


  


Essa mudança ocorre em um momento em que o Tesouro americano acumulou cerca de US$ 1 trilhão na Treasury General Account (TGA), após uma alta que, desde o início de julho, somou entre US$ 600 e 700 bilhões. Ao longo do _shutdown_ , o governo seguiu emitindo títulos (retirando liquidez), mas não gastou (não devolveu liquidez), produzindo uma espécie de “drenagem dupla” que pressionou as reservas bancárias.

  


  


A nosso ver, a combinação entre o fim do QT e o provável esvaziamento da TGA após a resolução do _shutdown_  pode criar um ponto de inflexão importante para os mercados globais. Quando os gastos do governo forem retomados, parte relevante desse caixa retorna ao sistema, revertendo a drenagem recente e gerando uma injeção de liquidez de várias centenas de bilhões de dólares nos próximos trimestres.

  


Os sinais de tensão já apareciam: reservas próximas ao piso operacional, maior uso dos instrumentos de liquidez do Fed e aperto nos _money markets_. Interromper o QT e realocar proventos de MBS para T-bills (títulos de dívida curtos) foi, portanto, uma resposta preventiva que reduz tensões de financiamento e torna a liquidez mais previsível.

  


Se o _shutdown_  for resolvido em dezembro, a sequência tende a ser clara: **(i)**  o fim do QT cessa a drenagem mensal; **(ii)**  o esvaziamento da TGA recoloca caixa no sistema; **(iii)**  o reinvestimento dos vencimentos de títulos do Fed mantém o sistema com reservas amplas. O efeito combinado alivia as pressões de liquidez em dólares, suaviza a curva de juros reais e melhora o pano de fundo para ativos de risco e economias emergentes.

  


Outubro, portanto, pode ter marcado o início de uma nova etapa do ciclo de liquidez global. Os juros seguem relativamente altos, mas a liquidez — antes um freio — pode começar a atuar como suporte.

  


#### Brasil: Política monetária fora de compasso

  


O Brasil continua a destoar do cenário global. Enquanto as principais economias iniciam a transição para um regime de juros mais baixos e liquidez crescente, o Banco Central brasileiro mantém a Selic em 15%, insistindo em uma postura de restrição prolongada. O discurso oficial permanece inalterado: a inflação ainda exige cautela e a convergência para a meta de 3% precisa ser assegurada por um longo período de política monetária apertada. Na prática, essa estratégia vem se tornando cada vez mais desconectada da realidade dos dados e dos fundamentos.

  


As leituras recentes do IPCA e do IPCA-15 reforçaram a trajetória de desinflação. O núcleo de serviços voltou a ceder, os bens industriais registraram deflação e os alimentos, tradicionalmente mais voláteis, também contribuíram para o recuo. As expectativas de inflação seguem em queda há meses, com as projeções do Focus para 2025 e 2026 caindo significativamente e orbitando o topo da banda de tolerância da meta. As inflações implícitas recuaram de níveis acima de 5,5% para a faixa de 4% a 5%, enquanto os juros reais longos — próximos a 8% ao ano — permanecem entre os mais elevados do mundo.

  


  


Apesar disso, a autoridade monetária insiste em ignorar a mudança de regime. A comunicação segue excessivamente dura, enfatizando riscos residuais e tratando a apreciação cambial e a moderação da atividade como fenômenos temporários. Essa rigidez contrasta com um ambiente doméstico de desaceleração nítida: os indicadores de difusão da atividade atingiram o menor nível desde a pandemia, e o PIB deve rodar próximo da estagnação no segundo semestre. A defasagem entre política e ciclo se amplia — a inflação cede, mas os juros permanecem punitivos.

  


A comparação internacional torna essa anomalia evidente: nos Estados Unidos, o Fed corta juros com inflação em trajetória descendente de 9% para 3%; no Brasil, há resistência em sinalizar cortes mesmo com inflação caindo de 12% para 4,5%. Com juros reais próximos de dois dígitos, o país mantém uma das políticas monetárias mais restritivas do mundo. Nos 15 anos anteriores à atual meta de 3%, trabalhávamos com meta de 4,5%, mas a inflação efetivamente entregue ficou em média de 6% ao ano. Os patamares atuais de 4%–4,5% representam desempenho relativamente positivo no contexto histórico brasileiro.

  


  


O resultado é um desalinhamento crescente entre discurso e realidade: o Banco Central age como se ainda houvesse risco de descontrole inflacionário, quando o verdadeiro desafio já é evitar que o aperto excessivo se converta em estagnação.

  


A estratégia funciona no sentido de controlar a inflação, mas o custo dessa abordagem é substancialmente maior que o necessário, gerando destruição de valor por meio de múltiplos canais — o encarecimento do serviço da dívida pública, a deterioração de balanços corporativos (como evidenciado pelos casos recentes de grandes empresas), a limitação de investimentos produtivos e a compressão de margens de empresas endividadas. O Brasil chega a este ponto do ciclo global com a política monetária no lugar errado e no tempo errado — protegendo uma meta já alcançada, ao custo de sufocar o próprio crescimento.

  


  


#### Brasil: O jogo de 2026 começou

  


A política brasileira entrou em nova fase. Após meses de desgaste com a desvalorização do real e a narrativa de taxação do Pix, o governo conseguiu recompor parte de sua popularidade, beneficiando-se da melhora do ambiente de mercado e de uma estratégia mais coordenada de comunicação. As pesquisas mais recentes mostram uma leve recuperação do presidente Lula, embora a rejeição permaneça elevada, com mais da metade dos entrevistados avaliando negativamente o desempenho presidencial.

  


  


Com as eleições de 2026 no horizonte, o governo passou a adotar uma postura mais propositiva. Outubro marcou o avanço de medidas de forte apelo popular — a ampliação da faixa de isenção do imposto de renda para quem ganha até R$ 5 mil, a criação de um novo programa habitacional voltado à classe média e o estudo de tarifa zero no transporte público. Todas essas iniciativas compartilham o mesmo objetivo: reconstruir a narrativa de prosperidade e inclusão, transformando políticas distributivas em plataforma eleitoral.

  


Apesar da retórica presidencial diária sobre expansão de gastos, que gera pânico episódico no mercado, os mecanismos de controle fiscal continuam a funcionar na prática. A derrubada da MP 1303 no Congresso evidencia duas dinâmicas: ciclicamente, o Congresso não tem incentivos para conceder vitórias fáceis ao governo em período pré-eleitoral; estruturalmente, o arcabouço fiscal tem se mostrado um mecanismo efetivo de contenção. Ao nosso ver, o governo conquista ganhos marginais, mas não consegue mais promover expansões de grande escala, como aquelas vistas em ciclos anteriores.

  


O diálogo reaberto com os Estados Unidos e o tom mais pragmático em relação à política comercial indicam tentativa de distensionar o ambiente externo e projetar moderação institucional, o que acabou gerando uma reação relativamente positiva entre a população. Ao mesmo tempo, a direita mantém nomes competitivos e base consolidada nas redes, embora ainda sem figura nacional definida para as eleições. Apesar de acreditarmos na vitória de um nome da direita em 2026, reconhecemos o cenário político como um dos principais riscos à frente.

  


Esse equilíbrio precário tem se refletido nos preços dos ativos. A ausência de novos catalisadores internos e a percepção de menor risco político imediato permitiram que o mercado brasileiro continuasse acompanhando a tendência global positiva, sustentado por fluxos estrangeiros robustos na segunda metade do mês — ainda que a natureza desses fluxos permaneça nebulosa e possivelmente pontual. O Brasil, sendo um mercado pequeno em termos de liquidez global, tende a amplificar o impacto de movimentos concentrados. Ainda assim, a política tende a permanecer como vetor de volatilidade, especialmente à medida que o ciclo eleitoral se intensifica e a agenda fiscal se aproxima dos limites do arcabouço.

  


O país vive, assim, uma transição de narrativas. O governo ajusta o tom e busca estabilidade para pavimentar 2026, enquanto o Banco Central, isolado em sua rigidez, ainda dita uma política que parece responder a um Brasil anterior. Entre o pragmatismo político e o conservadorismo monetário, o mercado encontra um ponto de equilíbrio temporário — sustentado mais pela liquidez global do que pela coerência doméstica.

  


 

  


#### **Nossas visões e posições**

  


#####  Renda Fixa

  


A dinâmica desinflacionária de outubro reforçou nossa visão de assimetria na precificação dos juros longos. O IPCA-15 voltou a surpreender positivamente, com desaceleração dos núcleos e alívio em bens industriais e energia, enquanto as expectativas do Focus continuaram recuando. Mesmo assim, o Banco Central manteve tom firme, reiterando a necessidade de juros elevados por período prolongado, o que ampliou a divergência entre a comunicação oficial e a precificação de mercado — que já indica cortes a partir do início de 2026.

  


Paralelamente, o ambiente global também exerceu influência importante. Mesmo com as incertezas em torno do ciclo de cortes pelo Fed e o fortalecimento do dólar, o Brasil segue apresentando diferencial de juros elevado e uma estrutura de inflação sob controle, o que sustenta a atratividade relativa dos ativos de renda fixa domésticos.

  


**Posicionamento** : Mantemos preferência por títulos prefixados, concentrando a exposição nos vértices mais longos, que devem capturar melhor a reprecificação da curva de juros em um contexto de desinflação consistente e possível flexibilização monetária à frente.

  


##### Crédito Privado

  


O mercado de crédito privado brasileiro encerrou outubro em um ambiente mais desafiador, marcado por deterioração gradual das condições de liquidez e reprecificação dos spreads, especialmente em papéis de maior duration e risco corporativo. Episódios de estresse envolvendo empresas como Raízen, Ambipar e Braskem ampliaram a cautela dos investidores e reforçaram a necessidade de maior seletividade nas alocações. Em resposta, observou-se migração relevante para ativos de alta qualidade (_high grade_), enquanto companhias com fundamentos sólidos, mas mais expostas ao ciclo econômico, também enfrentaram algum aumento nos prêmios, ainda que em níveis confortáveis.

  


O segmento de debêntures incentivadas passou por uma pequena correção, refletindo tanto o ajuste de risco corporativo quanto os efeitos da derrubada da MP 1303/25. Nesse contexto, o fluxo de investimento que já estava mandatado com a captação dos fundos infra ajudou a suavizar essa correção.

  


**Posicionamento:** Mantivemos uma postura defensiva e flexível, reduzindo de forma seletiva a exposição em crédito corporativo e debêntures incentivadas, com foco em ativos de alta qualidade e prazos mais curtos. Sendo assim, aumentamos a liquidez dos nossos fundos de crédito, além de realocarmos uma parte do portfólio para o segmento de crédito estruturado, buscando maior estabilidade de retorno e menor correlação com o risco de mercado. Evitamos vendas forçadas e priorizamos a preservação de capital, mantendo disciplina nas alocações e critérios rigorosos de análise de risco. Seguimos atentos à evolução dos riscos de crédito e liquidez, prontos para eventuais oportunidades pontuais, mas sem abrir mão de critérios rigorosos de seleção e gestão de risco.

  


##### Moedas

  


Apesar do corte de juros realizado pelo Fed, o discurso mais cauteloso sobre novos movimentos reforçou a leitura de que o ciclo de flexibilização monetária será gradual e condicionado à evolução da inflação. Ao mesmo tempo, a de-escalada no conflito comercial entre Estados Unidos e China contribuiu para uma leve melhora no sentimento de risco, mas não foi suficiente para inverter a tendência de valorização do dólar globalmente.

  


Apesar desse pano de fundo, o Real seguiu mostrando resiliência, apoiado pelo diferencial de juros ainda elevado e por fluxos externos pontuais. Esses fatores compensaram, em parte, o impacto do ruído fiscal doméstico, que manteve o câmbio sensível às manchetes de Brasília. O resultado foi um comportamento relativamente estável do real ao longo do mês, com volatilidade moderada e desempenho em linha com outras moedas emergentes de alta taxa de juros.

  


**Posicionamento** : Seguimos com posição comprada em Real e vendida em Dólar, sustentados pela tese estrutural de enfraquecimento do Dólar no médio prazo. A tendência de apreciação do Real permanece intacta, apoiada tanto em fundamentos locais quanto em fluxos externos construtivos. Além disso, o elevado diferencial de juros cria um carrego positivo para a posição. Monitoramos a dinâmica global, reconhecendo episódios de fortalecimento pontual do Dólar, mas sem alterações em nossa convicção estrutural sobre a moeda brasileira.

  


##### Renda Variável

  


As bolsas globais tiveram um mês majoritariamente positivo, sustentadas pela combinação entre resultados corporativos acima do esperado e a melhora do sentimento de risco após a trégua comercial entre Estados Unidos e China. Nos EUA, o S&P 500 se aproximou de suas máximas históricas, impulsionado pelo bom desempenho dos setores de tecnologia e consumo e pela percepção de que o processo de desaceleração econômica permanece sob controle.

  


No Brasil, o Ibovespa acompanhou o otimismo externo e registrou recuperação ao longo do mês, sustentado principalmente por fluxos estrangeiros positivos e pela resiliência dos setores ligados a commodities. Ainda enxergamos espaço para altas adicionais, dependentes de novos catalisadores domésticos ou uma continuidade da tendência vinda do exterior.

  


Entre os ativos alternativos, o ouro passou por um período de volatilidade acentuada, com correção expressiva após forte valorização nos meses anteriores. Apesar dessa pausa, acreditamos que a tendência de alta permanece firme, sobretudo para o médio e longo prazo.

  


**Posicionamento** : Mantivemos postura predominantemente defensiva em relação aos ativos de risco domésticos. No mercado internacional, seguimos cautelosos em relação à bolsa americana, atentos à evolução da liquidez global e ao comportamento dos fluxos de capital. Em ativos alternativos, mantivemos exposição a ouro e lítio, e reduzimos posições em prata e mineradoras de ouro, que têm sofrido com a correção da principal _commodity_  metálica. No caso do bitcoin, mantivemos exposição taticamente reduzida, diante da deterioração técnica e das preocupações com a liquidez global.

  


  


#### **Nossos fundos**

  


Para informações completas, consulte os materiais informativos.

  


Equipe Persevera 

 

[_contato@persevera.com.br_](mailto:contato@persevera.com.br)

(11) 4780-3794

164

164 visualizações

0

0 comentário

1 curtida. Post não marcado como curtido1

## Posts recentes

[Ver tudo](https://www.persevera.com.br/carta-mensal)

[](https://www.persevera.com.br/post/um-novo-porto-seguro)

[Um Novo Porto Seguro](https://www.persevera.com.br/post/um-novo-porto-seguro)

118

0 comentário0

Post não marcado como curtido

[](https://www.persevera.com.br/post/além-do-mantra)

[Além do Mantra](https://www.persevera.com.br/post/além-do-mantra)

183

0 comentário0

1 curtida. Post não marcado como curtido1

[](https://www.persevera.com.br/post/quando-os-juros-mordem-e-o-crédito-grita)

[Quando os juros mordem e o crédito grita](https://www.persevera.com.br/post/quando-os-juros-mordem-e-o-crédito-grita)

121

0 comentário0

Post não marcado como curtido

[Todas as publicações ](https://www.persevera.com.br/carta-mensal)

+55 11 4780-3794 | [contato@persevera.com.br](mailto:contato@persevera.com.br?subject=Contato)

Av. Juscelino Kubistchek, 1455 - 3o Andar

Vila Nova Conceição - 04543-011 -  São Paulo - SP - Brasil

  * [](https://www.facebook.com/pg/perseveraasset/about/)
  * [](https://www.instagram.com/persevera_asset/?hl=pt-br)
  * [](https://www.linkedin.com/company/persevera-asset-management/?viewAsMember=true)
  * [](https://www.youtube.com/channel/UCjo8U7VdUkvZDUGXm1w7M3w?view_as=subscriber)



##### Inscreva-se para receber nossa Carta Trimestral

Seu e-mail foi cadastrado!

Assinar

A Persevera Gestão de Recursos Ltda. (“Persevera”) é uma empresa do grupo Fami Capital e este site tem caráter meramente informativo, não constituindo uma oferta de serviço pela Persevera e nem venda de cotas dos fundos por ela geridos. A Persevera não comercializa e nem distribui cotas de fundos de investimento ou qualquer outro ativo financeiro. Para avaliação da performance de quaisquer fundos de investimentos, é recomendável uma análise de período de, no mínimo, 12 (doze) meses. Fundos de investimento não contam com garantia da Persevera, de qualquer de suas afiliadas, de qualquer mecanismo de seguro ou, ainda, do Fundo Garantidor de Créditos - FGC. Os fundos geridos pela Persevera utilizam estratégias com derivativos como parte integrante de sua política de investimento. Estratégias com derivativos apresentam risco elevado e podem resultar em significativas perdas patrimoniais para seus cotistas. As informações contidas neste website não constituem uma opinião ou recomendação, legal ou de qualquer outra natureza, por parte da Persevera, e não leva em consideração a situação particular de qualquer pessoa. A utilização das informações aqui contidas se dará exclusivamente por conta e risco de seu usuário. Antes de tomar qualquer decisão acerca de seus investimentos, a Persevera recomenda ao interessado que consulte um profissional especializado e também a leitura cuidadosa de prospectos, regulamentos e das lâminas de informações essenciais dos fundos de investimento.

bottom of page
