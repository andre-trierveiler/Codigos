top of page

Ir para o conteúdo principal

Material Informativo

Confira abaixo o material informativo 

referente à Julho/20 do fundo Persevera Compass FIC FIM. 

Acesse sua plataforma de investimentos e comece a investir! 

[](https://www.persevera.com.br/_files/ugd/056676_c77bf06ade654fd3bc4aa8a0d43a208b.pdf)

[](https://www.persevera.com.br)

  * [HOME](https://www.persevera.com.br)

  * [PERSEVERA](https://www.persevera.com.br/persevera)

    * [QUEM SOMOS](https://www.persevera.com.br/persevera)

    * [EQUIPE](https://www.persevera.com.br/persevera)

    * [IMPRENSA](https://www.persevera.com.br/imprensa)

  * [FUNDOS](https://www.persevera.com.br/fundos)

  * [CARTA TRIMESTRAL](https://www.persevera.com.br/carta-mensal)

  * [REGULATÓRIO](https://www.persevera.com.br/regulatório)

    * [TRANSPARÊNCIA INFORMACIONAL](https://www.persevera.com.br/transparencia-informacional)

  * [CONTATO](https://www.persevera.com.br/contato)




PT

EN

  * [Todos posts](https://www.persevera.com.br/carta-mensal)
  * [2025](https://www.persevera.com.br/carta-mensal/categories/2025)
  * [2024](https://www.persevera.com.br/carta-mensal/categories/2024)
  * [2023](https://www.persevera.com.br/carta-mensal/categories/2023)
  * [2022](https://www.persevera.com.br/carta-mensal/categories/2022)
  * [2021](https://www.persevera.com.br/carta-mensal/categories/2021)
  * [2020](https://www.persevera.com.br/carta-mensal/categories/2020)
  * [2019](https://www.persevera.com.br/carta-mensal/categories/2019)
  * [2018](https://www.persevera.com.br/carta-mensal/categories/2018)
  * [Whitepaper](https://www.persevera.com.br/carta-mensal/categories/whitepaper)
  * [2026](https://www.persevera.com.br/carta-mensal/categories/2026)



Buscar

# Entre ciclos

  * Fernando Fontoura
  * 4 de set. de 2025
  * 11 min de leitura



“A taxa de câmbio foi criada por Deus apenas para humilhar os economistas”

**Edmar Bacha**

  


  


#### **Sumário executivo**

  


** _Mercado Global_**

  


  * A sinalização de Powell em Jackson Hole consolidou a expectativa de cortes de juros nos Estados Unidos já em setembro, marcando o início de um novo ciclo de flexibilização monetária e abrindo um ciclo que tende a sustentar ativos de risco globais.

  * O ambiente internacional combina crescimento moderado, inflação sob controle e dólar estruturalmente mais fraco. Esse tripé cria condições favoráveis para a valorização de ativos de risco, especialmente em países emergentes que oferecem diferencial de juros e fundamentos externos mais equilibrados, como o Brasil.

  





**_Mercado Local_**

  


  * O episódio da Lei Magnitsky trouxe forte volatilidade, mas os preços se ajustaram rapidamente. Ainda assim, os riscos institucionais associados permanecem relevantes e podem ressurgir como fonte de estresse.

  * A recente deflação de agosto e a sequência de revisões baixistas nas expectativas de inflação reforçam o processo de desinflação. Esse avanço contrasta com a postura ainda excessivamente restritiva do Banco Central, que mantém juros reais historicamente elevados mesmo diante de câmbio apreciado e atividade em desaceleração.

  





**_Nossas Visões e Posições_**

  


  * Mantemos preferência por prefixados longos na renda fixa e postura cautelosa em crédito privado, diante de spreads comprimidos em emissores de alta qualidade e deterioração em segmentos de maior risco.

  * Seguimos confiantes na apreciação estrutural do real e no pano de fundo de enfraquecimento global do dólar. Também adotamos postura seletiva em renda variável no curto prazo, com menor exposição a ativos domésticos e foco em oportunidades globais.




  


 

  


#### Estados Unidos: A virada de Jackson Hole

  


Tradicionalmente palco de anúncios decisivos de política monetária, Jackson Hole voltou a cumprir esse papel em agosto. Após meses de resistência sistemática às pressões por flexibilização — tanto econômicas quanto políticas, vindas diretamente do presidente Trump —, Jerome Powell finalmente deixou transparecer uma mudança de postura. De forma sutil, mas inequívoca, o chairman do Federal Reserve (Fed) reconheceu que manter os juros em 4,5% diante de uma inflação de 2,5% havia se tornado restritivo demais para a realidade econômica atual.

  


A pressão vinha se acumulando. Os dados mais recentes do mercado de trabalho (payroll) decepcionaram e passaram por revisões significativas para baixo. O mercado de trabalho, que inicialmente parecia robusto, após os ajustes se revelou bem mais enfraquecido — um quadro que inclusive resultou na saída da então chefe do órgão de estatísticas (BLS), sob acusações de manipulação política dos números. Adicionalmente, indicadores de emprego dos ISMs, JOLTS e outros indicadores de alta frequência reforçaram a percepção de enfraquecimento da dinâmica do mercado de trabalho.

  


  


No lado da inflação, apesar de permanecer acima da meta, os indicadores seguem relativamente comportados, mesmo diante das preocupações com repasses inflacionários decorrentes da escalada tarifária. Parte dessas incertezas, no entanto, começou a se dissipar recentemente com avanços nas negociações comerciais. O núcleo do PCE, em linha com expectativas, reforçou a leitura de que há espaço para flexibilização já no curto prazo.

  


Nesse contexto, Powell transmitiu, em essência, a mensagem de que os juros estão altos, a inflação não está tão alta e a atividade está desacelerando gradualmente. Embora simples, essa sinalização representou uma virada importante na comunicação do Fed, ao indicar que a política monetária pode ter se tornado excessivamente restritiva.

  


O mercado reagiu rapidamente. As expectativas já precificam cortes iniciando em setembro com ~90% de probabilidade — não mais como hipótese distante, mas como questão de _quando_  e _quanto_. Entre os dirigentes, o tom foi predominantemente _dovish_  em Jackson Hole, ainda que alguns tenham reforçado a preferência por iniciar o ciclo com passos graduais de 25 pontos-base. Essa reconfiguração cria um ambiente favorável para ativos de risco, sobretudo porque Trump tem mostrado criatividade e determinação em enfraquecer o dólar à medida que os acordos comerciais avançam.

  


Adicionalmente, decisões judiciais recentes vêm limitando e potencialmente postergando parte do impacto pleno das tarifas de Trump, sugerindo que choques mais significativos podem se deslocar para o ano que vem. Isso abre espaço para que o Fed inicie cortes antes que a pressão inflacionária apresente de fato algum impacto mais pronunciado.

  


  


Com isso, essa conjunção de fatores — crescimento moderado, inflação sob controle, perspectiva de juros mais baixos e dólar estruturalmente mais fraco — cria um pano de fundo construtivo para ativos globais e, por extensão, para emergentes como o Brasil.

  


#### Brasil: Teste de estresse superado, por enquanto

  


Enquanto os Estados Unidos abriram espaço para um novo ciclo de flexibilização monetária, o Brasil enfrentou um episódio de forte volatilidade com a escalada da Lei Magnitsky. Trata-se de uma legislação americana que permite a imposição de sanções financeiras contra indivíduos ou instituições acusados de corrupção ou violações de direitos humanos. No caso brasileiro, a aplicação da lei — por hora, focada em Alexandre de Moraes — pode atingir diretamente empresas e bancos que, ao cumprir exigências dos EUA, entraram em rota de colisão com decisões do STF.

  


Esse choque regulatório expôs a dificuldade de conciliar normas internacionais de _compliance_ com determinações da Justiça brasileira. Para o mercado, a questão foi além de um detalhe técnico, pois trouxe à tona o risco de paralisia operacional em instituições financeiras, incertezas sobre a aplicação de sanções e questionamentos sobre a previsibilidade do ambiente regulatório doméstico.

  


O real sofreu pressão imediata e ativos locais — especialmente papéis de bancos públicos — tiveram desempenho abaixo da média. No entanto, o movimento foi rapidamente revertido, com o câmbio voltando a figurar entre os de melhor performance relativa. Essa rápida recuperação, a nosso ver, foi sustentada mais por fluxos estrangeiros e pela atratividade relativa do Brasil no mapa dos emergentes do que por convicção fundamental dos investidores locais.

  


Ainda que o “teste de estresse” tenha sido superado no curto prazo, vemos sinais de complacência do mercado em relação a esses riscos institucionais. Esses choques podem gerar episódios de volatilidade aguda mesmo em um ambiente de fundamentos benignos — inflação em queda, contas externas sob controle e reservas robustas. Em nossa visão, os riscos político-institucionais não desapareceram; permanecem no radar e podem ser reativados a qualquer novo choque de natureza regulatória ou judicial.

  


#### Brasil: Inflação em queda, mas o contraste permanece

  


Em meio à turbulência política e geopolítica, a economia brasileira apresentou sinais relevantes de avanço. A deflação observada no IPCA-15 de agosto — ainda que pontual — representa fenômeno raro e simbólico, especialmente diante de pressões temporárias como a bandeira tarifária vermelha. O resultado reforça a leitura de que o país atravessa um processo consistente de convergência inflacionária. Esse avanço convive, contudo, com um pano de fundo institucional ainda instável, que pode gerar episódios de volatilidade mesmo em meio a fundamentos benignos.

  


O mercado tem reconhecido essa transformação: já são 14 semanas consecutivas de revisões para baixo no Focus. Para 2025, a projeção de inflação caiu de 5,7% no início do ano para 4,8% e as expectativas para os anos seguintes também vêm recuando, ainda que em menor magnitude.

  


  


Paralelamente, o real segue como âncora de confiança. A tendência global de enfraquecimento do dólar nos últimos meses ajudou a conter preços de bens comercializáveis no mercado internacional, atuando como contrapeso à inflação de serviços, que ainda se mantém elevada. Mesmo diante dos ruídos domésticos, a moeda brasileira continuou refletindo fundamentos macroeconômicos sólidos e indicando que os choques recentes não foram suficientes para abalar sua estabilidade estrutural.

  


Ao mesmo tempo, os sinais de que a atividade econômica perde fôlego gradualmente se acumulam. Indicadores de consumo das famílias vêm arrefecendo, assim como dados de produção e confiança empresarial. Com menor impulso fiscal neste ano, a demanda agregada perde parte de sua sustentação, em um cenário marcado pelo aperto monetário e taxas de juros ainda restritivas.

  


Esse pano de fundo evidencia ainda mais o descompasso da política monetária. Enquanto o Fed reconheceu que juros de 4,5% se tornaram excessivos para uma inflação de 2,5%, o Banco Central mantém a Selic em patamar historicamente elevado — resultando em juros reais de dois dígitos. Sem sinalizar cortes no curto prazo, a comunicação do BC endureceu em agosto, adotando tom excessivamente _hawkish_  ao desconsiderar a apreciação cambial como fator estrutural.

  


Com câmbio apreciado, inflação surpreendendo sistematicamente para baixo e expectativas em queda, além de uma desaceleração da atividade em curso, entendemos que há espaço para uma flexibilização mais cedo do que o mercado precifica atualmente. A experiência mostra que autoridades que resistem em excesso acabam, quando mudam de postura, promovendo ajustes mais intensos. Caso o Fed também entre em ciclo de afrouxamento, o Banco Central poderá inclusive acelerar os cortes sem risco de desancorar expectativas.

  


  


Nesse contexto, enxergamos grandes oportunidades na renda fixa prefixada brasileira. As taxas atuais oferecem retorno potencial expressivo caso nossa tese de antecipação de cortes se confirme, e ainda entregam um carrego suficientemente elevado mesmo em cenário conservador.

  


#### Moedas: A resiliência do real

  


Mesmo enfrentando pressões que historicamente resultariam em depreciação significativa — como choques políticos e geopolíticos —, o real manteve trajetória de fortalecimento consistente, superando as expectativas iniciais do mercado.

  


Por décadas, o país foi refém de um modelo que combinava dependência crônica de capital externo com necessidade de juros punitivos para compensar vulnerabilidades, perpetuando volatilidade cambial elevada. Atualmente, contudo, as reservas internacionais permanecem robustas, em torno de US$ 350 bilhões, e a conta corrente, embora deficitária em cerca de 3,5% do PIB em 12 meses, segue administrável. Essa configuração garante maior resiliência externa, reduzindo a necessidade de juros excessivamente elevados como pilar de sustentação cambial.

  


  


Esse pano de fundo se combina com a reconfiguração global do mercado de moedas. Com a dissipação dos riscos tarifários, especuladores voltaram a priorizar o carry trade tradicional. Nesse ambiente, moedas desenvolvidas oferecem pouco ou nenhum diferencial contra o dólar, enquanto emergentes, com juros reais positivos, concentram a atratividade. O Brasil se destaca nesse mapa, oferecendo um dos carregos mais robustos, ao mesmo tempo em que conta com fundamentos que permitem suportar períodos de maior incerteza.

  


  


Naturalmente, o risco central continua sendo o Fed. Caso os cortes de juros nos Estados Unidos se revelem menores ou mais lentos do que o esperado, moedas emergentes poderiam enfrentar fechamento acelerado de posições — esse não é o nosso cenário base, mas reconhecemos que permanece como risco a monitorar de perto. Ainda assim, parte do prêmio de um Fed mais dovish segue não precificado, o que reforça o viés estrutural negativo para o dólar nos próximos meses e sustenta a atratividade relativa do real.

  


Em cenário global de dólar mais fraco e juros internacionais menores, o Brasil se beneficia duplamente: pelos fundamentos próprios melhorados e pelo contexto externo favorável. Essa resiliência estrutural reforça nossa convicção de que o real continuará a atuar como força estabilizadora para os ativos domésticos.

  


 

  


#### **Nossas visões e posições**

  


#####  Renda Fixa

  


A leitura deflacionária do IPCA-15 de agosto marcou um ponto de inflexão e reforçou nosso cenário de normalização dos preços domésticos. As expectativas de inflação caíram por 14 semanas consecutivas, com revisões generalizadas para baixo nas projeções de 2025 e 2026, gradualmente se aproximando da meta de 3%. O resultado chama atenção por ter ocorrido em um mês inteiro sob bandeira vermelha. Essa dinâmica reforça nossa convicção de que há um desalinhamento relevante na precificação dos juros longos.

  


Ainda assim, o Banco Central endureceu ainda mais a comunicação em agosto. Consideramos essa postura excessivamente _hawkish_  e contraproducente ao descartar a apreciação cambial como melhora estrutural. Apesar de já haver grande espaço para cortes de juros, o discurso recente do presidente Gabriel Galípolo sugere que esse movimento pode ficar apenas para o próximo ano, o que tende a prejudicar a performance de títulos de vencimentos mais curtos e beneficiar os mais longos.

  


Atualmente, as taxas de juros reais entre 11% e 11,5% nos parecem insustentáveis no médio prazo. A divergência de orientação entre os bancos centrais — com o Fed sinalizando cortes enquanto o BC permanece ultrarrígido — cria uma janela de oportunidade importante para ativos brasileiros.

  


**Posicionamento** : Mantemos preferência por títulos prefixados mais longos, que devem se beneficiar desse cenário, enquanto permanecemos cautelosos com ativos atrelados ao IPCA e com vencimentos mais curtos. 

  


##### Crédito Privado

  


O mercado de crédito corporativo segue claramente segmentado por risco. No _high grade_  (títulos de alta qualidade de crédito), há estabilidade: o mercado permanece “parado”, com ativos negociando a níveis que já consideramos excessivamente comprimidos. Em contraste, os segmentos fora do _high grade_  mostram deterioração relevante: empresas em situações mais estressadas vêm enfrentando abertura substancial de _spreads_.

  


A Lei Magnitsky tem sido o principal catalisador de estresse no setor bancário, com impacto particular sobre os títulos do Banco do Brasil. As letras financeiras do banco perderam liquidez e passaram a performar pior do que o mercado em geral. Além disso, o atual nível contracionista da Selic tem se mostrado bastante desafiador para emissores de setores tradicionais — como siderurgia, locadoras e petroquímica — que hoje operam com _spreads_  acima do padrão histórico em função de sua deterioração de condições financeiras.

  


Em infraestrutura, seguimos observando fechamento sistemático de _spreads_ , sobretudo nos papéis _high grade_ , com compressão que já nos parece excessiva. Reconhecemos que a relação risco-retorno pode mudar de forma significativa conforme evoluam os desdobramentos tributários, mas o momento atual pede cautela para alocações com prazos longos e que tenham por objetivo capturar apenas compressões adicionais do _spread_  de crédito.

  


**Posicionamento** : Implementamos redução gradual das posições longas, com foco em diminuir a exposição de maneira geral em títulos de maior prazo. Nos desfizemos de ativos que classificamos como _“priced to perfection”_(ou seja, preços que embutem cenário ideal), especialmente ativos _high grade_  de alguns bancos do segmento S1 e S3. Identificamos ainda outras oportunidades — por exemplo, a troca de debêntures da Itaúsa por perpétuas do Itaú —, estratégia que pode ser expandida para outros bancos, não necessariamente com emissores idênticos, mas sim com qualidades de créditos idênticas. A perspectiva de impactos da MP 1.303 sobre tributação acelerou esse processo de encurtamento de _duration_  em nossa visão estratégica, mesmo com os bons ventos para ativos em CDI.

  


##### Moedas

  


Mesmo durante os momentos de maior turbulência institucional, o real mostrou firmeza e não sofreu desvalorização desproporcional. Em nossa visão, a sua tendência permanece inabalável e sem sinais de reversão. No cenário doméstico, os avanços do processo de desinflação, os juros elevados e a percepção de que os choques políticos não escalaram em crise sistêmica contribuíram para a estabilidade do câmbio. Reconhecemos, porém, que episódios de instabilidade política podem gerar ruídos de curto prazo, mesmo sem alterar a tendência estrutural de apreciação.

  


Já no exterior, diversos fatores jogam a favor de um dólar mais fraco: a estratégia comercial de Trump para aumentar a competitividade dos produtos americanos e os sinais de Powell em Jackson Hole de que o ciclo de corte de juros se iniciará muito em breve.

  


**Posicionamento** : Mantemos posição vendida em dólar americano contra o real, sustentados pela tese estrutural de enfraquecimento do dólar. Vemos os movimentos recentes como ajustes técnicos que não alteram a tendência de apreciação do real como importante força estabilizadora. A ausência de volatilidade excessiva durante eventos potencialmente desestabilizadores reforça nossa convicção na robustez da moeda brasileira, embora mantenhamos cautela tática diante da dinâmica global de fortalecimento temporário do dólar.

  


##### Renda Variável

  


A forte recuperação da bolsa brasileira — sustentada pela forte temporada de resultados e pelo posicionamento técnico favorável, e apesar de ruídos episódicos, como declarações do STF e pesquisas eleitorais que geraram volatilidade desproporcional — acabou pesando marginalmente sobre nossa estratégia tática mais defensiva em ativos de risco domésticos. Não nos preocupa: é um desvio compatível com nosso processo de gestão em ambientes de incerteza.

  


Nos mercados globais, a bolsa americana também manteve viés construtivo, sustentada pela expectativa de cortes do Fed e pela resiliência dos lucros corporativos. Observamos ainda uma rotação gradual de _mega caps_  para empresas menores e setores mais descontados. Além disso, notamos uma deterioração significativa nos indicadores técnicos do Bitcoin — uma correção natural após o rali recente. Houve uma forte rotação para outros ativos, como o Ethereum, mas que não afeta nossa convicção estrutural de longo prazo em Bitcoin.

  


**Posicionamento** : Ao longo do mês, adotamos postura seletiva e defensiva em renda variável: reduzimos exposição e priorizamos ativos e setores com fundamentos sólidos e menor sensibilidade a choques macro ou políticos. Seguimos com viés positivo para o médio prazo (6-12 meses), mas muito atentos às turbulências de curto prazo pelas tensões com os Estados Unidos. No exterior, permanecemos comprados em bolsa americana, porém com exposição reduzida. Em Bitcoin, também diminuímos a alocação diante da piora técnica, aguardando sinais mais claros para voltar a aumentar posição.

  


  


#### **Nossos fundos**

  


Para informações completas, consulte os materiais informativos.

  


Equipe Persevera 

 

[_contato@persevera.com.br_](mailto:contato@persevera.com.br)

(11) 4780-3794

  * [2025](https://www.persevera.com.br/carta-mensal/categories/2025)



110

110 visualizações

0

0 comentário

Post não marcado como curtido

## Posts recentes

[Ver tudo](https://www.persevera.com.br/carta-mensal)

[](https://www.persevera.com.br/post/quando-os-juros-mordem-e-o-crédito-grita)

[Quando os juros mordem e o crédito grita](https://www.persevera.com.br/post/quando-os-juros-mordem-e-o-crédito-grita)

123

0 comentário0

Post não marcado como curtido

[](https://www.persevera.com.br/post/a-estrategia-do-caos)

[A estratégia do caos](https://www.persevera.com.br/post/a-estrategia-do-caos)

174

0 comentário0

1 curtida. Post não marcado como curtido1

[](https://www.persevera.com.br/post/quando-os-astros-se-alinham)

[Quando os astros se alinham](https://www.persevera.com.br/post/quando-os-astros-se-alinham)

209

0 comentário0

1 curtida. Post não marcado como curtido1

[Todas as publicações ](https://www.persevera.com.br/carta-mensal)

+55 11 4780-3794 | [contato@persevera.com.br](mailto:contato@persevera.com.br?subject=Contato)

Av. Juscelino Kubistchek, 1455 - 3o Andar

Vila Nova Conceição - 04543-011 -  São Paulo - SP - Brasil

  * [](https://www.facebook.com/pg/perseveraasset/about/)
  * [](https://www.instagram.com/persevera_asset/?hl=pt-br)
  * [](https://www.linkedin.com/company/persevera-asset-management/?viewAsMember=true)
  * [](https://www.youtube.com/channel/UCjo8U7VdUkvZDUGXm1w7M3w?view_as=subscriber)



##### Inscreva-se para receber nossa Carta Trimestral

Seu e-mail foi cadastrado!

Assinar

A Persevera Gestão de Recursos Ltda. (“Persevera”) é uma empresa do grupo Fami Capital e este site tem caráter meramente informativo, não constituindo uma oferta de serviço pela Persevera e nem venda de cotas dos fundos por ela geridos. A Persevera não comercializa e nem distribui cotas de fundos de investimento ou qualquer outro ativo financeiro. Para avaliação da performance de quaisquer fundos de investimentos, é recomendável uma análise de período de, no mínimo, 12 (doze) meses. Fundos de investimento não contam com garantia da Persevera, de qualquer de suas afiliadas, de qualquer mecanismo de seguro ou, ainda, do Fundo Garantidor de Créditos - FGC. Os fundos geridos pela Persevera utilizam estratégias com derivativos como parte integrante de sua política de investimento. Estratégias com derivativos apresentam risco elevado e podem resultar em significativas perdas patrimoniais para seus cotistas. As informações contidas neste website não constituem uma opinião ou recomendação, legal ou de qualquer outra natureza, por parte da Persevera, e não leva em consideração a situação particular de qualquer pessoa. A utilização das informações aqui contidas se dará exclusivamente por conta e risco de seu usuário. Antes de tomar qualquer decisão acerca de seus investimentos, a Persevera recomenda ao interessado que consulte um profissional especializado e também a leitura cuidadosa de prospectos, regulamentos e das lâminas de informações essenciais dos fundos de investimento.

bottom of page
