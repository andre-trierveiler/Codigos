top of page

Ir para o conteúdo principal

Material Informativo

Confira abaixo o material informativo 

referente à Julho/20 do fundo Persevera Compass FIC FIM. 

Acesse sua plataforma de investimentos e comece a investir! 

[](https://www.persevera.com.br/_files/ugd/056676_c77bf06ade654fd3bc4aa8a0d43a208b.pdf)

[](https://www.persevera.com.br)

  * [HOME](https://www.persevera.com.br)

  * [PERSEVERA](https://www.persevera.com.br/persevera)

    * [QUEM SOMOS](https://www.persevera.com.br/persevera)

    * [EQUIPE](https://www.persevera.com.br/persevera)

    * [IMPRENSA](https://www.persevera.com.br/imprensa)

  * [FUNDOS](https://www.persevera.com.br/fundos)

  * [CARTA TRIMESTRAL](https://www.persevera.com.br/carta-mensal)

  * [REGULATÓRIO](https://www.persevera.com.br/regulatório)

    * [TRANSPARÊNCIA INFORMACIONAL](https://www.persevera.com.br/transparencia-informacional)

  * [CONTATO](https://www.persevera.com.br/contato)




PT

EN

  * [Todos posts](https://www.persevera.com.br/carta-mensal)
  * [2025](https://www.persevera.com.br/carta-mensal/categories/2025)
  * [2024](https://www.persevera.com.br/carta-mensal/categories/2024)
  * [2023](https://www.persevera.com.br/carta-mensal/categories/2023)
  * [2022](https://www.persevera.com.br/carta-mensal/categories/2022)
  * [2021](https://www.persevera.com.br/carta-mensal/categories/2021)
  * [2020](https://www.persevera.com.br/carta-mensal/categories/2020)
  * [2019](https://www.persevera.com.br/carta-mensal/categories/2019)
  * [2018](https://www.persevera.com.br/carta-mensal/categories/2018)
  * [Whitepaper](https://www.persevera.com.br/carta-mensal/categories/whitepaper)
  * [2026](https://www.persevera.com.br/carta-mensal/categories/2026)



Buscar

# Quando os juros mordem e o crédito grita

  * Fernando Fontoura
  * 7 de out. de 2025
  * 13 min de leitura



“Ouro é dinheiro. Todo o resto é crédito”

**J.P. Morgan**

  


  


#### **Sumário executivo**

  


** _Mercado Global_**

  


  * O corte de juros de setembro marcou a virada oficial da política monetária americana. A desaceleração do mercado de trabalho mais pronunciada e os sinais de um enfraquecimento gradual da atividade levaram o Federal Reserve (Fed) a adotar um tom mais flexível, cortando juros e abrindo espaço para um novo ciclo global de liquidez sob a ótica tradicional da política monetária.

  * O ouro tem sido um dos principais beneficiários desse reposicionamento. A combinação de cortes de juros, fluxos institucionais recordes e crescente desconfiança em relação às moedas fiduciárias impulsionou o metal a novas máximas históricas, consolidando seu papel como reserva de valor em um sistema de liquidez crescente.

  





**_Mercado Local_**

  


  * O Brasil segue destoando do cenário internacional. A inflação surpreende sistematicamente para baixo, enquanto as expectativas se aproximam do topo da meta, mas a política monetária permanece excessivamente restritiva.

  * A atividade econômica tem perdido tração, e o crédito corporativo e de consumo mostram sinais claros de estresse. Juros reais próximos a 10% e aperto prolongado estão impondo custos crescentes à economia, especialmente sobre empresas alavancadas e famílias mais endividadas.

  





**_Nossas Visões e Posições_**

  


  * Mantemos preferência por prefixados longos na renda fixa e postura cautelosa em crédito privado, diante dos níveis apertados dos _spreads_  e da reavaliação estrutural de risco em curso.

  * Seguimos confiantes na resiliência estrutural do real, que tende a se beneficiar da fraqueza do dólar e do diferencial de juros ainda elevado. Também adotamos postura seletiva em renda variável no curto prazo, com menor exposição a ativos domésticos e foco em oportunidades globais.




  


 

  


#### Estados Unidos: A encruzilhada da política monetária

  


Setembro foi marcado por um ponto de inflexão importante na política monetária americana, com consequências relevantes para a economia global. Após meses de forte pressão de Trump sobre as decisões de política monetária e diante da deterioração mais pronunciada do mercado de trabalho, o Fed finalmente reduziu os juros em 25 pontos-base, retomando o ciclo de cortes que o mercado aguardava há meses.

  


O Fed se encontra em uma encruzilhada. De um lado, os dados de atividade ainda sustentam alguma resiliência, e os indicadores de inflação seguem apenas ligeiramente acima da meta, pressionados por efeitos tarifários. De outro, o mercado de trabalho continua a mostrar sinais de enfraquecimento — e foi justamente nessa dinâmica que o Fed ancorou a decisão de iniciar os cortes.

  


  


Durante boa parte do ano, o discurso oficial sustentou a narrativa de que o mercado de trabalho permanecia “surpreendentemente forte”, mas as evidências mais recentes apontam em direção oposta. As empresas estão demitindo pouco, é verdade, mas praticamente pararam de contratar. Em economias baseadas em serviços, como a americana, a desaceleração do emprego não começa com demissões em massa, e sim com a redução no ritmo de contratações. O número de vagas abertas segue em queda, a taxa de contratação do JOLTS está próxima das mínimas da série e os índices de emprego dos ISMs permanecem em território contracionista. Além disso, revisões recentes nos dados de emprego mostraram que o mercado já estava mais fraco do que parecia, com ajustes significativos para baixo nas leituras anteriores de _payroll_.

  


  


Há também fatores estruturais que acentuam essa tendência. O avanço da automação e da inteligência artificial tem levado empresas a adiar novas contratações, especialmente em setores de menor produtividade, sugerindo que parte da desaceleração do emprego pode ser permanente.

  


Nesse contexto, a decisão do Fed de iniciar os cortes reflete uma resposta inevitável ao enfraquecimento do mercado de trabalho, mais reativa do que preventiva. Com juros reais próximos de 2% e sinais claros de que um dos componentes do seu duplo mandato — o pleno emprego — começa a ceder, a manutenção de uma política excessivamente restritiva representaria risco crescente de erro. O desafio agora é calibrar o ritmo de flexibilização sem reverter os avanços obtidos no combate à inflação.

  


Essa transição tem consequências importantes para os mercados globais. A combinação de atividade moderada, inflação controlada e perspectiva de juros mais baixos nos Estados Unidos marca o início de um ciclo importante de liquidez global. Embora o processo seja gradual e sujeito a volatilidade de curto prazo, a tendência estrutural é de enfraquecimento do dólar, criando um pano de fundo mais construtivo para ativos de risco — especialmente em economias emergentes com fundamentos sólidos e diferencial de juros elevado, como o Brasil.

  


Nesse contexto de juros mais baixos e dólar estruturalmente mais fraco, os reflexos se manifestam de forma direta no mercado de ativos reais — em especial, no ouro, que voltou a ocupar papel central na reconfiguração dos portfólios globais.

  


#### Commodities: Uma oportunidade de ouro

  


O ouro vive um momento excepcional em 2025 e continuou atingindo novas máximas em setembro. Vemos o atual movimento do metal como a convergência de forças importantes: a mudança de postura do Fed, o enfraquecimento estrutural do dólar, o aumento de fluxos institucionais e a percepção crescente de que o sistema de moedas fiduciárias atravessa um processo de erosão de valor.

  


A primeira força motriz é o reposicionamento global de portfólios diante da transição do ciclo monetário. A mudança de postura do Fed — e a expectativa de cortes adicionais de juros — ocorre em um contexto de dólar estruturalmente mais fraco e juros reais em queda, impulsionando a busca por ativos reais. O ouro volta a cumprir duplo papel: proteção contra a perda de poder de compra das moedas fiduciárias e alternativa de reserva de valor em um mundo de endividamento crescente.

  


Essa percepção está intimamente ligada ao ambiente fiscal e monetário global. A combinação de déficits recorrentes, endividamento crescente e expansão permanente da base monetária reforça a percepção de que a desvalorização gradual das moedas é uma característica estrutural do sistema. O _“debasement”_  das moedas — a erosão lenta do seu poder de compra — tornou-se um fenômeno recorrente em economias avançadas, reacendendo o apelo do ouro como ativo independente da confiança em políticas públicas ou autoridades monetárias.

  


O reposicionamento dos portfólios tem se refletido em fluxos robustos para a commodity. O maior ETF de ouro do mundo (GLD) registrou entradas líquidas superiores a US$ 2 bilhões apenas em setembro e mais de US$ 13 bilhões no acumulado do ano — o maior volume desde 2020. Fundos sistemáticos (CTAs) também vêm retomando exposição, reforçando a tendência técnica do ativo. Além disso, bancos centrais de países emergentes seguem ampliando suas reservas em ouro, movimento que adiciona uma camada estrutural de demanda em meio à diversificação global de reservas.

  


  


Em nossa leitura, o movimento atual é menos um ciclo especulativo e mais uma reprecificação estrutural do papel do ouro no sistema financeiro global. À medida que a credibilidade fiscal e monetária se deteriora, o metal retoma sua função clássica de reserva de valor — um ativo escasso, sem passivo correspondente e imune às decisões discricionárias de política econômica. Por isso, ampliamos nossa exposição ao ouro e a mineradoras de ouro, combinando proteção estrutural e potencial de valorização em um ambiente de liquidez crescente e confiança monetária em declínio.

  


#### Brasil: O cenário que o BC ignora

  


O mês de setembro trouxe uma sequência impressionante de surpresas positivas no front inflacionário brasileiro. As leituras de IPCA e IPCA-15 vieram consistentemente abaixo das expectativas em um período que, sazonalmente, tende a registrar números mais elevados. E não foi apenas o _headline_  que surpreendeu — a qualidade do dado foi excepcional, com o recuo dos núcleos e da inflação de serviços. Raramente todos os componentes favoráveis se manifestam de forma tão sincronizada.

  


Esse movimento vem sendo acompanhado por sucessivas revisões baixistas nas expectativas de inflação (Boletim Focus). As projeções para 2025 e 2026 convergem gradualmente para o topo da meta de 4,5%, enquanto as inflações implícitas recuaram de níveis próximos a 7,5% para algo em torno de 5%. O ambiente inflacionário benigno é, portanto, uma realidade.

  


  


Vários fatores contribuem para esse processo de desinflação. A atividade doméstica começou a mostrar alguns sinais de moderação; os alimentos registraram quedas relevantes de preços diante de oferta abundante, em parte associada a dificuldades de exportação; e a apreciação do câmbio ajudou a conter preços de comercializáveis. A perspectiva de queda nas taxas de juros americanas ainda em 2025 sugere ainda um pano de fundo global de dólar estruturalmente ainda mais fraco, o que amplia o espaço para desinflação via câmbio no Brasil. Não vemos esse movimento como uma destruição severa de demanda, mas como uma moderação controlada do ciclo.

  


  


Apesar da convergência inflacionária, a Selic permanece em 15%, implicando juros reais próximos de 10%. A comunicação segue excessivamente dura, com a sinalização de que os juros serão mantidos em patamar restritivo por um “período bastante prolongado”. Além disso, a apreciação cambial foi descartada pela autoridade como fator estrutural de desinflação, tratada como fenômeno temporário sem relevância para as decisões de política monetária.

  


Essa postura já se reflete na precificação de mercado, que não incorpora cortes adicionais em 2025. O cenário dominante é de manutenção prolongada da Selic, com flexibilização apenas a partir de 2026. Isso reforça o desalinhamento entre a evolução da inflação — que converge gradualmente para o topo da meta — e a política monetária, que permanece disfuncionalmente restritiva.

  


O que nos preocupa particularmente é a desconexão entre Brasil e o resto do mundo. Lá fora, o cenário se desenha em duas possibilidades relativamente benignas: ou a economia permite cortes adicionais de juros, ou já cortamos o suficiente e agora aguardamos para observar os efeitos. Em ambos os cenários, estamos falando de ambientes onde a política monetária está em modo de normalização ou pausa em níveis razoáveis. O Brasil, em contraste absoluto, mantém juros estratosféricos e segue elevando-os, mesmo diante de um cenário inflacionário que tem se mostrado mais benigno e com câmbio relativamente controlado. Essa divergência fundamental cria uma dinâmica particularmente desafiadora para nossos ativos.

  


#### Brasil: Quando os juros mordem…

  


As evidências de que os juros estão altos demais se acumulam. Doze meses após o início do ciclo de aperto, os efeitos da política monetária começaram a se materializar e devem se intensificar nos próximos meses. O PIB do terceiro trimestre deve ter ficado praticamente estável em relação ao segundo, enquanto indicadores antecedentes como o IBC-Br e as vendas do varejo seguem frustrando expectativas. A economia brasileira já parece operar com o “freio de mão puxado”.

  


O canal de crédito ilustra bem essas restrições. As concessões diminuem, a composição das operações migra para prazos mais curtos e emergenciais, e há sinais claros de que o consumidor atingiu o limite de endividamento. Os resultados trimestrais dos principais bancos apontam para um "fechamento de torneiras", sobretudo para pequenas e médias empresas e famílias de baixa renda. Até mesmo o setor imobiliário, tradicionalmente protegido por financiamentos longos, começa a dar sinais de pressão. O serviço da dívida consome parcela crescente da renda de famílias e empresas, estrangulando balanços e limitando qualquer impulso de crescimento.

  


  


O impacto mais visível dessa restrição é sentido no mercado de crédito, onde o encarecimento do capital e a escassez de liquidez começam a se refletir em deterioração de balanços corporativos. Casos recentes de estresse corporativo envolvendo grandes empresas, como Braskem e Ambipar, ilustram esse ambiente: em um contexto de política monetária excessivamente restritiva, balanços fragilizados e custo de dívida punitivo se transformam rapidamente em crises localizadas, contaminando a percepção de risco de forma desproporcional.

  


#### Brasil: … e o crédito grita

  


Os eventos envolvendo grandes empresas com grau de investimento há alguns meses foram apenas o ponto de partida de um processo mais amplo de reprecificação no mercado de crédito. O que se observa hoje não é ainda uma abertura generalizada de _spreads_ , mas sim um aumento perceptível de desconforto nas pontas mais longas e em emissores de menor liquidez. A percepção de risco piorou sensivelmente nas últimas semanas, impulsionada por episódios corporativos recentes — como os casos de Braskem e Ambipar — e por preocupações macroeconômicas mais amplas. Embora os níveis médios de _spread_  permaneçam historicamente baixos, sustentados pelos juros elevados e pelo fluxo contínuo para fundos de renda fixa, o sentimento de risco se deteriorou e o mercado começa a se preparar para uma fase de reavaliação mais seletiva.

  


A dinâmica segue um padrão conhecido do mercado brasileiro: em momentos de incerteza, os ativos mais líquidos — tipicamente de melhor qualidade — são vendidos primeiro. Isso provoca a abertura dos _spreads_  de papéis AAA, enquanto créditos mais arriscados, por serem menos negociados, demoram a refletir plenamente a deterioração. O resultado é um processo desordenado que penaliza inclusive emissores de primeira linha.

  


Essa fragilidade se torna ainda mais clara quando comparada ao ambiente externo. Enquanto os mercados globais vivem um ciclo construtivo para _high grade_  e _high yield_  de qualidade — com empresas emitindo dívidas longas a custos historicamente baixos —, o Brasil caminha na contramão, enfrentando deterioração mesmo em seus créditos de melhor perfil. Essa descorrelação ressalta a natureza doméstica do problema: não é o mundo que pressiona, mas sim nossas próprias condições estruturais.

  


Embora a atenção esteja concentrada no crédito corporativo e bancário, dificilmente os incentivados escaparão. A base de investidores distinta pode retardar o movimento, mas a lógica de contágio em momentos de estresse é inevitável, e a tendência é de um realinhamento gradual também nesse segmento.

  


Nos últimos anos, o ambiente de _spreads_  comprimidos — alimentado pela busca por rendimento em um contexto de juros reais elevados — levou muitos investidores a aceitar riscos desproporcionais. Agora, com a reversão do ciclo e a materialização de perdas em casos emblemáticos, o ajuste de preços ocorre de forma abrupta, penalizando não apenas emissores mais fragilizados, como contaminando o sentimento de mercado como um todo.

Em nossa avaliação, este é apenas o início de um ciclo mais amplo de correção. Nos últimos anos, o mercado de crédito no Brasil foi guiado especialmente por fluxo, e não pelos fundamentos, onde os investidores compravam crédito essencialmente como "_proxy_  de CDI", buscando rentabilidade indexada à taxa básica com um pequeno prêmio. Foi um movimento de fluxo puro para os fundos, sem a análise rigorosa de valor relativo que caracteriza mercados mais maduros — por exemplo, em comparação à renda variável, com as ações excessivamente baratas. Com a reversão desse fluxo e o ajuste dos _spreads_ , a fragilidade do modelo se torna mais clara.

  


Nesse ambiente, reforçamos nossa postura defensiva e seletiva em relação à crédito. Não vemos uma crise de liquidez plena, mas sim uma reavaliação estrutural de risco. Nesse processo, prudência é a condição essencial para preservar capital e capturar oportunidades quando o mercado reencontrar equilíbrio.

  


 

  


#### **Nossas visões e posições**

  


#####  Renda Fixa

  


A dinâmica inflacionária de setembro reforçou nossa convicção de que há desalinhamento na precificação dos juros longos. A composição favorável do IPCA-15, combinada com a queda nas expectativas do Focus e a redução da inflação implícita, vai nessa direção. Apesar disso, o Banco Central endureceu o discurso, em nossa visão. A ata do Copom trouxe tom ligeiramente mais brando, mas a projeção de inflação em 3,4% no horizonte relevante — em contraste à expectativa do mercado de 3,2-3,3% — e a mensagem de juros elevados “por período bastante prolongado” praticamente eliminaram apostas de cortes em 2025.

  


Atualmente, as taxas de juros reais em dois dígitos nos parecem insustentáveis no médio prazo. O mercado precifica cortes concentrados entre a metade de 2026 e meados de 2027, período pós-eleitoral. Essa discrepância em relação ao Fed — que já iniciou cortes — abre uma janela de oportunidade relevante para ativos brasileiros.

  


**Posicionamento** : Mantemos forte preferência por títulos prefixados longos, que devem se beneficiar da convergência inflacionária e de eventual flexibilização monetária. Seguimos cautelosos com NTN-Bs, onde reduzimos substancialmente a exposição, enxergando que ainda vão demorar alguns meses para performarem bem.

  


##### Crédito Privado

  


O cenário corporativo apresentou sinais crescentes de stress ao longo de setembro, refletindo os efeitos prolongados da Selic em patamar restritivo. Grandes empresas que possuíam ratings AAA há alguns meses, como Braskem e Cosan, precisaram buscar reestruturações financeiras, enquanto o grupo Simpar enfrentou custos de funding significativamente elevados mesmo em operações tradicionalmente saudáveis. Esses casos ilustram como a pressão dos juros já atinge companhias tradicionalmente vistas como de risco muito baixo no mercado de crédito.

  


No setor bancário, houve deterioração relevante no crédito ao consumidor: as instituições reportaram aumento de operações de curto prazo emergencial em paralelo à queda dos financiamentos de longo prazo, uma dinâmica típica de restrição da capacidade de pagamento das famílias.

  


Em meio a esse ambiente, os _spreads_  das debêntures incentivadas AAA recuaram ainda mais, renovando mínimas históricas. As discussões em torno da MP 1303/25 e a proximidade do prazo de aprovação (8 de outubro) têm adicionado incertezas regulatórias significativas, com alta probabilidade de rejeição criando volatilidade adicional no segmento. Acreditamos que a atual configuração da proposta pode distorcer alocações de capital e prejudicar desenvolvimento do mercado de capitais doméstico.

  


**Posicionamento** : Implementamos redução substancial de exposição e _duration_  de _spreads_  de crédito ao longo do mês, acelerada pela incerteza regulatória em torno da MP 1303. Também temos reduzido sistematicamente posições bancárias. Mantemos a filosofia de cristalizar ganhos e priorizar segurança em detrimento de _carry_ , sobretudo diante da elevação dos riscos corporativos. Em linhas gerais, seguimos favorecendo posições defensivas, mantendo foco em ativos de qualidade e vencimentos mais curtos, enquanto aguardamos maior clareza sobre o ambiente macro e regulatório.

  


##### Moedas

  


O real manteve forte resiliência em setembro, superando a maioria dos emergentes no período, mesmo diante de ruídos políticos internos e da escalada das sanções Magnitsky. Importante destacar que os movimentos cambiais de valorização do dólar foram amplamente sincronizados com outras moedas emergentes, refletindo sobretudo a dinâmica global de um dólar temporariamente fortalecido, mais do que fatores idiossincráticos domésticos.

  


No plano político, a sinalização de Trump de possível negociação com o governo brasileiro ajudou a reduzir percepção de risco-país, favorecendo o real na margem. Do lado da política monetária, o Banco Central optou por não rolar parte dos _swaps_  cambiais que venceriam, sinalizando confiança na capacidade de autoajuste do mercado. Além disso, fundos sistemáticos internacionais ampliaram posições compradas em real, oferecendo suporte técnico adicional.

  


Os fundamentos domésticos seguem favoráveis: diferencial de juros elevado, bom crescimento econômico, convergência inflacionária e um balanço de pagamentos relativamente sólido. Esses fatores continuam sustentando a tese de fortalecimento relativo da moeda brasileira.

  


**Posicionamento** : Mantemos posição vendida em dólar contra o real, ainda que em magnitude reduzida, sustentados pela tese estrutural de enfraquecimento do dólar no médio prazo. A tendência de apreciação do real permanece intacta, apoiada em fundamentos sólidos e fluxos externos construtivos. Reduzimos parcialmente a exposição diante da volatilidade recente e do fortalecimento tático do dólar, mas sem alteração de nossa convicção de longo prazo sobre a moeda brasileira.

  


##### Renda Variável

  


A bolsa brasileira apresentou dinâmica peculiar em setembro, com a alta concentrada em ações de menor qualidade e fundamentos frágeis. Interpretamos esse movimento como um sinal de “fim de festa” especulativo de curto prazo, já que foi impulsionado principalmente pela cobertura de posições vendidas e pelo fluxo de investidores pessoa física em papéis de baixa liquidez. Pesquisas de sentimento também mostram níveis de otimismo extremos entre gestores, com caixa próximo de mínimas históricas. Essa combinação de posicionamento excessivo e liderança de ativos de qualidade deteriorada reforçou nossa decisão de adotar uma postura mais cautelosa na classe no curto prazo.

  


Já o Bitcoin seguiu em tendência de fraqueza desde julho, com deterioração de indicadores técnicos e queda no volume negociado. Ainda que a política monetária global sinalize flexibilização adiante, nossos indicadores de condições técnicas de mercado sugerem que o sistema financeiro internacional ainda atravessa uma fase transitória de menor liquidez no curto prazo, o que reforçou nossa decisão de reduzir exposição até que surjam sinais mais claros de estabilização.

  


**Posicionamento** : Mantivemos postura defensiva em renda variável, reduzindo exposição e priorizando empresas de maior qualidade em detrimento de apostas mais especulativas. Em Bitcoin, reduzimos taticamente a alocação diante da deterioração técnica e das preocupações com liquidez global. Em contrapartida, ampliamos exposições em ouro e mineradoras, além de diversificação em outras commodities como prata e lítio, que oferecem proteção adicional em um ambiente de incerteza. No mercado internacional, retomamos nossa exposição à bolsa chinesa e permanecemos defensivos em bolsa americana, atentos à evolução da liquidez global e ao posicionamento dos investidores.

  


  


#### **Nossos fundos**

  


Para informações completas, consulte os materiais informativos.

  


Equipe Persevera 

 

[_contato@persevera.com.br_](mailto:contato@persevera.com.br)

(11) 4780-3794

  * [2025](https://www.persevera.com.br/carta-mensal/categories/2025)



122

122 visualizações

0

0 comentário

Post não marcado como curtido

## Posts recentes

[Ver tudo](https://www.persevera.com.br/carta-mensal)

[](https://www.persevera.com.br/post/entre-ciclos)

[Entre ciclos](https://www.persevera.com.br/post/entre-ciclos)

107

0 comentário0

Post não marcado como curtido

[](https://www.persevera.com.br/post/a-estrategia-do-caos)

[A estratégia do caos](https://www.persevera.com.br/post/a-estrategia-do-caos)

172

0 comentário0

1 curtida. Post não marcado como curtido1

[](https://www.persevera.com.br/post/quando-os-astros-se-alinham)

[Quando os astros se alinham](https://www.persevera.com.br/post/quando-os-astros-se-alinham)

207

0 comentário0

1 curtida. Post não marcado como curtido1

[Todas as publicações ](https://www.persevera.com.br/carta-mensal)

+55 11 4780-3794 | [contato@persevera.com.br](mailto:contato@persevera.com.br?subject=Contato)

Av. Juscelino Kubistchek, 1455 - 3o Andar

Vila Nova Conceição - 04543-011 -  São Paulo - SP - Brasil

  * [](https://www.facebook.com/pg/perseveraasset/about/)
  * [](https://www.instagram.com/persevera_asset/?hl=pt-br)
  * [](https://www.linkedin.com/company/persevera-asset-management/?viewAsMember=true)
  * [](https://www.youtube.com/channel/UCjo8U7VdUkvZDUGXm1w7M3w?view_as=subscriber)



##### Inscreva-se para receber nossa Carta Trimestral

Seu e-mail foi cadastrado!

Assinar

A Persevera Gestão de Recursos Ltda. (“Persevera”) é uma empresa do grupo Fami Capital e este site tem caráter meramente informativo, não constituindo uma oferta de serviço pela Persevera e nem venda de cotas dos fundos por ela geridos. A Persevera não comercializa e nem distribui cotas de fundos de investimento ou qualquer outro ativo financeiro. Para avaliação da performance de quaisquer fundos de investimentos, é recomendável uma análise de período de, no mínimo, 12 (doze) meses. Fundos de investimento não contam com garantia da Persevera, de qualquer de suas afiliadas, de qualquer mecanismo de seguro ou, ainda, do Fundo Garantidor de Créditos - FGC. Os fundos geridos pela Persevera utilizam estratégias com derivativos como parte integrante de sua política de investimento. Estratégias com derivativos apresentam risco elevado e podem resultar em significativas perdas patrimoniais para seus cotistas. As informações contidas neste website não constituem uma opinião ou recomendação, legal ou de qualquer outra natureza, por parte da Persevera, e não leva em consideração a situação particular de qualquer pessoa. A utilização das informações aqui contidas se dará exclusivamente por conta e risco de seu usuário. Antes de tomar qualquer decisão acerca de seus investimentos, a Persevera recomenda ao interessado que consulte um profissional especializado e também a leitura cuidadosa de prospectos, regulamentos e das lâminas de informações essenciais dos fundos de investimento.

bottom of page
