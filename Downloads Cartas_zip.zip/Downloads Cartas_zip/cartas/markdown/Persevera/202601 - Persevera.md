top of page

Ir para o conteúdo principal

Material Informativo

Confira abaixo o material informativo 

referente à Julho/20 do fundo Persevera Compass FIC FIM. 

Acesse sua plataforma de investimentos e comece a investir! 

[](https://www.persevera.com.br/_files/ugd/056676_c77bf06ade654fd3bc4aa8a0d43a208b.pdf)

[](https://www.persevera.com.br)

  * [HOME](https://www.persevera.com.br)

  * [PERSEVERA](https://www.persevera.com.br/persevera)

    * [QUEM SOMOS](https://www.persevera.com.br/persevera)

    * [EQUIPE](https://www.persevera.com.br/persevera)

    * [IMPRENSA](https://www.persevera.com.br/imprensa)

  * [FUNDOS](https://www.persevera.com.br/fundos)

  * [CARTA TRIMESTRAL](https://www.persevera.com.br/carta-mensal)

  * [REGULATÓRIO](https://www.persevera.com.br/regulatório)

    * [TRANSPARÊNCIA INFORMACIONAL](https://www.persevera.com.br/transparencia-informacional)

  * [CONTATO](https://www.persevera.com.br/contato)




PT

EN

  * [Todos posts](https://www.persevera.com.br/carta-mensal)
  * [2025](https://www.persevera.com.br/carta-mensal/categories/2025)
  * [2024](https://www.persevera.com.br/carta-mensal/categories/2024)
  * [2023](https://www.persevera.com.br/carta-mensal/categories/2023)
  * [2022](https://www.persevera.com.br/carta-mensal/categories/2022)
  * [2021](https://www.persevera.com.br/carta-mensal/categories/2021)
  * [2020](https://www.persevera.com.br/carta-mensal/categories/2020)
  * [2019](https://www.persevera.com.br/carta-mensal/categories/2019)
  * [2018](https://www.persevera.com.br/carta-mensal/categories/2018)
  * [Whitepaper](https://www.persevera.com.br/carta-mensal/categories/whitepaper)
  * [2026](https://www.persevera.com.br/carta-mensal/categories/2026)



Buscar

# Quando os astros se alinham

  * Fernando Fontoura
  * 7 de jul. de 2025
  * 10 min de leitura



“O melhor momento para plantar uma árvore foi há 20 anos. O segundo melhor momento é agora”

**Provérbio Chinês**

  


#### **Sumário executivo**

  


** _Mercado Global_**

  


  * A "Guerra dos 12 Dias" entre EUA e Irã terminou com cessar-fogo rápido, demonstrando eficácia da estratégia americana de "força desproporcional" e reafirmando o papel estabilizador dos EUA. Este desfecho reduziu os riscos econômicos e geopolíticos e contribuiu para a compressão dos prêmios de risco globais.

  * O Fed enfrenta pressões políticas crescentes de Trump por cortes agressivos, enquanto dados econômicos parecem justificar flexibilização. Combinação de inflação estabilizada e pressão política pode acelerar antecipação do ciclo de cortes, favorecendo ativos de risco globalmente.

  





**_Mercado Local_**

  


  * No Brasil, a Selic subiu para 15% (maior patamar desde 2006) enquanto IPCA e IGP-M surpreenderam para baixo, levando à revisão das expectativas inflacionárias. A valorização cambial tem reforçado essa dinâmica deflacionária.

  * Cenário político se deteriorou após a derrubada do IOF pelo Congresso, eliminando R$ 20 bilhões de arrecadação. Esse cenário piora as chances de recuperação da situação negativa de Lula, cuja popularidade de Lula despencou para 24%. Essa fragilidade do governo segue alimentando expectativas de mudança política em 2026.

  





**_Nossas Visões e Posições_**

  


  * Em renda fixa, mantemos aplicação em juros nominais brasileiros concentrada em vértices médios e longos, além de posições em títulos longos atrelados à inflação. No exterior, encerramos nossa posição tomada em juros americanos.

  * Seguimos com alta exposição em bolsa brasileira e diversificados internacionalmente, com posições em mercados emergentes e bolsa americana. Mantemos convicção no real versus dólar e posição em Bitcoin como proteção contra incertezas monetárias.




  


 

  


#### Estados Unidos: Força desproporcional e nova estabilidade global

  


Em junho, o cenário geopolítico dominou as atenções com a escalada militar entre Estados Unidos e Irã, culminando em bombardeios americanos às instalações nucleares iranianas. O conflito, porém, teve desfecho surpreendentemente rápido. O presidente Trump declarou um cessar-fogo entre Israel e o Irã após apenas 12 dias, demonstrando a eficácia da estratégia americana de "demonstração desproporcional de força" no que seu governo chamou de "Guerra dos 12 Dias".

  


A operação americana no Irã estabeleceu um novo paradigma de guerra moderna, contrastando drasticamente com os conflitos prolongados que marcaram as últimas décadas. Ao mesmo tempo, os Estados Unidos deram claros sinais de que não abandonaram seu papel de potência estabilizadora. A rápida e contundente ação no Irã reafirmou o compromisso americano com a ordem internacional vigente e com seus aliados estratégicos.

  


Esta capitulação rápida não apenas validou a eficácia da estratégia de força desproporcional, como também sinalizou aos mercados globais que a nova gestão americana possui capacidade real de conter escaladas antes que se transformem em crises sistêmicas. Esse novo equilíbrio pode levar, possivelmente, a uma compressão nos prêmios de risco globais.

  


Enquanto os riscos geopolíticos foram efetivamente gerenciados, os Estados Unidos permanecem emaranhados em disputas comerciais - especialmente com a China - que ainda seguem não solucionadas. Estas guerras comerciais introduzem um tipo diferente de incerteza: não o risco de conflito militar, mas sim pressões inflacionárias graduais e persistentes que podem complicar a gestão da política monetária americana.

  


Os índices de preços pagos das pesquisas do NY Fed revelam que, embora os respondentes reportem desaceleração nos aumentos de preços de insumos, os níveis absolutos permanecem elevados. No entanto, vemos um contraste com os dados de inflação corrente. Enquanto as pesquisas de sentimento e expectativas indicam pressões de custos persistentes, os dados concretos - como o índice PCE, que serve de meta para o Federal Reserve (Fed) - continuam se segurando muito bem. Esta divergência entre percepções e realidade cria um ambiente ainda mais complexo para a formulação de política monetária.

  


Fonte: Empire State Manufacturing Survey e U.S. Bureau of Economic Analysis

  


A combinação de estabilidade geopolítica e tensões comerciais controladas tem impulsionado ativos de risco americanos enquanto acelera a depreciação do dólar - dinâmica que, como comentamos em nossa carta anterior, beneficia significativamente as maiores empresas do S&P 500.

  


  


Se nem conflitos diretos no Oriente Médio nem guerras comerciais conseguiram derrubar os mercados americanos, isso sugere que o ambiente atual é sustentado por fundamentos macroeconômicos sólidos e uma evolução positiva das políticas, não apenas por busca temporária de segurança.

  


#### Estados Unidos: O Fed em uma encruzilhada

  


Com a estabilidade geopolítica estabelecida, a atenção se volta para a política monetária americana, onde fundamentos econômicos se misturam com pressões políticas. Esta combinação está criando condições para flexibilização monetária que vai além de considerações puramente técnicas.

  


Em junho, os indicadores econômicos não ofereceram nenhuma interrupção em nossa visão positiva para a economia americana. O mercado de trabalho continua resiliente e sem grandes sinais de alerta. O acúmulo de mão de obra persiste, a restrição à imigração segue apertando a oferta de mão de obra e os fortes balanços das famílias continuam a amortecer a volatilidade cíclica, adicionando mais confiança à nossa visão de _soft landing_. Além disso, as revisões nas projeções econômicas trouxeram a combinação ideal: estimativas de crescimento melhorando na margem enquanto expectativas inflacionárias foram consistentemente revisadas para baixo.

  


  


Já na política monetária, o Fed tem se mostrado mais cauteloso que os dados justificam. Apesar de orientar cortes futuros, a instituição reduziu projeções de crescimento e elevou estimativas para a taxa neutra de juros, sinalizando que a inflação carrega mais peso em suas decisões. Segundo essas projeções, o Fed não espera atingir sua meta de inflação de 2% nos próximos anos. Ao longo do mês, esta postura _"wait and see"_ contrasta com alguns membros que demonstram maior abertura para flexibilização, argumentando que juros deveriam ser cortados antes que o mercado de trabalho "afunde".

  


A pressão política intensificou este debate. Trump tem demandado explicitamente taxas entre 1-2% - versus atuais 4,5% - e chegou a ameaçar antecipação do anúncio sobre a presidência da instituição. Em diversas ocasiões, a solicitar publicamente a renúncia de Powell, presidente do Fed. Esta não é retórica comum, mas uma tentativa de influenciar as decisões de política monetária por uma administração que já demonstrou disposição para desafiar instituições tradicionais quando necessário.

  


Apesar das pressões de Trump, não esperamos que Powell seja destituído até o fim do seu mandato. Ainda sim, acreditamos que essa combinação de fatores - inflação estabilizada, membros do Fed sinalizando interesse no início de ciclo de cortes e pressões políticas de Trump - poderão contribuir para a aceleração do ciclo de cortes de juros nos Estados Unidos.

  


Atualmente, o mercado já precifica entre 2-3 cortes ainda em 2025, enquanto o _"Powell replacement trade"_  ganha força, apostando que qualquer sucessor iniciará imediatamente ciclo mais agressivo de cortes. O _spread_  dos rendimentos dos títulos com vencimento em junho e março de 2026 (período quando haverá a troca de presidentes do Fed) mostra que o mercado já está começando a apostar que, seja quem for que assumir o Fed, vai imediatamente começar a cortar a taxa de juros.

  


  


Esta configuração - fundamentos que justificam flexibilização combinados com pressão política explícita - está criando ambiente excepcionalmente favorável para ativos de risco globais. Por isso, encerramos nossa posição tomada em juros americanos, em vista da possibilidade de antecipação do ciclo de cortes, e diversificamos nossa exposição em _equities_ internacional com posições compradas em índices de mercados emergentes, bolsa americana e índices _value_  e _growth._

  


####  Brasil: O tripé brasileiro

  


Nossa convicção em ativos brasileiros fundamenta-se em um "tripé" que avançou ao longo do mês: ambiente de dólar globalmente mais fraco, ciclo de cortes de juros domésticos e antecipação da mudança política em 2026. Os eventos de junho fortaleceram simultaneamente esses três pilares, criando uma configuração que raramente observamos na economia brasileira e que se beneficia diretamente das dinâmicas americanas descritas anteriormente.

  


O primeiro pilar - dólar globalmente mais fraco - está se consolidando através da combinação de estabilidade geopolítica americana, expectativas de cortes de juros e interesse do próprio governo na desvalorização da moeda. Esta tendência beneficia diretamente o real, que permanece comportado e mais forte, ajudado pelo ingresso de fluxos estrangeiros atraídos pelos juros altos. A moeda demonstra comportamento estruturalmente diferente, perdendo sua característica histórica de sofrer desproporcionalmente durante crises externas.

  


O segundo pilar se encontra sustentação na dinâmica inflacionária doméstica, que tem mostrado sinais de arrefecimento constante e melhor que o esperado. O IGP-M registrou deflação de 1,67%, com acumulado em 12 meses recuando dramaticamente de 7% para 4,30% em apenas duas leituras. Paralelamente, o IPCA-15 de junho surpreendeu para baixo, seguindo trajetória positiva dos dois meses anteriores. Até a inflação de serviços - que continua sendo o principal risco - mostrou alívio.

  


Esta moderação, amplificada pela apreciação do real, está gerando o ciclo virtuoso que antecipávamos: inflação mais baixa em 2025 criando menor inércia para 2026. O mercado tem revisado consistentemente para baixo suas estimativas, movimento que deverá contribuir para o futuro ciclo de cortes.

  


  


Em nossa visão, vivemos em um cenário econômico inédito: PIB crescendo consistentemente com inflação sob controle e real se valorizando simultaneamente. O mercado de trabalho continua criando empregos de forma robusta, enquanto a arrecadação federal permanece sólida.

  


Na política monetária, o Banco Central elevou a Selic mais uma vez para 15% - o maior patamar desde 2006 - e sinalizou manutenção por "período muito prolongado". Esta política monetária entrega juros reais em níveis extraordinariamente elevados, configuração que consideramos insustentável no médio prazo. Apesar do tom _hawkish_ da decisão, o BC reconheceu acertadamente a melhora no ambiente externo, como a reversão das tarifas, e a melhora nos dados de inflação e nas expectativas do Focus. Esse cenário benigno de dólar e inflação sob controle oferece sustentação técnica e política para cortes entre o final desse ano e o início de 2026, embora ainda exista razoável incerteza quanto à data de início destes.

  


O terceiro pilar - mudança política - ganhou _momentum_  decisivo. Junho trouxe a derrubada inesperada do IOF pelo Congresso, eliminando R$ 20 bilhões de arrecadação justamente quando Lula enfrenta deterioração crítica de popularidade. A aprovação despencou para 24%, de acordo com as últimas pesquisas eleitorais, enquanto candidatos de oposição tem ganhado força. Vemos este nível como crítico para o potencial candidato de 2026, considerando que está significativamente distante do mínimo histórico necessário de 35-40% para eleição. Esta fragilidade política alimenta diretamente nosso terceiro pilar.

  


Fonte: UBS

  


Esta convergência de fatores cria ambiente excepcionalmente favorável para ativos brasileiros. A combinação de inflação convergindo para meta, economia crescendo sustentadamente, fim da política monetária excessivamente restritiva e cenário político abrindo espaço para mudanças estruturais representa uma configuração rara na história econômica nacional. Permanecemos aplicados em juros, vendidos em dólar versus real e com alta exposição em bolsa brasileira, acreditando que essas posições capturarão a materialização deste tripé.

  


 

  


#### **Nossas visões e posições**

  


#####  Renda Fixa

  


Nossa convicção em renda fixa fundamenta-se no que chamamos de "tripé da tese para Brasil": ambiente de dólar globalmente mais fraco, início do ciclo de cortes de juros domésticos e antecipação da mudança política no horizonte de 2026. O atual cenário de juros atingiu configuração que consideramos insustentável no médio prazo, com juro real de 10,5% - patamar desnecessariamente alto, em nossa visão.

  


A dinâmica inflacionária atual reforça nossa tese. Após o soluço inflacionário que assustou o mercado, o IGP-M registrou deflação espetacular e o IPCA vem surpreendendo para baixo nos últimos meses. Não identificamos "motor inflacionário" que sustente expectativas persistentemente elevadas. A combinação atual de PIB crescendo consistentemente com valorização do real é inédita na história brasileira e cria expectativas claras de revisões contínuas para baixo.

  


Essa dinâmica confirma nossa visão. Nossa projeção de inflação para 2025 sempre foi 5,0%, mesmo quando o mercado projetava acima de 6,0%. Agora o mercado converge para nosso número, validando nossa tese de reapreciação cambial forte - cenário que divergia do consenso na época.

  


O Banco Central, ao elevar a Selic para 15% com sinalização de manutenção por período "muito prolongado", entregará patamar estruturalmente alto independentemente de ajustes graduais futuros. Esta configuração cria oportunidades nos vértices médios e longos, embora os próximos meses exijam cautela devido ao _carry_.

  


**Posicionamento:**  Seguimos aplicados em juros nominais brasileiros, concentrando nossa exposição nos vértices médios e longos, onde identificamos prêmios mais atrativos. Continuamos com nossa estratégia de proteção do carregamento de nossas posições estruturais em NTN-Bs longas através de aplicação em pré-fixados, aproveitando a atual queda da inflação implícita que pressiona temporariamente nossos papéis indexados à inflação. No mercado externo, encerramos nossa posição tomada em renda fixa americana.

  


##### Crédito Privado

  


Em relação ao crédito privado, o mercado manteve o aquecimento observado em maio, com _spreads_  generalizadamente comprimidos e demanda institucional robusta, com a maioria das emissões de qualidade continuando a ser rapidamente absorvidas. Ao longo do mês, o _spread_  médio das debêntures incentivadas com _rating_  AAA manteve o menor patamar desde o começo de 2024, refletindo a demanda ainda forte para os isentos com melhor qualidade de crédito.

  


Observamos uma transformação significativa com a regulamentação do consignado privado, que promete expandir o mercado em aproximadamente cinco vezes, com os primeiros repasses já iniciados neste mês. Simultaneamente, identificamos deterioração pontual no crédito PJ, especialmente concentrada em empresas menores que descontam duplicatas através de FIDCs com necessidades de giro de 30 dias. O setor varejista enfrenta condições particularmente difíceis, com empresas pequenas incapazes de repassar pressões de custos, enquanto o setor agropecuário atravessa período difícil que se estende por toda a cadeia relacionada.

  


**Posicionamento:**  Mantemos foco na qualidade do crédito, priorizando operações com melhor _rating_  em ambiente de compressão de _spreads_  para papéis de primeira linha. Evitamos exposição excessiva aos segmentos mais vulneráveis como varejo e agronegócio, enquanto monitoramos oportunidades no mercado primário de incentivados e no emergente consignado privado.

  


##### Moedas

  


Vemos o ambiente atual como uma mudança de regime, onde múltiplos fatores globais se alinharam para criar um período prolongado de fraqueza do dólar americano. Esta tendência representa mudança estrutural que beneficia particularmente moedas emergentes, criando suporte importante para o real brasileiro.

  


Nossa visão para o real é estruturalmente otimista. A moeda demonstra prêmio significativo em relação a fundamentos econômicos, configuração insustentável que está sendo corrigida pelo mercado. A convergência entre dólar estruturalmente mais fraco e real subvalorizado cria cenário excepcionalmente favorável. Esta dinâmica cambial não apenas impulsiona diretamente os ativos brasileiros, mas também facilita o controle inflacionário e reduz pressões sobre a sustentabilidade fiscal, criando círculo virtuoso para a economia doméstica.

  


**Posicionamento:**  Mantemos forte convicção no fortalecimento do real frente ao dólar, posicionamento que consideramos um dos pilares centrais de nossa estratégia para ativos brasileiros. A combinação de fatores globais e domésticos sustenta nossa perspectiva otimista para a moeda ao longo do ciclo. Sendo assim, seguimos vendidos no dólar americano. Atualmente, vemos esse _trade_  como extremamente consensual e, portanto, mantemo-nos vigilantes para ajustar as posições a qualquer momento.

  


##### Renda Variável

  


O ambiente para _equities_  no mundo permanece estruturalmente favorável, com diversos índices globais atingindo máximas históricas nas últimas semanas. Vemos a melhora na liquidez global, intensificação do fluxo de investidores estrangeiros e compras por parte de fundos sistemáticos (CTAs) como grandes contribuintes para o movimento recente da classe.

  


No Brasil, a bolsa permanece próxima de máximas históricas, aguardando catalisadores para movimento mais definido. Em nossa opinião, a bolsa doméstica está ainda leve em termos de posicionamento, criando oportunidades adicionais para entrada em ativos que se beneficiarão do ambiente global favorável e das melhorias domésticas antecipadas.

  


O Bitcoin tem demonstrado evolução importante como mecanismo de proteção contra incertezas monetárias, apresentando forte resiliência durante períodos de tensão geopolítica. Esta dinâmica está alinhada com nossa visão de dólar estruturalmente mais fraco e crescente aceitação institucional do ativo como reserva de valor alternativa.

  


**Posicionamento:**  Continuamos com nossa alta exposição em bolsa brasileira, seguindo o posicionamento de maio. No exterior, seguimos comprados em índices de mercados emergentes e S&P 500, incluindo estratégia _barbell_  combinando índices _value_  e _growth_  para capturar diferentes dinâmicas de mercado. Também mantemos posição comprada em Bitcoin.

  


  


#### **Nossos fundos**

  


Para informações completas, consulte os materiais informativos.

  


Equipe Persevera 

 

[_contato@persevera.com.br_](mailto:contato@persevera.com.br)

(11) 4780-3794

  * [2025](https://www.persevera.com.br/carta-mensal/categories/2025)



208

208 visualizações

0

0 comentário

1 curtida. Post não marcado como curtido1

## Posts recentes

[Ver tudo](https://www.persevera.com.br/carta-mensal)

[](https://www.persevera.com.br/post/quando-os-juros-mordem-e-o-crédito-grita)

[Quando os juros mordem e o crédito grita](https://www.persevera.com.br/post/quando-os-juros-mordem-e-o-crédito-grita)

123

0 comentário0

Post não marcado como curtido

[](https://www.persevera.com.br/post/entre-ciclos)

[Entre ciclos](https://www.persevera.com.br/post/entre-ciclos)

109

0 comentário0

Post não marcado como curtido

[](https://www.persevera.com.br/post/a-estrategia-do-caos)

[A estratégia do caos](https://www.persevera.com.br/post/a-estrategia-do-caos)

174

0 comentário0

1 curtida. Post não marcado como curtido1

[Todas as publicações ](https://www.persevera.com.br/carta-mensal)

+55 11 4780-3794 | [contato@persevera.com.br](mailto:contato@persevera.com.br?subject=Contato)

Av. Juscelino Kubistchek, 1455 - 3o Andar

Vila Nova Conceição - 04543-011 -  São Paulo - SP - Brasil

  * [](https://www.facebook.com/pg/perseveraasset/about/)
  * [](https://www.instagram.com/persevera_asset/?hl=pt-br)
  * [](https://www.linkedin.com/company/persevera-asset-management/?viewAsMember=true)
  * [](https://www.youtube.com/channel/UCjo8U7VdUkvZDUGXm1w7M3w?view_as=subscriber)



##### Inscreva-se para receber nossa Carta Trimestral

Seu e-mail foi cadastrado!

Assinar

A Persevera Gestão de Recursos Ltda. (“Persevera”) é uma empresa do grupo Fami Capital e este site tem caráter meramente informativo, não constituindo uma oferta de serviço pela Persevera e nem venda de cotas dos fundos por ela geridos. A Persevera não comercializa e nem distribui cotas de fundos de investimento ou qualquer outro ativo financeiro. Para avaliação da performance de quaisquer fundos de investimentos, é recomendável uma análise de período de, no mínimo, 12 (doze) meses. Fundos de investimento não contam com garantia da Persevera, de qualquer de suas afiliadas, de qualquer mecanismo de seguro ou, ainda, do Fundo Garantidor de Créditos - FGC. Os fundos geridos pela Persevera utilizam estratégias com derivativos como parte integrante de sua política de investimento. Estratégias com derivativos apresentam risco elevado e podem resultar em significativas perdas patrimoniais para seus cotistas. As informações contidas neste website não constituem uma opinião ou recomendação, legal ou de qualquer outra natureza, por parte da Persevera, e não leva em consideração a situação particular de qualquer pessoa. A utilização das informações aqui contidas se dará exclusivamente por conta e risco de seu usuário. Antes de tomar qualquer decisão acerca de seus investimentos, a Persevera recomenda ao interessado que consulte um profissional especializado e também a leitura cuidadosa de prospectos, regulamentos e das lâminas de informações essenciais dos fundos de investimento.

bottom of page
