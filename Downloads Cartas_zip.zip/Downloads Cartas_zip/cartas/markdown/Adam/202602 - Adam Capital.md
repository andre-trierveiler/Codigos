

---

Carta mensal 
Fevereiro 2026

---

Este relatório foi preparado pela ADAMCapital Gestão de Recursos LTDA. (ADAMCapital) e tem caráter meramente informativo, não se constituindo em oferta de venda de cotas dos fundos geridos e não conside-
rando objetivos de investimento ou necessidades individuais e particulares. A ADAMCapital não comercializa e nem distribui cotas de fundos ou qualquer outro ativo financeiro. Recomendamos uma consulta a 
assessores de investimento e profissionais especializados para uma análise específica, personalizada antes de sua decisão sobre investimentos. Aos investidores é recomendada a 
leitura cuidadosa de prospectos e regulamentos ao aplicar seus recursos. Os fundos geridos utilizam estratégias com derivativos como parte integrante de sua política de investimento. 
Tais estratégias, da forma como são adotadas, podem resultar em significativas perdas patrimoniais para seus cotistas, podendo inclusive acarretar perdas superiores ao capital aplica-
do e a consequente obrigação do cotista de aportar recursos adicionais para cobrir o prejuízo do fundo. Os fundos geridos estão autorizados a realizar aplicações em ativos financeiros 
no exterior. Os fundos multimercados podem estar expostos a significativa concentração em ativos de poucos emissores, com os riscos daí decorrentes. Fundos de Investimento não 
contam com a garantia do administrador do fundo, do gestor da carteira, de qualquer mecanismo de seguro ou, ainda, do Fundo Garantidor de Créditos – FGC. A rentabilidade obtida 
no passado não representa garantia de rentabilidade futura. Para avaliação da performance do fundo de investimento, é recomendável uma análise de, no mínimo, 12 (doze) meses. 
Nos fundos geridos pela ADAMCapital a data de conversão de cotas é diversa da data de aplicação e de resgate e a data de pagamento do resgate é diversa da data do pedido de 
resgate. Não há garantia de que os fundos multimercados terão o tratamento tributário para fundos de longo prazo. Este material não pode ser copiado, reproduzido ou distribuído a terceiros sem a expressa 
concordância da ADAMCapital. O regulamento e a lâmina dos fundos podem ser encontrados no website da ADAMCapital: www.adamcapital.com.br . 
Meu querido Vermelindo, 
Eu noto que você diz que está direcionando a leitura do seu paciente e se encarregando de fazer com que ele tenha encontros 
regulares com o tal amigo materialista. Mas será que você não está sendo um pouco ingênuo? Até parece que está achando 
que a argumentação seja o melhor modo de mantê-lo fora das garras do Inimigo. Até poderia ter sido esse o caso, há alguns 
séculos. Naquela época, as pessoas ainda sabiam muito bem quando algo tinha sido provado logicamente e quando não; e 
quando tinha sido provado, elas criam nisso de verdade. Elas ainda faziam associação entre o pensamento e a ação e esta-
vam dispostas a mudar o seu estilo de vida em decorrência de ideias racionalmente encadeadas. Mas, graças à imprensa 
diária e outras armas desse tipo, conseguimos alterar amplamente essa situação. 
LEWIS, C. S. Cartas de um diabo a seu aprendiz (no original The Screwtape Letters). Tradução de Gabriele Cornelli. Carta I. Rio 
de Janeiro: Thomas Nelson Brasil, 2017, p. 17. 
 
Em Cartas de um Diabo a seu Aprendiz, C. S. Lewis passou várias mensagens utilizando a ironia através de um discurso em 
primeira pessoa, em que o personagem principal é um "diabo" mais velho, Screwtape (Maldanado, na edição brasileira), que 
aconselha o seu sobrinho aprendiz, Wormwood (Vermelindo, o diabo jovem), a capturar a alma de uma pessoa que tenta se 
libertar dos grilhões do pensamento automático que frequentemente levam as pessoas a agirem no modo automático, tal 
como zumbis. 
O diabo velho começa seus conselhos contando a história de um de seus "pacientes" que costumava ler no Museu Britânico 
e que, em certo momento, estava mergulhado em reflexões profundas e potencialmente "perigosas". Vejam como Maldana-
do agiu: ao perceber uma cadeia de pensamentos que tomava o "caminho errado", ele não tentou argumentar. Em vez disso, 
sugeriu que já estava quase na hora do almoço. Assim, a pessoa resolveu ir almoçar e, ao sair à rua e ver o cotidiano — um 
jornaleiro gritando e o ônibus 73 —, foi convencido de que as ideias profundas de outrora não passavam de abstrações sem 
relação com a "vida real". 
A Conexão com a Economia Comportamental 
Não foi por acaso que o tema dos “ruídos” do nosso dia a dia entrou logo no 1º capítulo desta clássica obra da literatura 
inglesa que foi escrita há mais de 80 anos, durante o apogeu da 2ª guerra mundial e muito antes de autores de Finanças 
abordarem o assunto, como fizeram muito bem o psicólogo Daniel Kahneman nos livros Noise: A Flaw in Human Judgment 
(2021) / Thinking Fast and Slow (2011) e o economista Robert Shiller em Narrative Economics: How Stories Go Viral and Drive 
Major Economic Events (2019), nos quais estes autores demonstram – em suas diferentes obras – que grande parte das deci-
sões em diversas áreas e no mercado financeiro são impactadas por ruídos cotidianos, comprometendo desde diagnósticos 
médicos com falsos positivos/negativos, decisões judiciais que condenam inocentes a depender da fome do juiz (que estatis-
ticamente são mais punitivos antes do almoço ou quando seus times de futebol perdem na véspera das decisões (como mos-
tra Kahneman)¹. 
O exemplo narrado por Lewis na página 19 ilustra com perfeição o que Kahneman define como ruído psicológico: o 
'paciente', prestes a alcançar uma conclusão lógica, é distraído por um impulso biológico (a fome) e por estímulos sensori-
ais cotidianos (o ônibus e o jornaleiro). O diabo Screwtape (Maldanado) não venceu pelo argumento, mas pela interrup-
ção do pensamento profundo por meio do trivial. O pensamento racional e profundo, por sua vez, é o que Kahneman desig-
nava como sendo o “Sistema 2” de pensamento (ou pensamento lento, analítico e lógico, que exige alto esforço consciente, 
atenção e energia). 
 
¹ O economista e analista de pesquisas políticas Nate Silver também escreveu sobre isso em The Signal and the Noise (2012). 
 
1

---

Este relatório foi preparado pela ADAMCapital Gestão de Recursos LTDA. (ADAMCapital) e tem caráter meramente informativo, não se constituindo em oferta de venda de cotas dos fundos geridos e não conside-
rando objetivos de investimento ou necessidades individuais e particulares. A ADAMCapital não comercializa e nem distribui cotas de fundos ou qualquer outro ativo financeiro. Recomendamos uma consulta a 
assessores de investimento e profissionais especializados para uma análise específica, personalizada antes de sua decisão sobre investimentos. Aos investidores é recomendada a 
leitura cuidadosa de prospectos e regulamentos ao aplicar seus recursos. Os fundos geridos utilizam estratégias com derivativos como parte integrante de sua política de investimento. 
Tais estratégias, da forma como são adotadas, podem resultar em significativas perdas patrimoniais para seus cotistas, podendo inclusive acarretar perdas superiores ao capital aplica-
do e a consequente obrigação do cotista de aportar recursos adicionais para cobrir o prejuízo do fundo. Os fundos geridos estão autorizados a realizar aplicações em ativos financeiros 
no exterior. Os fundos multimercados podem estar expostos a significativa concentração em ativos de poucos emissores, com os riscos daí decorrentes. Fundos de Investimento não 
contam com a garantia do administrador do fundo, do gestor da carteira, de qualquer mecanismo de seguro ou, ainda, do Fundo Garantidor de Créditos – FGC. A rentabilidade obtida 
no passado não representa garantia de rentabilidade futura. Para avaliação da performance do fundo de investimento, é recomendável uma análise de, no mínimo, 12 (doze) meses. 
Nos fundos geridos pela ADAMCapital a data de conversão de cotas é diversa da data de aplicação e de resgate e a data de pagamento do resgate é diversa da data do pedido de 
resgate. Não há garantia de que os fundos multimercados terão o tratamento tributário para fundos de longo prazo. Este material não pode ser copiado, reproduzido ou distribuído a terceiros sem a expressa 
concordância da ADAMCapital. O regulamento e a lâmina dos fundos podem ser encontrados no website da ADAMCapital: www.adamcapital.com.br . 
É aqui que entra a conexão com Robert Shiller. No livro citado anteriormente, ele enumera diversos exemplos de como es-
ses mesmos ruídos descritos por Lewis como sendo a estratégia de ‘distração’ usada pelo diabo — o 'ônibus passando' na 
nossa frente ou as manchetes de um jornaleiro moderno (a mídia tradicional e/ou as redes sociais) — se transfiguram em 
narrativas capazes de impactar os fundamentos econômicos de forma duradoura. Shiller demonstra que fenômenos como a 
formação da 'Bolha da Internet' (1995-2000²) ou o da bolha do setor imobiliário de 2008 foram alimentados por histórias 
virais que substituíram a análise racional pela 'vida real' das cotações diárias, distorcendo o valor dos ativos até que a rea-
lidade, inevitavelmente, se impusesse. 
 
O Cenário Global e a Inteligência Artificial 
Transpondo este conceito para os tempos atuais, o que vemos é exatamente este mesmo fenômeno, mas com sinal con-
trário: as narrativas sobre o fim da ‘excepcionalidade americana’ e a respeito da ‘bolha de IA’ tem produzido efeitos signi-
ficativos nos mercados ao longo dos últimos 12 meses – o que é um período que não podemos mais classificar como “curto 
prazo”, mas parecem ser temores totalmente descolados da realidade observada nos resultados das empresas e nos da-
dos macroeconômicos.  
Na Carta anterior focamos nos potenciais impactos de inteligência artificial (IA) e nas razões que nos levam a investir sobre-
tudo nos ativos relacionados à economia americana – na direção contrárias às narrativas que têm predominado. Em relação 
ao que mostramos ali, não apareceram grandes novidades macroeconômicas dignas de nota neste mês de fevereiro, descon-
siderando os muitos ruídos provenientes da guerra no Irã, novos desdobramentos na Ucrânia ou de outros potenciais confli-
tos como a tensão entre China-Taiwan/Japão. De forma geral, a economia americana segue apresentando um crescimento 
real em torno de 3% (demanda doméstica) e boa parte deste crescimento está relacionado à expansão de atividades dire-
ta ou indiretamente ligadas à IA.  
 
 
 
 
 
 
 
 
 
 
 
 
Por outro lado, a inflação americana segue em patamar historicamente elevado, em torno de 3%, mas boa parte dessa 
pressão é oriunda do efeito das tarifas e da desvalorização do dólar sobre a inflação de bens, ainda que estes efeitos te-
nham sido muito menores em relação às expectativas de meados do ano passado que sugeriam uma aceleração do núcleo 
do PCE para perto de 4%. Ao nosso ver, como já argumentamos bastante, tanto o desempenho melhor da inflação como o 
PIB forte nos EUA estão sendo beneficiados por IA. 
 
² Entre o início de 1995 e março de 2000, o Nasdaq multiplicou por 10, quando as empresas do setor de tecnologia não geravam caixa e eram endividadas.  
 
2

---

Este relatório foi preparado pela ADAMCapital Gestão de Recursos LTDA. (ADAMCapital) e tem caráter meramente informativo, não se constituindo em oferta de venda de cotas dos fundos geridos e não conside-
rando objetivos de investimento ou necessidades individuais e particulares. A ADAMCapital não comercializa e nem distribui cotas de fundos ou qualquer outro ativo financeiro. Recomendamos uma consulta a 
assessores de investimento e profissionais especializados para uma análise específica, personalizada antes de sua decisão sobre investimentos. Aos investidores é recomendada a 
leitura cuidadosa de prospectos e regulamentos ao aplicar seus recursos. Os fundos geridos utilizam estratégias com derivativos como parte integrante de sua política de investimento. 
Tais estratégias, da forma como são adotadas, podem resultar em significativas perdas patrimoniais para seus cotistas, podendo inclusive acarretar perdas superiores ao capital aplica-
do e a consequente obrigação do cotista de aportar recursos adicionais para cobrir o prejuízo do fundo. Os fundos geridos estão autorizados a realizar aplicações em ativos financeiros 
no exterior. Os fundos multimercados podem estar expostos a significativa concentração em ativos de poucos emissores, com os riscos daí decorrentes. Fundos de Investimento não 
contam com a garantia do administrador do fundo, do gestor da carteira, de qualquer mecanismo de seguro ou, ainda, do Fundo Garantidor de Créditos – FGC. A rentabilidade obtida 
no passado não representa garantia de rentabilidade futura. Para avaliação da performance do fundo de investimento, é recomendável uma análise de, no mínimo, 12 (doze) meses. 
Nos fundos geridos pela ADAMCapital a data de conversão de cotas é diversa da data de aplicação e de resgate e a data de pagamento do resgate é diversa da data do pedido de 
resgate. Não há garantia de que os fundos multimercados terão o tratamento tributário para fundos de longo prazo. Este material não pode ser copiado, reproduzido ou distribuído a terceiros sem a expressa 
concordância da ADAMCapital. O regulamento e a lâmina dos fundos podem ser encontrados no website da ADAMCapital: www.adamcapital.com.br . 
 
O próprio banco central americano (Fed) tem dito que a inflação exclusive tarifas está abaixo de 2,5% e a taxa de desem-
prego segue subindo lentamente (o que também aponta para ganhos de produtividade decorrentes de IA).  
Do lado fiscal, há uma evidente melhora do déficit primário e nominal nos EUA que foi impulsionada não apenas pela alta 
das tarifas, mas também pelo efeito da alta da atividade econômica sobre a arrecadação em geral e pela redução do ritmo 
de crescimento das despesas. Neste contexto, parece-nos provável que o Fed venha a retomar a redução da taxa de juros 
básica em algum momento deste ano e parece ser razoável a atual precificação do mercado de 3 quedas de 25 bps neste 
ano, com a taxa recuando de 3,75% para em torno de 3% até dezembro. 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
Junto ao quadro macro parecido com o apresentado em nossa Carta do mês passado, tivemos uma nova rodada de divulga-
ção de resultados corporativos das principais empresas de tecnologia globais. Em nossa visão, estes balanços seguem apre-
sentando, de forma conjunta, sólidos fundamentos do ponto de vista de investimentos e adoção de modelos e ferramen-
tas. Estes, por sua vez, reforçam a o caráter disruptivo que a realidade de IA tem mostrado (sendo que os principais gargalos 
são de oferta; a demanda é exponencial). Os potenciais ganhos futuros estão sendo bastante subestimados pelo mercado, ao 
nosso ver. 
 
 
 
 
 
3

---

Este relatório foi preparado pela ADAMCapital Gestão de Recursos LTDA. (ADAMCapital) e tem caráter meramente informativo, não se constituindo em oferta de venda de cotas dos fundos geridos e não conside-
rando objetivos de investimento ou necessidades individuais e particulares. A ADAMCapital não comercializa e nem distribui cotas de fundos ou qualquer outro ativo financeiro. Recomendamos uma consulta a 
assessores de investimento e profissionais especializados para uma análise específica, personalizada antes de sua decisão sobre investimentos. Aos investidores é recomendada a 
leitura cuidadosa de prospectos e regulamentos ao aplicar seus recursos. Os fundos geridos utilizam estratégias com derivativos como parte integrante de sua política de investimento. 
Tais estratégias, da forma como são adotadas, podem resultar em significativas perdas patrimoniais para seus cotistas, podendo inclusive acarretar perdas superiores ao capital aplica-
do e a consequente obrigação do cotista de aportar recursos adicionais para cobrir o prejuízo do fundo. Os fundos geridos estão autorizados a realizar aplicações em ativos financeiros 
no exterior. Os fundos multimercados podem estar expostos a significativa concentração em ativos de poucos emissores, com os riscos daí decorrentes. Fundos de Investimento não 
contam com a garantia do administrador do fundo, do gestor da carteira, de qualquer mecanismo de seguro ou, ainda, do Fundo Garantidor de Créditos – FGC. A rentabilidade obtida 
no passado não representa garantia de rentabilidade futura. Para avaliação da performance do fundo de investimento, é recomendável uma análise de, no mínimo, 12 (doze) meses. 
Nos fundos geridos pela ADAMCapital a data de conversão de cotas é diversa da data de aplicação e de resgate e a data de pagamento do resgate é diversa da data do pedido de 
resgate. Não há garantia de que os fundos multimercados terão o tratamento tributário para fundos de longo prazo. Este material não pode ser copiado, reproduzido ou distribuído a terceiros sem a expressa 
concordância da ADAMCapital. O regulamento e a lâmina dos fundos podem ser encontrados no website da ADAMCapital: www.adamcapital.com.br . 
Neste sentido, uma novidade em nossa carteira é a inclusão da bolsa da Coreia do Sul, já que entendemos que este país 
tende a continuar sendo muito beneficiado pela onda global de investimentos em IA, já que ele é o maior produtor global 
de memória (que atualmente é um ativo fundamental e muito disputado pela cadeia de IA). Por este motivo, vemos que as 
exportações coreanas de chips estão subindo muito rapidamente, trazendo uma melhora significativa para o lucro das em-
presas de lá (que se reflete em melhoria de indicadores econômicos como a balança comercial deles). Para ilustrar este pon-
to, acabou de sair o dado de fevereiro que mostra uma expansão impressionante de 160,8% das exportações de chips na 
comparação anual, tendo atingido o valor recorde de USD 25.16 bilhões em um único mês (fevereiro) e superando o pata-
mar de USD 20 bilhões pelo 3º mês consecutivo. Já as exportações totais do país atingiram USD 67,5 bilhões em fevereiro. 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
4

---

Este relatório foi preparado pela ADAMCapital Gestão de Recursos LTDA. (ADAMCapital) e tem caráter meramente informativo, não se constituindo em oferta de venda de cotas dos fundos geridos e não conside-
rando objetivos de investimento ou necessidades individuais e particulares. A ADAMCapital não comercializa e nem distribui cotas de fundos ou qualquer outro ativo financeiro. Recomendamos uma consulta a 
assessores de investimento e profissionais especializados para uma análise específica, personalizada antes de sua decisão sobre investimentos. Aos investidores é recomendada a 
leitura cuidadosa de prospectos e regulamentos ao aplicar seus recursos. Os fundos geridos utilizam estratégias com derivativos como parte integrante de sua política de investimento. 
Tais estratégias, da forma como são adotadas, podem resultar em significativas perdas patrimoniais para seus cotistas, podendo inclusive acarretar perdas superiores ao capital aplica-
do e a consequente obrigação do cotista de aportar recursos adicionais para cobrir o prejuízo do fundo. Os fundos geridos estão autorizados a realizar aplicações em ativos financeiros 
no exterior. Os fundos multimercados podem estar expostos a significativa concentração em ativos de poucos emissores, com os riscos daí decorrentes. Fundos de Investimento não 
contam com a garantia do administrador do fundo, do gestor da carteira, de qualquer mecanismo de seguro ou, ainda, do Fundo Garantidor de Créditos – FGC. A rentabilidade obtida 
no passado não representa garantia de rentabilidade futura. Para avaliação da performance do fundo de investimento, é recomendável uma análise de, no mínimo, 12 (doze) meses. 
Nos fundos geridos pela ADAMCapital a data de conversão de cotas é diversa da data de aplicação e de resgate e a data de pagamento do resgate é diversa da data do pedido de 
resgate. Não há garantia de que os fundos multimercados terão o tratamento tributário para fundos de longo prazo. Este material não pode ser copiado, reproduzido ou distribuído a terceiros sem a expressa 
concordância da ADAMCapital. O regulamento e a lâmina dos fundos podem ser encontrados no website da ADAMCapital: www.adamcapital.com.br . 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
Nos demais blocos de países desenvolvidos também não parece ter havido grandes novidades. A China segue apresentando 
fraqueza na demanda doméstica, mas, paradoxalmente, as commodities que eles compram do Brasil não tem apresentado 
quedas significativas nos preços. O minério está caindo 7,5%, mas a soja sobe 11,7%, ambos neste ano (YTD). O petróleo, por 
sua vez, registrou uma alta de 25% YTD, claramente impulsionado por fatores geopolíticos (como a guerra contra o Irã).  
A Europa segue mostrando uma fase de acomodação da atividade com mercado de trabalho aquecido, ao contrário do que 
vemos nos EUA, sugerindo assim uma piora da produtividade neste continente marcado pela decadência econômico-política 
e cultural. 
5

---

Este relatório foi preparado pela ADAMCapital Gestão de Recursos LTDA. (ADAMCapital) e tem caráter meramente informativo, não se constituindo em oferta de venda de cotas dos fundos geridos e não conside-
rando objetivos de investimento ou necessidades individuais e particulares. A ADAMCapital não comercializa e nem distribui cotas de fundos ou qualquer outro ativo financeiro. Recomendamos uma consulta a 
assessores de investimento e profissionais especializados para uma análise específica, personalizada antes de sua decisão sobre investimentos. Aos investidores é recomendada a 
leitura cuidadosa de prospectos e regulamentos ao aplicar seus recursos. Os fundos geridos utilizam estratégias com derivativos como parte integrante de sua política de investimento. 
Tais estratégias, da forma como são adotadas, podem resultar em significativas perdas patrimoniais para seus cotistas, podendo inclusive acarretar perdas superiores ao capital aplica-
do e a consequente obrigação do cotista de aportar recursos adicionais para cobrir o prejuízo do fundo. Os fundos geridos estão autorizados a realizar aplicações em ativos financeiros 
no exterior. Os fundos multimercados podem estar expostos a significativa concentração em ativos de poucos emissores, com os riscos daí decorrentes. Fundos de Investimento não 
contam com a garantia do administrador do fundo, do gestor da carteira, de qualquer mecanismo de seguro ou, ainda, do Fundo Garantidor de Créditos – FGC. A rentabilidade obtida 
no passado não representa garantia de rentabilidade futura. Para avaliação da performance do fundo de investimento, é recomendável uma análise de, no mínimo, 12 (doze) meses. 
Nos fundos geridos pela ADAMCapital a data de conversão de cotas é diversa da data de aplicação e de resgate e a data de pagamento do resgate é diversa da data do pedido de 
resgate. Não há garantia de que os fundos multimercados terão o tratamento tributário para fundos de longo prazo. Este material não pode ser copiado, reproduzido ou distribuído a terceiros sem a expressa 
concordância da ADAMCapital. O regulamento e a lâmina dos fundos podem ser encontrados no website da ADAMCapital: www.adamcapital.com.br . 
Na parte doméstica, vamos focar em explicar por que a economia brasileira deve passar por uma forte correção em vista 
dos seus muitos desequilíbrios, especialmente considerando a sinalização do Banco Central em cortar os juros neste ano 
eleitoral e com a economia aquecida. A aproximação das eleições tende a elevar a incerteza, mas seguimos com a opinião 
de que, na ausência de uma forte correção do câmbio, a classe política seguirá sem incentivos para realizar as reformas 
econômicas estruturais profundas que seriam necessárias para endereçar os nossos múltiplos desequilíbrios. 
No gráfico a seguir mostramos que a tendência da inflação de serviços segue muito alta e isso faz total sentido diante de 
uma taxa de desemprego nas mínimas históricas.  
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
As últimas leituras do IPCA vieram com essa parte de serviços muito pressionada e este grupo foi o maior responsável pela 
subestimação de 28 bps do mercado na última divulgação do IPCA-15 de fevereiro (20 bps em relação à nossa projeção). O 
consenso de mercado das projeções coletadas pela da Bloomberg tinha uma mediana de 0,56%, mas o número veio 
0,84%, constituindo-se no maior erro de projeção da série histórica do IPCA-15 em mais de 20 anos. 
Nos ciclos anteriores em que o Banco Central reduziu os juros baseado em fundamentos econômicos favoráveis à inflação 
baixa (2016/2019), a taxa de desemprego estava em torno de 13%, mas agora está perto de 5%! Já em 2023 eles erraram 
ao cair e o desemprego estava em 8%, muito acima do nível atual (e ainda assim aquela estratégia deu errado porque o Ba-
cen foi atropelado pela aceleração do gasto público). 
 
 
 
 
 
6

---

Este relatório foi preparado pela ADAMCapital Gestão de Recursos LTDA. (ADAMCapital) e tem caráter meramente informativo, não se constituindo em oferta de venda de cotas dos fundos geridos e não conside-
rando objetivos de investimento ou necessidades individuais e particulares. A ADAMCapital não comercializa e nem distribui cotas de fundos ou qualquer outro ativo financeiro. Recomendamos uma consulta a 
assessores de investimento e profissionais especializados para uma análise específica, personalizada antes de sua decisão sobre investimentos. Aos investidores é recomendada a 
leitura cuidadosa de prospectos e regulamentos ao aplicar seus recursos. Os fundos geridos utilizam estratégias com derivativos como parte integrante de sua política de investimento. 
Tais estratégias, da forma como são adotadas, podem resultar em significativas perdas patrimoniais para seus cotistas, podendo inclusive acarretar perdas superiores ao capital aplica-
do e a consequente obrigação do cotista de aportar recursos adicionais para cobrir o prejuízo do fundo. Os fundos geridos estão autorizados a realizar aplicações em ativos financeiros 
no exterior. Os fundos multimercados podem estar expostos a significativa concentração em ativos de poucos emissores, com os riscos daí decorrentes. Fundos de Investimento não 
contam com a garantia do administrador do fundo, do gestor da carteira, de qualquer mecanismo de seguro ou, ainda, do Fundo Garantidor de Créditos – FGC. A rentabilidade obtida 
no passado não representa garantia de rentabilidade futura. Para avaliação da performance do fundo de investimento, é recomendável uma análise de, no mínimo, 12 (doze) meses. 
Nos fundos geridos pela ADAMCapital a data de conversão de cotas é diversa da data de aplicação e de resgate e a data de pagamento do resgate é diversa da data do pedido de 
resgate. Não há garantia de que os fundos multimercados terão o tratamento tributário para fundos de longo prazo. Este material não pode ser copiado, reproduzido ou distribuído a terceiros sem a expressa 
concordância da ADAMCapital. O regulamento e a lâmina dos fundos podem ser encontrados no website da ADAMCapital: www.adamcapital.com.br . 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
Cabe-nos, portanto, um questionamento: será que a estratégia de distração usada pelo diabo velho retratado na ficção de 
Lewis conseguiu convencer a todos nós que a inflação brasileira vai convergir para 3%? A rigor, mesmo olhando para os nú-
meros do Focus que são bem mais baixos que os nossos, ainda parece que não. 
Por outro lado, há uma confusão de ruído com fundamento econômico nessa questão da convergência da inflação. Argu-
menta-se que o Banco Central deveria olhar apenas para a sua projeção de inflação, independentemente de esta ter sido 
causada por uma soma de choques baixistas para a inflação que incluem a tendência global de desvalorização do dólar, a 
queda do petróleo no 2º semestre de 2025, o recuo dos custos de frete e dos alimentos no mundo durante os últimos 6 me-
ses, a boa safra e a queda dos preços industriais decorrente da imposição das tarifas nos Estados Unidos, mas estes são em 
grande parte fatores alheios à nossa política monetária doméstica e que não vão nos salvar de forma contínua ao longo dos 
próximos anos. Em outras palavras, o Brasil deu muita sorte em 2025 e não dá para contar eternamente com todos os ventos 
(ruídos) soprando a favor. 
Além destes choques de oferta impactarem integralmente a projeção de inflação do Bacen, a trajetória de hiato que eles 
utilizam nas suas projeções é reconhecida por muitos como excessivamente otimista e isso acaba ajudando na queda da in-
flação projetada, principalmente para os horizontes de tempo mais longos (que mais impactam na sinalização da política 
monetária).  
Em função disso, nas posições de Brasil, seguimos tomados no juro nominal longo, aplicados em juro real e comprados em 
câmbio. 
Em suma, seja na literatura de Lewis, na economia comportamental de Kahneman ou na macroeconomia de Shiller, o alerta 
é o mesmo: os ruídos devem ser tratados como tal e a dinâmica dele resultante não pode ser extrapolada (principalmente 
pelos banqueiros centrais). Para isso, é muito importante filtrar as informações que vão aparecendo, a fim de que as narrati-
vas do momento não nos afastem da análise racional dos fundamentos que realmente importam no longo prazo. 
7

---

Contato 
comercial@adamcapital.com.br 
ADAM Capital 
Rua Dias Ferreira, 190 – sala 502 – Leblon 
Rio de Janeiro, Brazil – CEP 22431-050 
+55 21 3993-7000 
 
www.adamcapital.com.br 
ADAM 
ADVANCED  
ADAM 
PREV  
ADAM 
MACRO  
saiba mais 
saiba mais  
saiba mais  
CONHEÇA OS 
FUNDOS DA ADAM|CAPITAL 
ADAM 
RENDA FIXA 
ADAM 
RENDA FIXA    
ATIVA PREV 
saiba mais  
saiba mais  
ATIVA