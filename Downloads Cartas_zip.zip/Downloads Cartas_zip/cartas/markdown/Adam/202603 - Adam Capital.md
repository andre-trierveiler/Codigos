

---

Carta mensal 
Março 2026

---

Este relatório foi preparado pela ADAMCapital Gestão de Recursos LTDA. (ADAMCapital) e tem caráter meramente informativo, não se constituindo em oferta de venda de cotas dos fundos geridos e não conside-
rando objetivos de investimento ou necessidades individuais e particulares. A ADAMCapital não comercializa e nem distribui cotas de fundos ou qualquer outro ativo financeiro. Recomendamos uma consulta a 
assessores de investimento e profissionais especializados para uma análise específica, personalizada antes de sua decisão sobre investimentos. Aos investidores é recomendada a 
leitura cuidadosa de prospectos e regulamentos ao aplicar seus recursos. Os fundos geridos utilizam estratégias com derivativos como parte integrante de sua política de investimento. 
Tais estratégias, da forma como são adotadas, podem resultar em significativas perdas patrimoniais para seus cotistas, podendo inclusive acarretar perdas superiores ao capital aplica-
do e a consequente obrigação do cotista de aportar recursos adicionais para cobrir o prejuízo do fundo. Os fundos geridos estão autorizados a realizar aplicações em ativos financeiros 
no exterior. Os fundos multimercados podem estar expostos a significativa concentração em ativos de poucos emissores, com os riscos daí decorrentes. Fundos de Investimento não 
contam com a garantia do administrador do fundo, do gestor da carteira, de qualquer mecanismo de seguro ou, ainda, do Fundo Garantidor de Créditos – FGC. A rentabilidade obtida 
no passado não representa garantia de rentabilidade futura. Para avaliação da performance do fundo de investimento, é recomendável uma análise de, no mínimo, 12 (doze) meses. 
Nos fundos geridos pela ADAMCapital a data de conversão de cotas é diversa da data de aplicação e de resgate e a data de pagamento do resgate é diversa da data do pedido de 
resgate. Não há garantia de que os fundos multimercados terão o tratamento tributário para fundos de longo prazo. Este material não pode ser copiado, reproduzido ou distribuído a terceiros sem a expressa 
concordância da ADAMCapital. O regulamento e a lâmina dos fundos podem ser encontrados no website da ADAMCapital: www.adamcapital.com.br . 
O choque de oferta derivado da guerra no Oriente Médio 
O mês passado foi marcado pelo choque de oferta causado pelo ataque conjunto dos Estados Unidos e de Israel ao Irã, que 
produziu uma forte elevação dos preços de energia e fertilizantes no mundo. Com isso, a cotação do barril de petróleo ultra-
passou 100 dólares e se encontra atualmente próximo deste patamar¹, significativamente acima do nível de 60 que era vi-
gente antes desta guerra. 
Segundo a Agência Internacional de Energia (AIE), “O conflito, que começou em 28 de fevereiro, prejudicou significativamente 
o fluxo de comércio de energia pelo Estreito de Ormuz, criando a maior interrupção no fornecimento da história do mercado 
global de petróleo. O fornecimento global de Gás Natural Liquefeito (GNL) também foi reduzido em cerca de 20% como resul-
tado dessa situação.”² 
Em 11 de março, os 32 países membros da AIE concordaram, por unanimidade, em disponibilizar 400 milhões de barris de 
petróleo de suas reservas estratégicas ao mercado. A medida visava mitigar as interrupções nos suprimentos causadas pela 
guerra no Oriente Médio. De acordo com dados da própria AIE, no final de janeiro de 2026, o estoque total de petróleo dos 
governos da OCDE era equivalente a 27,4 dias de consumo.³ 
Segundo estimativas da AIE, a produção global de petróleo girava em torno de 106 a 107 milhões de barris por dia (mb/d) 
antes da guerra, tendo caído para cerca de 98,8 mb/d agora (em março de 2026). Com a demanda global girando agora em 
torno de 103-105 mb/d após revisão para baixo causada pelo preço mais alto/menor crescimento/racionamento em alguns 
países⁴, estaríamos diante de um “gap” de cerca de 5% entre a oferta e demanda “subjacente”. 
No primeiro e segundo choques do petróleo (final de 1973 e 1979, respectivamente), a redução na oferta global ficou entre 
7% e 10%⁵. Assim, a disrupção que estamos observando agora foi, ao menos inicialmente, de uma escala semelhante àquela 
(em termos de volume retirado do mercado). No entanto, já houve rearranjos no transporte e parte da entrega está ocorren-
do por fora dos registros estatísticos (com os sistemas de localização dos navios desligados). Além disso, o mundo de hoje 
tem mais resiliência (estoques estratégicos, diversificação de produtores, shale oil etc.) e a participação de setores menos 
intensivos no uso de energia no PIB aumentou, o que mitiga parte do impacto econômico em comparação com aquela épo-
ca. Além destes atenuantes, a importância relativa do petróleo e seus derivados na cadeia energética caiu desde então. 
Por outro lado, os combustíveis fósseis continuam sendo a principal fonte de energia primária do mundo e para alguns países 
da Europa essa dependência pode ter aumentado, uma vez que vários deles optaram por políticas de redução do uso da 
energia nuclear. A Alemanha desligou totalmente seus reatores em 2023, e outros países europeus ainda estão desligando, 
aumentando assim a dependência de gás natural e carvão importados como fontes de despacho para a rede elétrica, o que 
indiretamente eleva a vulnerabilidade a choques em combustíveis fósseis. Isso não aumentou diretamente a dependência de 
petróleo, mas sim de fósseis importados em geral. A Alemanha, por exemplo, aumentou importações de gás e carvão após 
2022⁶. 
 
 
 
 
¹ Tanto no caso do Brent (referência na Europa) como no do WTI (negociado no Texas-EUA). 
²https://www.iea.org/news/iea-launches-tracker-to-monitor-policy-responses-to-energy-market-impacts-of-middle-east-conflict 
³Os países membros da AIE detinham reservas governamentais substanciais de 1,2 bilhão de barris de petróleo no final de janeiro de 2026. Esses estoques 
são mantidos especificamente para uso emergencial e são de propriedade diretamente dos governos ou de agências públicas especializadas. 
⁴ O ritmo anterior à guerra era estimado em 107 mb/d. 
⁵ Ver https://www.federalreservehistory.org/essays/oil-shock-of-1973-74 e https://www.federalreservehistory.org/essays/oil-shock-of-1978-79 
⁶ A Alemanha mudou a origem da importação. Antes dependente da Rússia, agora depende pesadamente de GNL (EUA, Catar) e carvão de outros 
fornecedores globais. 
 
 
1

---

Este relatório foi preparado pela ADAMCapital Gestão de Recursos LTDA. (ADAMCapital) e tem caráter meramente informativo, não se constituindo em oferta de venda de cotas dos fundos geridos e não conside-
rando objetivos de investimento ou necessidades individuais e particulares. A ADAMCapital não comercializa e nem distribui cotas de fundos ou qualquer outro ativo financeiro. Recomendamos uma consulta a 
assessores de investimento e profissionais especializados para uma análise específica, personalizada antes de sua decisão sobre investimentos. Aos investidores é recomendada a 
leitura cuidadosa de prospectos e regulamentos ao aplicar seus recursos. Os fundos geridos utilizam estratégias com derivativos como parte integrante de sua política de investimento. 
Tais estratégias, da forma como são adotadas, podem resultar em significativas perdas patrimoniais para seus cotistas, podendo inclusive acarretar perdas superiores ao capital aplica-
do e a consequente obrigação do cotista de aportar recursos adicionais para cobrir o prejuízo do fundo. Os fundos geridos estão autorizados a realizar aplicações em ativos financeiros 
no exterior. Os fundos multimercados podem estar expostos a significativa concentração em ativos de poucos emissores, com os riscos daí decorrentes. Fundos de Investimento não 
contam com a garantia do administrador do fundo, do gestor da carteira, de qualquer mecanismo de seguro ou, ainda, do Fundo Garantidor de Créditos – FGC. A rentabilidade obtida 
no passado não representa garantia de rentabilidade futura. Para avaliação da performance do fundo de investimento, é recomendável uma análise de, no mínimo, 12 (doze) meses. 
Nos fundos geridos pela ADAMCapital a data de conversão de cotas é diversa da data de aplicação e de resgate e a data de pagamento do resgate é diversa da data do pedido de 
resgate. Não há garantia de que os fundos multimercados terão o tratamento tributário para fundos de longo prazo. Este material não pode ser copiado, reproduzido ou distribuído a terceiros sem a expressa 
concordância da ADAMCapital. O regulamento e a lâmina dos fundos podem ser encontrados no website da ADAMCapital: www.adamcapital.com.br . 
Quando olhamos para a cotação do barril americano desde o Primeiro Choque do Petróleo, que teve início em outubro de 
1973, vemos um preço médio de 42 dólares, bem abaixo do nível atual. No início dos anos 80, o preço estava em torno des-
tes 40 dólares. 
 
 
 
 
 
 
 
 
 
 
 
 
 
No entanto, sabemos que 40 dólares naquela época apresentavam um poder de compra bem superior ao que esta quantia 
representa hoje, em vista da inflação acumulada em torno de 300%, de acordo com o índice de preços ao consumidor ameri-
cano (CPI). Isso parece muito para os Estados Unidos, mas este foi o resultado de uma inflação anual ligeiramente acima de 
3% ao ano (em média) durante 46 anos. 
Neste caso, também é importante vermos como ficaria o gráfico acima se ajustarmos a série do preço do petróleo tomando 
a inflação acumulada dos Estados Unidos neste período: 
 
 
 
 
 
 
 
 
 
 
 
2

---

Este relatório foi preparado pela ADAMCapital Gestão de Recursos LTDA. (ADAMCapital) e tem caráter meramente informativo, não se constituindo em oferta de venda de cotas dos fundos geridos e não conside-
rando objetivos de investimento ou necessidades individuais e particulares. A ADAMCapital não comercializa e nem distribui cotas de fundos ou qualquer outro ativo financeiro. Recomendamos uma consulta a 
assessores de investimento e profissionais especializados para uma análise específica, personalizada antes de sua decisão sobre investimentos. Aos investidores é recomendada a 
leitura cuidadosa de prospectos e regulamentos ao aplicar seus recursos. Os fundos geridos utilizam estratégias com derivativos como parte integrante de sua política de investimento. 
Tais estratégias, da forma como são adotadas, podem resultar em significativas perdas patrimoniais para seus cotistas, podendo inclusive acarretar perdas superiores ao capital aplica-
do e a consequente obrigação do cotista de aportar recursos adicionais para cobrir o prejuízo do fundo. Os fundos geridos estão autorizados a realizar aplicações em ativos financeiros 
no exterior. Os fundos multimercados podem estar expostos a significativa concentração em ativos de poucos emissores, com os riscos daí decorrentes. Fundos de Investimento não 
contam com a garantia do administrador do fundo, do gestor da carteira, de qualquer mecanismo de seguro ou, ainda, do Fundo Garantidor de Créditos – FGC. A rentabilidade obtida 
no passado não representa garantia de rentabilidade futura. Para avaliação da performance do fundo de investimento, é recomendável uma análise de, no mínimo, 12 (doze) meses. 
Nos fundos geridos pela ADAMCapital a data de conversão de cotas é diversa da data de aplicação e de resgate e a data de pagamento do resgate é diversa da data do pedido de 
resgate. Não há garantia de que os fundos multimercados terão o tratamento tributário para fundos de longo prazo. Este material não pode ser copiado, reproduzido ou distribuído a terceiros sem a expressa 
concordância da ADAMCapital. O regulamento e a lâmina dos fundos podem ser encontrados no website da ADAMCapital: www.adamcapital.com.br . 
Percebe-se, por meio deste gráfico com o barril trazido a preços de hoje, que a cotação atual está mais próxima da média do 
preço “real”⁷ desde 1974 do que a cotação nominal sem a correção inflacionária, mas ainda assim o nível atual supera a mé-
dia histórica desde o 1º choque do petróleo em mais de 40%. 
Por este e outros motivos, o mercado futuro precifica uma queda do petróleo maior do que de costume (o chamado 
backwardation ou curva invertida⁸). A extração de petróleo nos Estados Unidos, por exemplo, é facilmente ligada e desligada 
e o preço atual se encontra em um patamar muito acima do necessário para garantir a rentabilidade dos produtores ameri-
canos, que neste caso podem recorrer ao mercado futuro para venderem contratos para os próximos meses, a tempo de 
religarem as suas unidades produtivas para entrega física futura. Além disso, o mercado enxerga que a guerra é passageira e 
a capacidade produtiva e de transporte no Oriente Médio também serão retomadas. Assim, vemos que a curva futura dos 
contratos subiu bem menos em relação aos preços à vista e dos vencimentos curtos, conforme podemos ver no gráfico a 
seguir:  
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
⁷ Em dólares constantes de março de 2026 (corrigido pela inflação do CPI americano). 
⁸ Diferentemente do estado normal de uma curva de commodities, onde o preço futuro é mais alto que o preço à vista devido aos custos de carregamento 
(armazenagem, seguro), no backwardation a curva está "de cabeça para baixo". A escassez de curto prazo é frequentemente usada para explicar a causa do 
backwardation, já que ele geralmente ocorre quando há uma demanda imediata muito alta ou oferta restrita no presente. 
3

---

Este relatório foi preparado pela ADAMCapital Gestão de Recursos LTDA. (ADAMCapital) e tem caráter meramente informativo, não se constituindo em oferta de venda de cotas dos fundos geridos e não conside-
rando objetivos de investimento ou necessidades individuais e particulares. A ADAMCapital não comercializa e nem distribui cotas de fundos ou qualquer outro ativo financeiro. Recomendamos uma consulta a 
assessores de investimento e profissionais especializados para uma análise específica, personalizada antes de sua decisão sobre investimentos. Aos investidores é recomendada a 
leitura cuidadosa de prospectos e regulamentos ao aplicar seus recursos. Os fundos geridos utilizam estratégias com derivativos como parte integrante de sua política de investimento. 
Tais estratégias, da forma como são adotadas, podem resultar em significativas perdas patrimoniais para seus cotistas, podendo inclusive acarretar perdas superiores ao capital aplica-
do e a consequente obrigação do cotista de aportar recursos adicionais para cobrir o prejuízo do fundo. Os fundos geridos estão autorizados a realizar aplicações em ativos financeiros 
no exterior. Os fundos multimercados podem estar expostos a significativa concentração em ativos de poucos emissores, com os riscos daí decorrentes. Fundos de Investimento não 
contam com a garantia do administrador do fundo, do gestor da carteira, de qualquer mecanismo de seguro ou, ainda, do Fundo Garantidor de Créditos – FGC. A rentabilidade obtida 
no passado não representa garantia de rentabilidade futura. Para avaliação da performance do fundo de investimento, é recomendável uma análise de, no mínimo, 12 (doze) meses. 
Nos fundos geridos pela ADAMCapital a data de conversão de cotas é diversa da data de aplicação e de resgate e a data de pagamento do resgate é diversa da data do pedido de 
resgate. Não há garantia de que os fundos multimercados terão o tratamento tributário para fundos de longo prazo. Este material não pode ser copiado, reproduzido ou distribuído a terceiros sem a expressa 
concordância da ADAMCapital. O regulamento e a lâmina dos fundos podem ser encontrados no website da ADAMCapital: www.adamcapital.com.br . 
Observemos também abaixo o gráfico da relação entre o 1º vencimento do petróleo tipo WTI e o seu 7º vencimento, mos-
trando o problema da entrega física: ao contrário do que ocorreu no início da pandemia, quando ninguém queria receber 
petróleo, agora existe um déficit de entrega e ao mesmo tempo os produtores estão aproveitando para vender o petróleo 
futuro. Justamente por isso, o 1º vencimento futuro do barril WTI (para entrega em 21 de abril) está quase 40 dólares mais 
caro que o 7º futuro (para entre entrega no final de outubro). 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
A flexibilidade da produção americana é um ponto importante. O Fed de Dallas divulgou recentemente⁹ a sua pesquisa 
(survey) junto a empresários do setor em que eles fazem a seguinte pergunta: Qual o preço do petróleo West Texas Interme-
diate (WTI) necessário para que sua empresa cubra as despesas operacionais dos poços existentes?  
As respostas mostram um preço médio em toda a amostra de aproximadamente US$ 43 por barril, evidenciando quão lucra-
tiva é a extração diante dos níveis atualmente negociados no mercado futuro (o WTI para entrega em dezembro está em 
USD 70,8 hoje, dia 2/4/26). Em todas as regiões, o preço médio necessário para cobrir as despesas operacionais varia de US$ 
34 a US$ 47 por barril. Absolutamente todos os entrevistados responderam que conseguem cobrir as despesas operacionais 
dos poços existentes aos preços atuais. 
Uma outra pergunta importante desta pesquisa é qual o preço do petróleo WTI necessário para que sua empresa perfure 
um novo poço de forma lucrativa? Para toda a amostra, as empresas precisam, em média, de US$ 66 por barril para perfu-
rar de forma lucrativa. Em todas as regiões, os preços médios de equilíbrio para perfurar de forma lucrativa variam de US$ 
62 a US$ 70 por barril. Grandes empresas (com produção de petróleo bruto de 10.000 barris por dia ou mais a partir do quar-
to trimestre de 2025) precisam de um preço de US$ 59 por barril para perfurar de forma lucrativa, com base na média das 
respostas das empresas. Em comparação, para pequenas empresas (menos de 10.000 barris por dia), o valor é de US$ 68.  
 
⁹ https://www.dallasfed.org/research/surveys/des/2026/2601#tab-questions  
4

---

Este relatório foi preparado pela ADAMCapital Gestão de Recursos LTDA. (ADAMCapital) e tem caráter meramente informativo, não se constituindo em oferta de venda de cotas dos fundos geridos e não conside-
rando objetivos de investimento ou necessidades individuais e particulares. A ADAMCapital não comercializa e nem distribui cotas de fundos ou qualquer outro ativo financeiro. Recomendamos uma consulta a 
assessores de investimento e profissionais especializados para uma análise específica, personalizada antes de sua decisão sobre investimentos. Aos investidores é recomendada a 
leitura cuidadosa de prospectos e regulamentos ao aplicar seus recursos. Os fundos geridos utilizam estratégias com derivativos como parte integrante de sua política de investimento. 
Tais estratégias, da forma como são adotadas, podem resultar em significativas perdas patrimoniais para seus cotistas, podendo inclusive acarretar perdas superiores ao capital aplica-
do e a consequente obrigação do cotista de aportar recursos adicionais para cobrir o prejuízo do fundo. Os fundos geridos estão autorizados a realizar aplicações em ativos financeiros 
no exterior. Os fundos multimercados podem estar expostos a significativa concentração em ativos de poucos emissores, com os riscos daí decorrentes. Fundos de Investimento não 
contam com a garantia do administrador do fundo, do gestor da carteira, de qualquer mecanismo de seguro ou, ainda, do Fundo Garantidor de Créditos – FGC. A rentabilidade obtida 
no passado não representa garantia de rentabilidade futura. Para avaliação da performance do fundo de investimento, é recomendável uma análise de, no mínimo, 12 (doze) meses. 
Nos fundos geridos pela ADAMCapital a data de conversão de cotas é diversa da data de aplicação e de resgate e a data de pagamento do resgate é diversa da data do pedido de 
resgate. Não há garantia de que os fundos multimercados terão o tratamento tributário para fundos de longo prazo. Este material não pode ser copiado, reproduzido ou distribuído a terceiros sem a expressa 
concordância da ADAMCapital. O regulamento e a lâmina dos fundos podem ser encontrados no website da ADAMCapital: www.adamcapital.com.br . 
Além do provável aumento da produção americana, o consenso das expectativas é de que a produção e escoamento no Ori-
ente Médio começará a ser normalizado rapidamente nos próximos meses. No contexto atual (abril de 2026), com o Estreito 
de Ormuz ainda sob bloqueio parcial e com baixa disposição dos transportadores e das seguradoras de bancarem o risco das 
viagens, a confiança nessas projeções deve ser vista com algum grau de ceticismo, ao menos para o curto prazo. 
Alívios de curto prazo vindos da Venezuela também são pouco prováveis, em vista das dificuldades naturais para repor anos 
de destruição causados pelo socialismo naquele país. A produção lá até aumentou em fevereiro, mas a escala ainda é muito 
pequena: 
 
 
 
 
 
 
 
 
 
 
 
 
 
                                          Fonte: IEA¹⁰ 
  
 
Um outro problema – principalmente para os países importadores líquidos de derivados - é que o fim da guerra não impli-
ca normalização rápida dos preços do petróleo e muito menos em normalização dos preços dos derivados de petróleo, já 
que boa parte da infraestrutura das refinarias da região foi destruída pelos ataques de ambos os lados no Oriente Médio e, 
mesmo antes deste novo conflito, a Ucrânia já estava dizimando parte relevante das refinarias russas.  
 
 
 
 
 
 
 
 
¹⁰ https://iea.blob.core.windows.net/assets/a25ddf53-cd6c-4910-ac90-16bfd28399e7/12MAR2026_OilMarketReport.pdf 
5

---

Este relatório foi preparado pela ADAMCapital Gestão de Recursos LTDA. (ADAMCapital) e tem caráter meramente informativo, não se constituindo em oferta de venda de cotas dos fundos geridos e não conside-
rando objetivos de investimento ou necessidades individuais e particulares. A ADAMCapital não comercializa e nem distribui cotas de fundos ou qualquer outro ativo financeiro. Recomendamos uma consulta a 
assessores de investimento e profissionais especializados para uma análise específica, personalizada antes de sua decisão sobre investimentos. Aos investidores é recomendada a 
leitura cuidadosa de prospectos e regulamentos ao aplicar seus recursos. Os fundos geridos utilizam estratégias com derivativos como parte integrante de sua política de investimento. 
Tais estratégias, da forma como são adotadas, podem resultar em significativas perdas patrimoniais para seus cotistas, podendo inclusive acarretar perdas superiores ao capital aplica-
do e a consequente obrigação do cotista de aportar recursos adicionais para cobrir o prejuízo do fundo. Os fundos geridos estão autorizados a realizar aplicações em ativos financeiros 
no exterior. Os fundos multimercados podem estar expostos a significativa concentração em ativos de poucos emissores, com os riscos daí decorrentes. Fundos de Investimento não 
contam com a garantia do administrador do fundo, do gestor da carteira, de qualquer mecanismo de seguro ou, ainda, do Fundo Garantidor de Créditos – FGC. A rentabilidade obtida 
no passado não representa garantia de rentabilidade futura. Para avaliação da performance do fundo de investimento, é recomendável uma análise de, no mínimo, 12 (doze) meses. 
Nos fundos geridos pela ADAMCapital a data de conversão de cotas é diversa da data de aplicação e de resgate e a data de pagamento do resgate é diversa da data do pedido de 
resgate. Não há garantia de que os fundos multimercados terão o tratamento tributário para fundos de longo prazo. Este material não pode ser copiado, reproduzido ou distribuído a terceiros sem a expressa 
concordância da ADAMCapital. O regulamento e a lâmina dos fundos podem ser encontrados no website da ADAMCapital: www.adamcapital.com.br . 
O ponto mais relevante, contudo, é que mesmo que os preços futuros estivessem muito mais pressionados, os Estados 
Unidos são ganhadores dessa alta porque são grandes produtores de energia e autossuficientes em petróleo, derivados e 
gás. Além disso, para o setor de tecnologia, o preço do petróleo é pouco relevante, representando cerca 10% do custo da 
indústria de semicondutores e muito menos que isso para o consumidor final do setor de inteligência artificial. 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
6

---

Este relatório foi preparado pela ADAMCapital Gestão de Recursos LTDA. (ADAMCapital) e tem caráter meramente informativo, não se constituindo em oferta de venda de cotas dos fundos geridos e não conside-
rando objetivos de investimento ou necessidades individuais e particulares. A ADAMCapital não comercializa e nem distribui cotas de fundos ou qualquer outro ativo financeiro. Recomendamos uma consulta a 
assessores de investimento e profissionais especializados para uma análise específica, personalizada antes de sua decisão sobre investimentos. Aos investidores é recomendada a 
leitura cuidadosa de prospectos e regulamentos ao aplicar seus recursos. Os fundos geridos utilizam estratégias com derivativos como parte integrante de sua política de investimento. 
Tais estratégias, da forma como são adotadas, podem resultar em significativas perdas patrimoniais para seus cotistas, podendo inclusive acarretar perdas superiores ao capital aplica-
do e a consequente obrigação do cotista de aportar recursos adicionais para cobrir o prejuízo do fundo. Os fundos geridos estão autorizados a realizar aplicações em ativos financeiros 
no exterior. Os fundos multimercados podem estar expostos a significativa concentração em ativos de poucos emissores, com os riscos daí decorrentes. Fundos de Investimento não 
contam com a garantia do administrador do fundo, do gestor da carteira, de qualquer mecanismo de seguro ou, ainda, do Fundo Garantidor de Créditos – FGC. A rentabilidade obtida 
no passado não representa garantia de rentabilidade futura. Para avaliação da performance do fundo de investimento, é recomendável uma análise de, no mínimo, 12 (doze) meses. 
Nos fundos geridos pela ADAMCapital a data de conversão de cotas é diversa da data de aplicação e de resgate e a data de pagamento do resgate é diversa da data do pedido de 
resgate. Não há garantia de que os fundos multimercados terão o tratamento tributário para fundos de longo prazo. Este material não pode ser copiado, reproduzido ou distribuído a terceiros sem a expressa 
concordância da ADAMCapital. O regulamento e a lâmina dos fundos podem ser encontrados no website da ADAMCapital: www.adamcapital.com.br . 
O risco de inépcia dos bancos centrais ao choque de oferta 
O risco inflacionário é significativamente maior nas economias mais dependentes da importação de derivados, como é o 
caso do Leste Asiático, Oceania, Europa e Brasil. Nestas geografias, incluindo a China, o coeficiente de importação líquida de 
petróleo é elevado. Um agravante da Europa e do Brasil é o baixo crescimento da produtividade e o mercado de trabalho 
aquecido, o que tende a acentuar os impactos secundários do choque sobre os núcleos de inflação. 
Os banqueiros centrais, por sua vez, estão mostrando reações assimétricas diante do choque de oferta, mas de uma forma 
geral parece haver uma preferência por estratégias de acomodação do choque primário sobre a inflação cheia ou mesmo 
dos efeitos secundários sobre os núcleos da inflação, evitando-se ou adiando uma abordagem de subida das taxas de juros, 
agindo de forma semelhante à postura que adotaram diante dos choques do petróleo dos anos 70 e que culminou em forte 
aceleração da inflação e do desemprego, seguida da nomeação de Paul Volker, conforme podemos ler nos próprios registros 
públicos do Fed a este respeito: 
“Through early 1978, the Federal Reserve had maintained a highly accommodative stance of monetary policy, hoping to 
combat rising unemployment. Ultimately, though, the policies showed little success in stifling the deterioration in the 
unemployment rate and likely fostered an environment that allowed the rising energy prices to be transmitted into more 
general inflation. Consumer inflation, which had already begun to accelerate in the United States, continued to rise - from 
below 5 percent in early 1976 to nearly 7 percent by March 1979. By that time, unease among members of the Federal Open 
Market Committee (FOMC) that inflation could continue to rise was growing. Records from the meeting of the FOMC on Fe-
bruary 28, 1978, indicate that "considerable concern was expressed that the rate of inflation might accelerate significantly as 
the year progressed [and could] pose difficult questions concerning the appropriate role of monetary policy." Nevertheless, 
the committee voted unanimously to keep the policy rate unchanged. 
Despite increasing concern among the public and members of the FOMC about the declining value of the dollar and rising 
pace of inflation, the committee remained hesitant to raise interest rates too aggressively, fearful of stifling fragile econo-
mic growth. The Fed raised the federal funds rate from 6.9 percent in April 1978 to 10 percent by the end of the year. The 
increase was a clear move to try to curb rising inflation. However, modern economic historians now see the increases as 
timid and insufficient to stem a surge in inflationary pressure, which had already become entrenched in the American 
psyche and economy. Twelve-month consumer price index inflation rose to 9 percent by the end of 1979. 
The Carter administration's decision to appoint Paul Volcker as Fed chairman in August 1979 was a strong endorsement of 
using more aggressive monetary policy to try to break inflation's stranglehold on the US economy. As the president of the 
Federal Reserve Bank of New York, Volcker had been an outspoken proponent of using monetary policy to combat rising infla-
tion.¹¹ ” 
Nos Estados Unidos, mesmo antes da guerra, a projeção para o núcleo da inflação medida pelo PCE já estava subindo por 
fatores como o encarecimento de memória e seu consequente impacto na inflação de bens. Àquela altura, já parecia pro-
vável que fecharia este ano acima de 3%. Agora, ainda que o choque de oferta seja menos intenso nos EUA em relação a 
outras 9 maiores economias, não seria absurdo vermos o núcleo do PCE subindo além de 3,5% na comparação anual, mesmo 
contando com o efeito deflacionário produzido pelo aumento da produtividade via IA¹².  
 
 
 
 
¹¹ Fonte: https://www.federalreservehistory.org/essays/oil-shock-of-1978-79 
 
¹² Segundo declarações recentes e estudos do próprio Fed, a taxa de geração de empregos nos últimos meses tem ficado em patamar acima do nível consi-
derado neutro para a taxa de desemprego, que assim poderia seguir estável em patamar historicamente baixo ou até mesmo caindo.  
7

---

Este relatório foi preparado pela ADAMCapital Gestão de Recursos LTDA. (ADAMCapital) e tem caráter meramente informativo, não se constituindo em oferta de venda de cotas dos fundos geridos e não conside-
rando objetivos de investimento ou necessidades individuais e particulares. A ADAMCapital não comercializa e nem distribui cotas de fundos ou qualquer outro ativo financeiro. Recomendamos uma consulta a 
assessores de investimento e profissionais especializados para uma análise específica, personalizada antes de sua decisão sobre investimentos. Aos investidores é recomendada a 
leitura cuidadosa de prospectos e regulamentos ao aplicar seus recursos. Os fundos geridos utilizam estratégias com derivativos como parte integrante de sua política de investimento. 
Tais estratégias, da forma como são adotadas, podem resultar em significativas perdas patrimoniais para seus cotistas, podendo inclusive acarretar perdas superiores ao capital aplica-
do e a consequente obrigação do cotista de aportar recursos adicionais para cobrir o prejuízo do fundo. Os fundos geridos estão autorizados a realizar aplicações em ativos financeiros 
no exterior. Os fundos multimercados podem estar expostos a significativa concentração em ativos de poucos emissores, com os riscos daí decorrentes. Fundos de Investimento não 
contam com a garantia do administrador do fundo, do gestor da carteira, de qualquer mecanismo de seguro ou, ainda, do Fundo Garantidor de Créditos – FGC. A rentabilidade obtida 
no passado não representa garantia de rentabilidade futura. Para avaliação da performance do fundo de investimento, é recomendável uma análise de, no mínimo, 12 (doze) meses. 
Nos fundos geridos pela ADAMCapital a data de conversão de cotas é diversa da data de aplicação e de resgate e a data de pagamento do resgate é diversa da data do pedido de 
resgate. Não há garantia de que os fundos multimercados terão o tratamento tributário para fundos de longo prazo. Este material não pode ser copiado, reproduzido ou distribuído a terceiros sem a expressa 
concordância da ADAMCapital. O regulamento e a lâmina dos fundos podem ser encontrados no website da ADAMCapital: www.adamcapital.com.br . 
  
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
Os dados têm mostrado que a taxa de desemprego está em patamares historicamente baixos neste início de ano na quase 
totalidade das economias relevantes do G-20, com exceção da China, onde os dados são pouco confiáveis.  
Por outro lado, o “estresse” causado pela queda das bolsas e pelos temores de crédito também se mostraram insuficien-
tes – até aqui – para produzir uma alta significativa do indicador de condições financeiras globais, conforme podemos obser-
var no gráfico a seguir.  
 
 
 
 
 
 
8

---

Este relatório foi preparado pela ADAMCapital Gestão de Recursos LTDA. (ADAMCapital) e tem caráter meramente informativo, não se constituindo em oferta de venda de cotas dos fundos geridos e não conside-
rando objetivos de investimento ou necessidades individuais e particulares. A ADAMCapital não comercializa e nem distribui cotas de fundos ou qualquer outro ativo financeiro. Recomendamos uma consulta a 
assessores de investimento e profissionais especializados para uma análise específica, personalizada antes de sua decisão sobre investimentos. Aos investidores é recomendada a 
leitura cuidadosa de prospectos e regulamentos ao aplicar seus recursos. Os fundos geridos utilizam estratégias com derivativos como parte integrante de sua política de investimento. 
Tais estratégias, da forma como são adotadas, podem resultar em significativas perdas patrimoniais para seus cotistas, podendo inclusive acarretar perdas superiores ao capital aplica-
do e a consequente obrigação do cotista de aportar recursos adicionais para cobrir o prejuízo do fundo. Os fundos geridos estão autorizados a realizar aplicações em ativos financeiros 
no exterior. Os fundos multimercados podem estar expostos a significativa concentração em ativos de poucos emissores, com os riscos daí decorrentes. Fundos de Investimento não 
contam com a garantia do administrador do fundo, do gestor da carteira, de qualquer mecanismo de seguro ou, ainda, do Fundo Garantidor de Créditos – FGC. A rentabilidade obtida 
no passado não representa garantia de rentabilidade futura. Para avaliação da performance do fundo de investimento, é recomendável uma análise de, no mínimo, 12 (doze) meses. 
Nos fundos geridos pela ADAMCapital a data de conversão de cotas é diversa da data de aplicação e de resgate e a data de pagamento do resgate é diversa da data do pedido de 
resgate. Não há garantia de que os fundos multimercados terão o tratamento tributário para fundos de longo prazo. Este material não pode ser copiado, reproduzido ou distribuído a terceiros sem a expressa 
concordância da ADAMCapital. O regulamento e a lâmina dos fundos podem ser encontrados no website da ADAMCapital: www.adamcapital.com.br . 
A crítica à política monetária no Brasil  
Observamos atualmente uma desconexão preocupante entre a precificação de ativos e as nossas projeções inflacionárias 
de curto e longo prazos. Embora boa parte do mercado mantenha a tese de que o caminho correto é o corte de juros, nem 
mesmo os modelos do consenso de mercado apresentam um IPCA de 12 meses abaixo dos níveis atuais, nem para 2026, 
nem para 2027. Pelo contrário: as projeções indicam uma aceleração inflacionária sistemática até o final deste ano (e já indi-
cavam isso antes da eclosão do recente conflito no Oriente Médio). 
É fundamental ressaltar, portanto, que essa nossa visão de cautela já era válida antes mesmo da recente escalada do pe-
tróleo. Os fundamentos para o ceticismo permanecem os mesmos que temos levantado consistentemente: a pressão de 
gastos fiscais em pleno ano eleitoral, a persistência de políticas de crédito expansionistas e uma inflação de serviços muito 
elevada e que se recusa a ceder. O choque energético atual apenas expõe e acelera as fragilidades de um cenário que já 
apresentava sinais de desequilíbrio. 
Há também o agravante das interferências governamentais na formação de preços dos derivados. A forte queda das impor-
tações em março é reflexo direto desse controle de preços domésticos, que desestimula ou inviabiliza as compras externas. 
Segundo nossas estimativas, esse cenário faz com que o estoque atual de diesel seja suficiente para apenas 60 a 70 dias de 
consumo, mesmo já computada a produção local.  
Trata-se, portanto, de um risco muito elevado de desabastecimento local que poderia complicar bastante o cenário para o 
frete e os preços dos alimentos, que já sofrem diante do aumento de preço dos fertilizantes (também causado pela disrup-
ção de oferta no Oriente Médio). 
Nesse contexto, a estratégia de cortes de juros diante de uma inflação que se projeta em trajetória ascendente configura 
um erro de leitura de ciclo, em nossa visão. 
Em termos da nossa estratégia de investimentos, diante do cenário exposto, temos as seguintes posições: 
Comprados: Setor de tecnologia americano (Nasdaq) e dólar (contra Real e Euro); 
• Vendidos: Bolsas alemã e brasileira; 
• Tomados: Juros e inflação locais (Brasil). 
9

---

Contato 
comercial@adamcapital.com.br 
ADAM Capital 
Rua Dias Ferreira, 190 – sala 502 – Leblon 
Rio de Janeiro, Brazil – CEP 22431-050 
+55 21 3993-7000 
 
www.adamcapital.com.br 
ADAM 
ADVANCED  
ADAM 
PREV  
ADAM 
MACRO  
saiba mais 
saiba mais  
saiba mais  
CONHEÇA OS 
FUNDOS DA ADAM|CAPITAL 
ADAM 
RENDA FIXA 
ADAM 
RENDA FIXA    
ATIVA PREV 
saiba mais  
saiba mais  
ATIVA