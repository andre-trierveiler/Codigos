

---

C A R T A  D E  G E S T Ã O
C A R T A  M E N S A L  ·  A B R I L  2 0 2 6
Inteligência artificial, choques de 
oferta e a função de reação do 
Banco Central.
01 · Cenário Global
A revolução silenciosa da IA
02 · Cenário Doméstico
Brasil favorecido no curto prazo
03 · Política Monetária
Acomodação por esperança

---

C A R T A  D E  G E S T Ã O  ·  A B R I L  2 0 2 6
A D A M  C A P I T A L
A P R E S E N T A Ç Ã O
Nesta Carta abordamos basicamente três assuntos. No cenário internacional: (i) a persistência da discrepância entre o nosso 
diagnóstico de importância crescente do tema de inteligência artificial (IA) versus as narrativas predominantes do mercado, 
que segue muito mais atento aos desdobramentos da guerra; (ii) a falta de comprometimento dos bancos centrais em todo o 
mundo em combater o efeito inflacionário derivado das pressões de demanda e de oferta e, no plano doméstico, (iii) o peso 
decrescente que o Banco Central do Brasil vem dando aos desvios da inflação em relação à meta.
0 1  ·  C E N Á R I O  G L O B A L
A maior revolução industrial da história humana em andamento.
Enquanto o ruído das guerras no Oriente Médio continua dominando as manchetes e direcionando os mercados no curto prazo,
um processo muito mais transformador se desenrola silenciosamente: a ascensão da IA. Não vemos exagero em descrevê-la como
a maior revolução industrial da história humana — ainda que estejamos apenas na antessala de seus estágios iniciais. Seus efeitos
vão além da economia: vão redefinir o trabalho, o conhecimento, as relações sociais e o próprio equilíbrio de poder global.
Os Estados Unidos têm liderado com folga esta nova revolução, e não por outro motivo já se percebem mudanças no padrão do seu
mercado de trabalho: apesar da situação de geração de novas vagas de trabalho seguir positiva em virtude do robusto crescimento
econômico da sua demanda doméstica — entre 2% e 3% ao longo dos últimos trimestres — a situação está mudando para os
trabalhadores do setor de tecnologia, como se depreende pelos gráficos a seguir.
Gráfico 1. Participação de tecnologia no total de empregados nos EUA e taxa de desemprego (total e 20–24 anos). Fonte: FRED, ADAM Capital.
Apesar deste corte sugerir uma perspectiva pior para o emprego para algumas atividades, é muito provável que não faltarão
oportunidades em outros setores que estão se expandindo a taxas exponencialmente maiores, como a mão de obra para construir
ou manter data centers , por exemplo.
ADAM CAPITAL · CARTA DE GESTÃO · ABRIL 2026
PÁGINA 02 · 08

---

C A R T A  D E  G E S T Ã O  ·  A B R I L  2 0 2 6
0 1  ·  C E N Á R I O  G L O B A L
O termômetro do mercado de trabalho é o salário médio por hora trabalhada, que já estava crescendo em um ritmo razoável e
recentemente voltou a acelerar, principalmente no caso dos trabalhadores que trocam de emprego (os Job Switchers estão
recebendo, em média, 5% a mais que no mesmo mês do ano passado):
Gráfico 2. Indicador de crescimento de salários do Fed de Atlanta (médias móveis de 3 meses). Fonte: Current Population Survey, BLS, Fed eral Reserve Bank of Atlanta.
Prever o resultado deste processo é uma tarefa bastante complexa e sujeita a erros, principalmente em torno das defasagens
temporais envolvidas nos ciclos de investimento, produtividade, emprego e inflação. Dito isso, já argumentamos em
comunicações anteriores que é possível deduzir 1 (e não apenas induzir) que o capital se tornará crescentemente mais
caro, em virtude da competição por formas de financiamento por parte das empresas líderes dos segmentos de bens finais e
insumos necessários de alta tecnologia.
A "nova corrida do ouro" tem encarecido o custo de memória RAM e de outros insumos, causando uma aceleração da inflação
de bens como celulares, computadores etc., o que no fundo é um tipo de inflação derivada de um choque de demanda
(originada sobretudo pela aceleração do investimento em IA).
Já quando os choques de oferta passam e a inflação temporariamente recua, argumenta-se "a inflação caiu por efeito da defasagem
da política monetária contracionista". Esse ciclo de narrativas tem sido recorrente pelo menos desde os anos 70 (era uma das
críticas que Milton Friedman fazia àquela época).
Isso ocorre porque os banqueiros centrais sabem que precisam combater os efeitos inflacionários oriundos de ciclos de expansão
da demanda, mas acabam ignorando o simples combate aos efeitos secundários de choques de oferta diante dos alegados "riscos
baixistas para a atividade global".
1Diferentemente da dedução, a indução não garante a verdade, apenas a probabilidade. Se você diz "o capital subiu em todas as revoluções
tecnológicas anteriores, logo subirá nesta", você está fazendo uma indução. É um palpite educado baseado em padrões, não uma necessidade
lógica. Não estamos apenas olhando para o passado e esperando que ele se repita (indução); estamos analisando a estrutura atual do capital e
concluindo que o aumento do custo é uma necessidade lógica (dedução).
ADAM CAPITAL · CARTA DE GESTÃO · ABRIL 2026
PÁGINA 03 · 08
Por outro lado, há muito tempo o mercado procura por "desculpas" pelo lado da oferta para a subida da inflação e dos juros no
mundo e a guerra no Oriente Médio é o pretexto do momento. Entramos no sexto ano consecutivo em que a inflação
americana fica sensivelmente acima da meta de 2% do Fed e a cada choque de oferta, coloca-se a culpa de todo o processo
inflacionário no evento x, y ou z de "choque de oferta", com os bancos centrais de uma forma geral se eximindo das suas
responsabilidades.

---

C A R T A  D E  G E S T Ã O  ·  A B R I L  2 0 2 6
0 1  ·  C E N Á R I O  G L O B A L
Neste ínterim, paralelamente, outro fator ganha relevância: a alta nos yields de longo prazo observada recentemente no mundo.
Parte dessa pressão pode estar vindo justamente dos investimentos maciços em infraestrutura de IA — data centers , redes de
energia, chips e capacidade computacional — necessários para suportar o crescimento exponencial da demanda por tokens e
inferência de modelos. Não por outro motivo, já se observam números recordes de captação de bonds das companhias deste setor.
Nos anos 90, o ciclo de investimento em capital causado pelo advento da internet acabou "drenando" muitos recursos para os
Estados Unidos, produzindo efeitos secundários bastante relevantes na economia mundial e nos preços dos ativos: o dólar se
valorizou fortemente contra o euro, por exemplo, subindo quase 60% entre meados do ano de 1995 e o final de 2000 2, e muitas
economias emergentes entraram em crises cambiais durante este mesmo período, como México, Coreia do Sul, Tailândia, Rússia,
Brasil etc.
Gráfico 3. Euro/Dólar (médias mensais das cotações diárias) versus Ln(Nasdaq) — eixo direito. Fonte: Federal Reserve Bank of St. Louis.
Conforme já dissemos em outras publicações, temos observado uma pressão nos juros longos em vários países, mas o caso
particular do Japão é particularmente ilustrativo. Faz sentido pensar a taxa de juros de 1 dia daquele país como sendo um dos
principais contribuidores para uma espécie de "taxa básica do mundo" , em virtude de ela ser baixa (até o início de 2024 era
negativa, atualmente ela se encontra em 0,75%). Quando olhamos para a taxa de 10 anos deles, ela se encontra atualmente em
torno de 2,5% e está subindo pelo 6º ano consecutivo diante de uma inflação de salários substancialmente maior que o nível
observado nas décadas anteriores (mesmo os juros de 10 anos era próximo de zero até 2022).
No dia 30 de abril, o Banco Central do Japão (BoJ ) voltou a intervir no mercado de câmbio a fim de conter a desvalorização do
iene contra o dólar, evitando que a moeda ultrapassasse a barreira de 160, o que elevou ainda mais a pressão sobre a curva de
juros longa (3). Este fato pode ser um sinal de que aquele movimento global de enfraquecimento do dólar, observado no ano
passado, pode ter passado ou mesmo já estar se invertendo.
2 https://fred.stlouisfed.org/graph/?id=CCUSMA02EZM618N
3 Voltando um pouco mais no tempo, no início do boom de internet nos anos 90, os juros de 10 anos no Japão chegaram a subir para o patamar de 8%...

---

C A R T A  D E  G E S T Ã O  ·  A B R I L  2 0 2 6
0 2  ·  C E N Á R I O  D O M É S T I C O
0 2  ·  C E N Á R I O  D O M É S T I C O
Brasil: favorecido no curto prazo, fragilidade estrutural.
O Brasil segue sendo um destino procurado pelos investidores globais de curto prazo, mas o fluxo cambial, bem como a nossa
conta corrente, continua bem negativo. Então, apesar da melhoria na balança comercial ser um detalhe relevante, ela mostra um
retrato parcial, como explicamos a seguir.
Os números da balança comercial de fato melhoraram e isto tem muito a ver com o aumento da produção e do preço do petróleo,
do lado das exportações. As importações, por outro lado, seguem contidas mesmo diante de uma demanda doméstica pujante e da
valorização da nossa moeda para perto de R$ 5,00 — o que pode ter relação com o forte aumento da alíquota média efetiva de
importações (tarifas alfandegárias), de cerca de 38% em março deste ano , em relação ao patamar praticado no mesmo mês do
ano passado no caso do imposto de importação (segundo informações da própria Receita Federal).
Por outro lado, o déficit em conta corrente segue em torno de 3% do PIB e poderia estar pior, indo para 4%, se não fosse essa
melhoria observada em nossa balança comercial. Ainda assim, a tendência de longo prazo das contas externas continua sendo de
deterioração, porque o passivo externo líquido não para de aumentar e o impulso monetário advindo da expansão de cerca de 10%
ao ano do nosso M2 atua no sentido de ampliar este déficit ao longo do tempo.
Há também um ponto que já explicamos em outra Carta a respeito da parcela do déficit em conta corrente ligada aos serviços do
setor de tecnologia, como aplicativos de IA, locomoção, streaming etc. Estes serviços apresentam um crescimento de demanda
estrutural e pouco sensível aos ciclos domésticos e à taxa de câmbio: a regressão baseada nestas duas variáveis deixou de funcionar
a partir de 2020, passando a subestimar de forma crescente estas contas.
Então, neste caso, e diante de um câmbio que já valorizou mais de 25% em termos nominais em relação às máximas observadas
desde 2024, seguimos com uma visão estruturalmente ruim para a nossa moeda a longo prazo , ainda mais se levarmos
em conta que o dólar globalmente pode ter passado pela sua fase de desvalorização, conforme explicado na parte internacional
desta carta.
ADAM CAPITAL · CARTA DE GESTÃO · ABRIL 2026
PÁGINA 05 · 08
4 Ver no site da Receita Federal do Brasil (RFB) em Análise Mensal – Mar 2026, p. 5 (https://www.gov.br/receitafederal/pt-br/centrais-de-conteudo/publicacoes/relatorios/arrecadacao-
federal/2026)
V E TORE S  ADI CI ON AI S  S OBRE  A CURV A DE  JUROS
O investimento em IA pode ser uma das causas por trás desta 
inclinação crescente das curvas de juros, mas também há 
outros fatores relevantes: (ii) demografia pior, (iii) 
envelhecimento populacional, desglobalização diante do 
“reshoring” (volta das empresas para seu país de origem), (iv) 
aumento do investimento em energia verde nos últimos anos e 
(v) aumento dos gastos públicos com assistência social e 
corrida armamentista, constituem-se fatores adicionais de 
pressão sobre a inclinação das curvas de juros.
Gráfico 4. Japão — Taxa de juros de 10 anos. Fonte: Bloomberg.
Fonte: Bloomberg
Japão - Taxa de juros de 10 anos
-20%
30%
80%
130%
180%
230%
280%
2015
2018
2021
2024
#REF!
Projeção
-0.5
0.0
0.5
1.0
1.5
2.0
2.5
3.0

---

C A R T A  D E  G E S T Ã O  ·  A B R I L  2 0 2 6
0 3  ·  P O L Í T I C A  M O N E T Á R I A
0 3  ·  P O L Í T I C A  M O N E T Á R I A
Acomodação por esperança.
O último assunto diz respeito à nossa percepção de que os bancos centrais como um todo e, particularmente, o BCB, parecem
nutrir a esperança de que os choques de oferta se dissipem rapidamente, evitando a necessidade de aperto monetário. No entanto,
o que antes era uma percepção qualitativa, agora ganha contornos nítidos através de nossas estimativas para o caso brasileiro.
Ao analisarmos a sensibilidade da função de reação do BCB — utilizando o Filtro de Kalman com parâmetros variantes no
tempo (TVP)5 — observamos uma mudança estrutural preocupante na condução da política monetária. Nossas estimativas da
Regra de Taylor mostram que a disposição do Banco Central em reagir a desvios das expectativas de inflação vem sofrendo uma
queda consistente.
O ponto que chama a atenção é o retrocesso da vigilância: enquanto a sensibilidade ao desvio de inflação atingiu picos próximos a
3 na gestão anterior a 2019 e logo no início do mandato anterior (até o período imediatamente anterior à pandemia), os dados
atualmente mostram uma convergência para níveis historicamente baixos, flutuando ao redor de 2 . Por outro lado, é justo dizer
que este parâmetro já havia piorado bastante a partir de 2020.
Mesmo quando ajustamos o modelo para incluir o ciclo do desemprego, o padrão se repete: o BCB está reagindo menos aos
desvios da inflação do que reagiu em ciclos anteriores de pressão.
Gráfico 5. Sensibilidade da função de reação ao desvio das expectativas de inflação — Filtro de Kalman com parâmetros variantes no tempo (TVP). Fonte: ADAM Capital. * 
Equação de Taylor usada no MSPP do BCB. ** Equação de Taylor modificada pela ADAM Capital.
*MSPP: modelo semiestrutural de pequeno porte do BCB.6
5 Modelos de Time-Varying Parameter (TVP), ou Parâmetros Variantes no Tempo, na abordagem Bayesiana, são modelos estatísticos onde os coeficientes de regressão não são fixos, mas
evoluem ao longo do tempo. O parâmetro central estimado é o θ_π (sensibilidade da Selic real ao desvio da inflação esperada em relação à meta): valores próximos de 3 indicam reação agressiva;
valores em torno de 2, postura mais acomodatícia. A estimativa usa um modelo de espaço de estados resolvido pelo Filtro de Kalman, que atualiza recursivamente θ_π a cada período conforme
chegam novos dados (Selic, inflação esperada pelo Focus, hiato do produto). A abordagem Bayesiana controla a variância dos parâmetros — técnica padrão na literatura de política monetária com
coeficientes variantes no tempo.
ADAM CAPITAL · CARTA DE GESTÃO · ABRIL 2026
PÁGINA 06 · 08

---

C A R T A  D E  G E S T Ã O  ·  A B R I L  2 0 2 6
0 3  ·  P O L Í T I C A  M O N E T Á R I A
Essa menor reatividade explica o comportamento da Selic frente ao IPCA no horizonte relevante de 18 meses à frente (HR) das
projeções do Copom para a inflação medida pelo IPCA. Como demonstram as projeções deles mesmos, o IPCA projetado para HR
subiu de 3,3% para 3,5%, mas enquanto isso a autoridade monetária sinaliza que continuará cortando a Selic.
A penúltima vez que a projeção para o HR subiu de 3,4% para 3,5% foi entre julho e setembro de 2024, quando o Copom iniciou
um ciclo de alta da Selic , conforme podemos ver pelo gráfico a seguir:
Gráfico 6. IPCA no Horizonte Relevante e Mudança na Selic. Fonte: ADAM Capital.
A desconexão é clara: o Banco Central está operando com um viés de "acomodação por esperança" . Ao reduzir a taxa de juros —
em um cenário onde a inflação se mantém persistentemente acima da meta — o BCB assume o risco de desancorar as expectativas
de longo prazo.
Assim, a conclusão é que a função de reação do Banco Central está menos sensível à inflação e pode estar
ponderando mais o risco de atividade futura (possibilidade de piora do crédito?) ou mesmo surfando uma taxa
de câmbio conjunturalmente mais apreciada. Contudo, se a instituição continuar reagindo menos à inflação, o
custo para trazer os preços de volta à meta no futuro será, dedutivamente (e não apenas por indução), muito
mais elevado para a economia brasileira .
6 Relatório de Inflação de junho de 2024 (https://www.bcb.gov.br/content/ri/relatorioinflacao/202406/ri202406b12p.pdf).
1. Regra de Taylor retirada do modelo agregado do BCB:
i_t = θ₁i_{t-1} + θ₂i_{t-2} + (1 − θ₁ − θ₂)[(r*_t + π^meta_t) + θ₃(E_t[π_{t+4}] − π^meta_t)] + ε_t
2. Regra de Taylor que adotamos:
i_t − π^meta_t = r*_t + θ_π(E_t[π_{t+1}] − π^meta_t) + θ_d y^ciclo_t + ε_t
ADAM CAPITAL · CARTA DE GESTÃO · ABRIL 2026
PÁGINA 07 · 08

---

C A R T A  D E  G E S T Ã O  ·  A B R I L  2 0 2 6
P O S I C I O N A M E N T O  D O S  F U N D O S
P O S I C I O N A M E N T O  D O S  F U N D O S
Como esses diagnósticos se traduzem na carteira.
Em nossa estratégia de investimentos, a alocação em ações americanas do setor de tecnologia segue sendo o destaque. Esta posição tende a continuar
maximizando o retorno da carteira diante da inevitável aceleração do uso da IA como ferramenta de ganho de produtividade. Vale repetir que entendemos que o
mercado continua subestimando o caráter exponencial dos investimentos neste setor.
Atenciosamente,
ADAM Capital
Gestão de Recursos · Abril 2026
Para dúvidas e sugestões 
contato@adamcapital.com.br
Este relatório foi preparado pela ADAMCapital Gestão de Recursos LTDA. (ADAMCapital) e tem caráter meramente informativo, não se constituindo em oferta de venda de cotas dos fundos geridos e não
considerando objetivos de investimento ou necessidades individuais e particulares. A ADAMCapital não comercializa e nem distribui cotas de fundos ou qualquer outro ativo financeiro. Recomendamos
uma consulta a assessores de investimento e profissionais especializados para uma análise específica, personalizada antes de sua decisão sobre investimentos. Aos investidores é recomendada a leitura
cuidadosa de prospectos e regulamentos ao aplicar seus recursos. Os fundos geridos utilizam estratégias com derivativos como parte integrante de sua política de investimento. Tais estratégias, da forma
como são adotadas, podem resultar em significativas perdas patrimoniais para seus cotistas, podendo inclusive acarretar perdas superiores ao capital aplicado e a consequente obrigação do cotista de
aportar recursos adicionais para cobrir o prejuízo do fundo. Os fundos geridos estão autorizados a realizar aplicações em ativos financeiros no exterior. Os fundos multimercados podem estar expostos a
significativa concentração em ativos de poucos emissores, com os riscos daí decorrentes. Fundos de Investimento não contam com a garantia do administrador do fundo, do gestor da carteira, de
qualquer mecanismo de seguro ou, ainda, do Fundo Garantidor de Créditos – FGC. A rentabilidade obtida no passado não representa garantia de rentabilidade futura. Para avaliação da performance do
fundo de investimento, é recomendável uma análise de, no mínimo, 12 (doze) meses. Nos fundos geridos pela ADAMCapital a data de conversão de cotas é diversa da data de aplicação e de resgate e a
data de pagamento do resgate é diversa da data do pedido de resgate. Não há garantia de que os fundos multimercados terão o tratamento tributário para fundos de longo prazo. Este material não pode
ser copiado, reproduzido ou distribuído a terceiros sem a expressa concordância da ADAMCapital. O regulamento e a lâmina dos fundos podem ser encontrados no website da ADAMCapital:
www.adamcapital.com.br.
ADAM CAPITAL · CARTA DE GESTÃO · ABRIL 2026
PÁGINA 08 · 08
C O M P R A D O
Equities · Tecnologia EUA
Alocação em ações americanas de tecnologia diante da aceleração inevitável do uso da IA como ferramenta de ganho de 
produtividade.
V E N D I D O
Cesta de Moedas vs. USD
Exposição líquida vendida em algumas moedas contra o dólar.
T O M A D O
Juros local
Posições tomadas em juros nominais e em inflação implícita.