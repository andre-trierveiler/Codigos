

---

C A R T A  D E  G E S T Ã O
C A R T A  M E N S A L  ·  M A I O  2 0 2 6
O valor intrínseco dos ativos
01 · Cenário Global
Fronteira Tecnológica, 
Inflação e a Assimetria dos 
Bancos Centrais
02 · Cenário Doméstico
O Alerta Fiscal e a Ilusão do 
Crescimento
03 · Portfólio
Posicionamento dos Fundos

---

C A R T A  D E  G E S T Ã O  ·  M A I O 2 0 2 6
0 1  ·  C E N Á R I O  G L O B A L
Fronteira Tecnológica, Inflação e a Assimetria dos Bancos Centrais
ADAM CAPITAL · CARTA DE GESTÃO · MAIO 2026
PÁGINA 02 · 08
A relação entre taxas de juros, preferência temporal e a criação de malinvestments é um pilar da Teoria Austríaca dos Ciclos 
Econômicos, formulada originalmente por Ludwig von Mises em 'Ação Humana'. Nela, Mises demonstrou que juros 
manipulados abaixo do nível de mercado sinalizam uma falsa abundância de poupança, distorcendo o cálculo econômico.
Essa distorção analítica é complementada pela crítica estrutural de Murray N. Rothbard sobre a tendência inflacionária e 
centralizadora das autoridades monetárias:
"A tendência natural do governo, uma vez no controle do dinheiro, é inflacionar e destruir o valor da moeda... Esse 'boom' 
resultante é falso; tudo o que acontece é que mais dinheiro disputa os recursos existentes, fazendo com que os preços subam. 
Uma vez estabelecida uma mercadoria como moeda no mercado, nenhuma quantidade a mais de moeda é necessária. Como a 
única utilidade do dinheiro é a troca e o cálculo, mais unidades monetárias em circulação não conferem nenhum benefício 
social; elas simplesmente diluem o valor de troca de cada unidade existente.“
— Murray N. Rothbard, Essentials of Money and Inflation.
Após décadas de uma expansão fiscal inconsequente - que elevou o endividamento público global -, os juros futuros seguem
subindo para patamares inéditos desde o início do século. Esse movimento ocorre após mais de uma década de taxas
excepcionalmente baixas nos EUA, Japão e Europa. Sempre argumentamos que a verdadeira anomalia não está nos níveis
atuais, mas sim nos patamares vigentes entre 2011 e 2022. Naquela época, experimentos monetários heterodoxos conduziram o
mundo a uma fase de absoluta irresponsabilidade. Os bancos centrais inflaram enormemente seus balanços para absorver as
dívidas crescentes dos Tesouros Nacionais, passivos privados e até mesmo ações de empresas, como ocorreu no Japão.
Essa transição de regime expõe a mecânica fundamental do desconto de fluxos de caixa: a alta das taxas de juros penaliza
severamente os ativos cujos retornos não geram caixa, tais como o ouro, prata, bitcoin etc. Em contrapartida, ela valoriza ativos
ancorados em múltiplos realistas e na geração robusta de caixa atual e futuro, como as ações de tecnologia ligadas ao setor de
inteligência artificial. Esse fenômeno se conecta diretamente aos ensinamentos da Escola Austríaca de Economia: períodos
prolongados de juros artificialmente baixos distorcem a taxa natural de preferência temporal, induzindo o mercado a canalizar
capital para projetos economicamente inviáveis a longo prazo - os chamados malinvestments (investimentos ruins). É possível
que todo aquele período de infinitos Quantitative Easings (QEs) inaugurado com a crise de 2008 e que perdurou até depois da
pandemia tenha condicionado uma geração inteira de investidores a acreditar na sustentabilidade de investimentos ruins.
Porém, na medida em que o regime de juros vai se normalizando, essas distorções são expostas, punindo os ativos sem lastro de
caixa real.
1 https://mises.org/online-book/rothbard-reader/chapter-18-essentials-money-and-inflation
No plano global, o foco central permanece nos Estados Unidos como o polo dinâmico da fronteira tecnológica. É fundamental
destacar que o PIB nominal norte-americano, ainda que subestimado pelo surgimento do "PIB fantasma" (Phantom GDP
decorrente da subnotificação dos investimentos e do uso de Inteligência Artificial nos dados estatísticos oficiais, fundamentado em
estudos de mensuração econômica de think tanks globais como o Brookings Institution), tem crescido desde 2021 em um ritmo
bem superior ao de seus pares europeus e ao da própria China.

---

C A R T A  D E  G E S T Ã O  ·  M A I O 2 0 2 6
0 1  ·  C E N Á R I O  G L O B A L
ADAM CAPITAL · CARTA DE GESTÃO · MAIO 2026
PÁGINA 03 · 08
Gráfico 1. Evolução do PIB nominal em dólares de China e EUA (jan/2019=100). Fonte: Bloomberg, Adam Capital.
Embora a última divulgação oficial de dados tenha mostrado a renda pessoal estagnada no mês de abril e, consequentemente, uma
queda na taxa de poupança das famílias para o menor nível em vários anos, avaliamos esse indicador de curto prazo com
ceticismo. Historicamente, esses dados macroeconômicos iniciais de renda são eivados de ruídos e passam por revisões
abrangentes subsequentes, que podem alterar materialmente a leitura inicial, seguindo o padrão observado ano após ano nos
Estados Unidos. Diante dessa volatilidade e distorção estatística, preferimos ancorar nossa análise no Employment Cost Index
(ECI). O ECI, por ser um indicador estruturalmente mais robusto e menos sujeito a variações erráticas, tem sinalizado uma
expansão sólida e consistente da renda norte-americana em um patamar próximo a 4% ao ano. Esse dado chancela a nossa tese de
resiliência e sustentabilidade da demanda agregada na economia americana.
Gráfico 2. Evolução da renda pessoal nominal dos EUA, conforme diferentes divulgações/revisões da série. Fonte: ALFRED, Adam Capital .

---

C A R T A  D E  G E S T Ã O  ·  M A I O 2 0 2 6
0 1  ·  C E N Á R I O  G L O B A L
Gráfico 3. Evolução da taxa de poupança pessoal dos EUA, conforme diferentes divulgações/revisões da série. Fonte: ALFRED, Adam Capital .
Quanto à inflação americana, mantemos uma postura de dúvida razoável. Há forças nitidamente opostas atuando: vetores
inflacionários, como gastos militares em guerra, pressões conjunturais nos custos de combustíveis e alimentos e o massivo choque
de demanda inicial trazido pela Inteligência Artificial; e vetores deflacionários, como ganhos de produtividade trazidos pela
própria IA no médio prazo.
Por enquanto, os dados da inflação nos EUA nos parecem incertos. Além de ser um notável crítico dos QEs sucessivos, o próprio
Kevin Warsh (apontado como novo chairman do Federal Reserve) externalizou recentemente uma preferência pessoal pelo
acompanhamento do núcleo por médias aparadas e pela mediana da inflação do PCE em detrimento do tradicional núcleo por
exclusão. Contudo, cabe ressaltar que esta ainda é uma visão individual e não a postura oficial do comitê. O paradoxo atual é que,
enquanto o núcleo por exclusão sobe, as métricas preferidas do Warsh caem, adicionando névoa sobre o rumo da inflação
subjacente e dos juros básicos de curto prazo.
Se a visibilidade dos juros de curto prazo está turva, nossa visão para os juros de longo prazo é menos neutra: prevemos pressão
altista contínua nas curvas a termo. No curto prazo, qualquer investimento em Inteligência Artificial representa demanda pura,
forçando as empresas do setor a captarem volumes inéditos e crescentes de capital nos mercados de renda fixa.
PÁGINA 04 · 08
Gráfico 4. Evolução da renda pessoal e do custo do trabalho nos EUA. Fonte: Bloomberg, Adam Capital.
ADAM CAPITAL · CARTA DE GESTÃO · MAIO 2026

---

C A R T A  D E  G E S T Ã O  ·  M A I O 2 0 2 6
0 2  ·  C E N Á R I O  D O M É S T I C O
0 2  ·  C E N Á R I O  D O M É S T I C O
Há um claro descompasso temporal até que esses investimentos se maturem em produtividade real. Até lá, o equilíbrio macro dita
juros e inflação pressionados para cima no mundo, com exceção dos Estados Unidos (onde há vetores atuando em sentidos
opostos, como explicamos acima). Esta dinâmica de abertura dos juros longos pode ser reforçada caso Warsh convença o restante
do comitê a respeito da importância de se reduzir o tamanho do balanço do Fed.
Os dados econômicos recentes confirmam com precisão as teses que defendemos de forma isolada no final do ano passado. O PIB
brasileiro do primeiro trimestre registrou um crescimento de 1,1%, vindo exatamente em linha com a nossa projeção traçada há
seis meses (e bem acima em relação ao consenso das projeções naquela época). Esse dado chancela o cenário de reaceleração da
atividade econômica que já antecipávamos, impulsionado diretamente pela forte expansão fiscal. Embora o mercado celebre o
número, a nossa leitura é de cautela: esse dinamismo é artificial, movido por esteroides fiscais e parafiscais que mascaram a real
saúde da economia e impedem a convergência da inflação.
ADAM CAPITAL · CARTA DE GESTÃO · MAIO 2026
PÁGINA 05 · 08
Cr í ti ca E str u tu r al :  A P o stu ra Assi m étri c a d o s Ban q u ei ro s Cen trai s
Identificamos uma assimetria conceitual profunda na condução da política monetária global. Quando ocorrem choques
positivos de oferta, os bancos centrais apressam-se a colher os méritos, alegando eficácia da política monetária. Foi o que
ocorreu em 2023 com a reabertura do setor de serviços pós-pandemia e a normalização dos fretes globais - variáveis de
abertura comercial altamente significativas que foram confundidas com o efeito defasado dos juros. Por outro lado,
quando a inflação sobe, a culpa é atribuída exclusivamente a fatores de oferta, eximindo de questionamento o caráter
excessivamente estimulativo das políticas fiscal e monetária. Esse viés deliberado explica por que o PCE americano segue
acima da meta de 2% do Fed; em abril, o PCE cheio rodava a 3,8% em 12 meses e o núcleo a 3,3%, um fenômeno replicado
no Japão, na Europa e, crucialmente, no Brasil.
O Alerta Fiscal e a Ilusão do Crescimento
Ati vi dade E conôm i ca e o P I B do 1º Tri m estre
O I m p u l so  F i scal  " I n vi sí vel "  e a Di n âm i ca S u b jacen te d o  I P CA
Contrariando o consenso de mercado à época, já operávamos com um impulso fiscal entre 1% e 2% do PIB desde o fechamento
de 2025. Alertamos, inclusive, que o impulso real pode ser consideravelmente maior, superando 2% do PIB, se contabilizarmos
adequadamente as operações que correm fora do orçamento formal ("off-budget"). Isso inclui o uso agressivo de fundos
público-privados, a atuação de bancos de economia mista e a forte expansão de linhas de crédito subsidiadas pelas esferas
municipais, estaduais e federal. Esse fluxo contínuo de recursos atua como um amortecedor público que mascara riscos de
crédito e anula o aperto monetário.

---

C A R T A  D E  G E S T Ã O  ·  M A I O 2 0 2 6
0 3  ·  P O L Í T I C A  M O N E T Á R I A
Portanto, quando projetávamos um IPCA de 6% para 2026, estávamos simplesmente considerando a neutralidade desses
choques de oferta e cambiais. Não nos surpreendemos, de forma alguma, com a aceleração recente e com as revisões massivas
feitas pelos economistas de mercado ao longo deste ano. Na atual função de reação do Banco Central, os desvios da inflação
em relação à meta parecem ter pesos decrescentes (conforme mostramos na carta imediatamente anterior), chancelando a
resiliência na inflação de serviços e a aceleração em bens, alimentos e preços administrados.
P roduti vi dade em  Queda e o Col apso do P I B P otenci al
ADAM CAPITAL · CARTA DE GESTÃO · MAIO 2026
PÁGINA 06 · 08
Gráfico 5. IPCA EX Câmbio e serviços ligados à MDO. Fonte: IBGE, BCB, Adam Capital..
Mais grave ainda é o diagnóstico estrutural do lado da oferta: nossas estimativas para o PIB potencial do Brasil, quando
excluímos o setor agrícola, desabaram para níveis próximos a 0%. A produtividade do trabalho no setor real está em rota
francamente decadente, sufocada pelo aumento contínuo da carga tributária e por retrocessos institucionais de cunho
puramente populista, como as discussões e propostas legislativas voltadas para a redução da jornada semanal de 44 para 40
horas e a proibição da escala de trabalho 6x1. Essas medidas cobram um preço econômico alto e devem empurrar o PIB
potencial para o terreno negativo nos próximos trimestres.
Este expansionismo sem lastro justifica nosso fundamento de que o Banco Central errou ao iniciar e insistir no ciclo de cortes
de juros - a taxa básica não deveria ter caído abaixo do patamar de 15%. Nas nossas comunicações oficiais e cartas mensais do
final do ano passado, explicitávamos que, ao retirar do IPCA acumulado em 12 meses os choques positivos e simultâneos de
2025 (safras agrícolas excepcionais, desvalorização global do dólar com apreciação do real, queda nos preços do petróleo e
clima favorável), a inflação subjacente real já rodava próxima a 6%.

---

C A R T A  D E  G E S T Ã O  ·  M A I O 2 0 2 6
0 3  ·  P O L Í T I C A  M O N E T Á R I A
ADAM CAPITAL · CARTA DE GESTÃO · MAIO 2026
PÁGINA 07 · 08
S etor E xterno:  A Deteri oração E strutural  da Conta Corrente
Por fim, o setor externo corrobora os sinais de desequilíbrio macroeconômico. Excetuando o desempenho conjuntural da
balança comercial - que tem sido artificialmente inflada pelos aumentos de produção física e pelos preços internacionais
favoráveis do petróleo -, todo o restante da conta corrente exibe uma dinâmica de forte deterioração estrutural. As contas de
serviços e de rendas permanecem em rota de piora contínua, reflexo direto do aumento do passivo externo líquido do país e
da conjuntura de fortes estímulos fiscais e paraficais. Como o Brasil continua absorvendo mais investimentos do que
enviando recursos para o exterior, notadamente recursos de curto prazo nos mercados derivativos, a necessidade futura de
remessas e pagamentos de juros e dividendos tende a se ampliar de forma significativa.
O fluxo de caixa real do balanço de pagamentos responderá a essa assimetria com déficits crescentes nos próximos
trimestres, fragilizando o colchão externo brasileiro no médio prazo.
Neste ambiente, observamos uma excelente performance da nossa carteira nos meses de abril e maio, um resultado que reflete
o retorno do espectro do mercado para o que realmente importa: a relevância de se olhar para avaliações em valor intrínseco, e
não meramente para tendências de curto prazo. Em um ambiente prolongado de juros elevados, a disciplina de valor tende a
voltar a ditar as regras.
E stratégi a de I nvesti m ento e P osi ci onam ento da Cartei ra
Diante dos diagnósticos globais e domésticos apresentados, a estratégia de alocação da nossa carteira mantém um desenho
focado em assimetrias nítidas de valor e estruturado para capturar os desequilíbrios estruturais globais e a fragilidade fiscal
doméstica. Nossas principais teses estão distribuídas nos seguintes pilares operacionais:
•
Foco em Tecnologia nos EUA e Compra de Dólar (USD): Mantemos nossa alocação central focada em ações
selecionadas do setor de tecnologia nos Estados Unidos, cujas empresas lideram o ganho real e estrutural da fronteira de
inovação, amparadas por fortes balanços e geração robusta de caixa atual. Essa exposição é integralmente combinada à nossa
posição comprada em Dólar americano, que funciona de forma dupla: como uma tese de valorização cambial em relação à
outras moedas - efeito da drenagem de recursos globais em direção à maior rentabilidade da fronteira tecnológica
representada pelas ações americanas - e como um hedge macroeconômico natural indispensável para o portfólio em
momentos de risk off.
Com um PIB potencial zerado ou negativo, a condução da política monetária torna-se uma tarefa hercúlea. Entendemos que
apenas recessões severas seriam capazes de trazer o IPCA significativamente para baixo, dada a blindagem de gastos
públicos. Contudo, a classe política em Brasília permanece anestesiada pelo câmbio ao redor de R$ 5, interpretando que a
situação está sob controle. Historicamente, Brasília só compreende e reage à linguagem do estresse cambial agudo, qualquer
que seja o governo que esteja no poder. Sem esse freio, o apetite por gastos e a consequente deterioração da dívida líquida
continuarão a avançar de forma acentuada.
Gráfico 6. PIB ex-agro efetivo e PIB potencial do Brasil estimado a partir da Lei de Okun. Fonte: BCB, IBGE, Adam Capital.

---

C A R T A  D E  G E S T Ã O  ·  M A I O 2 0 2 6
P O S I C I O N A M E N T O  D O S  F U N D O S
P O S I C I O N A M E N T O  D O S  F U N D O S
Como esses diagnósticos se traduzem na carteira.
Para dúvidas e sugestões 
contato@adamcapital.com.br
Este relatório foi preparado pela ADAMCapital Gestão de Recursos LTDA. (ADAMCapital) e tem caráter meramente informativo, não se constituindo em oferta de venda de cotas dos fundos geridos e não
considerando objetivos de investimento ou necessidades individuais e particulares. A ADAMCapital não comercializa e nem distribui cotas de fundos ou qualquer outro ativo financeiro. Recomendamos
uma consulta a assessores de investimento e profissionais especializados para uma análise específica, personalizada antes de sua decisão sobre investimentos. Aos investidores é recomendada a leitura
cuidadosa de prospectos e regulamentos ao aplicar seus recursos. Os fundos geridos utilizam estratégias com derivativos como parte integrante de sua política de investimento. Tais estratégias, da forma
como são adotadas, podem resultar em significativas perdas patrimoniais para seus cotistas, podendo inclusive acarretar perdas superiores ao capital aplicado. Os fundos geridos estão autorizados a
realizar aplicações em ativos financeiros no exterior. Os fundos multimercados podem estar expostos a significativa concentração em ativos de poucos emissores, com os riscos daí decorrentes. Fundos
de Investimento não contam com a garantia do administrador do fundo, do gestor da carteira, de qualquer mecanismo de seguro ou, ainda, do Fundo Garantidor de Créditos – FGC. A rentabilidade obtida
no passado não representa garantia de rentabilidade futura. Para avaliação da performance do fundo de investimento, é recomendável uma análise de, no mínimo, 12 (doze) meses. Nos fundos geridos
pela ADAMCapital a data de conversão de cotas é diversa da data de aplicação e de resgate e a data de pagamento do resgate é diversa da data do pedido de resgate. Não há garantia de que os fundos
multimercados terão o tratamento tributário para fundos de longo prazo. Este material não pode ser copiado, reproduzido ou distribuído a terceiros sem a expressa concordância da ADAMCapital. O
regulamento e a lâmina dos fundos podem ser encontrados no website da ADAMCapital: www.adamcapital.com.br.
ADAM CAPITAL · CARTA DE GESTÃO · MAIO 2026
PÁGINA 08 · 08
C O M P R A D O
Equities · Tecnologia EUA · Dólar
Alocação em ações americanas de tecnologia diante da aceleração inevitável do uso da IA como ferramenta de ganho de 
produtividade e sucessiva valorização do dólar.
V E N D I D O
Bolsa Brasileira (Ibovespa) · Euro
Exposição líquida vendida no índice da bolsa brasileira e contra o Euro.
T O M A D O
Inflação Implícita
Posições tomadas em juros nominais e em inflação implícita.
•
Posição Vendida em Euro (EUR) : No plano cambial global, estabelecemos e carregamos uma posição vendida em
Euro. O bloco europeu enfrenta uma dinâmica de deterioração estrutural profunda, marcada pela perda contínua de
competitividade industrial frente à China, custos de energia desvantajosos e um dreno severo de capital privado. Esse fluxo de
caixa real e a migração de fortunas e investimentos corporativos em direção aos Estados Unidos desenham um cenário de
enfraquecimento e depreciação estrutural para a moeda comum europeia nos próximos trimestres e anos, à semelhança do
que ocorreu no ciclo de investimentos em internet ao longo da segunda metade dos anos 90.
•
Posição Vendida em Bolsa Brasileira (Ibovespa): Em contrapartida ao otimismo artificial do mercado local com dados de
atividade inflados por gastos públicos, sustentamos nossa posição vendida (short) na bolsa brasileira. O colapso do PIB
potencial do Brasil (ex-agro) para níveis próximos a 0% tira o suporte de valor intrínseco das empresas domésticas. Esse
quadro é severamente agravado por retrocessos institucionais e propostas legislativas populistas voltadas para a redução da
jornada semanal de 44 para 40 horas e o fim da escala de trabalho 6x1. Essas medidas destroem ainda mais a produtividade
do trabalho no setor real, encarecem os custos de produção e empurram o PIB potencial para o terreno negativo, justificando
nossas posições vendidas no mercado acionário doméstico.
•
Comprados em Inflação Implícita no Brasil: A forte aceleração da piora fiscal, a resiliência do mercado de
trabalho e dos preços dos serviços nos posicionam na compra de inflação implícita. Os prêmios praticados pelo mercado
continuam subestimando o caráter resiliente e estrutural do IPCA subjacente em direção aos 6%, mantido pressionado pelo
expressivo impulso fiscal.