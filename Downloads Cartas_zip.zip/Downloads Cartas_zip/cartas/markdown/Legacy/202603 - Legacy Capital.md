

---

Março 2026

---

2.
www.legacycapital.com.br
Carta Mensal Março 2026
2.
www.legacycapital.com.br
Caros  
investidores,
O
mês de março foi marcado pelo início da guerra entre os EUA e o Irã, evento que 
levou a uma queda generalizada dos preços de ativos de risco. O preço do 
petróleo subiu mais de 50% no mês. Moedas e bolsas sofreram de forma signiﬁcativa, 
e as taxas de juros abriram. Mesmo os preços de metais preciosos não resistiram e 
também cederam. Os ativos brasileiros tiveram comportamento em linha com os 
ativos globais, com boa performance relativa do BRL e do Ibovespa em relação aos 
demais países. Nos juros, o oposto se veriﬁcou.
Variação do Preço dos Ativos
Março
Ano
-9.3%
-6.5%
-5.1%
-4.9%
-3.9%
-0.7%
Euro
China
S&P
NASDAQ
Mexico
Brasil
Bolsas
-4.0%
-2.2%
-1.1%
Mexico
Euro
Brasil
Moedas
-11.6%
-7.4%
0.0%
2.1%
7.4%
42.7%
51.6%
Ouro
Cobre
Soja
Milho
Minério
Brent
WTI
Commodities
42
115
38
61
US 2Y
Pré Jan/28
US 10Y
Pré Jan/34
Juros (Bps)
-6.0%
-4.6%
-3.8%
-1.9%
6.7%
16.3%
NASDAQ
S&P
Euro
China
Mexico
Brasil
Bolsas
-1.6%
0.4%
5.7%
Euro
Mexico
Brasil
Moedas
-2.2%
-0.8%
2.1%
8.1%
10.4%
71.9%
77.9%
Cobre
Minério
Milho
Ouro
Soja
Brent
WTI
Commodities
59
32
15
33
Pré Jan/27
US 2Y
US 10Y
Pré Jan/34
Juros (Bps)

---

3.
www.legacycapital.com.br
Carta Mensal Março 2026
Atribuição de resultado 
Reﬂetindo a mudança completa de cenário, o fundo teve rendimento de -3,55% no 
mês, e de -0,34% no ano. As maiores perdas foram em juros locais e bolsa externa.

---

A dimensão da guerra e a perspectiva de grande incerteza quanto à sua duração 
levou a uma completa mudança de cenário. Trabalhávamos até o ﬁnal de fevereiro 
com um cenário externo benigno, caracterizado por inﬂação contida na maior parte 
das economias centrais, crescimento robusto nos EUA, lastreado por produtividade 
e um ciclo de investimentos em tecnologia, e algum espaço para queda de juros. 
Este panorama foi amplamente modiﬁcado pelos acontecimentos de março. A 
realidade hoje inclui uma grande dimensão de operações militares; o fechamento do 
estreito de Hormuz - que levou a uma redução signiﬁcativa do trânsito de petróleo 
por uma rota por onde normalmente se escoa 20% da produção mundial; ataques à 
infraestrutura de energia e gás natural dos países do golfo, por parte do Irã; a chega-
da de navios com fuzileiros e paraquedistas dos EUA, unidades que podem ser even-
tualmente utilizadas para a tomada do controle do estreito à força; entre outros des-
dobramentos que contribuíram para a elevação da incerteza e, também, do prêmio 
de risco nos ativos. As negociações com respeito ao ﬁm das hostilidades estão em 
curso, mas seu desenlace e prazo de conclusão são muito incertos.
Em termos econômicos, a elevação massiva e possivelmente duradoura dos 
preços do petróleo e do gás natural leva ao aumento da inﬂação, em um primeiro 
momento, e, posteriormente, induz desaceleração na atividade econômica. É 
provável que bancos centrais de regiões muito expostas ao aumento do preço do 
gás natural, como Europa e Reino Unido, sejam forçados a subirem os juros. Nos 
EUA, o mais provável é a estabilidade de juros ao longo do ano. 
Se a guerra se encerrar num prazo relativamente curto (abril), e o preço do 
petróleo assim retorne, por exemplo, para um patamar próximo a 80 USD, a econo-
mia global experimentará um surto de inﬂação e de desaceleração relativamente 
contidos. No entanto, se a situação atual piorar, como por exemplo no caso de uma 
invasão do Irã por terra, por parte dos EUA – uma situação que levaria a preços de 
petróleo ainda mais elevados – a economia global, muito provavelmente, entrará em 
recessão. A manutenção dos preços do petróleo atuais por mais poucos meses já 
será capaz, em nossa avaliação, de levar a economia global a um estado de recessão.
4.
www.legacycapital.com.br
Carta Mensal Março 2026
Cenário internacional à frente

---

5.
www.legacycapital.com.br
Carta Mensal Março 2026
Brasil – cenário e perspectivas 
A economia brasileira está integralmente sujeita ao novo cenário global descrito 
nos parágrafos anteriores. As projeções de inﬂação sofreram uma elevação signiﬁca-
tiva, reﬂetindo os impactos diretos e indiretos do choque observado nos preços do 
petróleo. Com isso, revisamos nossas estimativas para 2026 e 2027, que passaram 
de 3,4% e 3,7% para 4,7% e 4,3%, respectivamente. Apesar desse ajuste, as expecta-
tivas mantêm um viés de alta devido à incerteza do panorama atual. Um eventual 
prolongamento ou intensiﬁcação do conﬂito poderá empurrar a inﬂação para níveis 
superiores a 5%.
A atividade econômica também deve sentir os reﬂexos do conﬂito. No entanto, por 
ora, não prevemos impactos duradouros em nossas estimativas, motivo pelo qual 
mantivemos a projeção de crescimento do PIB em 1,5% para 2026.
Na política monetária, o tom das últimas comunicações indica que o Banco Central 
(BCB) parece disposto a manter os cortes na taxa de juros, mesmo diante das adver-
sidades presentes. Caso essas condições persistam, nosso entendimento é de que 
a autoridade monetária dará continuidade à sua estratégia de calibragem, reduzin-
do o aperto em passos de 25 pontos-base por reunião. Contudo, se o conﬂito se 
prolongar, o impacto na inﬂação corrente e nas expectativas do mercado deve limi-
tar o tamanho do ajuste imaginado pelo BCB.
Somam-se a esse cenário o risco de escassez de óleo diesel, derivado que o Brasil 
necessita importar em grandes volumes, e o agravamento do estresse no crédito 
privado. A perspectiva de manutenção da Selic em patamar elevado por mais tempo 
pode submeter empresas já endividadas a diﬁculdades ﬁnanceiras severas.

---

6.
www.legacycapital.com.br
Carta Mensal Março 2026
Brasil – cenário e perspectivas 
No plano eleitoral, o cenário tem evoluído de forma favorável à oposição. A baixa 
popularidade do governo tende a se acentuar com o aumento da inﬂação, puxada 
não apenas pelos combustíveis, mas também pelo encarecimento indireto de 
alimentos e bens de consumo associados ao frete. Além disso, a persistência do 
noticiário sobre os escândalos do INSS e do Banco Master deve continuar se 
traduzindo em um aumento da percepção de corrupção, desgastando ainda mais a 
imagem do presidente Lula. Em paralelo, a estratégia do principal candidato da 
oposição, Flávio Bolsonaro, tem se revelado acertada. Ao manter-se distante de 
polêmicas e adotar uma postura mais moderada, afastando-se da retórica bol-
sonarista tradicional para atrair eleitores sem forte posicionamento ideológico, ele 
se consolida hoje em posição de favoritismo para as eleições presidenciais de 
outubro.

---

7.
www.legacycapital.com.br
Carta Mensal Março 2026
Posicionamento  
Legacy Capital
Reduzimos de forma signiﬁcativa as posições ao longo do mês, optando por uma 
postura mais cautelosa enquanto aguardamos melhores oportunidades e maior 
visibilidade sobre o cenário à frente. A elevação nos preços do petróleo tem 
exercido pressão sobre os ativos de risco de maneira geral, adicionando um vetor 
relevante de incerteza.
Além disso, a indeﬁnição em relação ao conﬂito geopolítico mantém o ambiente 
com características binárias. Embora consideremos mais provável a construção de 
algum arranjo que leve a um cessar-fogo, a eventual continuidade das hostilidades 
pode resultar em revisões adicionais de preços no curto prazo.
Nesse contexto, mantivemos a preferência por exposições em empresas e índices 
de maior qualidade, combinadas a posições em moedas que tendem a se beneﬁciar 
de preços mais elevados de commodities e de um ambiente de juros mais altos.

---

LEGACY CAPITAL FIC FIM
Público Alvo
Rentabilidade do fundo 1
Jan
Fev
Mar
Abr
Mai
Jun
Ago
Set
Out
Nov
Dez
Ano
12 m
Acumulado
(desde o início)
Fundo
1.56%
1.74%
-3.55%
-
-
-
-
-
-
-
-
-0.34%
14.35%
121.09%
% CDI
134%
174%
-
-
-
-
-
-
-
-
-
-
97%
127%
Rentabilidade Acumulada
Ano
Fundo
% CDI
2018
5.17%
164%
2019
15.00%
251%
2020
13.74%
496%
2021
1.32%
30%
2022
23.56%
190%
2023
7.85%
60%
2024
3.96%
36%
2025
14.89%
104%
2026
-0.34%
-
Indicadores
PL do fundo 2
Meses Positivos
PL Médio 12m ³
Meses Negativos
PL do Fundo Master ²
Índice de Sharpe
Retorno Médio Mensal 4
Volatilidade Anualizada
Informações Gerais
CNPJ
Taxa de administração 5 
1.90% a.a
Data de Início 
Taxa de performance 
20% do que exceder 100% do CDI
Classificação Anbima
Horário limite de movimentações 
14h30
Cota
Investimento inicial mínimo
R$ 25,000.00
Benchmark
Movimentação adicional mínima 
R$ 5,000.00
Tributação 
Longo Prazo
Saldo mínimo de Permanência 
R$ 10,000.00
Gestão
Legacy Capital Gestora de Recursos Ltda
Cotização de aplicação 
Administração 
BNY Mellon Serviços Financeiros DTVM SA
Cotização de resgate
Auditoria
Deloitte Touche Tohmatsu Limited
Liquidação de resgate
1 du após a cotização
Contato : ri@legacycapital.com.br | Tel: +55  (11) 4130-7950 | www.legacycapital.com.br 
Av. Brigadeiro Faria Lima, 4221 - 10º andar - Itaim Bibi - São Paulo / SP - CEP 04538-133 
LEGACY CAPITAL GESTORA DE RECURSOS LTDA.  |  CNPJ : 28.674.641/0001-40  | Ato Declaratório CVM n° 16.010 de  07/12/2017.
3 Média aritmética da soma do PL apurado no último dia útil de cada mês, nos 12 (doze) meses anteriores.
4 Desde o início do fundo
² Valores do fechamento de 31/03/2026
29/06/2018
Multimercados Macro
Fechamento
66
27
0.28
A Legacy Capital não comercializa nem distribui cotas de fundos de investimento ou qualquer outro ativo financeiro. As informações contidas neste material são de caráter exclusivamente informativo e não se
caracterizam e nem devem ser entendidas como uma promessa ou um compromisso da Legacy Capital. A Legacy Capital não se responsabiliza por decisões do investidor, nem por ato ou fato de profissionais
especializados por ele consultados. Fundos de investimento não contam com a garantia do administrador, gestor da carteira ou qualquer mecanismo de seguro ou, ainda, pelo fundo garantidor de crédito – FGC.
Leia a lâmina de informações essenciais, se houver, o regulamento, o anexo – classe e o apêndice subclasse, conforme o caso, antes de investir. Para avaliação da performance de fundos de investimento, é
recomendável uma análise de, no mínimo, 12 meses. Rentabilidade obtida no passado não representa garantia de resultados futuros. A rentabilidade divulgada não é líquida de impostos. Este fundo pode utilizar
estratégias com derivativos como parte integrante de sua política de investimento. Tais estratégias, podem resultar em perdas patrimoniais para seus cotistas, podendo inclusive acarretar perdas superiores ao
capital aplicado e a consequente obrigação do cotista de aportar recursos adicionais para cobrir o prejuízo do fundo. Os ativos financeiros integrantes nesta carteira podem não possuir liquidez imediata,
podendo seus prazos e/ou rentabilidade variar de acordo com o vencimento ou prazo de resgate de cada ativo, caso seja negociado antecipadamente. Para mais informações, visite o site da Gestora ou do
Administrador. Administrador: BNY Mellon SF DTVM SA (CNPJ: 02.201.501/0001-61). Endereço; Av. Presidente Wilson, 231, 11º andar, Rio de Janeiro/RJ, CEP 20030-905. www.bnymellon.com.br/sf . SAC:
sac@bnymellon.com.br ou (21) 3219-2600 / (11) 3050-8010. Ouvidoria: ouvidoria@bnymellon.com.br ou  0800-725-3219.
R$ 139,500,856.90
5 Computando-se eventuais investimentos em outros fundos, a taxa de administração poderá atingir no máximo 2,50% a.a. sobre o PL do Fundo.
CDI
30.586.677/0001-14
0.87%
1 Rentabilidade mensal calculada com base na cota do último dia útil do mês, líquida de administração e performance e bruta de taxa de saída e impostos. 
5.89%
30 dc após a solicitação
R$ 154,725,757.68
1 du após a solicitação
R$ 3,214,232,737.02
Objetivo do Fundo
Proporcionar aos cotistas a valorização de suas cotas por meio da aplicação dos recursos em ativos financeiros e/ou modalidades operacionais disponíveis nos mercados de
renda fixa, renda variável, cambial, derivativos e cotas de fundos de investimento, negociados nos mercados interno e externo, baseado em cenários macroeconômicos de médio
e longo prazos. A política de investimentos do Fundo consiste em aplicar, no mínimo, 95% de seu patrimônio líquido em cotas do LEGACY CAPITAL MASTER FIM (CNPJ:
29.236.556/0001-63).
Jul
Investidores em geral.
2026
-
-
-20%
0%
20%
40%
60%
80%
100%
120%
140%
jul-18
jan-19
jul-19
jan-20
jul-20
jan-21
jul-21
jan-22
jul-22
jan-23
jul-23
jan-24
jul-24
jan-25
jul-25
jan-26
Legacy Capital FIC
CDI
Março de 2026
Material de divulgação
8.
www.legacycapital.com.br

---

www.legacycapital.com.br
A Legacy Capital não se responsabiliza por decisões do investidor, nem por ato ou fato de proﬁssionais especializados por ele consultados. O investidor deve se basear, 
exclusivamente, em sua opinião e na opinião de proﬁssionais especializados por ele contratados, para opinar e decidir. Este material não pode ser reproduzido, copiado 
ou distribuído para terceiros. Esta apresentação não se caracteriza nem deve ser entendida como uma promessa ou um compromisso da Legacy Capital de realizar as 
operações ou estruturar os veículos de investimento aqui descritos. Esta apresentação não se caracteriza e não deve ser entendida como consultoria jurídica, contábil, 
regulatória ou ﬁscal em relação aos assuntos aqui tratados. Este material é meramente informativo, não considera objetivos de investimento, situação ﬁnanceira ou 
necessidades individuais e particulares e não contém todas as informações que um investidor em potencial deve considerar ou analisar antes de 
investir. Não deve ser entendido como análise de valor mobiliário, material promocional, solicitação de compra ou venda, oferta ou recomendação de 
qualquer ativo ﬁnanceiro ou investimento e não conﬁgura sugestão ou consultoria jurídica. Recomendamos que consulte proﬁssionais especializados 
antes de decidir sobre investimentos.