

---

Abril 2026

---

2.
www.legacycapital.com.br
Carta Mensal Abril 2026
2.
www.legacycapital.com.br
Caros  
investidores,
O
mês de abril seguiu dominado pela dinâmica do conﬂito entre Irã e Estados 
Unidos. Após o anúncio de cessar-fogo no início do mês, os mercados registrar-
am forte alívio: os futuros curtos de petróleo recuaram cerca de 20%, as bolsas 
globais se recuperaram e os juros aliviaram a forte alta observada em março.
Ao longo do mês, porém, ﬁcou claro que as condições impostas pelos Estados 
Unidos para um acordo nuclear com o Irã são mais rigorosas do que se antecipava. 
Nas últimas semanas, a imposição de um bloqueio naval americano no Estreito de 
Ormuz adicionou incerteza sobre a duração das negociações.
Com a probabilidade de nova escalada militar agora considerada menor, o mercado 
se sentiu confortável para voltar a olhar determinados temas em um mundo 
pós-guerra. Isso beneﬁciou especialmente as bolsas globais, com destaque para o 
S&P, que atingiu novas máximas com o retorno do interesse por ativos ligados à tecn-
ologia e, também, pela temporada de resultados corporativos, que voltou a exibir 
forte crescimento de lucros. Os juros globais, por outro lado, seguiram condicionados 
à dinâmica do petróleo e ao risco de efeitos inﬂacionários de segunda ordem de um 
conﬂito mais prolongado, mantendo os bancos centrais em postura cautelosa.

---

2.
www.legacycapital.com.br
Carta Mensal Abril 2026
3.
www.legacycapital.com.br
 
Variação do Preço dos Ativos
Abril
Ano

---

4.
www.legacycapital.com.br
Carta Mensal Abril 2026
Atribuição de resultado 
O fundo teve rendimento de +2,54% no mês e de +2,19% no ano. O resultado posi-
tivo foi, em grande parte, concentrado nos livros com posições otimistas em bolsa 
global. As estratégias de moedas e commodities também contribuíram positiva-
mente para o resultado do mês.

---

t5.
www.legacycapital.com.br
Carta Mensal Abril 2026
Cenário internacional à frente
O cenário permanece binário. A reabertura do Estreito de Ormuz depende da con-
clusão de um acordo nuclear entre os Estados Unidos e o Irã, desfecho ainda incer-
to. Enquanto não houver acordo, não se pode descartar completamente uma reto-
mada das hostilidades, embora atribuamos a esse risco probabilidade menor.
O fechamento do estreito provocou a redução de cerca de 15 milhões de barris 
por dia na produção da região do Golfo, equivalente a aproximadamente 15% do 
consumo mundial. Como resultado, o preço do petróleo já subiu cerca de 75%, 
atingindo US$ 105 por barril, e segue extremamente volátil.
Até o momento, o choque de preços provocou uma queda da demanda global de 
“apenas” cerca de 4 milhões de barris por dia. A diferença vem sendo suprida pela 
utilização de estoques comerciais e estratégicos. Como esses estoques são ﬁnitos, 
caso o estreito permaneça fechado por um período prolongado, a queda dos 
estoques tende a pressionar os preços do petróleo. No limite, estimamos que o 
preço do petróleo precisaria subir para cerca de US$ 200 por barril para equilibrar 
oferta e demanda se o estreito ﬁcar fechado indeﬁnidamente.
No cenário benigno, em que um acordo seja alcançado e o estreito seja reaberto 
nos próximos meses, a produção de petróleo pode ser normalizada em um horizon-
te de três a seis meses. Projetamos, nesse caso, que o preço do petróleo retorne a 
US$ 90 por barril até o ﬁm de 2026 e a US$ 75 por barril até o ﬁm de 2027, à medida 
que os estoques globais sejam reabastecidos.
Nesse cenário mais favorável, o surto de inﬂação e a desaceleração econômica 
tendem a ser relativamente contidos e transitórios. Alguns bancos centrais de 
países desenvolvidos podem até subir os juros, mas em ritmo lento e apenas para 
conter os efeitos secundários da alta dos preços de energia.

---

6.
www.legacycapital.com.br
Carta Mensal Abril 2026
Cenário internacional à frente
Nos Estados Unidos, o Fed não deve elevar os juros, pois historicamente não reage 
a choques de oferta de energia, especialmente com as expectativas de inﬂação bem 
ancoradas. A inﬂação deve permanecer próxima de 3% ao longo do ano, mas, se o 
choque dissipar, pode permitir ao Fed retomar os cortes de juros no 4T26 ou no 
1T27.
Na Europa, o impacto do choque energético deve ser mais intenso do que nos 
EUA, uma vez que a energia representa cerca de 9% do índice de preços ao consumi-
dor e o continente importa gás natural da região do Golfo. Por isso, o Banco Central 
Europeu (BCE) pode subir os juros já em junho. Ainda assim, o ajuste total deve ser 
modesto, da ordem de 25 a 50 pontos-base, pois, embora a inﬂação na zona do euro 
possa chegar a 4%, os efeitos de segunda ordem tendem a ser amenos no cenário 
benigno.

---

7.
www.legacycapital.com.br
Carta Mensal Abril 2026
Brasil – cenário e perspectivas 
Assim como em outros países, a economia brasileira também seguiu sentindo os 
efeitos deletérios do choque nos preços do petróleo. O arrefecimento do conﬂito no 
Oriente Médio não foi suﬁciente para conter a dinâmica de revisões nas projeções 
de inﬂação, que, desde o início da guerra, subiram mais de 100 pontos-base para 
2026, com impactos também em horizontes mais longos de projeção. Projetamos 
inﬂação de 4,7% em 2026 e de 4,1% em 2027.
Do lado da atividade, os dados divulgados até aqui seguem apontando para uma 
economia resiliente, em parte potencialmente impulsionada pelo aumento da renda 
disponível decorrente da ampliação da isenção do imposto de renda implementada 
pelo governo a partir da virada do ano. A atividade econômica também deve sentir 
os reﬂexos do conﬂito, mas, diante da incerteza sobre sua extensão, mantivemos 
esses efeitos como riscos baixistas em relação ao nosso cenário base. Nossa pro-
jeção é de crescimento trimestral de 1,0% do PIB no 1T26 e de 1,8% no ano de 2026.
Em relação à política monetária, a comunicação mais recente do Banco Central do 
Brasil (BCB) também reforçou a necessidade de cautela na condução do ciclo de cali-
bração dos juros, em um ambiente de elevada incerteza. A piora das condições de 
contorno da economia, com atividade resiliente, inﬂação corrente pressionada e 
expectativas longas em deterioração, demandou uma postura mais dura do BCB, 
que sinalizou estar sensível à evolução do conjunto de informações e, eventual-
mente, poderia reavaliar a extensão do ciclo de calibração inicialmente imaginado 
pelo comitê. Nosso entendimento é que, salvo uma nova deterioração relevante nos 
preços do petróleo, o BCB seguirá avaliando que o ciclo de calibração é suﬁciente-
mente amplo para permitir a continuidade dos ajustes na taxa Selic em passos de 25 
pontos-base. Por outro lado, uma eventual resolução do conﬂito que permita uma 
queda mais relevante do petróleo provavelmente nos devolveria a um cenário de 
maior extensão do ciclo e de ritmo mais intenso de ajustes, como sugere a ma-
nutenção, na comunicação oﬁcial do BCB, do trecho que abre essa possibilidade.

---

8.
www.legacycapital.com.br
Carta Mensal Abril 2026
Brasil – cenário e perspectivas 
Na curva de juros brasileira, chama a atenção como, desde o início da guerra, a 
preciﬁcação de mercado para o tamanho do ciclo de juros em 2026 passou a acom-
panhar de forma quase idêntica a dinâmica do preço do petróleo em reais, con-
forme mostra o gráﬁco abaixo. Isso revela como fatores idiossincráticos da conjun-
tura econômica brasileira perderam relevância na determinação da dinâmica de 
mercado. Temas que antes ocupavam papel central, como medidas ﬁscais populis-
tas endereçadas pelo governo para ﬁns eleitorais, ou surpresas em dados de 
inﬂação e atividade, foram praticamente deixados de lado. 
No mês de abril, o panorama eleitoral apresentou poucas mudanças, com a 
oposição mantendo um viés mais positivo na margem. As pesquisas seguiram 
mostrando, em sua grande maioria, o presidente incumbente e o candidato de 
oposição, Flávio Bolsonaro, em empate técnico nas simulações de segundo turno. O 
governo seguiu com a popularidade em baixa, movimento que tende a se acentuar 
à frente, à medida que os efeitos do choque do petróleo passem a afetar de maneira 
mais relevante as leituras de inﬂação corrente. A fragilidade do governo também se 
reﬂete na relação com o Congresso, que impôs uma derrota histórica ao Executivo 
ao rejeitar a nomeação de Jorge Messias para a vaga de ministro do STF e ao der-
rubar o veto feito pelo presidente Lula ao projeto de lei da dosimetria. Do lado da 
oposição, Flávio Bolsonaro segue tentando se aproximar do público mais moderado, 
evitando temas polêmicos, tanto na agenda econômica quanto na pauta de cos-
tumes.

---

9.
www.legacycapital.com.br
Carta Mensal Abril 2026
Posicionamento  
Legacy Capital
Mantivemos um nível de risco menor ao longo do mês de Abril enquanto 
atravessamos esse cenário de maior volatilidade. A dinâmica do petróleo segue 
tendo efeito preponderante sobre os preços dos ativos, sobretudo, das curvas de 
juros, o que nos torna mais cautelosos na adoção de posições mais signiﬁcativas em 
nossos livros.
Diante de um cenário que é, por natureza, binário, seguimos mantendo a 
preferência por exposições em empresas e índices de maior qualidade, combinadas 
a posições em moedas que tendem a se beneﬁciar de preços mais elevados de 
commodities e de um ambiente de juros mais altos.

---

LEGACY CAPITAL FIF CIC RL
Público Alvo
Rentabilidade do fundo 1
Jan
Fev
Mar
Abr
Mai
Jun
Ago
Set
Out
Nov
Dez
Ano
12 m
Acumulado
(desde o início)
Fundo
1.56%
1.74%
-3.55%
2.54%
-
-
-
-
-
-
-
2.19%
13.62%
126.71%
% CDI
134%
174%
-
233%
-
-
-
-
-
-
-
48%
92%
130%
Rentabilidade Acumulada
Ano
Fundo
% CDI
2018
5.17%
164%
2019
15.00%
251%
2020
13.74%
496%
2021
1.32%
30%
2022
23.56%
190%
2023
7.85%
60%
2024
3.96%
36%
2025
14.89%
104%
2026
2.19%
48%
Indicadores
PL do fundo 2
Meses Positivos
PL Médio 12m ³
Meses Negativos
PL do Fundo Master ²
Índice de Sharpe
Retorno Médio Mensal 4
Volatilidade Anualizada
Informações Gerais
CNPJ
Taxa de administração 5 
1.90% a.a
Data de Início 
Taxa de performance 
20% do que exceder 100% do CDI
Classificação Anbima
Horário limite de movimentações 
14h30
Cota
Investimento inicial mínimo
R$ 25,000.00
Benchmark
Movimentação adicional mínima 
R$ 5,000.00
Tributação 
Longo Prazo
Saldo mínimo de Permanência 
R$ 10,000.00
Gestão
Legacy Capital Gestora de Recursos Ltda
Cotização de aplicação 
Administração 
BTG Pactual Serviços Financeiros SA DTVM
Cotização de resgate
Auditoria
Deloitte Touche Tohmatsu Limited
Liquidação de resgate
1 du após a cotização
Contato : ri@legacycapital.com.br | Tel: +55  (11) 4130-7950 | www.legacycapital.com.br 
Av. Brigadeiro Faria Lima, 4221 - 10º andar - Itaim Bibi - São Paulo / SP - CEP 04538-133 
LEGACY CAPITAL GESTORA DE RECURSOS LTDA.  |  CNPJ : 28.674.641/0001-40  | Ato Declaratório CVM n° 16.010 de  07/12/2017.
3 Média aritmética da soma do PL apurado no último dia útil de cada mês, nos 12 (doze) meses anteriores.
4 Desde o início do fundo
² Valores do fechamento de 30/04/2026
29/06/2018
Multimercados Macro
Fechamento
67
27
0.30
A Legacy Capital não comercializa nem distribui cotas de fundos de investimento ou qualquer outro ativo financeiro. As informações contidas neste material são de caráter exclusivamente informativo e não se
caracterizam e nem devem ser entendidas como uma promessa ou um compromisso da Legacy Capital. A Legacy Capital não se responsabiliza por decisões do investidor, nem por ato ou fato de profissionais
especializados por ele consultados. Fundos de investimento não contam com a garantia do administrador, gestor da carteira ou qualquer mecanismo de seguro ou, ainda, pelo fundo garantidor de crédito – FGC.
Leia a lâmina de informações essenciais, se houver, o regulamento, o anexo – classe e o apêndice subclasse, conforme o caso, antes de investir. Para avaliação da performance de fundos de investimento, é
recomendável uma análise de, no mínimo, 12 meses. Rentabilidade obtida no passado não representa garantia de resultados futuros. A rentabilidade divulgada não é líquida de impostos. Este fundo pode utilizar
estratégias com derivativos como parte integrante de sua política de investimento. Tais estratégias, podem resultar em perdas patrimoniais para seus cotistas, podendo inclusive acarretar perdas superiores ao
capital aplicado e a consequente obrigação do cotista de aportar recursos adicionais para cobrir o prejuízo do fundo. Os ativos financeiros integrantes nesta carteira podem não possuir liquidez imediata, podendo
seus prazos e/ou rentabilidade variar de acordo com o vencimento ou prazo de resgate de cada ativo, caso seja negociado antecipadamente. Para mais informações, visite o site da Gestora ou do Administrador.
Administrador: BNY Mellon SF DTVM SA (CNPJ: 02.201.501/0001-61). Endereço; Av. Presidente Wilson, 231, 11º andar, Rio de Janeiro/RJ, CEP 20030-905. www.bnymellon.com.br/sf . SAC: sac@bnymellon.com.br ou
(21) 3219-2600 / (11) 3050-8010. Ouvidoria: ouvidoria@bnymellon.com.br ou  0800-725-3219.
R$ 136,554,533.45
5 Computando-se eventuais investimentos em outros fundos, a taxa de administração poderá atingir no máximo 2,50% a.a. sobre o PL do Fundo.
CDI
30.586.677/0001-14
0.89%
1 Rentabilidade mensal calculada com base na cota do último dia útil do mês, líquida de administração e performance e bruta de taxa de saída e impostos. 
5.88%
30 dc após a solicitação
R$ 151,478,841.95
1 du após a solicitação
R$ 3,171,584,277.31
Objetivo do Fundo
Proporcionar aos cotistas a valorização de suas cotas por meio da aplicação dos recursos em ativos financeiros e/ou modalidades operacionais disponíveis nos mercados de
renda fixa, renda variável, cambial, derivativos e cotas de fundos de investimento, negociados nos mercados interno e externo, baseado em cenários macroeconômicos de médio
e longo prazos. A política de investimentos do Fundo consiste em aplicar, no mínimo, 95% de seu patrimônio líquido em cotas do LEGACY CAPITAL MASTER FIM (CNPJ:
29.236.556/0001-63).
Jul
Investidores em geral.
2026
-
-
-20%
0%
20%
40%
60%
80%
100%
120%
140%
jul-18
jul-19
jul-20
jul-21
jul-22
jul-23
jul-24
jul-25
Legacy Capital FIC
CDI
Abril de 2026
Material de divulgação
10.
www.legacycapital.com.br

---

www.legacycapital.com.br
A Legacy Capital não se responsabiliza por decisões do investidor, nem por ato ou fato de proﬁssionais especializados por ele consultados. O investidor deve se basear, 
exclusivamente, em sua opinião e na opinião de proﬁssionais especializados por ele contratados, para opinar e decidir. Este material não pode ser reproduzido, copiado 
ou distribuído para terceiros. Esta apresentação não se caracteriza nem deve ser entendida como uma promessa ou um compromisso da Legacy Capital de realizar as 
operações ou estruturar os veículos de investimento aqui descritos. Esta apresentação não se caracteriza e não deve ser entendida como consultoria jurídica, contábil, 
regulatória ou ﬁscal em relação aos assuntos aqui tratados. Este material é meramente informativo, não considera objetivos de investimento, situação ﬁnanceira ou 
necessidades individuais e particulares e não contém todas as informações que um investidor em potencial deve considerar ou analisar antes de 
investir. Não deve ser entendido como análise de valor mobiliário, material promocional, solicitação de compra ou venda, oferta ou recomendação de 
qualquer ativo ﬁnanceiro ou investimento e não conﬁgura sugestão ou consultoria jurídica. Recomendamos que consulte proﬁssionais especializados 
antes de decidir sobre investimentos.