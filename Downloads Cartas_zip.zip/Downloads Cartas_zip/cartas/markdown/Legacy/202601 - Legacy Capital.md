

---

JAN  . 26

---

2.
www.legacycapital.com.br
Carta Mensal Janeiro 2026
2.
www.legacycapital.com.br
Caros  
investidores,
O
mês de janeiro foi marcado por maciço ﬂuxo de alocação direcionado a ativos 
não denominados em USD. Metais preciosos, moedas de economias maduras e 
bolsas beneﬁciaram-se deste ﬂuxo e registraram ganhos expressivos, que foram 
parcialmente revertidos no último dia do mês. Os ativos brasileiros performaram 
bem, impulsionados por este movimento global.
Variação do Preço dos Ativos
Janeiro
NSN T1NI79KFCAO0
1.2%
1.4%
2.7%
3.8%
5.1%
12.6%
NASDAQ
S&P
Euro
China
Mexico
Brasil
Bolsas
0.9%
3.1%
4.0%
Euro
Mexico
Brasil
Moedas
-2.7%
-1.5%
1.6%
4.3%
13.3%
14.0%
14.6%
Milho
Minério
Soja
Cobre
Ouro
WTI
Brent
s
eitid
o
m
m
o
C
-48
-29
5
7
Pré Jan/28
US 2Y
Pré Jan/34
US 10Y
Juros (Bps)

---

3.
www.legacycapital.com.br
Carta Mensal Janeiro 2026 
Atribuição de resultado 
O fundo teve rendimento de 1,6% no mês. O desempenho reﬂetiu ganhos em 
posições vendidas em USD e aplicadas em juros, parcialmente contrabalançadas por 
perdas em posições de bolsa.

---

4.
www.legacycapital.com.br
Carta Mensal Janeiro 2026
Cenário internacional à frente
O ritmo de crescimento da economia dos EUA manteve-se sólido nos últimos 
meses de 2025. O crescimento do consumo e do investimento em outubro e 
novembro, combinado ao forte ritmo registrado no 3T, sugerem que o PIB dos EUA 
deva ter crescido aproximadamente 2,5% em 2025. O mercado de trabalho, do 
ponto de vista de criação de empregos, parece ter se estabilizado. A inﬂação deve 
ter encerrado o ano com variação de 2,9%, tendo exibido comportamento mais 
benigno do que o esperado, ao longo do ano.
Seguimos esperando aceleração da atividade econômica em 2026, tendo em vista 
os efeitos da distensão da política monetária e da dissipação do efeito 
contracionista das tarifas sobre a demanda. Estimamos crescimento do PIB de 2,7% 
em 2026, e inﬂação (core PCE) de 2,2%, número próximo à meta. Se estivermos 
corretos quanto à dinâmica da inﬂação, o FOMC poderá cortar adicionalmente os 
juros em 50BP, provavelmente entre o 2T e o 3T de 2026.  
Em nossa avaliação, o ciclo de investimentos em tecnologia permanece saudável. 
Os resultados das empresas do setor seguem com ótima qualidade, e a demanda 
por capacidade computacional e pela infraestrutura necessária à operação das 
empresas prossegue ﬁrme. 
OS EUA se encontram a 9 meses das eleições mid-term, que renovará todos os 
assentos da câmara de representantes, 1/3 das cadeiras do senado, e o governo de 
35 dos 50 estados. As ações do Presidente Trump têm sido e serão mais fortemente 
deﬁnidas, a partir de agora, tendo em vista suas potenciais contribuições – do ponto 
de vista do presidente - para o aumento de chances dos candidatos republicanos no 
pleito de novembro. 
Em qualquer eleição, a aceleração da atividade econômica é um fator que sempre 
beneﬁcia o governo incumbente. Juros mais baixos e USD fraco tornariam as 
condições ﬁnanceiras mais relaxadas, e contribuiriam para a aceleração da atividade 
econômica. É através desta lente que, acreditamos, as sucessivas tentativas de 
intimidação à liderança, e de controle sobre as decisões do FED devem ser vistas.

---

5.
www.legacycapital.com.br
Carta Mensal Janeiro 2026
Cenário internacional à frente
Neste sentido, a indicação de Kevin Warsh para a liderança do FED, no último dia 
do mês, foi um desenvolvimento positivo. Warsh é uma ﬁgura respeitada nos meios 
acadêmico e de policy, tendo atuado como diretor do FED entre 2006 e 2011, 
período que incluiu a grande crise ﬁnanceira de 2008. Recentemente, tem defendido 
juros mais baixos, em meio ao cenário de crescimento robusto e inﬂação baixa 
possibilitado pela elevada produtividade. Em nosso entendimento, esta indicação 
reduz materialmente o temor da captura e instrumentalização do FED pelo poder 
executivo. 
Já os sucessivos movimentos de intervenção na Venezuela, na Groenlândia, e, 
possivelmente, proximamente no Irã, podem fazer sentido do ponto de vista da 
segurança e dos interesses econômicos dos EUA. Pode-se, mesmo, argumentar que 
alguns destes movimentos também se justiﬁquem do ponto de vista humanitário. 
Mas, fundamentalmente, eles reﬂetem, em nossa visão, a intenção de Trump em 
procurar reduzir os preços do petróleo (através da expansão da oferta do Irã e da 
Venezuela), e, também, em explicitar aos europeus (e canadenses) a importância e a 
urgência do aumento de seus gastos com defesa. Maiores gastos com defesa 
signiﬁcam maior impulso ﬁscal e juros mais elevados fora dos EUA, contribuindo 
para a depreciação do USD. E, também, menor necessidade, por parte dos EUA, em 
aumentar (ainda mais) seus gastos com defesa.
De um ponto de vista mais estrutural, o ambiente global mais belicoso e inseguro 
leva à necessidade de aumento de gastos com defesa e de infraestrutura – dos 
déﬁcits ﬁscais, portanto - e à duplicação de cadeias de suprimentos, o que ajuda a 
pressionar a demanda por metais e materiais industriais. As condições iniciais de 
elevado endividamento das maiores economias ocidentais exacerba, então, o efeito 
dessa pressão no preço dos metais preciosos. Os recentes eventos no Japão se 
encaixam nesse contexto. A perspectiva de mais expansão ﬁscal na economia 
japonesa – cuja razão dívida / PIB é de 240% - provocou forte depreciação do JPY, 
abertura dos juros longos, e aumento da compra de ativos alternativos por parte de 
investidores japoneses. O movimento foi parcialmente contido por ações de 
autoridades japonesas e americanas nos mercados de ativos denominados em JPY.

---

6.
www.legacycapital.com.br
Carta Mensal Janeiro 2026
Cenário internacional à frente
Em outra frente, o crescimento consistente da produtividade na casa de 2% 
confere ao PIB potencial dos EUA uma nítida vantagem em relação às demais 
economias, e atua na direção contrária aos movimentos descritos nos parágrafos 
anteriores, contribuindo para a valorização do USD e dos ativos nele denominados.
 
Como sempre, a médio prazo, as diferenças de nível e de consistência nas taxas de 
retorno serão os fatores determinantes na alocação de equilíbrio entre classes de 
ativos por parte dos investidores.

---

7.
www.legacycapital.com.br
Carta Mensal Janeiro 2026
No Brasil, a atividade econômica segue em desaceleração, embora a mudança em 
curso na sazonalidade nas vendas de ﬁnal de ano – que tem se deslocado, ao longo 
dos últimos anos, do mês de dezembro para novembro – diﬁculte a leitura da 
tendência recente. Nossa expectativa é de que os dados de dezembro mostrem 
alguma acomodação, ante os dados muito fortes em novembro. Seguimos 
projetando desaceleração do crescimento do PIB para 1,5% em 2026, ante 2,3% em 
2025.
A inﬂação segue acomodada em um nível mais contido. A recente apreciação da 
taxa de câmbio deve contribuir para novas quedas nas expectativas de inﬂação, e 
também na inﬂação corrente.
Diante desse quadro, o Banco Central sinalizou, em sua última reunião, o início do 
ciclo de corte de juros em março. 
Nas atuais circunstâncias, estimamos que a extensão do ciclo deva ser próxima a 
400bp. O espaço para corte será maior, caso a depreciação do USD se intensiﬁque, 
e/ou a desaceleração da atividade econômica torne-se mais palpável e generalizada.  
Brasil – cenário e perspectivas

---

8.
www.legacycapital.com.br
Carta Mensal Janeiro 2026
Posicionamento  
Legacy Capital
O cenário externo tem evoluído de forma complexa. Movimentos extremos em 
certas classes de ativos, excesso de ruído geopolítico, e o ritmo frenético das ações 
de policy diﬁcultam o carrego das posições. No entanto, seguimos com o 
entendimento de que a combinação de inﬂação contida e crescimento moderado 
seja positiva para ativos de risco. A despeito da volatilidade e da crescente 
complexidade do quadro, os bons resultados das empresas de tecnologia e a 
demanda crescente por investimento em IA ajudam a compor um horizonte 
favorável para bolsas, especialmente no setor de tecnologia.  Prosseguimos com 
posições compradas em ações deste setor. Em moedas, seguimos vendidos em USD, 
alternando concentração em moedas de carry e em moedas DM mais cíclicas. 
Voltamos a aumentar a alocação em juros reais e nominais no Brasil, pois, em nossa 
visão, o ciclo tende a ser mais extenso do que o apreçado na curva de juros.

---

LEGACY CAPITAL FIC FIM
Público Alvo
Rentabilidade do fundo 1
Jan
Fev
Mar
Abr
Mai
Jun
Ago
Set
Out
Nov
Dez
Ano
12 m
Acumulado
(desde o início)
Fundo
1.56%
-
-
-
-
-
-
-
-
-
-
1.56%
14.12%
125.31%
% CDI
134%
-
-
-
-
-
-
-
-
-
-
134%
97%
138%
Rentabilidade Acumulada
Ano
Fundo
% CDI
2018
5.17%
164%
2019
15.00%
251%
2020
13.74%
496%
2021
1.32%
30%
2022
23.56%
190%
2023
7.85%
60%
2024
3.96%
36%
2025
14.89%
104%
2026
1.56%
134%
Indicadores
PL do fundo 2
Meses Positivos
PL do Fundo Master ²
Meses Negativos
PL Médio 12m ³
Índice de Sharpe
Retorno Médio Mensal 4
Volatilidade Anualizada
Informações Gerais
CNPJ
Taxa de administração 5 
1.90% a.a
Data de Início 
Taxa de performance 
20% do que exceder 100% do CDI
Classificação Anbima
Horário limite de movimentações 
14h30
Cota
Investimento inicial mínimo
R$ 25,000.00
Benchmark
Movimentação adicional mínima 
R$ 5,000.00
Tributação 
Longo Prazo
Saldo mínimo de Permanência 
R$ 10,000.00
Gestão
Legacy Capital Gestora de Recursos Ltda
Cotização de aplicação 
Administração 
BNY Mellon Serviços Financeiros DTVM SA
Cotização de resgate
5 Computando-se event Deloitte Touche Tohmatsu Limited
Liquidação de resgate
1 du após a cotização
Objetivo do Fundo
Proporcionar aos cotistas a valorização de suas cotas por meio da aplicação dos recursos em ativos financeiros e/ou modalidades operacionais disponíveis nos mercados de
renda fixa, renda variável, cambial, derivativos e cotas de fundos de investimento, negociados nos mercados interno e externo, baseado em cenários macroeconômicos de
médio e longo prazos. A política de investimentos do Fundo consiste em aplicar, no mínimo, 95% de seu patrimônio líquido em cotas do LEGACY CAPITAL MASTER FIM (CNPJ:
29.236.556/0001-63).
Jul
Investidores em geral.
2026
-
-
CDI
30.586.677/0001-14
0.91%
1 Rentabilidade mensal calculada com base na cota do último dia útil do mês, líquida de administração e performance e bruta de taxa de saída e impostos. 
5.85%
30 dc após a solicitação
R$ 3,384,806,860.93
1 du após a solicitação
R$ 168,001,399.68
Contato : ri@legacycapital.com.br | Tel: +55  (11) 4130-7950 | www.legacycapital.com.br 
Av. Brigadeiro Faria Lima, 4221 - 10º andar - Itaim Bibi - São Paulo / SP - CEP 04538-133 
LEGACY CAPITAL GESTORA DE RECURSOS LTDA.  |  CNPJ : 28.674.641/0001-40  | Ato Declaratório CVM n° 16.010 de  07/12/2017.
3 Média aritmética da soma do PL apurado no último dia útil de cada mês, nos 12 (doze) meses anteriores.
4 Desde o início do fundo
² Valores do fechamento de 30/01/2026
29/06/2018
Multimercados Macro
Fechamento
65
26
0.38
A Legacy Capital não comercializa nem distribui cotas de fundos de investimento ou qualquer outro ativo financeiro. As informações contidas neste material são de caráter exclusivamente informativo e não se
caracterizam e nem devem ser entendidas como uma promessa ou um compromisso da Legacy Capital. A Legacy Capital não se responsabiliza por decisões do investidor, nem por ato ou fato de profissionais
especializados por ele consultados. Fundos de investimento não contam com a garantia do administrador, gestor da carteira ou qualquer mecanismo de seguro ou, ainda, pelo fundo garantidor de crédito –
FGC. Leia a lâmina de informações essenciais, se houver, o regulamento, o anexo – classe e o apêndice subclasse, conforme o caso, antes de investir. Para avaliação da performance de fundos de investimento,
é recomendável uma análise de, no mínimo, 12 meses. Rentabilidade obtida no passado não representa garantia de resultados futuros. A rentabilidade divulgada não é líquida de impostos. Este fundo pode
utilizar estratégias com derivativos como parte integrante de sua política de investimento. Tais estratégias, podem resultar em perdas patrimoniais para seus cotistas, podendo inclusive acarretar perdas
superiores ao capital aplicado e a consequente obrigação do cotista de aportar recursos adicionais para cobrir o prejuízo do fundo. Os ativos financeiros integrantes nesta carteira podem não possuir liquidez
imediata, podendo seus prazos e/ou rentabilidade variar de acordo com o vencimento ou prazo de resgate de cada ativo, caso seja negociado antecipadamente. Para mais informações, visite o site da
Gestora ou do Administrador.
Administrador: BNY
Mellon SF
DTVM SA
(CNPJ:
02.201.501/0001-61).
Endereço; Av.
Presidente Wilson,
231, 11º
andar, Rio
de Janeiro/RJ,
CEP 20030-905.
www.bnymellon.com.br/sf . SAC: sac@bnymellon.com.br ou (21) 3219-2600 / (11) 3050-8010. Ouvidoria: ouvidoria@bnymellon.com.br ou  0800-725-3219.
R$ 144,659,652.07
5 Computando-se eventuais investimentos em outros fundos, a taxa de administração poderá atingir no máximo 2,50% a.a. sobre o PL do Fundo.
-20%
0%
20%
40%
60%
80%
100%
120%
140%
jul-18
abr-19
jan-20
out-20
jul-21
abr-22
jan-23
out-23
jul-24
abr-25
jan-26
Legacy Capital FIC
CDI
Janeiro de 2026
Material de divulgação
9.
www.legacycapital.com.br

---

www.legacycapital.com.br
A Legacy Capital não se responsabiliza por decisões do investidor, nem por ato ou fato de proﬁssionais especializados por ele consultados. O investidor deve se basear, 
exclusivamente, em sua opinião e na opinião de proﬁssionais especializados por ele contratados, para opinar e decidir. Este material não pode ser reproduzido, copiado 
ou distribuído para terceiros. Esta apresentação não se caracteriza nem deve ser entendida como uma promessa ou um compromisso da Legacy Capital de realizar as 
operações ou estruturar os veículos de investimento aqui descritos. Esta apresentação não se caracteriza e não deve ser entendida como consultoria jurídica, contábil, 
regulatória ou ﬁscal em relação aos assuntos aqui tratados. Este material é meramente informativo, não considera objetivos de investimento, situação ﬁnanceira ou 
necessidades individuais e particulares e não contém todas as informações que um investidor em potencial deve considerar ou analisar antes de 
investir. Não deve ser entendido como análise de valor mobiliário, material promocional, solicitação de compra ou venda, oferta ou recomendação de 
qualquer ativo ﬁnanceiro ou investimento e não conﬁgura sugestão ou consultoria jurídica. Recomendamos que consulte proﬁssionais especializados 
antes de decidir sobre investimentos.