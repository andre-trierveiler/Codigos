

---

Fevereiro 2026

---

2.
www.legacycapital.com.br
Carta Mensal Fevereiro 2026
2.
www.legacycapital.com.br
Caros  
investidores,
E
m fevereiro, o ﬂuxo de alocação direcionado a ativos não denominados em USD 
prosseguiu. Preços de metais preciosos, moedas e bolsas de economias emer-
gentes foram os principais beneﬁciários desse movimento. Os ativos brasileiros 
seguiram performando positivamente, impulsionados por este movimento global.   
-2.3%
-0.9%
1.1%
3.2%
4.1%
5.6%
NASDAQ
S&P
China
Euro
Brasil
Mexico
Bolsas
-0.3%
1.4%
2.7%
Euro
Mexico
Brasil
Moedas
-6.2%
1.3%
2.9%
3.5%
5.1%
7.9%
8.7%
Minério
Cobre
Milho
WTI
Brent
Ouro
Soja
Commodities
-15
-8
-30
1
US 2Y
Pré Jan/28
US 10Y
Pré Jan/34
Juros (Bps)
-1.1%
0.5%
4.9%
6.0%
11.0%
17.2%
NASDAQ
S&P
China
Euro
Mexico
Brasil
Bolsas
0.6%
4.5%
6.8%
Euro
Mexico
Brasil
Moedas
-7.6%
0.1%
5.6%
10.3%
17.4%
20.5%
22.2%
Minério
Milho
Cobre
Soja
WTI
Brent
Ouro
Commodities
-10
-56
-28
-23
US 2Y
Pré Jan/27
Pré Jan/34
US 10Y
Juros (Bps)
Variação do Preço dos Ativos
Fevereiro
Ano

---

3.
www.legacycapital.com.br
Carta Mensal Fevereiro 2026
Atribuição de resultado 
O fundo teve rendimento de 1,7% no mês, e de 3,3% no ano. O desempenho reﬂe-
tiu, principalmente, ganhos em posições vendidas em USD e aplicadas em juros, par-
cialmente contrabalançadas por perdas em posições de bolsa.

---

O PIB dos EUA encerrou 2025 com crescimento de 2,2%, devendo acelerar-se para 
2,7% em 2026, de acordo com nossas projeções, tendo em vista a dissipação do 
efeito contracionista das tarifas, e o relaxamento das condições ﬁnanceiras imple-
mentado em 2025. A inﬂação, na métrica do core PCE, encerrou 2025 a 3,0%. Menor 
inﬂação de serviços e de bens devem levar a variação do core PCE para 2,2% em 
2026, nível próximo à meta. 
Pendente ainda o dado do 4T 25, estimamos que cerca de 1.8pp do crescimento 
do PIB de 2,4% registrado em 2025 tenha sido devido à produtividade. Esta taxa está 
em linha com o crescimento médio da produtividade nos últimos dez anos, e 
também com a média dos últimos 50 anos (gráﬁco abaixo).
O atual ciclo de investimento em tecnologia e IA ainda não está contribuindo para 
os ganhos contemporâneos de produtividade de forma material. Nosso entendi-
mento é que, à frente, os mesmos podem ser substanciais, devendo contribuir, a 
médio prazo, para a elevação do crescimento da produtividade da economia dos 
EUA para além de 2%, para a moderação do crescimento dos salários, e para a 
queda da inﬂação. Naturalmente, a velocidade elevada com que o processo vem 
avançando tem gerado preocupações com a possibilidade de disrupção de modelos 
de negócios de empresas grandes, e mesmo de setores inteiros, e, também, quanto 
às eventuais consequências que estes rearranjos possam gerar para o ciclo 
econômico, para a taxa de desemprego e a sustentabilidade da demanda agregada. 
4.
www.legacycapital.com.br
Carta Mensal Fevereiro 2026
Cenário internacional à frente

---

5.
www.legacycapital.com.br
Carta Mensal Fevereiro 2026
Cenário internacional à frente
Nossa visão é de que o ciclo de investimento permanece saudável, e tende a seguir 
contribuindo para o crescimento da demanda ao longo dos próximos trimestres, 
ainda que existam riscos importantes neste processo.  
 
O cenário global sofreu um choque importante com a deﬂagração do conﬂito de 
Israel e EUA contra o Irã, a partir do último dia de fevereiro. É bastante difícil, a esta 
altura, precisar como e por quanto tempo o conﬂito irá evoluir. A piora nas 
condições ﬁnanceiras representada pelo choque nos preços dos ativos – especial-
mente pela elevação no preço do petróleo – age no sentido de reduzir a atividade 
econômica global, aumentar a inﬂação e reduzir a renda disponível das famílias. 
Estes deveriam ser os efeitos econômicos caso o conﬂito se arraste por um tempo 
razoável. No momento, assumimos a hipótese de um conﬂito limitado no escopo e 
no tempo, que não gere alterações materiais no cenário benigno para ativos de risco 
com que temos trabalhado.

---

6.
www.legacycapital.com.br
Carta Mensal Fevereiro 2026
Brasil – cenário e perspectivas 
No Brasil, a atividade econômica segue em desaceleração. Os dados de dezembro 
conﬁrmaram nossa suspeita quanto à mudança de sazonalidade nas vendas de ﬁnal 
de ano, e reverteram parte importante da alta registrada em novembro. O cresci-
mento do PIB no 4T 25 conﬁrmou a desaceleração do consumo das famílias iniciada 
no 3T, e da demanda doméstica como um todo, ao longo de todo o ano de 2025. 
Seguimos projetando crescimento de 1,5% para o PIB em 2026.
A apreciação cambial continuada tem contribuído para o prosseguimento da 
queda das expectativas de inﬂação. A última leitura do IPCA-15 trouxe uma surpresa 
altista em alguns itens, mas que não comprometeu, em nossa avaliação, a perspecti-
va de convergência da inﬂação à meta. Projetamos inﬂação de 3,5% em 2026, e esti-
mamos que o BC já esteja enxergando inﬂação na meta no horizonte relevante, con-
siderando o cenário que contempla quedas de juros como no relatório focus. É 
importante também ter em mente que, de acordo com nossas projeções, a inﬂação 
acumulada em 12m, em junho deste ano, chegará a 3,0%, o ponto central da meta.
Nestas circunstâncias, a tendência é que o BC inicie o ciclo com um corte de 50bp 
em março. Seguimos enxergando espaço para um movimento total entre 350 e 
400bp de corte em 2026.
Os desenvolvimentos no plano eleitoral também têm sido favoráveis. A aprovação 
do governo Lula segue caindo, em especial, devido à continuidade dos escândalos 
de corrupção do Banco Master e do INSS. As pesquisas já apontam empate entre 
Flávio Bolsonaro e o presidente Lula, num eventual segundo turno, sendo que algu-
mas já mostram Lula numericamente atrás de Flávio. À frente, o ﬂuxo de notícias 
deve prosseguir desfavorável ao governo.
O efeito do conﬂito no Irã e dos choques de preços de ativos associados, no Brasil, 
tende a ser menos contracionista do que em economias com preços de combus-
tíveis livres e/ou que sejam importadoras de petróleo. Isso porque 1) a Petrobrás 
trabalhou, nos últimos trimestres, com preços de combustíveis aos distribuidores 
com prêmio signiﬁcativo sobre seus valores internacionais, o que permite à estatal 
não reajustar os preços internamente por um bom período; e 2) o país, como expor-
tador de petróleo, terá ganho de renda via maiores exportações líquidas.

---

7.
www.legacycapital.com.br
Carta Mensal Fevereiro 2026
Posicionamento  
Legacy Capital
A combinação de inﬂação contida e crescimento moderado é positiva para ativos 
de risco. A despeito da volatilidade e da crescente complexidade do quadro, os bons 
resultados das empresas americanas e a demanda crescente por investimento em 
IA ajudam a compor um horizonte favorável para bolsas. Prosseguimos com 
posições compradas em bolsas, mas reduzimos a exposição a empresas de 
tecnologia individuais, e diversiﬁcamos o portfólio, acrescentando posições em 
bolsas de países emergentes. Em moedas, seguimos comprados em moedas de 
carry e de DM cíclicas contra moedas de DM não cíclicas. Em juros internacionais, 
estamos aplicados nos EUA, México e UK, e tomados na Austrália. Mantemos a 
alocação em juros reais e nominais no Brasil, reﬂetindo nossa visão de que o ciclo 
tende a ser mais extenso do que o apreçado na curva de juros.

---

LEGACY CAPITAL FIC FIM
Público Alvo
Rentabilidade do fundo 1
Jan
Fev
Mar
Abr
Mai
Jun
Ago
Set
Out
Nov
Dez
Ano
12 m
Acumulado
(desde o início)
Fundo
1.56%
1.74%
-
-
-
-
-
-
-
-
-
3.32%
18.65%
129.22%
% CDI
134%
174%
-
-
-
-
-
-
-
-
-
-
-
-
153%
129%
139%
Rentabilidade Acumulada
Ano
Fundo
% CDI
2018
5.17%
164%
2019
15.00%
251%
2020
13.74%
496%
2021
1.32%
30%
2022
23.56%
190%
2023
7.85%
60%
2024
3.96%
36%
2025
14.89%
104%
2026
3.32%
153%
Indicadores
PL do fundo 2
Meses Positivos
PL Médio 12m ³
Meses Negativos
PL do Fundo Master²
Índice de Sharpe
Retorno Médio Mensal 4
Volatilidade Anualizada
Informações Gerais
CNPJ
Taxa de administração 5 
1.90% a.a
Data de Início 
Taxa de performance 
20% do que exceder 100% do CDI
Classificação Anbima
Horário limite de movimentações 
14h30
Cota
Investimento inicial mínimo
R$ 25,000.00
Benchmark
Movimentação adicional mínima 
R$ 5,000.00
Tributação 
Longo Prazo
Saldo mínimo de Permanência 
R$ 10,000.00
Gestão
Legacy Capital Gestora de Recursos Ltda
Cotização de aplicação 
Administração 
BNY Mellon Serviços Financeiros DTVM SA
Cotização de resgate
Auditoria
Deloitte Touche Tohmatsu Limited
Liquidação de resgate
1 du após a cotização
Contato : ri@legacycapital.com.br | Tel: +55  (11) 4130-7950 | www.legacycapital.com.br 
Av. Brigadeiro Faria Lima, 4221 - 10º andar - Itaim Bibi - São Paulo / SP - CEP 04538-133 
LEGACY CAPITAL GESTORA DE RECURSOS LTDA.  |  CNPJ : 28.674.641/0001-40  | Ato Declaratório CVM n° 16.010 de  07/12/2017.
3 Média aritmética da soma do PL apurado no último dia útil de cada mês, nos 12 (doze) meses anteriores.
4 Desde o início do fundo
² Valores do fechamento de 27/02/2026
29/06/2018
Multimercados Macro
Fechamento
66
26
0.39
A Legacy Capital não comercializa nem distribui cotas de fundos de investimento ou qualquer outro ativo financeiro. As informações contidas neste material são de caráter exclusivamente informativo e não se
caracterizam e nem devem ser entendidas como uma promessa ou um compromisso da Legacy Capital. A Legacy Capital não se responsabiliza por decisões do investidor, nem por ato ou fato de profissionais
especializados por ele consultados. Fundos de investimento não contam com a garantia do administrador, gestor da carteira ou qualquer mecanismo de seguro ou, ainda, pelo fundo garantidor de crédito – FGC.
Leia a lâmina de informações essenciais, se houver, o regulamento, o anexo – classe e o apêndice subclasse, conforme o caso, antes de investir. Para avaliação da performance de fundos de investimento, é
recomendável uma análise de, no mínimo, 12 meses. Rentabilidade obtida no passado não representa garantia de resultados futuros. A rentabilidade divulgada não é líquida de impostos. Este fundo pode utilizar
estratégias com derivativos como parte integrante de sua política de investimento. Tais estratégias, podem resultar em perdas patrimoniais para seus cotistas, podendo inclusive acarretar perdas superiores ao
capital aplicado e a consequente obrigação do cotista de aportar recursos adicionais para cobrir o prejuízo do fundo. Os ativos financeiros integrantes nesta carteira podem não possuir liquidez imediata, podendo
seus prazos e/ou rentabilidade variar de acordo com o vencimento ou prazo de resgate de cada ativo, caso seja negociado antecipadamente. Para mais informações, visite o site da Gestora ou do Administrador.
Administrador: BNY Mellon SF DTVM SA (CNPJ: 02.201.501/0001-61). Endereço; Av. Presidente Wilson, 231, 11º andar, Rio de Janeiro/RJ, CEP 20030-905. www.bnymellon.com.br/sf . SAC: sac@bnymellon.com.br ou
(21) 3219-2600 / (11) 3050-8010. Ouvidoria: ouvidoria@bnymellon.com.br ou  0800-725-3219.
R$ 146,426,694.14
5 Computando-se eventuais investimentos em outros fundos, a taxa de administração poderá atingir no máximo 2,50% a.a. sobre o PL do Fundo.
CDI
30.586.677/0001-14
0.92%
1 Rentabilidade mensal calculada com base na cota do último dia útil do mês, líquida de administração e performance e bruta de taxa de saída e impostos. 
5.84%
30 dc após a solicitação
R$ 158,028,123.85
1 du após a solicitação
R$ 3,402,180,361.24
Objetivo do Fundo
Proporcionar aos cotistas a valorização de suas cotas por meio da aplicação dos recursos em ativos financeiros e/ou modalidades operacionais disponíveis nos mercados de
renda fixa, renda variável, cambial, derivativos e cotas de fundos de investimento, negociados nos mercados interno e externo, baseado em cenários macroeconômicos de médio
e longo prazos. A política de investimentos do Fundo consiste em aplicar, no mínimo, 95% de seu patrimônio líquido em cotas do LEGACY CAPITAL MASTER FIM (CNPJ:
29.236.556/0001-63).
Jul
Investidores em geral.
2026
-
-20%
0%
20%
40%
60%
80%
100%
120%
140%
jul-18
jan-19
jul-19
jan-20
jul-20
jan-21
jul-21
jan-22
jul-22
jan-23
jul-23
jan-24
jul-24
jan-25
jul-25
jan-26
Legacy Capital FIC
CDI
Fevereiro de 2026
Material de divulgação
8.
www.legacycapital.com.br

---

www.legacycapital.com.br
A Legacy Capital não se responsabiliza por decisões do investidor, nem por ato ou fato de proﬁssionais especializados por ele consultados. O investidor deve se basear, 
exclusivamente, em sua opinião e na opinião de proﬁssionais especializados por ele contratados, para opinar e decidir. Este material não pode ser reproduzido, copiado 
ou distribuído para terceiros. Esta apresentação não se caracteriza nem deve ser entendida como uma promessa ou um compromisso da Legacy Capital de realizar as 
operações ou estruturar os veículos de investimento aqui descritos. Esta apresentação não se caracteriza e não deve ser entendida como consultoria jurídica, contábil, 
regulatória ou ﬁscal em relação aos assuntos aqui tratados. Este material é meramente informativo, não considera objetivos de investimento, situação ﬁnanceira ou 
necessidades individuais e particulares e não contém todas as informações que um investidor em potencial deve considerar ou analisar antes de 
investir. Não deve ser entendido como análise de valor mobiliário, material promocional, solicitação de compra ou venda, oferta ou recomendação de 
qualquer ativo ﬁnanceiro ou investimento e não conﬁgura sugestão ou consultoria jurídica. Recomendamos que consulte proﬁssionais especializados 
antes de decidir sobre investimentos.