

---

Maio 2026

---

2.
www.legacycapital.com.br
Carta Mensal Maio 2026
2.
www.legacycapital.com.br
Caros  
investidores,
A
dinâmica de mercado ao longo de maio foi marcada pela expectativa em torno 
da evolução das negociações para um acordo de paz entre Estados Unidos e Irã. 
Os preços dos ativos de risco permaneceram voláteis, oscilando conforme novas 
manchetes e declarações de representantes de ambos os países traziam sinais sobre 
a direção das conversas.
A falta de visibilidade quanto à resolução das divergências que impedem o avanço 
do acordo para a reabertura do Estreito de Ormuz intensiﬁcou a percepção de que 
poderemos conviver por um período mais prolongado com restrições na oferta de 
petróleo e derivados. Esse cenário manteve a pressão sobre o preço da commodity e 
sobre as curvas de juros ao redor do mundo, reforçando uma postura mais cautelosa 
por parte dos bancos centrais. Ainda assim, mesmo sem indicações concretas sobre 
o ﬁm do conﬂito, os mercados globais seguiram ampliando a exposição a risco ao 
longo do mês, sobretudo, em bolsas globais, em grande parte sustentados pela 
continuidade do entusiasmo com os setores de tecnologia.
Na margem, os sinais passaram a sugerir que o desenho de um acordo satisfatório 
para ambas as partes pode estar mais próximo. O preço do petróleo recuou cerca de 
15% em relação ao pico observado em meados do mês, enquanto outros ativos de 
risco também apresentaram desempenho positivo.

---

2.
www.legacycapital.com.br
Carta Mensal Maio 2026
3.
www.legacycapital.com.br
Caros  
investidores,
Variação do Preço dos Ativos
Maio
Ano

---

4.
www.legacycapital.com.br
Carta Mensal Maio 2026
Atribuição de resultado 
 O fundo teve rendimento de 1,48% no mês e de 3,71% no ano. O resultado 
positivo seguiu concentrado nos livros com posições otimistas em bolsa global, 
moedas e commodities.

---

5.
www.legacycapital.com.br
Carta Mensal Maio 2026
Cenário internacional à frente
O cenário macro global segue acompanhando a evolução do conﬂito. O risco de 
escalada parece ter diminuído após o cessar-fogo e o aparente estreitamento das 
posições dos EUA e do Irã nas negociações do acordo nuclear, que deve permitir a 
reabertura do Estreito de Ormuz.
Ainda não se pode descartar a possibilidade de uma retomada das hostilidades, 
que pode comprometer a infraestrutura de produção de energia do Golfo. No 
entanto, a probabilidade da volta ao conﬂito armado parece ter diminuído 
adicionalmente no último mês com o aparente avanço nas negociações.
A produção de petróleo na região do Golfo segue 15MBD abaixo do pré-guerra, o 
que representa quase 15% do o consumo mundial de petróleo. O preço do barril 
segue ﬂutuando entre US$ 90 e US$ 100 por barril, cerca 65% acima do nível 
pré-guerra. 
Estimamos que esse aumento de preço tenha provocado uma queda no consumo 
global de petróleo de 3 milhões de barris por dia (Mbpd), cerca de 3% do total. O 
déﬁcit remanescente de oferta de 12 Mbpd vem sendo coberto principalmente pela 
redução de estoques, em particular na China e no Japão. Se o estreito continuar 
fechado por um período prolongado, esgotando os estoques, o preço do petróleo 
deverá rondar na faixa de US$ 200 por barril para reequilibrar a demanda com a 
oferta reduzida. 
A ocorrência de um cenário benigno, em que um acordo é alcançado e o Estreito 
de Ormuz é reaberto em breve, vem se tornando mais provável nas últimas 
semanas. Nesse caso, estimamos que a produção pode voltar ao normal em um 
horizonte de três a seis meses após a reabertura, e o preço do petróleo pode cair 
para cerca de US$ 80 por barril até o ﬁm de 2026 e para US$ 70 por barril até o ﬁm 
de 2027, à medida que os estoques globais forem reconstituídos.

---

6.
www.legacycapital.com.br
Carta Mensal Maio 2026
Cenário internacional à frente
Nesse cenário, o surto de inﬂação e a desaceleração econômica devem ser 
relativamente contidos e transitórios. Alguns bancos centrais de países 
desenvolvidos poderão elevar as taxas de juros de forma pontual, com o objetivo 
principal de conter os efeitos secundários da alta nos preços de energia. 
Nos Estados Unidos, o Fed não deve elevar os juros, a menos que o Estreito de 
Ormuz permaneça fechado por um período prolongado, apesar do tom mais duro 
de alguns membros do comitê de política monetária. A inﬂação nos EUA deve ﬁcar 
perto de 3% no ﬁnal de 2026, mas se o choque se dissipar rapidamente, o Fed pode 
retomar os cortes de juros no ﬁm de 2026 ou início de 2027.
Na Europa, o BCE sinaliza que tenciona subir os juros em junho, mas o ajuste deve 
ser modesto, algo entre 25 e 50 pontos-base, dependendo da rapidez da reabertura 
do Estreito de Ormuz.

---

7.
www.legacycapital.com.br
Carta Mensal Maio 2026
Brasil – cenário e perspectivas 
No Brasil, a atividade econômica voltou a dar sinais de desaceleração. Os dados de 
abril indicaram piora nos principais vetores do consumo, com perda de dinamismo 
no mercado de trabalho, ainda que a taxa de desemprego permaneça em níveis 
historicamente baixos. O mercado de crédito também mostrou nova desaceleração 
nas concessões a famílias e empresas, enquanto o elevado comprometimento de 
renda segue como um ponto de atenção, sugerindo novas altas da inadimplência à 
frente. Nesse contexto, mantemos nossa projeção de desaceleração do crescimento 
do PIB para 1,8% em 2026.
A inﬂação corrente voltou a apresentar leituras sazonalmente elevadas, reﬂetindo 
tanto os efeitos do petróleo sobre os combustíveis quanto choques temporários de 
oferta que pressionam os preços de alimentos in natura. Além disso, as narrativas 
relacionadas aos riscos de médio prazo para a inﬂação evoluíram de forma 
desfavorável, sugerindo novas fontes de pressão sobre os preços em temas não 
diretamente associados à guerra. Entre esses riscos, destacam-se os potenciais 
efeitos do El Niño, que as previsões indicam poder ser o mais intenso desde o início 
da série histórica, em 1850; os impactos de uma eventual aprovação da legislação 
que altera a escala de trabalho no país; e, as medidas de estímulo da demanda 
doméstica feitas pelo governo diante do ciclo eleitoral. Passamos a incorporar 
parcialmente esses riscos em nosso cenário-base e, com isso, revisamos nossas 
projeções de inﬂação para 5,1% em 2026 e 4,8% em 2027.
A manutenção de um cenário ainda desaﬁador, marcado por atividade resiliente, 
inﬂação corrente pressionada e expectativas longas desancoradas, segue exigindo 
uma postura ﬁrme do Banco Central do Brasil. Apesar desse ambiente adverso, 
entendemos que o BCB ainda enxerga espaço suﬁciente no atual grau de aperto 
monetário para manter a estratégia de redução gradual da taxa de juros.

---

8.
www.legacycapital.com.br
Carta Mensal Maio 2026
Brasil – cenário e perspectivas 
Ao longo de maio, a dinâmica do conﬂito no Oriente Médio continuou 
inﬂuenciando o comportamento da curva de juros no Brasil. A correlação entre o 
preço da commodity em reais e a preciﬁcação do ciclo de juros, destacada em nossa 
carta mensal de abril, manteve-se consistente até meados do mês, quando a 
divulgação do vídeo envolvendo o candidato de oposição Flávio Bolsonaro e o 
empresário Daniel Vorcaro provocou uma descontinuidade na trajetória projetada. 
Desde então, a dinâmica da curva de juros não tem mais seguido de perto as 
oscilações do petróleo, abrindo uma diferença relevante entre a preciﬁcação 
estimada e a observada, sugerindo que o ciclo de cortes preciﬁcado pelo mercado, 
mesmo em um cenário de ﬁm da guerra, pode ser mais modesto do que o estimado 
anteriormente.

---

9.
www.legacycapital.com.br
Carta Mensal Maio 2026
Brasil – cenário e perspectivas 
O cenário eleitoral também passou por uma mudança relevante em maio. A 
divulgação de gravações envolvendo o candidato de oposição Flávio Bolsonaro e o 
empresário Daniel Vorcaro teve reﬂexos imediatos nas pesquisas de intenção de 
voto, que recolocaram o presidente em exercício na condição de favorito. Além da 
crise de imagem da oposição, o governo manteve ﬁrme a estratégia de utilização da 
máquina pública, ampliando a presença de menções positivas ao presidente Lula no 
noticiário e colhendo dividendos nas pesquisas ao longo do mês. Na margem, o 
candidato de oposição obteve uma vitória política importante ao articular, junto ao 
governo americano, a classiﬁcação de facções criminosas brasileiras como 
organizações terroristas. A medida coloca o presidente Lula e seu partido em uma 
posição delicada, por envolver um tema em relação ao qual historicamente mantém 
posicionamento controverso.

---

10.
www.legacycapital.com.br
Carta Mensal Maio 2026
Posicionamento  
Legacy Capital
Mantivemos uma postura cautelosa em termos de risco agregado, buscando 
atravessar um ambiente ainda marcado por elevada incerteza geopolítica e 
volatilidade. Apesar disso, seguimos enxergando um cenário relativamente mais 
favorável para os ativos americanos. A continuidade do ciclo de investimentos em 
inteligência artiﬁcial segue sustentando revisões positivas de lucro e forte 
desempenho das empresas de tecnologia, enquanto o dólar permanece resiliente, 
apoiado pelo diferencial de crescimento americano, pela atração de ﬂuxos para 
ativos americanos e pelo aumento das incertezas globais.
A combinação de crescimento mais resiliente, liderança tecnológica e ﬂuxos 
direcionados para os EUA tem permitido que bolsa e dólar apresentem força 
simultaneamente, um comportamento incomum, mas consistente com a atual 
percepção de excepcionalismo da economia americana. Para os próximos meses, 
continuamos privilegiando exposições de maior qualidade, com preferência por 
ativos americanos e posições compradas em dólar, mantendo disciplina na alocação 
de risco diante das incertezas ainda presentes no cenário global.
No Brasil estamos com risco mais baixo pela conjuntura local mais adversa, como 
discutido em nosso cenário, e pela expectativa de uma perda de atratividade de 
países emergentes em um cenário global que vem nos parecendo assimétrico na 
direção de um dólar mais forte.

---

LEGACY CAPITAL FIF CIC RL
Público Alvo
Rentabilidade do fundo 1
Jan
Fev
Mar
Abr
Mai
Jun
Ago
Set
Out
Nov
Dez
Ano
12 m
Acumulado
(desde o início)
Fundo
1.56%
1.74%
-3.55%
2.54%
1.48%
-
-
-
-
-
-
3.71%
13.47%
130.07%
% CDI
134%
174%
-
233%
138%
-
-
-
-
-
-
65%
91%
131%
Rentabilidade Acumulada
Ano
Fundo
% CDI
2018
5.17%
164%
2019
15.00%
251%
2020
13.74%
496%
2021
1.32%
30%
2022
23.56%
190%
2023
7.85%
60%
2024
3.96%
36%
2025
14.89%
104%
2026
3.71%
65%
Indicadores
PL do fundo 2
Meses Positivos
PL Médio 12m ³
Meses Negativos
PL do Fundo Master ²
Índice de Sharpe
Retorno Médio Mensal 4
Volatilidade Anualizada
Informações Gerais
CNPJ
Taxa de administração 5 
1.90% a.a
Data de Início 
Taxa de performance 
20% do que exceder 100% do CDI
Classificação Anbima
Horário limite de movimentações 
14h30
Cota
Investimento inicial mínimo
R$ 25,000.00
Benchmark
Movimentação adicional mínima 
R$ 5,000.00
Tributação 
Longo Prazo
Saldo mínimo de Permanência 
R$ 10,000.00
Gestão
Legacy Capital Gestora de Recursos Ltda
Cotização de aplicação 
Administração 
BTG Pactual Serviços Financeiros SA DTVM
Cotização de resgate
Auditoria
Deloitte Touche Tohmatsu Limited
Liquidação de resgate
1 du após a cotização
Contato : ri@legacycapital.com.br | Tel: +55  (11) 4130-7950 | www.legacycapital.com.br 
Av. Brigadeiro Faria Lima, 4221 - 10º andar - Itaim Bibi - São Paulo / SP - CEP 04538-133 
LEGACY CAPITAL GESTORA DE RECURSOS LTDA.  |  CNPJ : 28.674.641/0001-40  | Ato Declaratório CVM n° 16.010 de  07/12/2017.
3 Média aritmética da soma do PL apurado no último dia útil de cada mês, nos 12 (doze) meses anteriores.
4 Desde o início do fundo
² Valores do fechamento de 29/05/2026
29/06/2018
Multimercados Macro
Fechamento
68
27
0.31
A Legacy Capital não comercializa nem distribui cotas de fundos de investimento ou qualquer outro ativo financeiro. As informações contidas neste material são de caráter exclusivamente informativo e não se
caracterizam e nem devem ser entendidas como uma promessa ou um compromisso da Legacy Capital. A Legacy Capital não se responsabiliza por decisões do investidor, nem por ato ou fato de profissionais
especializados por ele consultados. Fundos de investimento não contam com a garantia do administrador, gestor da carteira ou qualquer mecanismo de seguro ou, ainda, pelo fundo garantidor de crédito – FGC.
Leia a lâmina de informações essenciais, se houver, o regulamento, o anexo – classe e o apêndice subclasse, conforme o caso, antes de investir. Para avaliação da performance de fundos de investimento, é
recomendável uma análise de, no mínimo, 12 meses. Rentabilidade obtida no passado não representa garantia de resultados futuros. A rentabilidade divulgada não é líquida de impostos. Este fundo pode utilizar
estratégias com derivativos como parte integrante de sua política de investimento. Tais estratégias, podem resultar em perdas patrimoniais para seus cotistas, podendo inclusive acarretar perdas superiores ao
capital aplicado e a consequente obrigação do cotista de aportar recursos adicionais para cobrir o prejuízo do fundo. Os ativos financeiros integrantes nesta carteira podem não possuir liquidez imediata, podendo
seus prazos e/ou rentabilidade variar de acordo com o vencimento ou prazo de resgate de cada ativo, caso seja negociado antecipadamente. Para mais informações, visite o site da Gestora ou do Administrador.
Administrador: BNY Mellon SF DTVM SA (CNPJ: 02.201.501/0001-61). Endereço; Av. Presidente Wilson, 231, 11º andar, Rio de Janeiro/RJ, CEP 20030-905. www.bnymellon.com.br/sf . SAC: sac@bnymellon.com.br ou
(21) 3219-2600 / (11) 3050-8010. Ouvidoria: ouvidoria@bnymellon.com.br ou  0800-725-3219.
R$ 127,528,260.98
5 Computando-se eventuais investimentos em outros fundos, a taxa de administração poderá atingir no máximo 2,50% a.a. sobre o PL do Fundo.
CDI
30.586.677/0001-14
0.90%
1 Rentabilidade mensal calculada com base na cota do último dia útil do mês, líquida de administração e performance e bruta de taxa de saída e impostos. 
5.86%
30 dc após a solicitação
R$ 147,711,855.77
1 du após a solicitação
R$ 3,106,088,111.64
Objetivo do Fundo
Proporcionar aos cotistas a valorização de suas cotas por meio da aplicação dos recursos em ativos financeiros e/ou modalidades operacionais disponíveis nos mercados de
renda fixa, renda variável, cambial, derivativos e cotas de fundos de investimento, negociados nos mercados interno e externo, baseado em cenários macroeconômicos de médio
e longo prazos. A política de investimentos do Fundo consiste em aplicar, no mínimo, 95% de seu patrimônio líquido em cotas do LEGACY CAPITAL MASTER FIM (CNPJ:
29.236.556/0001-63).
Jul
Investidores em geral.
2026
-
-
-20%
0%
20%
40%
60%
80%
100%
120%
140%
jul-18
jul-19
jul-20
jul-21
jul-22
jul-23
jul-24
jul-25
Legacy Capital FIC
CDI
Maio de 2026
Material de divulgação
11.
www.legacycapital.com.br

---

www.legacycapital.com.br
A Legacy Capital não se responsabiliza por decisões do investidor, nem por ato ou fato de proﬁssionais especializados por ele consultados. O investidor deve se basear, 
exclusivamente, em sua opinião e na opinião de proﬁssionais especializados por ele contratados, para opinar e decidir. Este material não pode ser reproduzido, copiado 
ou distribuído para terceiros. Esta apresentação não se caracteriza nem deve ser entendida como uma promessa ou um compromisso da Legacy Capital de realizar as 
operações ou estruturar os veículos de investimento aqui descritos. Esta apresentação não se caracteriza e não deve ser entendida como consultoria jurídica, contábil, 
regulatória ou ﬁscal em relação aos assuntos aqui tratados. Este material é meramente informativo, não considera objetivos de investimento, situação ﬁnanceira ou 
necessidades individuais e particulares e não contém todas as informações que um investidor em potencial deve considerar ou analisar antes de 
investir. Não deve ser entendido como análise de valor mobiliário, material promocional, solicitação de compra ou venda, oferta ou recomendação de 
qualquer ativo ﬁnanceiro ou investimento e não conﬁgura sugestão ou consultoria jurídica. Recomendamos que consulte proﬁssionais especializados 
antes de decidir sobre investimentos.