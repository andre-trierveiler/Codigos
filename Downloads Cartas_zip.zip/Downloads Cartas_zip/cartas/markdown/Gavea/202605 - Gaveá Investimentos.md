

---

Aberto para captação - Maio de 2026
PERFIL
O FUNDO
OBJETIVO
PÚBLICO-ALVO
POLÍTICA DE INVESTIMENTO DO FUNDO MASTER
GERENCIAMENTO DE RISCO
RENTABILIDADE
Jan
Fev
Mar
Abr
Mai
Jun
Jul
Ago
Set
Out
Nov
Dez
2026
Retorno
Excesso de Retorno
Fundo
0.32
  
1.85
  
2.82
-  
2.85
  
1.60
  
3.76
Retorno 
Anualizado ³
%CDI ⁴
Anualizado ³ ⁵
CDI
1.16
  
1.00
  
1.21
  
1.09
  
1.07
  
5.66
Maio
1.60%
22.19%
149.35%
7.79%
%CDI ⁴
27.10
185.32
-
261.52 149.35
66.41
2026
3.76%
9.65%
66.41%
-5.09%
12 Meses
8.37%
8.37%
56.71%
-6.39%
Desde Início
466.66%
10.20%
105.06%
0.25%
Jan
Fev
Mar
Abr
Mai
Jun
Jul
Ago
Set
Out
Nov
Dez
Ano
CDI
%CDI
2025
 0.37 
 0.07 - 1.43 
 0.58 - 0.81 
 2.15 -  1.69 
 1.77 
 0.72 
 0.48 
 0.20 
 0.77    3.16 
 14.31 
  22.08 
2024
- 0.43 - 0.07 
 1.77 - 2.15 - 0.11 
 1.86 
  1.51 - 0.04 
 1.91 
 0.56 
 0.81 
 1.84    7.64 
 10.87 
  70.25 
Dados Mensais
2026
12 Meses 
Desde Início
2023
 2.05 
 1.13 - 0.19 
 0.22 
 0.99 - 0.01 
  1.09 
 0.50 - 0.94 - 1.03 
 4.23 
 2.42 
 10.86 
 13.05 
  83.22 
Retorno Médio
0.76%
0.68%
0.82%
2022
 2.55 
 0.70 
 2.06 
 2.96 
 0.93 
 2.71 
  1.13 
 0.50 
 0.59 
 0.96 
 1.19 
 1.01 
 18.68 
 12.37 
150.96 
Maior Retorno
2.85%
2.85%
6.85%
2021
 1.10 
 2.34 
 1.61 - 0.09 
 0.34 
 0.64 -  1.69 
 1.12 
 2.36 - 1.05 - 0.34 
 0.17    6.62    4.40 
150.53 
Menor Retorno
-2.82%
-2.82%
-7.23%
2020
- 0.65 
 2.55 
 2.72 
 0.49 
 1.07 
 0.49 
  1.46 
 0.90 - 0.12 
 0.64 
 1.22 - 0.01 
 11.25    2.77 
406.47 
% Meses Positivos
80%
83%
76%
2019
 2.41 
 0.87 - 1.33 
 1.14 
 0.54 
 0.37 
  2.12 - 0.99 - 1.89 - 0.14 - 0.37 
 2.66    5.40    5.97 
  90.46 
% Meses Acima CDI
60%
42%
53%
2018
 1.39 
 0.23 
 0.11 
 1.69 
 3.06 
 3.34 -  0.48 
 2.02 - 0.21 
 1.05 - 2.06 - 2.04    8.24    6.42 
128.31 
Máximo Drawdown
-2.82%
-2.82%
-10.60%
2017
- 0.81 - 0.49 
 0.84 
 0.44 - 0.81 
 1.15 
  0.06 
 1.29 
 1.38 
 0.97 
 1.55 
 0.51    6.22    9.95 
  62.50 
-- # de Meses
1
1
2
2016
 1.24 
 0.82 - 3.26 
 2.02 
 0.99 
 1.00 
  0.74 
 4.14 
 0.91 
 2.74 
 2.20 
 1.57 
 16.02 
 14.00 
114.45 
2015
 4.43 
 1.73 
 3.85 - 2.68 
 4.14 - 0.61 
  4.94 
 3.05 
 2.72 - 0.07 
 1.97 
 0.71 
 26.69 
 13.23 
201.75 
2014
 0.62 - 0.28 
 0.78 - 1.32 - 0.42 - 0.71 
  2.27 - 0.56 
 6.85 - 4.25 
 0.48 
 1.18    4.37 
 10.81 
  40.44 
2013
 2.01 
 1.21 
 1.73 
 0.75 
 1.73 - 0.03 
  0.89 - 0.15 - 2.63 
 0.09 
 1.82 
 1.67    9.38    8.05 
116.41 
2012
 2.93 
 1.02 
 0.10 
 0.26 - 1.57 
 1.12 
  2.09 
 0.88 
 0.58 
 0.29 
 1.21 
 3.50 
 13.02    8.41 
154.70 
2011
 0.21 
 1.38 
 0.92 
 0.58 - 0.21 
 0.54 
  0.80 
 2.77 
 0.50 
 1.15 
 1.17 - 1.08    9.02 
 11.59 
  77.76 
2010
 1.06 
 0.73 
 0.53 
 2.26 
 0.02 - 0.04 
  0.20 
 1.31 
 1.54 
 1.11 
 0.11 
 1.31 
 10.61    9.74 
108.93 
2009
 2.41 
 0.91 
 1.33 
 0.97 
 3.49 
 2.14 
  2.27 
 0.92 
 2.62 
 1.03 
 0.95 
 1.35 
 22.34    9.90 
225.73 
2008
 
 
 
 
 
   1.45 
 0.08 - 3.63 - 7.23 
 0.56 
 1.85 -  7.04    6.63 
- 
*RENTABILIDADE MENSAL (%) CALCULADA COM BASE NA COTA DO ÚLTIMO DIA ÚTIL DO MÊS, LÍQUIDA DE TAXAS DE ADMINISTRAÇÃO E PERFORMANCE E BRUTA DE IMPOSTOS.
Dados Diários
Volatilidade Anualizada ³
Sharpe Anualizado ³
Maior Retorno
Menor Retorno
Máximo Run-up 
Máximo Run-down
Máximo Drawdown
Maio
2026
12 meses
Desde Início
Câmbio
Ásia (ex. Japão)
43
56
100
2,722
Bolsa
EMEA 
21
12
27
2,488
Renda Fixa
Desenvolvidos
31
(135)
(135)
4,635
Outros
 
América Latina(ex. Brasil)
21
72
103
2,833
Excesso Bruto
Brasil
(46)
(88)
(440)
(27)
Caixa
Múltiplas  Regiões  
0
0
(4)
58
Despesas ⁷
Excesso Bruto
71
(83)
(349)
12,708
Excesso de Retorno
CDI
# de Países
18
24
25
48
Retorno
# de Estratégias
66
134
174
1,532
RETORNOS MENSAIS DOS ANOS ANTERIORES*
Material Publicitário
RETORNOS MENSAIS 2026*
O GÁVEA MACRO FIF CIC MULTIMERCADO RL (“Fundo”) é um fundo de investimento em cotas de fundo de investimento constituído sob a forma
de condomínio aberto, com prazo indeterminado de duração, regido por regulamento próprio e pelas disposições legais e regulamentares
aplicáveis.
Buscar a valorização de suas cotas por meio de aplicação de, no mínimo, 95% de seu patrimônio líquido em cotas do Gávea Macro Master FIM
(“Fundo Master”).
O Fundo destina-se a receber aplicação de pessoas físicas e pessoas jurídicas em geral.
Sua carteira, de perfil agressivo, poderá ser composta por instrumentos negociados no mercado de derivativos, sujeitos a variações
expressivas de preço. Sua estratégia de investimento poderá incluir posições de compra e venda direcionais, operações de arbitragem e pares
de valor relativo. Poderá incluir também aplicações de até 20% de seu patrimônio líquido (ou percentual maior caso isso venha a ser permitido
pela regulamentação) em ativos financeiros negociados no exterior. Não há limites de alavancagem das operações no mercado de derivativos,
com exceção dos limites definidos pelo gerenciamento de risco adotado pela gestora, e não há restrições quanto à diversificação e/ou
concentração de ativos, sempre observada a legislação em vigor.
Os principais fatores de risco do Fundo são taxas de câmbio, renda fixa, renda variável e commodities, negociados no Brasil (principalmente) e 
no exterior. O gerenciamento de risco visa monitorar as diferentes dimensões dos riscos do Fundo. Para tanto, são utilizadas diversas medidas
de risco. O Fundo tem seu risco máximo limitado por metodologia de teste de estresse que combina estudos estatísticos sobre o
comportamento histórico dos fatores de risco e análise sobre o possível comportamento futuro destes fatores segundo a avaliação da
gestora.O limite de risco aqui referido é estabelecido pelo Comitê de Risco, de acordo com as diretrizes internas da Gávea Investimentos. O
limite de risco não constitui uma obrigação legal e pode ser alterado a qualquer momento. Não há garantias de que os fundos não incorrerão
perdas maiores que seu limite de risco.
1.47%
Maio
3.4%
1.9
-4.99%
-1.63%
17
0
Maio
(9)
63
(169)
(5)
(349)
-12.02%
4.30%
-6.58%
2.47%
(639)
(12,799)
2,248
(107)
0
(220)
12 meses
(140)
(35)
2026
(95)
12,708
44,419
46,666
71
(1)
(17)
53
107
160
(83)
(23)
(85)
(190)
566
376
1,476
837
2,339
Desde Início
4,754
(1,934)
9,765
122
(69)
2026
7.0%
-0.6
1.40%
120
0.64%
-0.31%
-2.82%
-0.84%
-0.56%
Desde Início
5.0%
0.1
2.36%
-2.22%
80
180
280
380
480
580
680
jun-08
dez-08
jun-09
dez-09
jun-10
dez-10
jun-11
dez-11
jun-12
dez-12
jun-13
dez-13
jun-14
dez-14
jun-15
dez-15
jun-16
dez-16
jun-17
dez-17
jun-18
dez-18
jun-19
dez-19
jun-20
dez-20
jun-21
dez-21
jun-22
dez-22
jun-23
dez-23
jun-24
dez-24
jun-25
dez-25
GÁVEA MACRO FIF CIC MULTIMERCADO RL
ATRIBUIÇÃO DE DESEMPENHO POR MERCADO ⁶ ¹¹
ATRIBUIÇÃO DE DESEMPENHO POR REGIÃO ⁶ ¹¹
PERFORMANCE ACUMULADA
PRINCIPAIS CARACTERÍSTICAS
Classificação ANBIMA
Multimercados Livre
Código ANBIMA
211788
Data de Início
30 de junho de 2008
Gestora
Gávea Investimentos Ltda.
Administrador
BEM DTVM Ltda. (Grupo Bradesco)
Custodiante
Banco Bradesco  S.A.
Auditores
KPMG
Taxa de Administração e Custódia
Taxa Máxima de Custódia: 0,02% ao ano, paga mensalmente
Taxa de Administração Global: 1,975% ao ano, paga mensalmente.¹
Taxa Máxima de Administração e de Gestão: 2% ao ano, paga mensalmente.²
Taxa de Performance
20% do rendimento do Fundo que exceder a 100% da variação do CDI, paga
semestralmente.
Valores Mínimos
Aplicação Inicial e Permanência:R$ 50.000,00
Movimentações Subsequentes: R$ 25.000,00
ESTATÍSTICAS
ESTATÍSTICAS
EVOLUÇÃO DA COTA FINAL DE MÊS
Mês (R$ mil): 121,827
Médio dos últimos 12 meses (R$ mil): 236,773
https://www.gaveainvest.com.br/fundos/gavea-macro-fic-fim/

---

Aberto para captação - Maio de 2026
RISCO
Pior Cenário
Plausível
Por Região
Asia (ex. Japão)
EMEA
Desenvolvidos
América Latina
   Brasil
Múltiplas Regiões
Por Mercado
Câmbio
Bolsa
Renda Fixa
Outros
PROCEDIMENTOS DE MOVIMENTAÇÃO
APLICAÇÕES
RESGATES
TAXA DE INGRESSO / SAÍDA
PROCEDIMENTO
Não há.
VALORES MÍNIMOS
Aplicação Inicial e Permanência:R$ 50.000,00
Movimentações Subsequentes: R$ 25.000,00
0.83%
1.37%
4.34%
Material Publicitário
7.86%
30/04/2026
0.22%
Global Risk 
Aversion
29/05/2026
30/04/2026
0.00%
0.35%
3.99%
0.18%
0.17%
0.00%
0.12%
0.26%
0.16%
0.35%
1.95%
0.13%
0.00%
0.44%
-0.48%
0.49%
-0.59%
2.58%
2.76%
3.45%
Teste de Estresse 3 dias ⁸, %PL
(Pior Cenário Plausível)
VaR Monte-Carlo ⁹
1 dia, 98%
0.36%
Global Risk 
Aversion
1.67%
29/05/2026
1.01%
0.85%
0.38%
Cenário
3.48%
0.44%
0.02%
0.12%
0.07%
0.11%
0.15%
0.39%
0.00%
0.13%
0.07%
0.00%
5.79%
-0.01%
LEIA A LÂMINA DE INFORMAÇÕES ESSENCIAIS (SE HOUVER), O REGULAMENTO, COMUNICADOS E EVENTUAIS FATOS RELEVANTES ANTES DE INVESTIR. ESSES DOCUMENTOS PODEM SER OBTIDOS NA SEÇÃO DE
INFORMAÇÕES AOS COTISTAS DO SITE DO ADMINISTRADOR DOS FUNDOS (www.bradescobemdtvm.com.br). A RENTABILIDADE PASSADA NÃO REPRESENTA GARANTIA DE RENTABILIDADE FUTURA. FUNDOS DE
INVESTIMENTO NÃO CONTAM COM GARANTIA DO ADMINISTRADOR DO FUNDO, DO GESTOR DA CARTEIRA, DE QUALQUER MECANISMO DE SEGURO OU, AINDA, DO FUNDO GARANTIDOR DE CRÉDITOS – FGC. A
RENTABILIDADE DIVULGADA NÃO É LÍQUIDA DE IMPOSTOS, MAS É LÍQUIDA DE TAXA DE ADMINISTRAÇÂO E DE TAXA DE PERFORMANCE. 
Nesse fundo, a data de conversão de cotas é diversa da data de pagamento do resgate. Não há garantia de que este fundo terá o tratamento tributário para fundos de longo prazo. Este fundo está
autorizado a realizar aplicações em ativos financeiros no exterior. Este fundo pode estar exposto a significativa concentração em ativos de poucos emissores, com os riscos daí decorrentes. Este fundo
utiliza estratégias que podem resultar em significativas perdas patrimoniais para seus cotistas, podendo inclusive acarretar perdas superiores ao capital aplicado e a consequente obrigação do cotista de
aportar recursos adicionais para cobrir o prejuízo. IOF: Cobrado no caso de resgate até o 29º dia da aplicação, segundo a tabela publicada na Portaria nº 264/99. Imposto de Renda: 15% sobre o ganho
nominal para permanência superior a 2 anos. 
Ouvidoria: 0800 60 42832 ou 0800 60 GAVEA | ouvidoria@gaveainvest.com.br | www.gaveainvest.com.br | Av. Ataulfo de Paiva, 1100 - 7º andar, Leblon, Rio de Janeiro | 22440-035 - Brasil
(1) O sumário da remuneração de prestadores de serviço, contendo as taxas segregadas, está disponível na página de Transparência Informacional;
(2) Compreende a Taxa de Administração Global de 1,975% e a Taxa Máxima de Administração e de Gestão cobrada pelo Fundo Master;
(3) Anualizado a partir dos retornos diários, supondo 252 dias úteis no ano, exceto períodos que compreendam 12 meses; 
(4) % CDI é a razão percentual entre o retorno do Fundo e o CDI acumulado. Nas hipóteses em que o índice de referência (benchmark), ou o Fundo, ou ambas as variáveis forem negativas, a informação será omitida, em conformidade com as
DIRETRIZES ANBIMA PARA PUBLICIDADE E DIVULGAÇÃO DE MATERIAL TÉCNICO DE FUNDOS DE INVESTIMENTO; 
(5) Do retorno do Fundo acumulado anualizado, subtrai-se o CDI acumulado anualizado no período; 
(6) Excesso de retorno sobre CDI, pontos percentuais, valores aproximados; 
(7) Contém despesas do Fundo, tais como: taxas de administração e performance, auditoria, liquidação, custodia, etc; 
(8) Teste de estresse: tem como propósito simular a pior perda plausível do portfólio em 3 dias. O resultado do teste de estresse é a perda máxima simulada dentre diversos cenários macroeconômicos e estatísticos.
(9) Value at Risk (VaR): perda máxima esperada do portfólio em 1 dia para o nível de confiança de 98%; 
(10) A distribuição conjunta dos fatores de risco da carteira tem a seguinte forma paramétrica: os fatores são modelados por distribuições t assimétricas, e a estrutura de interdependência entre eles, por uma cópula t. A distribuição é
simulada por Monte Carlo e os retornos da carteira são calculados por apreçamento completo. O risco da carteira é uma perda severa simulada; 
(11) A partir de janeiro/2015, alteramos a metodologia de cálculo da atribuição de performance por classe de ativos e por região com o objetivo de aumentar a acurácia da alocação do fator cruzado entre os componentes. A partir de
janeiro/2023, a quebra do desempenho por região foi ajustada para refletir os retornos por estratégia ao invés de por ativo investido, com exceção das estratégias em múltiplas regiões. 
Para maiores esclarecimentos, por favor entre em contato com a nossa área comercial (relacionamento@gaveainvest.com.br e (11/21) 3526-9901).
Serão efetivadas pelo valor da cota de fechamento em vigor no mesmo dia
da disponibilidade dos recursos ao Administrador. Aplicações podem ser
efetuadas através de TED ou qualquer outro instrumento de transferência no
âmbito do Sistema de Pagamentos Brasileiro (SPB).
Resgates serão pagos utilizando-se o valor da cota em
vigor 29 (vinte e nove) dias após o recebimento do
pedido de resgate (“data de conversão”). Resgates
serão efetivados no 1° (primeiro) dia útil subseqüente
à data de conversão.
Aplicações e resgates devem ser solicitados por escrito
à área de atendimento ao cliente até as 15:00 horas
de cada dia. Os pedidos de aplicações e resgates
efetuados aos sábados, domingos e feriados, serão
processados no dia útil subsequente.
0%
1%
2%
3%
4%
5%
6%
7%
8%
9%
10%
11%
12%
13%
14%
15%
0%
1%
2%
3%
4%
5%
6%
7%
8%
9%
10%
11%
12%
13%
14%
15%
jul-08
jul-09
jul-10
jul-11
jul-12
jul-13
jul-14
jul-15
jul-16
jul-17
jul-18
jul-19
jul-20
jul-21
jul-22
jul-23
jul-24
jul-25
Limite Máximo
Média
TESTE DE ESTRESSE - PIOR CENÁRIO PLAUSÍVEL DESDE O INÍCIO
Distribuidor: Gávea Investimentos Ltda.
E-mail: relacionamento@gaveainvest.com.br
Tel: (21/11) 3526-9901
www.gaveainvest.com.br
Ouvidoria : 0800 60 42832
Supervisão e Fiscalização:
Comissão de Valores Imobiliários - CVM 
Contato: www.cvm.gov.br
Serviço de Atendimento ao Cidadão em 
www.cvm.gov.br.
ATENDIMENTO AO CLIENTE
DADOS BANCÁRIOS
Favorecido: GÁVEA MACRO FIF CIC MULTIMERCADO RL (08.893.082/0001-
52)
Banco: Bradesco (237)
Agência: 2856-8
Conta Corrente: 589.780-7
GÁVEA MACRO FIF CIC MULTIMERCADO RL