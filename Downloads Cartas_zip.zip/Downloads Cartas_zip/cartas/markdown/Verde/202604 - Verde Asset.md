

---

A Verde Asset Management S.A. (“Verde”) não comercializa e nem distribui cotas de fundos ou qualquer outro ativo financeiro. Este relatório mensal retrata as opiniões da Verde acerca 
da estratégia e gestão do fundo e não deve ser entendido como oferta, recomendação ou análise de investimento ou ativos. Rentabilidade obtida no passado não representa garantia de 
resultados futuros. A rentabilidade divulgada não é líquida de impostos O investimento em Fundo não é garantido pelo Fundo Garantidor de Crédito. Leia a lâmina de informações
essenciais, se houver, e o regulamento antes de investir. A Verde não se responsabiliza por erros de avaliação ou omissões. Os investidores devem tomar suas próprias
decisões de investimento. O investimento em fundos pode resultar em perdas patrimoniais para seus cotistas, podendo inclusive acarretar perdas superiores ao 
capital aplicado e a consequente obrigação do cotista de aportar recursos adicionais para cobrir o prejuízo do fundo. Para mais informações acerca das taxas de 
administração, cotização e público-alvo de cada um dos fundos, consulte os documentos do fundo disponíveis no site verdeasset.com.br. Este material não pode 
ser copiado, reproduzido ou distribuído sem a prévia e expressa concordância da Verde. Supervisão e Fiscalização: Comissão de Valores Mobiliários (CVM) -
Serviço de Atendimento ao Cidadão: www.cvm.gov.br. Contato Institucional Verde AM: institucional@verdeasset.com.br / +55 11 4935-8500. 
VERDE FIF CIC MULTIMERCADO RL 
Relatório de Gestão 
Abril de 2026 
 
O fundo Verde teve em abril ganhos em renda variável, tanto no exterior 
quanto no mercado local, na posição comprada em Real, e em posições de 
juros reais nos Estados Unidos. As perdas vieram das posições em metais 
preciosos e no hedge em crédito da Arábia Saudita. 
A evolução do conflito entre Estados Unidos e Irã foi determinada no início 
do mês pelo cessar-fogo entre as partes. Os mercados reagiram com 
bastante empolgação, mas a questão do estreito de Hormuz continua sem 
resolução – os iranianos tentando consolidar controle e pedagiar o fluxo 
de navios, enquanto os americanos (e o resto do mundo) argumentam que 
tal solução é inviável. Isso levou a uma alta do preço do petróleo na 
segunda metade do mês, revertendo a maior parte do otimismo inicial com 
a parada das hostilidades. A postura do presidente Trump nos últimos dias 
indica uma baixa tolerância para retomada de ataques militares, e os 
persas tentam construir alavancagem negocial a partir dessa percepção. 
Há indicativos de que na próxima semana teremos um acordo, com 
colaboração da China, mas não estamos plenamente confortáveis com essa 
conclusão – as possibilidades de os iranianos exagerarem na dose durante 
as negociações são relevantes. Enquanto isso não se resolve, os estoques 
do mundo, tanto no petróleo cru quanto em seus derivados, vão sendo 
consumidos. Em meados de junho podemos entrar numa fase mais aguda 
de necessidade de destruição de demanda. O fundo voltou a ter proteções 
via opções para um cenário de preços de petróleo mais altos. 
 
Desempenho 
Abril 2026 
Acumulado 2026 
 
 
Verde 
2,71% 
7,41% 
 
 
CDI 
1,09% 
4,54% 
 
 
Para mais informações relevantes à análise da rentabilidade deste Fundo - tais como taxa de administração, 
taxa de performance, rentabilidade “mês a mês” ou PL médio, consulte o Resumo Gerencial ao final deste material.

---

Abril de 2026 
2 
VERDE FIF CIC MULTIMERCADO RL 
Relatório de gestão 
Apesar da guerra, o grande tema do mês foi a forte alta das ações ligadas 
ao ciclo de investimento em Inteligência Artificial. A explosão de demanda 
por capacidade computacional e de memória, a partir do crescimento 
exponencial do consumo de tokens por ferramentas como Claude Code e 
OpenAI Codex, é dinâmica dominante no mercado acionário americano (e 
outros como Coréia e Taiwan). Temos visto revisões positivas de 
expectativa de lucro das empresas americanas, especialmente daquelas 
ligadas a semicondutores e os chamados hyperscalers, dinâmica 
confirmada na recente temporada de divulgação de resultados das 
empresas. Com isso os mercados responderam com performance forte – 
S&P 500 +10.4% e Nasdaq +15.6% no mês - e voltamos a discutir o tema 
do excepcionalismo americano. 
O Brasil, tendo se beneficiado enormemente de fluxos externos nos meses 
anteriores, viu alguma acomodação ao longo de abril, com os primeiros 
sinais de saídas pontuais de capital. Ainda assim o Real teve um mês muito 
bom, valorizando-se +4.3%, enquanto o Ibovespa fechou essencialmente 
de lado. No momento que os mercados mudaram seu foco da guerra (e 
petróleo) para a dinâmica de tecnologia e IA, a atratividade relativa do país, 
já num preço mais caro, ficou menor. Mantemos olhar atento para 
oportunidades que surjam nesse contexto se a correção do mercado local 
se aprofundar. 
O fundo manteve sua exposição em renda variável, tanto no Brasil quanto 
no mercado global. Na renda fixa local não temos posições direcionais. 
Nos EUA mantemos a alocação aplicada em juro real e comprada na 
inflação implícita. Zeramos a maior parte das posições de moedas por 
disciplina de risco mantendo apenas opções de compra no Real. 
Continuamos alocados em ouro e prata. Continuamos carregando uma 
compra de proteção de crédito da Arábia Saudita, e voltamos a 
implementar posições compradas em petróleo através de opções. A 
alocação de crédito local foi mantida.

---

Abril de 2026 
3 
VERDE FIF CIC MULTIMERCADO RL 
Relatório de gestão 
 
Breakdown — Resultados do Fundo 
 
 
 
 
 
 
 
Abril
Acum ulado
2026
2026
Dólar 
0,49
0,97
Moedas
0,01
-0,06
Resultado Moedas
0,49
0,91
II) Book Renda Fixa
DI pré
0,00
0,07
Cupom cambial
0,00
0,00
RF Inflação
-0,10
-0,17
Global Rates
0,18
0,30
Crédito
-0,15
-0,98
Resultado Renda Fixa
-0,08
-0,78
III) Book Ações
Resultado Ações
1,64
2,81
CDI
1,09
4,54
Moedas(I)+Renda Fixa(II)+Outros
0,49
1,04
Ações(III)
1,64
2,81
Custos
-0,51
-0,98
Resultado do Fundo 
2,71
7,41
Resultado Real do Verde — Rentabilidade ex CDI
I) Book Moedas
Para todos os ativos que utilizamos caixa,  as rentabilidades expressas acima já 
são reais (ex CDI)
4,54%
2,81%
0,91%
0,91%
-0,78%
-0,98%
7,41%
0,0%
0,5%
1,0%
1,5%
2,0%
2,5%
3,0%
3,5%
4,0%
4,5%
5,0%
5,5%
6,0%
6,5%
7,0%
7,5%
8,0%
8,5%
9,0%
9,5%
CDI
Book
Ações
Outros
Book
Moedas
Book
Renda
Fixa
Custos TOTAL

---

Resumo Gerencial
Público-alvo
Características
Performance
CNPJ
Retorno anualizado
Data de início
Desvio padrão anualizado *
Aplicação mínima
Índice de sharpe *
Saldo mínimo
Rentabilidade acumulada em 12 meses
Movimentação mínima
Número de meses positivos
Cota
Número de meses negativos
Cota de aplicação
Número de meses acima de 100% do CDI
Cota de resgate
Número de meses abaixo de 100% do CDI
Liquidação de resgate
Maior rentabilidade mensal
Carência para resgate
Menor rentabilidade mensal
Tributação aplicável
Patrimônio líquido *
R$
Taxa de saída antecipada
Patrimônio líquido médio em 12 meses
R$
Taxa Global *
Taxa de performance
Fechado para novas aplicações
Classificação ANBIMA:
Multimercado Macro
Admite Alavancagem:
Sim
Gestor:
Verde Asset Management S.A
Administrador:
Intrag Distribuidora De Títulos E Valores Mobiliários Ltda.
Volatilidade anualizada (Desvio padrão - média 40 dias)
* Calculado desde a constituição do fundo até 30/abr/2026
1,99
1,41
1,06
1,01
15,94
14,31
31.811,05
3.805,79
1,50% sobre o patrimônio líquido do fundo, apropriada 
diariamente, com pagamento mensal
1,70
-0,18
3,29
2,20
12,10
10,87
27.422,96
3.316,75
-0,46
3,51
-0,30
0,93
15,93
12,37
21.336,72
2025
1,64
0,55
0,58
1,90
1,31
0,97
0,22
2,27
2024
-0,28
0,89
1,52
-3,83
2,53
1,66
1,44
0,72
2.625,98
2022
1,49
1,32
4,19
1,02
1,31
-1,86
1,54
2,34
20% que exceder a 100% do CDI
VERDE FIF CIC MULTIMERCADO RL  x CDI
887.092.178,10
889.146.641,78
-11,46%
recomendação ou análise de investimento ou ativos. Rentabilidade obtida no passado não representa garantia de resultados futuros. A rentabilidade divulgada não é líquida de impostos. O investimento em Fundo não é garantido pelo Fundo
Garantidor de Crédito. Leia a lâmina de informações essenciais, se houver, e o regulamento antes de investir. A Verde não se responsabiliza por erros de avaliação ou omissões. Os investidores devem tomar suas próprias decisões de
investimento. O investimento em fundos pode resultar em perdas patrimoniais para seus cotistas, podendo inclusive acarretar perdas superiores ao capital aplicado e a consequente obrigação do cotista de aportar recursos adicionais para
cobrir o prejuízo do fundo. Para mais informações acerca das taxas de administração, cotização e público-alvo de cada um dos fundos, consulte os documentos do fundo disponíveis no site verdeasset.com.br. Este material não pode ser
copiado, reproduzido ou distribuído sem a prévia e expressa concordância da Verde. Supervisão e Fiscalização: Comissão de Valores Mobiliários - CVM. Serviço de Atendimento ao Cidadão: www.cvm.gov.br.
Contato Institucional Verde AM: institucional@verdeasset.com.br / +55 11 4935-8500.
3,05
0,12
0,58
-0,18
-1,80
0,29
1,10
0,70
1,30
0,89
0,00
1,92
13,33
5,97
17.893,01
A Verde Asset Management S.A. (“Verde”) não comercializa e nem distribui cotas de fundos ou qualquer outro ativo financeiro. Este relatório mensal retrata as opiniões da Verde acerca da estratégia e gestão do fundo e não deve ser entendido como oferta,
2018
2014
2013
0,65
-0,27
1,05
3,87
2006
988,32
1.079,88
1.174,90
8,05
8.572,99
1,45
3,71
2,46
2,19
2,19
1,23
13,75
19,00
15,05
-1,13
2012
2011
1.312,68
0,70
459,37
543,53
1.945,54
2.512,98
3.316,10
1,94
-0,48
2,63
2,70
4.705,98
19,55
5.366,93
9,90
9,74
50,37
6.042,75
7.243,48
4,38
4,98
8,41
12,36
2,16
2,44
Calculado até 30/abr/2026
-0,30
3,77
0,55
-0,13
7,91
6,42
15.776,46
2.033,78
304,64
16,17
3.096,20
11,82
1,24
27,74
30,74
370,06
294,66
404,89
5,31
17,33
1,14
1,69
11,59
2004
2003
2002
2001
2,90
2,29
2005
-0,00
2010
2009
2008
2007
0,82
0,73
5,96
Não há
Longo Prazo
Não há
D+0
D+1
Fechamento
D+0
63,45%
-
                    
-
                    
3,28%
0,13%
1999
1998
1,57
3,45
2015
619,62
708,64
788,66
875,24
1,81
0,77
0,43
2,84
6,69
1,38
2,89
0,27
5,16
3,68
1,44
0,33
4,58
3,66
2,43
2000
0,83
3,62
2,19
1,37
1,16
3,65
-1,37
3,79
4,37
-2,46
-3,53
-3,92
-1,68
2,52
3,00
-2,17
1,10
2,62
1,16
3,33
-0,68
4,12
1,86
1.499,56
1,58
2,48
1,04
28,67
13,23
-0,64
3,46
2,98
8,80
10,81
9.336,59
12.041,74
1,18
556,42
876,24
1.288,44
-7,32
-8,91
2,20
1,47
-6,44
12,37
1,90
2,12
1,99
0,60
1.599,90
22,43
4,02
2,96
20,33
0,93
42,22
23,28
CDI
0,28
135,40
25,17
1,03
2,01
3,34
1,58
1,11
30,01
17,27
0,12
2,62
27,93
29,86
28,61
4,51
4,14
Set
Ago
1,86
18,10
-0,42
0,12
-1,76
1,86
2,76
2,32
0,43
1,83
0,77
1,09
2,19
Dez
Acum. 
Ano
2,71
6,96
1,95
2,30
0,11
4,80
4,17
-0,15
-0,35
4,52
1,45
6,09
2,70
2,77
3,31
-0,06
-0,51
-0,19
2,28
3,68
0,96
5,41
-0,31
0,98
4,48
3,56
2,61
2,80
-0,94
0,69
1,74
0,91
1,22
1,98
0,71
1,79
0,36
1,91
1,71
0,33
-0,87
4,76
3,35
1,27
2,65
-0,65
0,33
1,66
11,41
-1,66
3,70
1,39
-2,71
2,55
-0,50
Jan
4,37
2,43
1,87
2,41
1,98
3,12
1,40
-0,06
0,37
0,97
-1,25
2,75
0,48
4,46
3,71
0,97
-1,30
3,83
2,28
-0,28
4,40
63,45
2,61
-1,70
-0,95
5,09
2,26
2,82
4,23
1,99
4,68
4,09
4,82
2,46
-0,85
4,39
7,43
0,78
4,80
29,10
24,43
2,01
5,32
1,15
1,90
29,10
24,43
Acum. Fdo.
Acum. CDI*
1997
2,15
0,92
1,15
3,09
Out
Nov
Mai
Jun
Jul
Fev
Mar
Abr
228,22
175,62
135,02
100,31
60,03
4,94
10,96
1,53
3,13
1,69
48,72
19,09
0,73
0,72
1,85
2,23
3,84
1,09
2,54
2,23
3,79
4,76
4,09
67,66
Rentabilidades (%)
VERDE FIF CIC MULTIMERCADO RL 
CDI
Fundo
21/mai/2015*
R$ 5.000,00
R$ 5.000,00
22,11%
13,54%
8,50%
0,37%
1,01
-
                    
30/abr/2026
18,88%
288
                    
63
                      
218
                    
133
                    
14,83%
351
                    
0
                       
R$ 2.000,00
13.879,21
1.723,51
2017
0,11
1,35
1,11
0,43
9,95
14.612,59
1.904,99
-0,88
0,45
1,89
0,37
0,51
-0,38
-0,43
0,62
5,25
2016
1,09
0,75
-2,47
1,76
14,00
1,52
1,76
1,82
1,64
1,20
1,09
1,03
3,07
15,13
2.161,12
2019
3,77
0,09
0,42
0,86
1,28
1,49
0,44
0,18
Fundo destinado ao público em geral, observados os valores mínimos de
aplicação inicial, permanência e movimentação constantes no prospecto.
O fundo VERDE FIF CIC MULTIMERCADO RL é resultado de uma cisão realizada em 21/mai/2015
do fundo CSHG VERDE AM FIC FIF MULTIMERCADO RL, que teve início em 2/jan/1997.
22.187.946/0001-41
Estratégia multimercado flagship
lançada em 1997, é um dos
maiores e mais antigos hedge funds brasileiros. Atua no mercado
brasileiro e internacional de ações, renda fixa e moedas sob a
gestão de Luis Stuhlberger.
A descrição acima não pode ser considerada como objetivo do Fundo. Todas as informações obrigatórias estão
disponíveis no formulário de informações complementares, na lâmina de informações essenciais (se houver) e/ou no
regulamento, disponíveis em www.verdeasset.com.br
* Calculado desde a constituição do fundo CSHG VERDE FICFI MULT até 30/abr/2026.
* A metodologia de rateio da Taxa Global entre o Administrador, o Gestor e demais prestadores de serviço da Classe/Subclasse dos 
fundos referidos nesta apresentação, com a indicação da efetiva alíquota, condição ou valor que cada um deles fazem ou fizeram 
jus em relação à Taxa Global, ficará disponível na página na internet do Gestor (https://www.verdeasset.com.br, no link CVM 175 - 
Transparência Informacional).
2020
-0,19
-2,86
-11,46
8,61
2,52
0,91
2,05
1,33
-1,22
-0,49
4,45
1,49
3,94
2,77
18.601,56
2.223,70
-0,12
-4,39
-0,24
2,14
-1,13
4,40
18.390,98
2.325,83
2021
0,68
-0,24
1,47
1,20
0,58
-0,21
-2,16
0,33
0,85
-0,42
2,91
3,32
14,53
13,05
24.451,62
2.981,65
2023
2,74
0,04
-0,41
-0,03
0,89
1,62
2,24
0,00
7,41
4,54
34.174,27
3.983,13
2026
3,03
1,44
0,05
2,71
0%
2.000%
4.000%
6.000%
8.000%
10.000%
12.000%
14.000%
16.000%
18.000%
20.000%
22.000%
24.000%
26.000%
28.000%
30.000%
32.000%
34.000%
36.000%
jan-97
jan-99
jan-01
jan-03
jan-05
jan-07
jan-09
jan-11
jan-13
jan-15
jan-17
jan-19
jan-21
jan-23
jan-25
VERDE FIF CIC MULTIMERCADO RL
CDI
0%
10%
20%
30%
40%
50%
mar-97
mar-98
mar-99
mar-00
mar-01
mar-02
mar-03
mar-04
mar-05
mar-06
mar-07
mar-08
mar-09
mar-10
mar-11
mar-12
mar-13
mar-14
mar-15
mar-16
mar-17
mar-18
mar-19
mar-20
mar-21
mar-22
mar-23
mar-24
mar-25
mar-26
VERDE FIF CIC MULTIMERCADO RL
CDI