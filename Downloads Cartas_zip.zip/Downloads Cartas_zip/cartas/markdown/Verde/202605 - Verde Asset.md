

---

A Verde Asset Management S.A. (“Verde”) não comercializa e nem distribui cotas de fundos ou qualquer outro ativo financeiro. Este relatório mensal retrata as opiniões da Verde acerca 
da estratégia e gestão do fundo e não deve ser entendido como oferta, recomendação ou análise de investimento ou ativos. Rentabilidade obtida no passado não representa garantia de 
resultados futuros. A rentabilidade divulgada não é líquida de impostos O investimento em Fundo não é garantido pelo Fundo Garantidor de Crédito. Leia a lâmina de informações
essenciais, se houver, e o regulamento antes de investir. A Verde não se responsabiliza por erros de avaliação ou omissões. Os investidores devem tomar suas próprias
decisões de investimento. O investimento em fundos pode resultar em perdas patrimoniais para seus cotistas, podendo inclusive acarretar perdas superiores ao 
capital aplicado e a consequente obrigação do cotista de aportar recursos adicionais para cobrir o prejuízo do fundo. Para mais informações acerca das taxas de 
administração, cotização e público-alvo de cada um dos fundos, consulte os documentos do fundo disponíveis no site verdeasset.com.br. Este material não pode 
ser copiado, reproduzido ou distribuído sem a prévia e expressa concordância da Verde. Supervisão e Fiscalização: Comissão de Valores Mobiliários (CVM) -
Serviço de Atendimento ao Cidadão: www.cvm.gov.br. Contato Institucional Verde AM: institucional@verdeasset.com.br / +55 11 4935-8500. 
VERDE FIF CIC MULTIMERCADO RL 
Relatório de Gestão 
Maio de 2026 
 
O fundo Verde teve em maio ganhos em renda variável global e nos livros 
de crédito. As perdas vieram da posição em ações no mercado local, do 
ouro e da proteção no crédito da Arábia Saudita. 
O conflito no Oriente Médio segue sem solução, com promessas de acordo 
sendo constantemente empurradas para diante, e pequenos conflitos 
militares localizados de baixa intensidade. O apetite do presidente Trump 
por uma retomada da intensidade militar continua baixíssimo, e a 
contraparte persa entende isso e usa essa alavancagem a seu favor. Dada 
esta realidade – que ao contrário das previsões mudou pouco no último 
mês – por que não temos preços de petróleo e derivados substancialmente 
mais altos? A resposta para esta pergunta passa por três pontos com 
razoável grau de incerteza: (i) queda forte das importações chinesas de 
petróleo, explicada por estoques mais altos e um grau surpreendente de 
destruição de demanda; (ii) trânsito “nas sombras” de parte importante do 
óleo que ficou retido no estreito de Hormuz; (iii) consumo de estoques 
estratégicos mais amplos pelo mundo. Essas três explicações juntas 
respondem, em nossa opinião, pelo fato de não termos um nível de 
estresse muito mais elevado no mundo com a (ainda) não-resolução do 
conflito. 
 
Desempenho 
Maio 2026 
Acumulado 2026 
 
 
Verde 
0,33% 
7,76% 
 
 
CDI 
1,07% 
5,66% 
 
 
Para mais informações relevantes à análise da rentabilidade deste Fundo - tais como taxa de administração, 
taxa de performance, rentabilidade “mês a mês” ou PL médio, consulte o Resumo Gerencial ao final deste material.

---

Maio de 2026 
2 
VERDE FIF CIC MULTIMERCADO RL 
Relatório de gestão 
O tema guerra continuou perdendo importância para os mercados ao 
longo de maio, enquanto Inteligência Artificial seguiu ganhando 
proeminência, impulsionando novamente todos os ativos ligados à cadeia 
de semicondutores e capacidade computacional. A continuidade desse 
movimento trouxe de volta “Excepcionalismo Americano” como tema 
macro, uma dinâmica que os mercados viveram fortemente em 2023 e 
2024, mas que tinha sido substituído por uma busca por diversificação 
para fora do dólar em 2025 e início desse ano. A resiliência da economia 
americana, a precificação – mesmo que tímida – de possíveis altas de juro 
pelo Federal Reserve, e a pujança do ecossistema de IA parecem reforçar 
esse tema, e temos visto algum fortalecimento do Dólar como principal 
consequência macro dessa lógica. Zeramos as alocações em Real por conta 
de preocupação com isso, embora tenhamos mantido as posições em 
metais preciosos. 
A volta do excepcionalismo americano – mesmo que em versão ainda suave 
– explica a reversão dos fluxos que temos visto no mercado brasileiro. Isso 
ficou claramente marcado no Ibovespa esse mês, com uma queda de -
7.22%, e embaixo da superfície da bolsa tivemos correções mais profundas 
ainda. O mercado de juros também tem passado por reprecificação 
importante, essencialmente tirando o ciclo de cortes da curva e 
precificando um ciclo de altas nos próximos meses. Parece um certo 
exagero, mas a constante pressão dos pacotes parafiscais que o governo 
anuncia – com óbvio intuito eleitoral – torna a vida do Banco Central muito 
difícil, numa economia com desemprego nas mínimas. Seguimos sem 
alocações de juros, embora os níveis do juro real chamem atenção, e temos 
visto oportunidades de comprar mais convexidade na bolsa. 
O fundo manteve sua exposição em renda variável, tanto no Brasil quanto 
no mercado global. Na renda fixa local não temos posições direcionais. 
Nos EUA trocamos a alocação em inflação implícita por maior posição 
aplicada em juro real. Em moedas zeramos a exposição em Real, 
continuamos alocados em ouro e fizemos aumento pontual na posição de 
prata. Continuamos carregando uma compra de proteção de crédito da 
Arábia Saudita, e zeramos posições em petróleo através de opções. A 
alocação de crédito local foi mantida.

---

Maio de 2026 
3 
VERDE FIF CIC MULTIMERCADO RL 
Relatório de gestão 
 
Breakdown — Resultados do Fundo 
 
 
 
 
 
 
 
Maio
Acum ulado
2026
2026
Dólar 
0,00
0,97
Moedas
0,00
-0,06
Resultado Moedas
0,00
0,91
II) Book Renda Fixa
DI pré
0,00
0,07
Cupom cambial
0,00
0,00
RF Inflação
0,04
-0,12
Global Rates
0,01
0,31
Crédito
0,00
-1,02
Resultado Renda Fixa
0,06
-0,76
III) Book Ações
Resultado Ações
-0,81
2,00
CDI
1,07
5,66
Moedas(I)+Renda Fixa(II)+Outros
0,03
1,03
Ações(III)
-0,81
2,00
Custos
0,04
-0,92
Resultado do Fundo 
0,33
7,76
Resultado Real do Verde — Rentabilidade ex CDI
I) Book Moedas
Para todos os ativos que utilizamos caixa,  as rentabilidades expressas acima já 
são reais (ex CDI)
5,66%
2,00%
0,91%
0,88%
-0,76%
-0,92%
7,76%
0,0%
0,5%
1,0%
1,5%
2,0%
2,5%
3,0%
3,5%
4,0%
4,5%
5,0%
5,5%
6,0%
6,5%
7,0%
7,5%
8,0%
8,5%
9,0%
9,5%
10,0%
CDI
Book
Ações
Book
Moedas
Outros
Book
Renda
Fixa
Custos TOTAL

---

Resumo Gerencial
Público-alvo
Características
Performance
CNPJ
Retorno anualizado
Data de início
Desvio padrão anualizado *
Aplicação mínima
Índice de sharpe *
Saldo mínimo
Rentabilidade acumulada em 12 meses
Movimentação mínima
Número de meses positivos
Cota
Número de meses negativos
Cota de aplicação
Número de meses acima de 100% do CDI
Cota de resgate
Número de meses abaixo de 100% do CDI
Liquidação de resgate
Maior rentabilidade mensal
Carência para resgate
Menor rentabilidade mensal
Tributação aplicável
Patrimônio líquido *
R$
Taxa de saída antecipada
Patrimônio líquido médio em 12 meses
R$
Taxa Global *
Taxa de performance
Fechado para novas aplicações
Classificação ANBIMA:
Multimercado Macro
Admite Alavancagem:
Sim
Gestor:
Verde Asset Management S.A
Administrador:
Intrag Distribuidora De Títulos E Valores Mobiliários Ltda.
Volatilidade anualizada (Desvio padrão - média 40 dias)
* Calculado desde a constituição do fundo até 29/mai/2026
1,99
1,41
1,06
1,01
15,94
14,31
31.811,05
3.805,79
1,50% sobre o patrimônio líquido do fundo, apropriada 
diariamente, com pagamento mensal
1,70
-0,18
3,29
2,20
12,10
10,87
27.422,96
3.316,75
-0,46
3,51
-0,30
0,93
15,93
12,37
21.336,72
2025
1,64
0,55
0,58
1,90
1,31
0,97
0,22
2,27
2024
-0,28
0,89
1,52
-3,83
2,53
1,66
1,44
0,72
2.625,98
2022
1,49
1,32
4,19
1,02
1,31
-1,86
1,54
2,34
20% que exceder a 100% do CDI
VERDE FIF CIC MULTIMERCADO RL  x CDI
872.720.967,95
889.379.367,21
-11,46%
recomendação ou análise de investimento ou ativos. Rentabilidade obtida no passado não representa garantia de resultados futuros. A rentabilidade divulgada não é líquida de impostos. O investimento em Fundo não é garantido pelo Fundo
Garantidor de Crédito. Leia a lâmina de informações essenciais, se houver, e o regulamento antes de investir. A Verde não se responsabiliza por erros de avaliação ou omissões. Os investidores devem tomar suas próprias decisões de
investimento. O investimento em fundos pode resultar em perdas patrimoniais para seus cotistas, podendo inclusive acarretar perdas superiores ao capital aplicado e a consequente obrigação do cotista de aportar recursos adicionais para
cobrir o prejuízo do fundo. Para mais informações acerca das taxas de administração, cotização e público-alvo de cada um dos fundos, consulte os documentos do fundo disponíveis no site verdeasset.com.br. Este material não pode ser
copiado, reproduzido ou distribuído sem a prévia e expressa concordância da Verde. Supervisão e Fiscalização: Comissão de Valores Mobiliários - CVM. Serviço de Atendimento ao Cidadão: www.cvm.gov.br.
Contato Institucional Verde AM: institucional@verdeasset.com.br / +55 11 4935-8500.
3,05
0,12
0,58
-0,18
-1,80
0,29
1,10
0,70
1,30
0,89
0,00
1,92
13,33
5,97
17.893,01
A Verde Asset Management S.A. (“Verde”) não comercializa e nem distribui cotas de fundos ou qualquer outro ativo financeiro. Este relatório mensal retrata as opiniões da Verde acerca da estratégia e gestão do fundo e não deve ser entendido como oferta,
2018
2014
2013
0,65
-0,27
1,05
3,87
2006
988,32
1.079,88
1.174,90
8,05
8.572,99
1,45
3,71
2,46
2,19
2,19
1,23
13,75
19,00
15,05
-1,13
2012
2011
1.312,68
0,70
459,37
543,53
1.945,54
2.512,98
3.316,10
1,94
-0,48
2,63
2,70
4.705,98
19,55
5.366,93
9,90
9,74
50,37
6.042,75
7.243,48
4,38
4,98
8,41
12,36
2,16
2,44
Calculado até 29/mai/2026
-0,30
3,77
0,55
-0,13
7,91
6,42
15.776,46
2.033,78
304,64
16,17
3.096,20
11,82
1,24
27,74
30,74
370,06
294,66
404,89
5,31
17,33
1,14
1,69
11,59
2004
2003
2002
2001
2,90
2,29
2005
-0,00
2010
2009
2008
2007
0,82
0,73
5,96
Não há
Longo Prazo
Não há
D+0
D+1
Fechamento
D+0
63,45%
-
                    
-
                    
3,28%
0,13%
1999
1998
1,57
3,45
2015
619,62
708,64
788,66
875,24
1,81
0,77
0,43
2,84
6,69
1,38
2,89
0,27
5,16
3,68
1,44
0,33
4,58
3,66
2,43
2000
0,83
3,62
2,19
1,37
1,16
3,65
-1,37
3,79
4,37
-2,46
-3,53
-3,92
-1,68
2,52
3,00
-2,17
1,10
2,62
1,16
3,33
-0,68
4,12
1,86
1.499,56
1,58
2,48
1,04
28,67
13,23
-0,64
3,46
2,98
8,80
10,81
9.336,59
12.041,74
1,18
556,42
876,24
1.288,44
-7,32
-8,91
2,20
1,47
-6,44
12,37
1,90
2,12
1,99
0,60
1.599,90
22,43
4,02
2,96
20,33
0,93
42,22
23,28
CDI
0,28
135,40
25,17
1,03
2,01
3,34
1,58
1,11
30,01
17,27
0,12
2,62
27,93
29,86
28,61
4,51
4,14
Set
Ago
1,86
18,10
-0,42
0,12
-1,76
1,86
2,76
2,32
0,43
1,83
0,77
1,09
2,19
Dez
Acum. 
Ano
2,71
6,96
1,95
2,30
0,11
4,80
4,17
-0,15
-0,35
4,52
1,45
6,09
2,70
2,77
3,31
-0,06
-0,51
-0,19
2,28
3,68
0,96
5,41
-0,31
0,98
4,48
3,56
2,61
2,80
-0,94
0,69
1,74
0,91
1,22
1,98
0,71
1,79
0,36
1,91
1,71
0,33
-0,87
4,76
3,35
1,27
2,65
-0,65
0,33
1,66
11,41
-1,66
3,70
1,39
-2,71
2,55
-0,50
Jan
4,37
2,43
1,87
2,41
1,98
3,12
1,40
-0,06
0,37
0,97
-1,25
2,75
0,48
4,46
3,71
0,97
-1,30
3,83
2,28
-0,28
4,40
63,45
2,61
-1,70
-0,95
5,09
2,26
2,82
4,23
1,99
4,68
4,09
4,82
2,46
-0,85
4,39
7,43
0,78
4,80
29,10
24,43
2,01
5,32
1,15
1,90
29,10
24,43
Acum. Fdo.
Acum. CDI*
1997
2,15
0,92
1,15
3,09
Out
Nov
Mai
Jun
Jul
Fev
Mar
Abr
228,22
175,62
135,02
100,31
60,03
4,94
10,96
1,53
3,13
1,69
48,72
19,09
0,73
0,72
1,85
2,23
3,84
1,09
2,54
2,23
3,79
4,76
4,09
67,66
Rentabilidades (%)
VERDE FIF CIC MULTIMERCADO RL 
CDI
Fundo
21/mai/2015*
R$ 5.000,00
R$ 5.000,00
22,06%
13,54%
8,49%
0,37%
1,00
-
                    
29/mai/2026
17,73%
289
                    
63
                      
218
                    
134
                    
14,76%
352
                    
0
                       
R$ 2.000,00
13.879,21
1.723,51
2017
0,11
1,35
1,11
0,43
9,95
14.612,59
1.904,99
-0,88
0,45
1,89
0,37
0,51
-0,38
-0,43
0,62
5,25
2016
1,09
0,75
-2,47
1,76
14,00
1,52
1,76
1,82
1,64
1,20
1,09
1,03
3,07
15,13
2.161,12
2019
3,77
0,09
0,42
0,86
1,28
1,49
0,44
0,18
Fundo destinado ao público em geral, observados os valores mínimos de
aplicação inicial, permanência e movimentação constantes no prospecto.
O fundo VERDE FIF CIC MULTIMERCADO RL é resultado de uma cisão realizada em 21/mai/2015
do fundo CSHG VERDE AM FIC FIF MULTIMERCADO RL, que teve início em 2/jan/1997.
22.187.946/0001-41
Estratégia multimercado flagship
lançada em 1997, é um dos
maiores e mais antigos hedge funds brasileiros. Atua no mercado
brasileiro e internacional de ações, renda fixa e moedas sob a
gestão de Luis Stuhlberger.
A descrição acima não pode ser considerada como objetivo do Fundo. Todas as informações obrigatórias estão
disponíveis no formulário de informações complementares, na lâmina de informações essenciais (se houver) e/ou no
regulamento, disponíveis em www.verdeasset.com.br
* Calculado desde a constituição do fundo CSHG VERDE FICFI MULT até 29/mai/2026.
* As taxas segregadas dos prestadores de serviço poderão ser consultadas na Plataforma de Transparência de Taxas no endereço 
eletrônico: www.data.anbima.com/busca/transparencia-de-taxas-de-fundos e/ou na página na internet do GESTOR 
(https://www.verdeasset.com.br, no link CVM 175 - Transparência Informacional).
2020
-0,19
-2,86
-11,46
8,61
2,52
0,91
2,05
1,33
-1,22
-0,49
4,45
1,49
3,94
2,77
18.601,56
2.223,70
-0,12
-4,39
-0,24
2,14
-1,13
4,40
18.390,98
2.325,83
2021
0,68
-0,24
1,47
1,20
0,58
-0,21
-2,16
0,33
0,85
-0,42
2,91
3,32
14,53
13,05
24.451,62
2.981,65
2023
2,74
0,04
-0,41
-0,03
0,89
1,62
2,24
0,00
7,76
5,66
34.288,53
4.026,96
2026
3,03
1,44
0,05
2,71
0,33
0%
2.000%
4.000%
6.000%
8.000%
10.000%
12.000%
14.000%
16.000%
18.000%
20.000%
22.000%
24.000%
26.000%
28.000%
30.000%
32.000%
34.000%
36.000%
jan-97
jan-99
jan-01
jan-03
jan-05
jan-07
jan-09
jan-11
jan-13
jan-15
jan-17
jan-19
jan-21
jan-23
jan-25
VERDE FIF CIC MULTIMERCADO RL
CDI
0%
10%
20%
30%
40%
50%
mar-97
mar-98
mar-99
mar-00
mar-01
mar-02
mar-03
mar-04
mar-05
mar-06
mar-07
mar-08
mar-09
mar-10
mar-11
mar-12
mar-13
mar-14
mar-15
mar-16
mar-17
mar-18
mar-19
mar-20
mar-21
mar-22
mar-23
mar-24
mar-25
mar-26
VERDE FIF CIC MULTIMERCADO RL
CDI