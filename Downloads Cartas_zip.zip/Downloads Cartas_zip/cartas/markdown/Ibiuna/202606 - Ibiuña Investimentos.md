

---

1/3
Ibiuna Hedge FIF CIC
 maio, 2026

Comentário Mensal
Performance de maio
O livro de moedas foi um dos destaques positivos do mês, principalmente com posições
vendidas em dólar vs. moedas de países emergentes.  No livro de juros, posições
aplicadas em curvas de juros de países emergentes selecionados ficaram do lado
positivo. Do lado negativo, o livro de commodities foi o destaque, principalmente com
posições compradas em ouro e petróleo. 
Perspectivas para junho
Eventual alta de juros pelos EUA?
O choque nos preços de energia a partir da crise no Irã elevou substancialmente as
projeções de inflação pelo mundo. A avaliação inicial do consenso era de que, após alta
temporária, a inflação retomaria trajetória de queda. Essa percepção, no entanto, vem se
mostrando mais frágil com o aumento das pressões subjacentes, reflexo de uma
economia global resiliente, política fiscal expansionista e expectativas de médio prazo
com ancoragem fragilizada após 5 anos de inflação acima da meta. Se confirmada, essa
mudança implica um cenário de médio prazo mais adverso a risco, moedas e mercados
emergentes.
Nesse contexto, a revisão da inflação nos EUA foi destaque nos últimos dois meses. O
país é um dos menos afetados pelo choque de energia, mas as previsões de consenso
para o núcleo do PCE se elevaram quase 60 bps desde o início do ano, o que
potencialmente poderá afetar também as projeções para 2027. Com a economia
crescendo pouco acima do potencial e mercado de trabalho em equilíbrio, os agentes
retiraram a precificação de corte de juros e passaram a considerar algum prêmio de alta
pelo Fed. Uma eventual alta implicaria menor espaço para cortes em outras economias,
um dólar que pode voltar a se apreciar e diante da força do ciclo de tecnologia e IA,
bolsas americanas sugando recursos de mercados com baixa exposição a esse tema.
Nosso portfólio vem sendo ajustado para explorar esses temas caso o cenário pós-
guerra se confirme.
Para o Brasil, essa mudança seria relevante porque um ambiente externo favorável tem
amortecido o impacto nos ativos dos ruídos gerados pela deterioração fiscal, alta da
inflação e proximidade da corrida presidencial. A dívida/PIB ultrapassou 80%, o déficit
nominal deste ano ficará próximo a 9% e o Governo tem respondido com gastos
parafiscais que devem somar 1,5% do PIB em ano eleitoral. A inflação projetada para os
próximos 18 meses também subiu, retirando espaço para o Banco Central cortar juros.
Na política, a elevada rejeição do incumbente incentiva práticas populistas, mesmo com
a recente queda da oposição diante do escândalo do Banco Master. Esses ruídos devem
se intensificar com a aproximação da eleição, o que, combinado com um potencial
ambiente externo mais adverso, sugere cautela com ativos brasileiros no segundo
semestre.
As principais posições da estratégia macro se mantêm: Renda Fixa: no Brasil, posição
aplicada em juros nominais curtos vs. tomada em juros longos e trades de valor relativo
nas curvas reais e implícitas; no exterior, misto de posições aplicadas e tomadas no G10
com redução em emergentes selecionados. Moedas: Comprados em Yuan chinês e
Florim Húngaro, com trades táticos vendidos em dólar via opções. Renda Variável:
exposição comprada na bolsa americana e emergentes, mantendo risco via estratégia
long-short não direcional no Brasil. Crédito: Aumentamos a exposição seletiva a
corporativos brasileiros diante de estabilização de prêmios e spreads correntes que nos
parecem oferecer compensação adequada pelo risco. Commodities: pequena posição
comprada em petróleo e ouro.
Atribuição de Performance
ESTRATÉGIA
MAI/26
2026
12M
24M
JUROS
0,08%
-4,95%
-5,62%
-2,42%
Brasil
-0,16%
-0,19%
-0,69%
0,67%
G-10
-0,14%
-1,52%
-2,41%
-2,75%
EM (ex-Brasil)
0,38%
-3,24%
-2,53%
-0,34%
MOEDAS
0,29%
1,50%
1,49%
-0,52%
Dólar/Real
-0,07%
0,59%
0,74%
0,14%
G-10
-0,09%
-0,09%
-0,31%
-0,44%
EM (ex-Brasil)
0,45%
1,00%
1,07%
-0,22%
EQUITIES
0,04%
0,28%
0,69%
0,49%
Bottom-up
-0,30%
-0,47%
-0,20%
-0,09%
Top-down
0,34%
0,74%
0,89%
0,57%
OUTROS
-0,03%
-0,40%
-0,21%
-0,55%
Commodities
-0,07%
0,04%
0,17%
0,13%
Crédito
0,07%
-0,03%
0,03%
0,07%
Estratégias
compartilhadas
-
-0,51%
-0,53%
-0,58%
Sistemático
-0,04%
0,11%
0,12%
-0,17%
Caixa + Despesas
0,98%
4,49%
11,92%
22,26%
TOTAL
1,36%
0,92%
8,27%
19,26%
% CDI
127%
16%
56%
68%
Risco
Volatilidade
5,58%
7,77%
5,64%
4,51%
VaR
0,77%
0,70%
0,49%
0,39%
Stress
7,61%
9,18%
8,70%
6,92%
Índices de Mercado
MAI/26
2026
12M
24M
CDI
1,07%
5,66%
14,82%
28,40%
IMA-B
0,31%
5,18%
10,52%
16,33%
IBOVESPA
-7,22%
7,86%
25,45%
40,40%
IBRX
-7,26%
7,95%
25,41%
40,52%
IMA-B 5
0,97%
6,25%
12,26%
22,42%

---

2/3
Ibiuna Hedge FIF CIC
maio, 2026
Retornos Mensais
JAN
FEV
MAR
ABR
MAI
JUN
JUL
AGO
SET
OUT
NOV
DEZ
ANO
INICIO
2010
-
-
-
-
-
-
-
-
-
-
2,07%
-0,24%
1,82%
1,82%
% CDI
-
-
-
-
-
-
-
-
-
-
256%
-
105%
105%
2011
1,70%
0,49%
1,36%
2,39%
0,06%
0,88%
0,81%
4,25%
1,34%
0,20%
0,87%
-0,27%
14,94%
17,03%
% CDI
198%
58%
148%
286%
6%
92%
84%
396%
142%
23%
102%
-
129%
126%
2012
0,55%
0,89%
0,70%
2,27%
2,09%
1,30%
1,42%
0,36%
0,79%
2,13%
1,18%
1,64%
16,42%
36,25%
% CDI
62%
120%
86%
323%
285%
204%
209%
52%
147%
350%
217%
306%
195%
157%
2013
1,33%
-0,44%
0,69%
0,45%
1,73%
0,71%
0,84%
-0,22%
-1,23%
0,42%
1,38%
1,38%
7,23%
46,10%
% CDI
226%
-
129%
76%
297%
120%
119%
-
-
52%
194%
177%
90%
140%
2014
0,03%
0,67%
0,57%
0,52%
0,81%
1,35%
1,02%
1,01%
-0,56%
0,03%
0,98%
0,92%
7,58%
57,17%
% CDI
4%
86%
75%
64%
94%
165%
109%
118%
-
4%
116%
96%
70%
121%
2015
2,25%
1,43%
2,83%
-1,17%
1,15%
-0,05%
2,14%
0,75%
1,35%
0,33%
1,11%
0,69%
13,50%
78,39%
% CDI
242%
175%
273%
-
117%
-
182%
68%
122%
30%
105%
59%
102%
117%
2016
1,40%
0,72%
0,09%
2,30%
0,09%
2,25%
1,62%
1,09%
1,53%
0,98%
-1,17%
1,72%
13,31%
102,14%
% CDI
132%
72%
7%
218%
8%
194%
147%
90%
138%
93%
-
153%
95%
113%
2017
1,48%
2,01%
1,50%
0,59%
-1,33%
1,93%
2,97%
0,92%
2,00%
-0,39%
0,21%
1,47%
14,12%
130,68%
% CDI
137%
233%
143%
75%
-
238%
372%
114%
313%
-
37%
274%
142%
120%
2018
2,84%
1,00%
1,00%
-0,15%
-1,85%
1,10%
0,15%
-0,49%
0,38%
0,72%
-0,44%
0,82%
5,13%
142,51%
% CDI
487%
214%
188%
-
-
212%
29%
-
81%
133%
-
166%
80%
116%
2019
2,15%
-0,32%
-0,11%
0,30%
0,56%
2,55%
1,21%
0,75%
0,60%
1,20%
-0,70%
1,75%
10,34%
167,59%
% CDI
396%
-
-
57%
104%
544%
213%
150%
129%
251%
-
467%
174%
123%
2020
0,19%
1,17%
2,01%
1,76%
0,42%
0,63%
1,83%
0,47%
-0,76%
0,10%
0,25%
1,19%
9,63%
193,36%
% CDI
50%
399%
593%
619%
176%
298%
943%
295%
-
65%
165%
726%
349%
136%
2021
-0,56%
2,23%
0,78%
-0,24%
0,26%
0,46%
-1,37%
0,75%
2,11%
2,27%
-0,39%
1,24%
7,75%
216,08%
% CDI
-
1.661%
390%
-
97%
150%
-
176%
477%
466%
-
162%
175%
141%
2022
1,02%
1,60%
3,78%
2,51%
1,10%
0,07%
-1,11%
2,84%
1,97%
1,65%
-0,12%
0,08%
16,40%
267,91%
% CDI
139%
212%
408%
301%
106%
7%
-
243%
184%
162%
-
7%
132%
145%
2023
1,25%
-0,78%
-0,65%
1,11%
0,37%
1,79%
1,03%
-0,34%
-0,87%
-0,32%
2,02%
3,30%
8,08%
297,65%
% CDI
111%
-
-
121%
33%
167%
96%
-
-
-
220%
369%
62%
134%
2024
-0,85%
0,73%
0,73%
-2,30%
0,94%
0,05%
0,56%
0,70%
0,57%
0,37%
2,20%
1,57%
5,32%
318,82%
% CDI
-
91%
88%
-
112%
7%
62%
81%
68%
40%
278%
169%
49%
124%
2025
0,30%
0,87%
0,20%
2,65%
-0,28%
1,55%
-0,55%
2,17%
1,26%
1,63%
1,35%
-0,28%
11,37%
366,45%
% CDI
30%
88%
21%
251%
-
142%
-
187%
104%
128%
129%
-
79%
119%
2026
3,72%
1,53%
-7,02%
1,68%
1,36%
-
-
-
-
-
-
-
0,92%
370,72%
% CDI
319%
153%
-
154%
127%
-
-
-
-
-
-
-
16%
112%
Cota e Patrimônio Líquido
Valores em R$
PL de fechamento do mês
355.663.522
PL médio (12 meses)
423.341.692
PL de fechamento do mês do fundo master
908.020.893
PL médio do fundo master (12 meses)
1.045.334.673
Estatísticas
2026
Desde Início
Meses Positivos
4
151
Meses Negativos
1
36
Meses Acima do CDI
4
104
Meses Abaixo do CDI
1
83
Principais Características
Objetivo do Fundo
Ibiuna Hedge FIF CIC é um fundo multimercado com enfoque macro global e grau de volatilidade moderado. O fundo tem como principal diferencial explorar ciclos de política monetária no mundo, principalmente
através de posições nos mercados de juros, moedas, ações e commodities. Para maiores detalhes, vide regulamento.
Público Alvo
Investidores em geral que busquem performance diferenciada no longo prazo e entendam a natureza dos riscos envolvidos. Para maiores detalhes, vide regulamento.
CNPJ: 12.154.412/0001-65
Início Atividades: 29-out-2010
Gestão: Ibiuna Macro Gestão de Recursos Ltda.
Auditor: KPMG
Custodiante: Banco Bradesco S.A.
Administrador: BEM DTVM Ltda.
Tipo Anbima: Multimercados Macro
Tributação: Busca o longo prazo
Taxa Adm. e Custódia: 2,00% a.a.
Taxa Performance: 20,00% sobre o que exceder o CDI 
* Para consultar a metodologia de rateio da taxa global entre o administrador fiduciário, o gestor e os demais
prestadores de serviço das classes/subclasses, acesse o link: https://www.ibiunainvest.com.br/transparencia-informacional
 Respeitando o High Watermark, pagos semestralmente ou no resgate
§
§
Dados para Movimentação
Aplicação Inicial: R$ 5.000
Movimentação Mínima: R$ 1.000
Saldo Mínimo: 5.000
Aplicação: D+0
Cotização do Resgate: D+30 ou D+3 
Liquidação: D+1 após cotização
 Mediante pagamento da taxa de saída de 5,00% do valor de resgate
O regulamento e a Lâmina de informações Essenciais do Fundo encontram-se disponíveis no site do Administrador em
www.bradescobemdtvm.com.br
*
*

---

3/3
Gestor:
Ibiuna Macro Gestão de Recursos
CNPJ 11.918.575/0001-04
Av. São Gabriel, 477, 16º andar
01435-001 São Paulo, SP, Brasil
Tel: +55 11 2655 0355
contato@ibiunainvest.com.br
 
Gestor:
Ibiuna Ações Gestão de Recursos
CNPJ 18.506.057/0001-22
Av. São Gabriel, 477, 6º andar
01435-001 São Paulo, SP, Brasil
Tel: +55 11 2655 0355
contato@ibiunainvest.com.br
 
Gestor:
Ibiuna Crédito Gestão de Recursos
CNPJ 19.493.000/0001-07
Av. São Gabriel, 477, 6º andar
01435-001 São Paulo, SP, Brasil
Tel: +55 11 2655 0355
contato@ibiunainvest.com.br
 
Gestor:
Ibiuna Previdência Gestão de Recursos
CNPJ 49.223.404/0001-33
Av. São Gabriel, 477, 15º andar
01435-001 São Paulo, SP, Brasil
Tel: +55 11 2655 0355
contato@ibiunainvest.com.br
 
Administrador:
BEM DTVM
CNPJ 00.006.670/0001-00
Cidade de Deus, Prédio Novissimo, 4º andar
06029-900 Osasco, SP, Brasil
Tel: +55 11 3684 9401
www.bradescocustodia.com.br
 
Siga a Ibiuna:
www.ibiunainvest.com.br
 @ibiunainvestimentos
 ibiunainvestimentos
 Ibiuna Investimentos
Este comunicado foi preparado pelas Gestoras do grupo Ibiuna Investimentos. As Gestoras não comercializam e nem distribuem cotas de fundos ou qualquer outro ativo financeiro. A rentabilidade obtida no passado não representa garantia de resultados futuros. A
rentabilidade divulgada não é líquida de impostos. Antes de investir, é recomendada a leitura cuidadosa do regulamento dos fundos de investimento e da lâmina de informações essenciais, disponíveis no site do Administrador - www.bradescobemdtvm.com.br. As
informações contidas neste material são de caráter exclusivamente informativo. Fundos de investimento não contam com a garantia do administrador, do gestor da carteira, de qualquer mecanismo de seguro ou, ainda, do Fundo Garantidor de Créditos (FGC). Os fundos
de investimento utilizam estratégias com derivativos como parte integrante de suas políticas de investimento. Tais estratégias, da forma como são adotadas, podem resultar em significativas perdas patrimoniais para seus cotistas. Os fundos de investimento são
autorizados a realizar aplicações em ativos financeiros no exterior. Os fundos multimercados com renda variável podem estar expostos a significativa concentração em ativos de poucos emissores, com os riscos daí decorrentes.


