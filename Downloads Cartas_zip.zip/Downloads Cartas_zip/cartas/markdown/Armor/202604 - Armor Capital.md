

---

®
Abril 2026
Estimativas para 2026
armorcapital.com.br
Selic: 13,50%
Câmbio: R$5,30
PIB: 1,80%
IPCA: 4,90%
Carta do Gestor

---

2 
 
 
 
  
www.armorcapital.com.br 
Carta Mensal 
Abril 2026 
Cenário Internacional  
No início do mês, os agentes de mercado estavam atentos às possíveis negociações sobre um cessar
-
fogo no Oriente Médio e à reabertura do Estreito de Ormuz. Esses eventos, de fato, ocorreram, mas 
acabaram gerando apenas volatilidade adicional nos preços, al
ternando entre movimentos de 
risk - on 
e risk - off à medida que as negociações se mostravam inconclusivas.
 
Após ameaças de ataques à infraestrutura do Irã por parte do governo norte
- americano, as duas 
partes concordaram em realizar um cessar
- fogo de duas semanas, enquanto as conversas 
avançavam. Com isso, os preços do petróleo, assim como sua curva futura, refl
etiram de forma 
significativa esse otimismo, principalmente em meados do mês, quando o contrato de petróleo para o 
fim do ano chegou a atingir US$ 85/barril. No entanto, a falta de acordo sobre o fim do programa 
nuclear e a manutenção de tropas americanas 
em torno do estreito fizeram a volatilidade predominar, 
levando os preços do petróleo de volta a níveis semelhantes aos observados no fim do mês.
 
Curva de Petróleo:  
 
Fonte: CME 
O gráfico acima compara a curva futura de petróleo brent em três datas específicas
. A primeira, em 
18 de março, corresponde ao período da maioria das decisões de política monetária, quando os bancos 
centrais adotaram um tom mais 
hawkish , conforme comentado na carta do mês anterior. A segunda 
mostra a melhora e o otimismo em meados de abril, após sinais positivos nas negociações. Já a 
terceira mostra o comportamento da curva no último dia de abril.
 
 
O fato é que os “ganhos” vistos no início e em meados de abril foram totalmente revertidos à medida 
que o estreito permaneceu fechado. É claro que a curva futura é totalmente dependente dos 
desdobramentos da guerra, mas, pelo nível da própria curva e pelo 
tempo em que o ativo tem 
permanecido pressionado, é possível presumir que os efeitos não podem ser considerados tão 
transitórios.

---

3 
 
 
 
  
www.armorcapital.com.br 
Carta Mensal 
Abril 2026 
Em função disso, o mercado global de juros tem precificado menos espaço para cortes neste ano e, 
em alguns casos, como na Zona do Euro e no Reino Unido, já passou a incorporar um ciclo de alta, 
na 
casa dos 0,75 p.p . 
Diante disso, revisamos nossa projeção para as 
Fed Funds  neste ano de 3,50% para 3,75%, mantendo 
o nível atual de juros por mais tempo. Considerando a resiliência do mercado de trabalho e da atividade 
econômica, evidenciada pelos dados mais recentes, a urgência de um corte de juros se torna cada vez 
menor. Aind a assim, não acreditamos em alta de juros por parte do Fed, uma vez que a taxa se 
encontra em patamar modestamente restritivo.
 
Reforçando esse viés menos propenso a cortes, o FOMC de abril apresentou um dissenso na própria 
comunicação do Fed, algo totalmente inesperado. No comunicado das decisões, o Fed tem mantido um 
easing bias , sugerindo que o próximo movimento, caso não seja de manutenção, seria de corte. No 
entanto, três dirigentes se opuseram à manutenção desse trecho e registraram dissenso no 
comunicado escrito, conferindo um viés mais 
hawkish  à comunicação.  
Em seu último discurso como chairman do Fed, Jerome Powell anunciou que continuará no Board por 
mais algum período, atuando como um membro mais 
low profile , como ele mesmo afirmou. Quanto 
aos próximos passos, manteve a visão de dependência dos dados, diante da elevada incerteza. Vale 
citar que Kevin Warsh, o novo indicado para a presidência do Fed, deve ser votado no Senado em 11 de 
maio, com posse prevista 
para 15 de maio.  
Quanto ao ECB, esperamos que a autoridade monetária da Zona do Euro realize duas altas de 0,25 p.p., 
em junho e julho, encerrando o ano com a taxa de juros em 2,50%. Após os dados de expectativas dos 
consumidores mostrarem números de inflação mais pression
ados, os discursos recentes dos 
membros votantes do ECB têm apontado para um aperto das condições financeiras, em resposta aos 
possíveis efeitos secundários sobre a inflação.
 
Diante desse cenário de elevada incerteza, realizamos a já citada calibragem no cenário para as 
Fed 
Funds  em 2026, elevando a projeção de 3,50% para 3,75%. Para o core PCE, projetamos 2,7% neste ano 
e 2,3% no próximo, enquanto o 
headline  deve ficar em 2,8% e 2,4%, respectivamente. Para o PIB, 
esperamos crescimento de 2,0% em 2026 e de mesma magnitude em 2027.
 
Cenário Doméstico 
No ambiente local, a dinâmica continuou sendo ditada pelas perspectivas externas em torno da guerra 
no Oriente Médio e pela decisão de política monetária, que, conforme esperado, reduziu a Selic para 
14,50%, com tom bastante conservador e cauteloso em rela
ção aos passos futuros.
 
A ausência de uma resolução para o conflito manteve, em abril, a pressão sobre as taxas de juros
, 
embora em menor intensidade do que em março
 e favoreceu a valorização do real, impulsionada pela 
melhora dos termos de troca.
 
Com isso, a piora das expectativas de inflação continuou no radar dos agentes de mercado. Em um 
mês, a inflação de 2026 no Focus passou de 4,36% para 4,89%; a de 2027 passou de 3,85% para 4,00%; 
e a de 2028, de 3,60% para 3,64%. Isso, aliado a cada dia adi
cional de estreito fechado, fez com que o 
mercado retirasse cortes da curva de juros e reacendesse as preocupações acerca da impossibilidade 
de cortes neste ano. Diante disso, elaboramos um 
breve estudo para entender melhor a dinâmica e a 
posição atual da política monetária brasileira.

---

4 
 
 
 
  
www.armorcapital.com.br 
Carta Mensal 
Abril 2026 
Tabela 1.  Comparação entre situação atual e início do ciclo de alta
  
                   
 
Fonte: IBGE, BCB; Elaboração Armor Capital
 
A tabela acima realiza uma comparação entre os indicadores decisivos para a condução da política 
monetária em três períodos. O primeiro diz respeito a dezembro de 2024, quando foi contratado o ciclo 
de alta de 300 bps que levou a Selic a 15%. O segundo mos
tra a situação anterior à decisão mais 
recente, enquanto o terceiro apresenta o quadro atual desses indicadores.
 
Para as decisões de política monetária, os indicadores mais relevantes são as expectativas de IPCA, 
nas quais é possível notar alguma melhora, refletindo parte dos efeitos do nível de restrição 
monetária. O IPCA do ano seguinte encontra
- se 99 bps abaixo do
 observado em dezembro de 2024, 
enquanto os horizontes mais longos estão, em média, 40 bps abaixo. Além disso, as taxas de inflação 
implícita e a taxa de câmbio estão em patamares muito mais acomodados do que no início do ciclo.
 
Dado esse cenário, mantemos nossa visão de que é possível realizar cortes ainda neste ano sem que 
haja desancoragem adicional das expectativas. No entanto, é importante ressaltar que o cenário atual 
exige maior cautela quanto ao ritmo de cortes, quando com
parado ao ambiente pré
- guerra. Em 
fevereiro deste ano, o Focus indicava que a Selic encerraria o ano entre 12,50% e 12,25%, passando 
para 13% após incorporar parte dos efeitos do choque de petróleo.
 
Diante disso, revisamos nossa projeção de Selic para o fim deste ano de 13,00% para 13,50%, com o 
Banco Central devendo cortar a taxa em passos lentos, de 0,25 p.p., até novembro. Portanto, ainda 
vemos algum espaço para recalibragem da política monetária, 
embora a taxa de juros deva encerrar 
o ano em patamar bastante restritivo.
 
Nesse contexto, revisamos nossa projeção de inflação para este ano de 4,5% para 4,8% e esperamos 
crescimento de 1,8% do PIB. Para a taxa Selic, projetamos encerramento do ano em 13,50%. Já para a 
taxa de câmbio, esperamos que atinja R$ 5,30 ao final do ano
. 
Início do 
Ciclo de Alta
Pré Guerra
Atual
31/12/2024
27/02/2026
24/04/2026
IPCA 12m à frente
4,97
4,44
4,24
IPCA corrente
4,83
5,83
4,14
IPCA t0
4,89
3,91
4,86
IPCA t1
4,99
3,79
4,00
IPCA t2
4,02
3,50
3,61
IPCA t3
3,88
3,50
3,50
Implícita 2y
7,20
4,60
5,26
Implícita 5y
7,17
5,33
5,57
PIB t0
3,49
1,81
1,85
PIB t1
2,02
1,80
1,80
PIB t2
1,80
2,00
2,00
USDBRL
6,18
5,12
4,97
Comparação dos indicadores decisivos para política monetária
Indicador

---

5 
 
 
 
  
www.armorcapital.com.br 
Carta Mensal 
Abril 2026 
Comentário dos Gestores 
Conforme destacado no cenário econômico, a volatilidade predominou ao longo do mês, em meio às 
idas e vindas do conflito no Oriente Médio. O início do mês foi marcado por um movimento de 
risk - on, 
após sinais de negociação, que foi gradualmente mitigado diante da falta de avanços concretos para a 
resolução do conflito.  
O petróleo continua sendo o principal ativo a refletir a temperatura da guerra para o mercado. A 
commodity avançou quase 10% no mês nos vencimentos mais curtos, após ter caído 13% em seu melhor 
momento, evidenciando a intensa volatilidade do período. Com i
sso, as taxas das 
Treasuries  norte-
americanas abriram cerca de 6 bps, enquanto o dólar global se desvalorizou 1,9%. Ainda assim, o S&P 
500 avançou 10% no mês, refletindo os bons resultados das empresas de tecnologia, e descolando do 
ambiente mais pressiona
do por inflação e juros.
 
Apesar de ter se valorizado mais de 6% na primeira quinzena do mês após o anúncio de cessar fogo, 
o Ibovespa encerrou o mês praticamente estável, com uma performance aquém dos pares por parte 
das bolsas latino - americanas, que tinham sofrido menos no mês de
 abril. Na curva de juros doméstica, 
as taxas nominais curtas abriram cerca de 5 pontos
- base no mês, enquanto as mais longas fecharam 
em torno de 8 bps, refletindo um mês de 
flattening  da curva. Esse movimento reflete o processo de 
reprecificação dos juros
 observado no mês anterior, quando as taxas chegaram a abrir cerca de 100 
bps. 
As principais contribuições para o desempenho do mês vieram das posições em renda variável, com 
destaque para posições vendidas em bolsa doméstica e compradas em bolsa americana, montadas na 
segunda quinzena do mês de abril, renda fixa local, aplicadas em 
juros reais e nominais de médio 
prazo. E em moedas, com posições compradas no real.
 
Diante da elevada volatilidade no cenário macro global, mantemos uma baixa exposição ao risco, 
privilegiando alocações mais táticas. Mantemos um viés construtivo para a bolsa americana, ancorado 
na resiliência do setor de tecnologia e na forte temporada de
 balanços, além da manutenção de 
posições compradas em iene japonês contra o euro.
 
No brasil, a moeda continua estruturalmente suportada pela melhora nos termos de troca derivada do 
choque de petróleo. Em contrapartida, mantemos cautela com o mercado acionário doméstico, que é 
afetado negativamente em um cenário de taxas de juros mais al
tas por um período prolongado, o que 
é mais provável diante de uma inflação alta e persistente nesse cenário de choque global na cadeia 
de energia e fertilizantes.

---

6 
 
 
 
  
www.armorcapital.com.br 
Carta Mensal 
Abril 2026 
Projeções Econômicas  
 
Fonte: Armor Capital  
Rentabilidade dos Fundos 
 
Fonte: BTG Pactual, Economatica  
Variável
2026
2027
Longo Prazo
PIB (%)
1,80
2,00
2,00
Inflação (%)
4,90
4,00
3,50
Câmbio
5,30
5,40
5,40
SELIC (%)
13,50
11,50
11,00
PIB (%)
2,50
2,00
2,00
Core PCE (%)
2,90
2,40
2,00
Fed Funds (%)
3,50
3,25
3,00
PIB (%)
0,80
1,10
1,30
Inflação - Core (%)
2,40
2,20
2,00
Taxa de Juros (%)
2,50
2,50
2,00
Zona do Euro
Brasil
EUA
FUNDO
Armor Axe 
Armor Previdência 
Armor Sword
2026
4,43
4,44
4,21
% do CDI (Ano)
98
98
93
12m
13,36
13,51
12,74
% do CDI (12m)
90
91
86
24m
30,16
28,67
26,11
% do CDI (24m)
108
103
93
36m
50,14
50,02
39,47
% do CDI (36m)
115
114
90
desde o início
150,74
101,82
62,19
% do CDI  (desde o início)
183
120
93
2025
15,03
13,31
12,94
2024
14,37
13,93
9,86
2023
15,48
16,67
12,73
2022
21,89
11,79
11,27
2021
4,76
5,54
-
2020
8,71
6,40
-
2019
13,85
2,21
-
Retornos (%) (até 30/04/2026)

---

7 
 
 
 
  
www.armorcapital.com.br 
Carta Mensal 
Abril 2026

---

8 
 
 
 
  
www.armorcapital.com.br 
Carta Mensal 
Abril 2026 
 
 
 
Fonte: Armor Capital 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
A Armor Gestora de Recursos Ltda. (“Armor Capital”) é uma sociedade devidamente autorizada pela Comissão de Valores 
Mobiliários para o exercício da atividade de administração de carteiras de valores mobiliários, na categoria “gestora de 
recursos”. A Armor Capital não comercializa nem distribui cotas de fundos de investimento ou qualquer outro ativo financeiro. 
As informações, opiniões e estimativas aqui contidas refletem o julgamento da Armor Capital na data de sua publicação e 
podem ser alteradas sem aviso
 prévio. As informações contidas neste material têm caráter exclusivamente informativo e 
não constituem recomendação de investimento, oferta ou aconselhamento de valores mobiliários. A Armor Capital não se 
responsabiliza por erros, omissões ou decisões de 
investimento tomadas com base neste conteúdo. A rentabilidade passada 
não representa garantia de resultados futuros. A rentabilidade divulgada não é líquida de impostos. Leia o regulamento antes 
de investir. Mais informações sobre a Armor Capital e seus fu
ndos de investimento estão disponíveis em 
www.armorcapital.com.br . 
 
Armor Capital Gestão de Investimentos 
armorcapital 
+55 11 4550-5701 
contato@armorcapital.com.br