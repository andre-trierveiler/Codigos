

---

®
Carta do Gestor
Carta do Gestor
Março 2026
Estimativas para 2026
Estimativas para 2026
armorcapital.com.br
Selic: 12,50%
Câmbio: R$5,35
PIB: 1,80%
IPCA: 4,50%

---

2 
 
 
 
  
www.armorcapital.com.br 
Carta Mensal 
Março 2026 
Cenário Internacional  
Os ataques ao Irã por parte de Israel e dos Estados Unidos deram a tônica para o mês de março e 
trouxeram uma intensa aversão ao risco, alterando o patamar dos preços dos ativos. O início do mês 
foi marcado por uma ofensiva que resultou na morte do líder s
upremo da nação, Ali Khamenei, como 
resposta ao regime político e aos processos de enriquecimento de urânio na região. Logo após os 
ataques iniciais, o presidente norte
- americano, Donald Trump, anunciou que as ofensivas perdurariam 
por mais quatro semanas.
 
Em resposta, o 
Irã bloqueou o Estreito de Ormuz de 
forma a reduzir o fluxo a zero. Cerca de 30% do 
fluxo global de petróleo e gás natural é transportado pelo estreito; dessa forma, os preços das duas 
commodities dispararam e, diante da ausência de resolução, seguiram se ajustando para cima. Em 
fevereiro, o  preço do petróleo era de US$ 65 por barril e encerrou março em US$ 103 por barril, 
representando um avanço de 60% no mês.
 
Os ataques continuaram ao longo do mês, mas o tom das autoridades passou a se atenuar. O 
presidente Trump chegou a anunciar negociações com o Irã, o que foi negado pelo governo iraniano. 
Ainda assim, foi enviada ao país uma série de propostas para encerrar
 o conflito, incluindo a retomada 
do fluxo no Estreito de Ormuz e o fim do programa nuclear. Em resposta, o Irã apresentou uma 
contraproposta exigindo o encerramento total dos ataques. Até o momento, não há uma resolução 
clara para o conflito, embora o tom
 das negociações tenha sido visto como positivo, contribuindo para 
a acomodação dos preços no fim do mês.
 
Com a alta do petróleo, tanto no mercado à vista quanto na curva futura, os demais ativos globais 
foram penalizados, especialmente as taxas de juros. Regiões mais dependentes da importação de 
petróleo e gás natural sentiram rapidamente os efeitos do choque
 energético. Na zona do euro e no 
Reino Unido, os agentes passaram a precificar duas altas de juros em 2026, levando a uma abertura 
significativa das taxas curtas e contribuindo para um ambiente global de juros mais elevados.
 
Diante do elevado grau de incerteza quanto aos impactos do petróleo sobre inflação e atividade 
econômica, os mercados voltaram as atenções para as decisões de política monetária ao longo do 
mês, em especial para eventuais mudanças de comunicação por parte 
dos bancos centrais.
 
O primeiro comitê a se reunir foi o FOMC, nos Estados Unidos. Conforme amplamente esperado, a taxa 
foi mantida em 3,75%, com apenas um voto dissidente favorável a um corte de 0,25 p.p. No conjunto 
das projeções, houve revisões altistas para a inflação, pri
ncipalmente em 2026, e leve ajuste para 
2027, refletindo o choque de petróleo. As projeções de PIB foram revisadas para cima em todos os 
anos, impulsionadas por ganhos de produtividade. Ainda assim, os “
dots ” continuaram a indicar um 
corte de 0,25 p.p. nes te ano e outro de mesma magnitude no próximo.
 
Em sua comunicação, o presidente do Fed, Jerome Powell, destacou preocupações com as tensões 
geopolíticas e seus impactos sobre a economia norte
- americana, ressaltando um balanço de riscos 
assimétrico para a inflação. Powell também afirmou que a criação de
 vagas de emprego em nível de 
equilíbrio está próxima de zero, o que conferiu um tom mais 
hawkish  do que o esperado e levou à 
incorporação de prêmio de alta na curva de juros dos EUA.
 
Posteriormente, ainda refletindo um ambiente mais pressionado para juros após o FOMC, o Banco da 
Inglaterra (BoE) também adotou um tom mais 
hawkish  ao manter a taxa básica em 3,75%, desta vez 
com votação consensual 
— diferentemente de reuniões anteriores, marcadas por dissensos em 
direção a cortes.

---

3 
 
 
 
  
www.armorcapital.com.br 
Carta Mensal 
Março 2026 
Por fim, o Banco Central Europeu (BCE) manteve a taxa em 2,0%. Em sua comunicação, Christine 
Lagarde destacou que a autoridade monetária está monitorando os efeitos do choque energético sobre 
a inflação e manteve em aberto os próximos passos da política mo
netária. Apesar do tom inicialmente 
moderado, Lagarde posteriormente adotou uma visão mais pessimista quanto aos impactos da guerra 
e à lentidão do processo de normalização após eventual resolução do conflito, o que gerou mal
- estar 
nos mercados globais de 
juros.  
Diante desse cenário de elevada incerteza, realizamos uma calibragem no cenário para a 
Fed Funds  
em 2026, elevando a projeção de 3,25% para 3,50%, em função do nível mais alto do petróleo. Para o 
core PCE, projetamos 2,5% neste ano e 2,2% no próximo
, enquanto o headline deve ficar na casa dos 
2,8% e 2,40%, respectivamente
. Para o PIB, esperamos crescimento de 2,0% em 2026 e de mesma 
magnitude em 2027.  
Por fim, ressaltamos que o cenário prospectivo permanece fortemente condicionado aos 
desdobramentos da guerra no Irã.
 
Cenário Doméstico 
O ambiente doméstico também passou por alterações relevantes em função dos desdobramentos da 
guerra no Irã, bem como da alta nos preços do petróleo. Antes do conflito, o cenário para a política 
monetária no Brasil se mostrava mais benigno, com a mediana da
 Selic para 2026 em 12% e boa parte 
do mercado precificando um ciclo de aproximadamente 300 bps de cortes. Diante de um ambiente de 
preços mais pressionados, o Banco Central passou a adotar uma postura mais cautelosa, tanto na 
magnitude dos cortes quanto n
a comunicação.  
No Copom de março, o comitê optou por iniciar o ciclo de flexibilização de forma gradual, com um 
corte de 0,25 p.p., em grande medida devido à disparada dos preços do petróleo e ao elevado nível de 
incerteza gerado pelas tensões no Irã. Em sua comunicação,
 o Banco Central tem destacado que o 
ciclo de flexibilização segue como cenário base, mas que sua magnitude ao longo deste ano está 
comprometida e fortemente condicionada aos desdobramentos no Oriente Médio.
 
Além da alta do petróleo, as surpresas altistas recentes na inflação corrente também contribuíram 
para a deterioração das expectativas. Tanto o IPCA de fevereiro quanto o IPCA
- 15 de março vieram 
mais pressionados, sobretudo nas categorias de serviços e, ma
is recentemente, alimentação no 
domicílio. Como resultado, a expectativa de inflação para 2026 no Focus passou de 3,9% para 4,3%; 
para 2027, de 3,8% para 3,84%; e, para 2028, de 3,50% para 3,57%. Esse ambiente corrobora um cenário 
de maior cautela por part
e do Copom, que deve prosseguir com um ciclo de cortes graduais, entre 
0,25 p.p. e 0,50 p.p.  
Diante desse contexto, revisamos nossa projeção para a Selic em 2026 de 12,0% para 12,50%, com viés 
para menos cortes, a depender dos impactos futuros sobre os preços. Ainda assim, mantemos a 
avaliação de que há espaço para um ciclo total de cerca de 250 b
ps, sustentado por um cenário mais 
favorável para o real no curto prazo, que tende a se beneficiar do nível mais elevado do preço do 
petróleo via melhora nos termos de troca. Com a já observada melhora na conta corrente, aliada ao 
saldo comercial positivo 
do setor de petróleo, o câmbio deve seguir como um ativo atrativo até meados 
do ano, antes do período eleitoral, que tende a adicionar volatilidade à moeda.
 
Nesse contexto, revisamos nossa projeção de inflação para este ano de 4,0% para 4,5% e esperamos 
crescimento de 1,8% do PIB. Para a taxa Selic, projetamos encerramento do ano em 12,50%. Já para a 
taxa de câmbio, esperamos que atinja R$ 5,35 ao final do ano
.

---

4 
 
 
 
  
www.armorcapital.com.br 
Carta Mensal 
Março 2026 
Comentário dos Gestores 
Conforme destacado na carta do mês anterior, a expectativa de que o acirramento dos conflitos no 
Oriente Médio desencadearia um ambiente de 
risk - off se materializou. O principal ativo a liderar os 
movimentos no período foi o petróleo, que avançou de US$ 67 para US$ 101 por barril, mostrando alta 
de 76,6% no mês. Com isso, a perspectiva de estagflação global voltou ao radar, pressionando 
significativam ente os ativos de risco. O S&P 500 recuou 5,09%, enquanto o DXY se valorizou 2,3%. Já 
as taxas dos 
US Treasu ries  abriram, em média, 40 pontos
- base, refletindo discursos mais 
hawkish 
dos bancos centrais, cada vez mais atentos à dinâmica inflacionária diante da elevação dos preços das 
commodities energéticas.
 
No mercado doméstico, observou
- se um processo relevante de reprecificação diante do novo patamar 
do petróleo. Em março, o Ibovespa recuou 0,7%, em linha com o ambiente global de maior aversão ao 
risco, mas em menor grau por conta do peso das empresas petro
líferas no índice. Na curva de juros, 
as taxas nominais abriram cerca de 90 pontos
- base no mês, com destaque para o DI janeiro/29, que 
avançou 107bps. Esse movimento reflete não apenas o aumento das incertezas associadas às tensões 
no Irã, mas também revis
ões altistas no Boletim Focus, que passou a incorporar expectativas 
inflacionárias mais pressionadas, influenciadas pelo petróleo e pelas recentes surpresas altistas de 
inflação doméstica.  
No câmbio, o real se desvalorizou 1% no mês, ainda assim apresentando desempenho relativamente 
melhor que seus pares 
— movimento compatível com a condição do Brasil como exportador líquido 
de petróleo, o que tende a gerar termos de troca mais favoráveis em
 um cenário de preços elevados 
da commodity.  
Em termos de estratégia, a principal contribuição positiva para o desempenho no mês veio da posição 
comprada em real e vendida em euro, ancorada na tese de divergência de termos de troca: enquanto 
o Brasil se beneficia do petróleo mais caro, a Europa figur
a entre as regiões mais penalizadas por 
esse choque. Por outro lado, as posições em renda variável 
— principalmente em bolsa doméstica 
— 
foram detratoras de performance, assim como as posições aplicadas em juros nos EUA e no Brasil. 
Essas estratégias estav
am baseadas na expectativa de desaceleração da atividade econômica e na 
possibilidade de cortes de juros pelo Federal Reserve ainda em 2026, cenário cuja probabilidade foi 
significativamente reduzida ao longo do período.
 
Olhando à frente, reforçamos que o cenário permanece altamente dependente dos desdobramentos 
do conflito no Irã. Ainda assim, avaliamos que há espaço mais limitado para cortes agressivos de juros 
neste ano. Diante desse contexto, optamos por manter posiçõe
s táticas em moedas e juros nominais, 
com menor exposição ao risco, priorizando a proteção frente à elevada volatilidade, especialmente 
enquanto não houver uma resolução clara para o conflito.

---

5 
 
 
 
  
www.armorcapital.com.br 
Carta Mensal 
Março 2026 
Projeções Econômicas  
 
Fonte: Armor Capital  
Rentabilidade dos Fundos 
 
Fonte: BTG Pactual, Economatica  
Variável
2026
2027
Longo Prazo
PIB (%)
1,80
2,00
2,00
Inflação (%)
4,50
3,90
3,50
Câmbio
5,35
5,40
5,40
SELIC (%)
12,50
11,00
10,00
PIB (%)
2,50
2,00
2,00
Inflação (%)
2,80
2,40
2,00
Fed Funds (%)
3,50
3,25
3,00
PIB (%)
1,10
1,30
1,30
Inflação (%)
2,50
2,25
2,00
Taxa de Juros (%)
2,25
2,00
1,75
Zona do Euro
Brasil
EUA
FUNDO
Armor Axe 
Armor Previdência 
Armor Sword
2026
2,28
2,54
2,79
% do CDI (Ano)
67
75
82
12m
14,53
13,28
13,25
% do CDI (12m)
98
90
90
24m
15,40
26,05
23,68
% do CDI (24m)
92
94
85
36m
48,55
49,39
39,20
% do CDI (36m)
112
114
90
desde o início
145,57
98,15
59,97
% do CDI  (desde o início)
181
118
92
2025
15,03
13,31
12,94
2024
14,37
13,93
9,86
2023
15,48
16,67
12,73
2022
21,89
11,79
11,27
2021
4,76
5,54
-
2020
8,71
6,40
-
2019
13,85
2,21
-
Retornos (%) (até 31/03/2026)

---

6 
 
 
 
  
www.armorcapital.com.br 
Carta Mensal 
Março 2026

---

7 
 
 
 
  
www.armorcapital.com.br 
Carta Mensal 
Março 2026 
 
Fonte: Armor Capital 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
A Armor Gestora de Recursos Ltda. (“Armor Capital”) é uma sociedade devidamente autorizada pela Comissão de Valores 
Mobiliários para o exercício da atividade de administração de carteiras de valores mobiliários, na categoria “gestora de 
recursos”. A Armor Capital não comercializa nem distribui cotas de fundos de investimento ou qualquer outro ativo financeiro. 
As informações, opiniões e estimativas aqui contidas refletem o julgamento da Armor Capital na data de sua publicação e 
podem ser alteradas sem aviso
 prévio. As informações contidas neste material têm caráter exclusivamente informativo e 
não constituem recomendação de investimento, oferta ou aconselhamento de valores mobiliários. A Armor Capital não se 
responsabiliza por erros, omissões ou decisões de 
investimento tomadas com base neste conteúdo. A rentabilidade passada 
não representa garantia de resultados futuros. A rentabilidade divulgada não é líquida de impostos. Leia o regulamento antes 
de investir. Mais informações sobre a Armor Capital e seus fu
ndos de investimento estão disponíveis em 
www.armorcapital.com.br . 
 
Armor Capital Gestão de Investimentos 
armorcapital 
+55 11 4550-5701 
contato@armorcapital.com.br