

---

®
Carta do Gestor
Carta do Gestor
Maio 2026
Estimativas para 2026
armorcapital.com.br
Selic: 14,00%
Câmbio: R$5,30
PIB: 1,90%
IPCA: 5,20%

---

2 
 
 
 
  
www.armorcapital.com.br 
Carta Mensal 
Maio 2026 
Cenário Internacional  
Maio começou com um tom conciliador, em meio à forte crença de que o conflito no Oriente Médio 
estaria próximo de uma resolução. Havia motivos para sustentar esse ambiente, uma vez que tanto 
os EUA quanto o Irã davam sinais de desgaste com a situação, espe
cialmente diante das pressões 
sobre os preços do petróleo.
 
Ao longo do mês, o tema central foi a negociação entre os dois países, marcada por constantes 
mudanças de narrativa e oscilações frequentes de tom. Apesar de alguns sinais pontuais de melhora, 
como passagens limitadas de navios e avanços nas tratativas ent
re EUA e Irã, o fluxo marítimo 
permaneceu bastante restrito, mantendo elevado o prêmio de risco sobre o petróleo. Além disso, em 
alguns momentos, quando parecia que os países estavam próximos de um acordo, ataques pontuais 
voltavam a elevar a tensão na reg
ião. 
A melhora parcial da situação veio no final do mês, com a sinalização de um possível cessar
- fogo de 
60 dias e a reabertura do estreito durante esse período. Apesar do sinal positivo, o mercado tem 
adotado uma postura mais cautelosa em relação às negociaçõe
s, o que tem impedido uma melhora 
mais expressiva nos preços dos ativos.
 
Ainda assim, alguns ativos apresentaram desempenho positivo, mesmo em um ambiente de juros 
elevados e dólar mais forte. A bolsa norte
- americana continuou mostrando resiliência, sustentada 
pelos bons resultados das empresas de tecnologia, o que ajudou a con
ter parte do pessimismo 
associado à guerra no Oriente Médio.
 
Quanto aos dados econômicos globais, os números mais recentes da China e da Zona do Euro vieram 
mais fracos que o esperado, aumentando o temor de uma desaceleração mais pronunciada da 
atividade. Por outro lado, a economia norte
- americana segue apresentando
 dinamismo, com números 
impulsionados pelo investimento e pelo CAPEX. O mercado de trabalho, por sua vez, passa por um 
momento de estabilização, caracterizado pelo padrão de “low hire, low fire”, com a taxa de desemprego 
oscilando próxima de 4,3%.
 
No campo da inflação global, permanece a preocupação dos dirigentes dos principais bancos centrais 
com os impactos secundários da alta dos preços do petróleo. Assim, os discursos dos formuladores 
de política monetária têm mostrado uma postura mais cautelos
a em relação à inflação, e, entre os 
membros do Fed, isso não tem sido diferente. A ata do FOMC de abril já trouxe uma comunicação mais 
dura, ao indicar que a probabilidade de elevação de juros aumentaria caso houvesse uma piora 
adicional da inflação. Com 
isso, o Fed corrobora a retirada total do “easing bias” na próxima 
comunicação.  
Nesse ambiente adverso, o novo chairman do Fed, Kevin Warsh, assume a posição na próxima reunião, 
que acontecerá em meados de julho, configurando uma transição em um momento particularmente 
delicado. Diante disso, Warsh deverá defender a independência do F
ed e adotar uma comunicação 
mais dura, em linha com o restante do board.
 
Diante desse cenário de elevada incerteza, esperamos que os Fed Funds permaneçam inalterados 
neste ano e no próximo. Para o core PCE, projetamos altas de 3,0% neste ano e de 2,4% no próximo, 
enquanto o headline deve avançar 3,3% e 2,4%, respectivamente. Pa
ra o PIB, esperamos crescimento 
de 2,5% em 2026 e de 2,0% em 2027.

---

3 
 
 
 
  
www.armorcapital.com.br 
Carta Mensal 
Maio 2026 
Por fim, vale destacar que junho começa com as negociações ainda em aberto, o que pode favorecer 
um ambiente de maior propensão ao risco caso surja um acordo crível. No entanto, como mencionado 
anteriormente, os agentes seguem mais cautelosos e devem aguar
dar fatos concretos antes de adotar 
uma postura mais favorável ao risco.
 
Cenário Doméstico 
No ambiente local, a dinâmica continuou sendo ditada pelas perspectivas externas em torno da guerra 
no Oriente Médio, mas também contou com sinais internos importantes, sobretudo ruídos políticos, à 
medida que as eleições de outubro se aproximam.
 
Um dos principais temas do mês foi o processo de tramitação e aprovação da emenda constitucional 
que determina o fim da escala 6x1. Segundo o texto, a implementação deve ocorrer em até 14 meses e 
contempla a redução gradual da jornada semanal, com corte in
icial de duas horas por semana e 
entrada em vigor até dois meses após a promulgação. Com a aprovação inicial na Câmara, a proposta 
agora segue para análise do Senado.
 
Ainda na esfera política, o tema eleitoral tem entrado cada vez mais no radar. Contudo, as expectativas 
em relação a uma possível alternância de governo foram colocadas em xeque, diante da melhora da 
aprovação do governo atual nas últimas pesquisas de opin
ião. Boa parte desse movimento foi 
explicada pela possível vinculação da oposição ao caso Master, por meio de relações com o ex
-
presidente do banco, Daniel Vorcaro. Além disso, como mais um vetor de perda de apetite por risco 
nos ativos locais, o governo n
orte- americano classificou duas das principais facções do crime 
organizado no Brasil como organizações terroristas.
 
Quanto ao ambiente econômico, o PIB do primeiro trimestre teve resultado em linha com o esperado 
e confirmou o ritmo ainda aquecido da atividade. O produto cresceu 1,1% na comparação trimestral, 
frente à expectativa de 1,0%. Como se trata do dado do primei
ro trimestre — período em que as safras 
tendem a ter forte contribuição para o crescimento 
—, é pertinente calcular o PIB excluindo a 
agropecuária. Nessa medida, o PIB também apresentou crescimento sólido, de 1,0% no trimestre, 
mostrando que a dinâmica de 
consumo segue bastante elevada e sem sinais muito claros de 
descompressão.  
O ritmo ainda aquecido da atividade, o mercado de trabalho resiliente, a expectativa de um El Niño 
forte no segundo trimestre e os efeitos secundários da alta do petróleo reforçam uma perspectiva de 
piora para as expectativas de inflação. No Boletim Focus 
do início de maio, as expectativas de inflação 
para 2026 e 2027 estavam em 4,89% e 4,00%, respectivamente, lembrando que abril já havia sido um 
mês de fortes revisões altistas. Ao fim de maio, os mesmos horizontes se encontravam em 5,09% e 
4,02%. 
Diante dos possíveis impactos de um El Niño mais forte 
— com chuvas intensas na região Sul e maior 
seca nas regiões Norte e Nordeste 
—, revisamos nosso cenário de inflação para 2026, que passou de 
4,90% para 5,20%, enquanto mantivemos a projeção para 2027 
em 4,00%. Como forma de combater a 
inércia da inflação deste ano para o próximo, esperamos que o Banco Central leve a taxa Selic para 
14% em 2026, com algum espaço para calibragem em 2027, levando
- a para 13%. 
Quanto à atividade econômica, esperamos crescimento de 1,9% neste ano e de 1,8% no próximo. Para 
o câmbio, projetamos uma taxa de 5,30 em 2026 e de 5,40 em 2027.

---

4 
 
 
 
  
www.armorcapital.com.br 
Carta Mensal 
Maio 2026 
Comentário dos Gestores 
Maio foi pautado pela expectativa de resolução do conflito no Oriente Médio. O tom mais conciliador 
no início do mês fez o petróleo recuar mais de 10% nos vencimentos curtos. Apesar do alívio na 
commodity, a resiliência da atividade americana e as preocupa
ções com a inflação pressionaram as 
taxas das Treasuries, que abriram cerca de 15 bps no mês, encerrando o período voltando a precificar 
altas de juros para este ano. Nas bolsas norte
- americanas, a busca por eficiência e o forte 
crescimento das expectativa
s de resultados no setor de tecnologia ditaram a dinâmica. O 
protagonismo dos semicondutores fez o ETF do setor (SOXX) saltar 23%, impulsionando o Nasdaq 
(+10,5%) e o S&P 500 (em torno de +5%). No câmbio, o iene voltou a se enfraquecer em grande 
magnitude após as intervenções de abril, fortalecendo o dólar globalmente (DXY +0,87%). Contudo, o 
ambiente de risk - on sustentou o bom desempenho da maior parte das moedas de países emergentes.
 
Na contramão de seus pares emergentes, os ativos brasileiros performaram mal. O mercado local 
sofreu com a divulgação de conversas entre Flávio Bolsonaro e Daniel Vorcaro, o que reduziu a 
percepção de uma possível alternância de poder e penalizou os ativos
 de risco. Esse cenário político 
ruidoso, somado a um índice com alta concentração em bancos e commodities e sem exposição ao 
rali global de tecnologia, resultou em uma queda superior a 7% no Ibovespa. O movimento foi 
acompanhado por uma expressiva saída d
e fluxo estrangeiro, totalizando aproximadamente US$ 3 
bilhões retirados da B3. Na renda fixa, o movimento foi de aversão ao risco, com as taxas pré
- fixadas 
abrindo entre 10 e 15 bps ao longo de maio.
 
A performance do fundo no mês foi positiva, impulsionada principalmente por renda variável, onde 
capturamos valor com posições compradas na bolsa americana e vendidas na bolsa local. Tivemos 
também contribuições positivas das posições tomadas em juros nomi
nais locais e das posições 
aplicadas em juros americanos, montadas de forma tática no decorrer do mês.
 
Diante das dúvidas remanescentes no Oriente Médio e do horizonte cada vez mais próximo das 
eleições no Brasil, mantemos uma gestão de portfólio predominantemente tática. Ao longo do mês, 
aumentamos posições aplicadas em juros reais domésticos de médio praz
o, com hedge em operações 
táticas tomadas na curva nominal. No exterior, seguimos com alocação aplicada nas Treasuries e 
posições compradas em bolsa global. Em moedas, permanecemos com posições compradas em real 
e em iene, contra o euro. Além disso, seguim
os com um viés pessimista com a bolsa local.

---

5 
 
 
 
  
www.armorcapital.com.br 
Carta Mensal 
Maio 2026 
Projeções Econômicas  
 
Fonte: Armor Capital  
Rentabilidade dos Fundos 
 
Fonte: BTG Pactual, Economatica  
Variável
2026
2027
Longo Prazo
PIB (%)
1,90
1,80
2,00
Inflação (%)
5,20
4,00
3,00
Câmbio
5,30
5,40
5,40
SELIC (%)
14,00
13,00
11,00
PIB (%)
2,50
2,00
2,00
Core PCE (%)
3,00
2,40
2,00
Fed Funds (%)
3,50
3,50
3,00
PIB (%)
0,80
1,10
1,30
Inflação - Core (%)
2,50
2,20
2,00
Taxa de Juros (%)
2,50
2,50
2,00
Zona do Euro
Brasil
EUA
FUNDO
Armor Axe 
Armor Previdência 
Armor Sword
2026
6,14
5,93
5,43
% do CDI (Ano)
108
105
96
12m
14,26
13,74
12,97
% do CDI (12m)
96
93
88
24m
29,10
28,18
25,60
% do CDI (24m)
103
99
90
36m
52,18
50,51
39,60
% do CDI (36m)
119
115
90
desde o início
154,84
104,70
64,09
% do CDI  (desde o início )
184
121
93
2025
15,03
13,31
12,94
2024
14,37
13,93
9,86
2023
15,48
16,67
12,73
2022
21,89
11,79
11,27
2021
4,76
5,54
-
2020
8,71
6,40
-
2019
13,85
2,21
-
Retornos (%) (até 31/05/2026)

---

6 
 
 
 
  
www.armorcapital.com.br 
Carta Mensal 
Maio 2026

---

7 
 
 
 
  
www.armorcapital.com.br 
Carta Mensal 
Maio 2026 
 
 
 
Fonte: Armor Capital 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
A Armor Gestora de Recursos Ltda. (“Armor Capital”) é uma sociedade devidamente autorizada pela Comissão de Valores 
Mobiliários para o exercício da atividade de administração de carteiras de valores mobiliários, na categoria “gestora de 
recursos”. A Armor Capital não comercializa nem distribui cotas de fundos de investimento ou qualquer outro ativo financeiro. 
As informações, opiniões e estimativas aqui contidas refletem o julgamento da Armor Capital na data de sua publicação e 
podem ser alteradas sem aviso
 prévio. As informações contidas neste material têm caráter exclusivamente informativo e 
não constituem recomendação de investimento, oferta ou aconselhamento de valores mobiliários. A Armor Capital não se 
responsabiliza por erros, omissões ou decisões de 
investimento tomadas com base neste conteúdo. A rentabilidade passada 
não representa garantia de resultados futuros. A rentabilidade divulgada não é líquida de impostos. Leia o regulamento antes 
de investir. Mais informações sobre a Armor Capital e seus fu
ndos de investimento estão disponíveis em 
www.armorcapital.com.br . 
 
Armor Capital Gestão de Investimentos 
armorcapital 
+55 11 4550-5701 
contato@armorcapital.com.br