

---

®
Carta do Gestor
Carta do Gestor
Fevereiro 2026
Estimativas para 2026
Selic:12,00%
Câmbio:R$5,45
PIB:1,80%
IPCA:4,00%
armorcapital.com.br

---

2 
 
 
 
  
www.armorcapital.com.br 
Carta Mensal 
Fevereiro 2026 
Cenário Internacional  
Fevereiro foi um mês de intensa volatilidade para os ativos de risco e pode ser fragmentado em duas 
partes. A primeira parte consiste na digestão do nome de Kevin Warsh como substituto de Jerome 
Powell no FED e surpresas altistas nos dados de atividade. A 
segunda foi concentrada na elevação da 
incerteza em relação a inteligência artificial
, tarifas de importação e acirramento das tensões no 
Oriente Médio, especialmente no Irã.
 
Conforme citado por nós na carta do gestor de janeiro, 
a indicação de  Warsh como próximo chairman 
do FED trouxe maior conforto aos agentes de mercado num primeiro momento, sendo um nome que 
sustentaria a credibilidade da instituição. No entanto, ao decorrer do mês, ruídos sobre a possibilidade 
de ações coordenadas entre o F
ED e o tesouro, relacionadas à emissão e compra dos títulos de dívida 
dos EUA, colocou um ponto de interrogação no mercado como um todo
, trazendo um viés de aplicação 
de taxa de juros nor
te- americana . 
Entretanto, as surpresas altistas nos dados de atividade, em especial, no mercado de trabalho, 
adicionaram volatilidade aos preços. O Payroll do mês de janeiro mostrou a criação de 172 mil vagas, 
muito acima dos 68 mil projetados pelo mercado. Além disso, 
a taxa de desemprego passou de 4,4% 
para 4,3%, acalmando, por ora, as preocupações em relação ao mercado de trabalho norte
- americano.  
O fato é que, diante dos investimentos massivos e crescentes em inteligência artificial, o mercado tem 
levantado a preocupação de que essa tecnologia possa substituir de forma significativa a mão de obra
 
e impactar  negativamente a criação de empregos no país. Essa tese se baseia no ganho de 
produtividade das empresas após tais investimentos e no receio de que, com salários mais baixos, o 
consumo das famílias perca tração nos próximos anos.
 
Ao analisarmos os dados mais recentes do mercado de trabalho, observamos que o impacto da 
substituição de mão de obra por inteligência artificial ainda é relativamente pequeno. Entre os setores, 
o mais claramente afetado é o de Informação e Tecnologia, o q
ue é coerente, já que se trata do 
segmento que mais tem investido nessa tecnologia.
 
Além disso, outros setores podem até se beneficiar no curto prazo, como o de construção, 
impulsionado pelo anúncio de diversos projetos de data centers em território norte
- americano. Dessa 
forma, acreditamos que o processo de substituição tende a ocorrer d
e maneira gradual e em menor 
magnitude ao longo dos próximos cinco anos, à medida que as empresas incorporarem essa 
tecnologia em seus processos . Com isso, estimamos que a taxa de desemprego neste ano deverá ficar 
em torno de 4,4%.  
Vale citar também, os imbróglios políticos e geopolíticos dos EUA durante o mês. O primeiro deles é 
em relação às tarifas de importação, em que o governo Trump perdeu uma batalha importante. A 
suprema corte dos EUA derrubou as tarifas após julgá
- las como inconstitucionais. E
m resposta, 
Trump anunciou a adoção de uma tarifa universal em 10% para todos os países, mas tem feito 
constantes ameaças para elevar a tarifa base para 15%.
 
Enquanto isso, as tensões no irã ficaram cada vez mais crescentes a ponto da realização de ataques 
coordenados entre EUA e Israel em solo iraniano. Com esse ataque, as bases do governo iraniana 
foram desfeitas, mas os ataques ainda devem perdurar pelo próx
imo mês, conforme o discurso do 
Presidente Trump. Isso deixa para o início do mês de março, uma maior aversão ao risco, uma vez que 
os custos de petróleo devem 
aumentar  no curto prazo.

---

3 
 
 
 
  
www.armorcapital.com.br 
Carta Mensal 
Fevereiro 2026 
 
Dada a resiliência da atividade, esperamos que os EUA apresentem crescimento de 2,7% e inflação de 
2,8% em 2026. Com as expectativas inflacionárias ancoradas, ainda há espaço para dois cortes de 0,25 
p.p. nas Fed Funds, levando o upper bound para 3,25%, qu
e, em nossa visão, corresponde ao nível 
neutro da taxa de juros do país.
 
Cenário Doméstico 
O ambiente doméstico ainda tem sido bastante influenciado pelo cenário 
global. Com as instabilidades 
citadas no capítulo anterior, os países emergentes continua
ram atrativos e, consequentemente com 
um fluxo positivo em seus mercados.
 
Dado esse apetite por risco em emergentes, o Brasil é bastante beneficiado, uma vez que em meio a 
grandes incertezas globais é considerado um país neutro, iniciará um ciclo de cortes juros, ainda que 
o carry trade  seja bastante favorável às operações em moeda local. 
 
Tendo isso em vista, a agenda de indicadores não mostrou 
surpresas significativas no curto prazo. Os 
dados de atividade econômica, confirmam um processo de desaceleração gradual dos negócios, ao 
mesmo tempo que o mercado de trabalho têm mostrado dinamismo.
 A PNAD de dezembro registrou 
a menor taxa de desemprego da série histórica iniciada em 2013, atingindo o patamar de 5,1%. Além 
disso, os rendimentos continuam em patamares bastante elevados,
 o que continua a ser uma 
preocupação do banco central e deve ser
 um dos fatores limitativos para cortes mais agressivos no 
ciclo que iniciará em março.
 
Os dados de inflação, continuaram a mostrar um qualitativo dúbio, com bens industriais em patamares 
baixos, em função da taxa de câmbio apreciado, enquanto os serviços se mantêm em níveis elevados. 
Especificamente no IPCA
- 15 de fevereiro, os serviços mostr
aram uma pressão adicional em função de 
passagens aéreas e higiene pessoal, que são itens mais voláteis, e por seguro voluntário de veículos, 
refletindo os reajustes de início de ano. Ainda assim, os números não são significativos a ponto de 
recalibrar as 
expectativas de inflação para o ano e para 2027.
 
Já a agenda política foi bastante esvaziada em função do feriado de carnaval. Ainda assim, um dos 
temas de destaque foi o fim da escala 6x1, que parece ser uma das principais propostas do governo 
atual, depois da aprovação da isenção do Imposto de Renda pa
ra os que ganham até R$ 5 mil. O 
Presidente da Câmara, Hugo Motta, 
chegou a citar que a votação deve acontecer em maio e vê clima 
favorável à aprovação.
 
Já na esteira das eleições, as pesquisas têm mostrado um avanço significativo de Flávio Bolsonaro, 
apontando para um cenário bastante competitivo, dado o baixo nível de aprovação do g
overno.  
Diante desse ambiente, reiteramos nossa projeção de crescimento do PIB em 1,8% neste ano e inflação 
de 4,0%. Quanto à taxa Selic, projetamos que finalize o ano em 12%, com 6 cortes consecutivos de 0,50 
p.p. Para a taxa de câmbio, esperamos que atinja R$ 5,
45 no fim do ano.

---

4 
 
 
 
  
www.armorcapital.com.br 
Carta Mensal 
Fevereiro 2026 
Comentário dos Gestores 
Como citado anteriormente, fevereiro foi marcado por um aumento na volatilidade dos mercados
 
globais . O receio sobre a possibilidade da substituição de alguns serviços por inteligência artificial foi 
latente no início  do mês, impactando os preços das empresas 
americanas de alguns setores, como 
as 
de softwares, bancos, seguradoras e até mesmo de empresas de transportes.
 Dessa forma, as ações 
do setor financeiro caíram em torno de 3,7% e 
do setor de softwares quase 10%. O S&P500 caiu apenas 
0,82%, suportado p or setores defensivos que subiram em torno de 10% no mês, como materiais básicos 
e empresas petrolíferas.
 O temor em relação a essa eventual mudança de paradigma, aliado com 
discussões sobre a liquidez de fundos de 
private credit  americanos e o acirramento das tensões dos 
EUA com o Irã levou o mercado americano para um movimento de risk
- off ao longo do mês, com isso 
taxas das treasuries de longo prazo fecharam mais de 25bps no mês, com as taxas dos títulos de 10 
anos encerrando o mês abaixo de 4%.
 
O mercado doméstico seguiu em uma dinâmica positiva, impulsionado pelo fluxo global para mercado
s 
emergentes  e por pesquisas eleitorais mostrando um cenário eleitoral mais acirrado. No mês de 
fevereiro o Ibovespa se valorizou 4,1%, beneficiando
- se de um fluxo positivo de estrangeiros para a 
bolsa brasileira de quase US$8bi nos dois primeiros meses do ano. Diante
 desse otimismo, o Real se 
valorizou 2,4% frente ao dólar
, com uma performance marginalmente acima dos seus pares. 
Aproveitando o fluxo cambial favo
rável, o Banco Central deixou vencer US$1,25bi
 em SWAPs cambiais 
na PTAX do último dia de fevereiro, totalizando uma redução de mais de US$2bi nos últimos 6 meses.
 
As principais contribuições para o desempenho do mês vieram das posições em renda fixa local, com 
destaque para posições aplicadas em juros reais e nominais, e moedas, em posições compradas em 
real contra dólar. As posições em renda variável, sendo posiçõe
s táticas compradas em bolsa 
americana contra bolsa doméstica e renda fixa global, com posições tomadas em taxas de juros 
americanas, contribuíram negativamente para a performance.
 
No cenário externo, ainda acreditamos que a economia americana deve se manter resiliente, mas 
estamos com posições táticas em bolsa e juros americanos dada a alta volatidade dos mercados. O 
ponto de atenção do mês de março será o desenrolar do conflito ent
re os EUA e o Irã, deixando mais 
claro o apetite do mercado para ativos de risco. Dessa forma, permanecemos com as posições táticas 
em bolsa e juros locais, assim como em moedas
.

---

5 
 
 
 
  
www.armorcapital.com.br 
Carta Mensal 
Fevereiro 2026 
Projeções Econômicas  
 
Fonte: Armor Capital  
Rentabilidade dos Fundos 
 
Fonte: BTG Pactual, Economatica  
Variável
2026
2027
Longo Prazo
PIB (%)
1,80
2,00
2,00
Inflação (%)
4,00
3,80
3,50
Câmbio
5,45
5,45
5,45
SELIC (%)
12,00
11,00
10,00
PIB (%)
2,70
2,00
2,00
Inflação (%)
2,80
2,50
2,00
Fed Funds (%)
3,25
3,00
3,00
PIB (%)
1,30
1,30
1,30
Inflação (%)
2,00
2,00
2,00
Taxa de Juros (%)
1,75
1,75
1,50
Zona do Euro
Brasil
EUA
FUNDO
Armor Axe 
Armor Previdência 
Armor Sword
2026
2,24
1,74
2,00
% do CDI (Ano)
103
80
92
12m
15,69
13,30
13,57
% do CDI (12m)
108
91
93
24m
28,48
27,50
24,07
% do CDI (24m)
104
101
88
36m
49,99
50,33
39,45
% do CDI (36m)
115
116
91
desde o início
145,48
96,59
58,74
% do CDI  (desde o início )
156
120
93
2025
15,03
13,31
12,94
2024
14,37
13,93
9,86
2023
15,48
16,67
12,73
2022
21,89
11,79
11,27
2021
4,76
5,54
-
2020
8,71
6,40
-
2019
13,85
2,21
-
Retornos (%) (até 28/02/2026)

---

6 
 
 
 
  
www.armorcapital.com.br 
Carta Mensal 
Fevereiro 2026

---

7 
 
 
 
  
www.armorcapital.com.br 
Carta Mensal 
Fevereiro 2026 
  
Fonte: Armor Capital 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
A Armor Gestora de Recursos Ltda. (“Armor Capital”) é uma sociedade devidamente autorizada pela Comissão de Valores 
Mobiliários para o exercício da atividade de administração de carteiras de valores mobiliários, na categoria “gestora de 
recursos”. A Armor Capital não comercializa nem distribui cotas de fundos de investimento ou qualquer outro ativo financeiro. 
As informações, opiniões e estimativas aqui contidas refletem o julgamento da Armor Capital na data de sua publicação e 
podem ser alteradas sem aviso
 prévio. As informações contidas neste material têm caráter exclusivamente informativo e 
não constituem recomendação de investimento, oferta ou aconselhamento de valores mobiliários. A Armor Capital não se 
responsabiliza por erros, omissões ou decisões de 
investimento tomadas com base neste conteúdo. A rentabilidade passada 
não representa garantia de resultados futuros. A rentabilidade divulgada não é líquida de impostos. Leia o regulamento antes 
de investir. Mais informações sobre a Armor Capital e seus fu
ndos de investimento estão disponíveis em 
www.armorcapital.com.br . 
 
Armor Capital Gestão de Investimentos 
armorcapital 
+55 11 4550-5701 
contato@armorcapital.com.br