

---

Fonte: Bahia Asset Management | Data: 01/2026
Fonte: Bahia Asset Management | Data: 02/2026
PREÇO DO PETRÓLEO BRENT | US$ POR BARRIL
Comentários do Gestor
COPYRIGHT © 2025 - TODOS OS DIREITOS RESERVADOS
Carta
do Gestor
O mês de fevereiro foi marcado por volatilidade de 
ativos de risco e dos juros americanos diante de 
incertezas em torno de disrupções decorrentes do 
avanço da inteligência artiﬁcial e seu ciclo de 
investimentos, assim como da persistência de 
tensões geopolíticas.
Após algumas rodadas de negociação, as forças 
armadas dos EUA e de Israel bombardearam o Irã, 
matando o líder supremo do país, Ali Khamenei, e 
muitas de suas principais lideranças. As forças 
iranianas responderam com ataques a países 
vizinhos e a bases militares americanas na região. 
Ademais, a Guarda Revolucionária declarou o 
fechamento do estreito de Ormuz, ameaçando 
bombardear navios que tentem fazer a travessia e 
limitando o escoamento de petróleo, o que provocou 
uma alta relevante nos preços.
Nos Estados Unidos, a taxa de desemprego caiu 
novamente em janeiro, acompanhada de uma 
geração de vagas robusta. Já os demais indicadores 
do mercado de trabalho apresentaram sinais mistos 
na 
margem, 
oscilando 
entre 
estabilização 
e 
afrouxamento adicional. Do lado da atividade, em 
que pese as estatísticas de consumo terem 
moderado na margem, a demanda privada se 
manteve bem, com destaque para investimentos em 
bens de capital. Por último, a despeito de uma 
surpresa positiva em aluguéis, um componente 
tipicamente inercial, é esperado que o núcleo do 
PCE, principal indicador de inﬂação acompanhado 
pelo Federal Reserve, se mantenha elevado em 
janeiro devido a alguns itens voláteis e aos bens 
afetados pelas tarifas. 
FEV
2026
JURO NOMINAL BRASILEIRO DE JAN/29
58,00
63,00
68,00
73,00
78,00
mar-25
mai-25
jul-25
set-25
nov-25
jan-26
mar-26
12,5
12,7
12,9
13,1
13,3
13,5
13,7
jun-25
set-25
dez-25
mar-26

---

Comentários do Gestor
COPYRIGHT © 2025 - TODOS OS DIREITOS RESERVADOS
Na Zona do Euro, a inﬂação seguiu próxima da meta, 
enquanto a atividade econômica e o mercado de 
trabalho continuaram resilientes, com os últimos 
dados indicando crescimento perto do potencial. As 
falas dos membros do ECB ecoaram o discurso de 
estarem “bem-posicionados” para responderem a 
eventuais choques, sem ajustes iminentes na taxa de 
juros em seu cenário central.
Na Ásia, os dados de janeiro da China mostraram 
persistência da fraqueza do setor imobiliário, 
contrastando com um setor externo ainda ﬁrme. No 
Japão, o partido da primeira-ministra Takaichi 
conquistou uma supermaioria na Câmara após a 
eleição parlamentar, eliminando a necessidade de 
aliança com partidos menores mais à esquerda, que 
possuem demandas ﬁscais mais agressivas.
No 
Brasil, 
pesquisas 
eleitorais 
mais 
recentes 
mostraram estreitamento das intenções de voto 
entre Lula e Flávio Bolsonaro, com a aprovação do 
governo 
em 
queda. 
Quanto 
aos 
indicadores 
econômicos, a divulgação mais recente do PIB 
mostrou uma demanda doméstica fraca e abaixo do 
esperado. Do lado da inﬂação, o dado mais recente 
apresentou 
surpresa 
altista 
relevante, 
porém 
bastante concentrada em itens voláteis e pouco 
inerciais. A interpretação foi de um número pior, 
porém com poucas implicações para a dinâmica à 
frente. Do lado de política monetária, em suas 
comunicações mais recentes, o presidente do 
Comitê manteve a sugestão do início do ciclo de 
cortes de juros em março, destacando cautela e 
parcimônia na condução do processo.
Na elaboração de nossas teses de investimentos, 
reconhecemos o elevado nível de incerteza em 
relação 
aos 
ciclos 
econômicos 
das 
principais 
economias globais e aos riscos geopolíticos. A 
agenda 
da 
administração 
norte-americana 
provavelmente ocasionará um rearranjo nas cadeias 
de suprimentos globais e até mesmo de alianças 
geopolíticas vigentes desde o pós-guerra. Dessa 
forma, a reação de cada banco central e governo é 
complexa e altamente incerta.  Nos Estados Unidos, o 
Fed está particularmente atento ao mercado de 
trabalho e ao impacto das tarifas na inﬂação. No 
bloco europeu, consideramos que a elevação 
considerável 
nos 
gastos 
ﬁscais, 
liderada 
pela 
Alemanha, deve ocupar o espaço para novos 
afrouxamentos monetários.
Consideramos que os fatores externos que merecem 
maior atenção são: (i) a implementação e os 
impactos das políticas econômicas e geopolíticas do 
presidente Donald Trump; (ii) a postura dos bancos 
centrais em relação aos próximos passos da política 
monetária; (iii) a retomada da atividade e a evolução 
da inﬂação nos principais blocos econômicos, em 
particular do mercado de trabalho norte-americano; 
(iv) a atividade na China e novas medidas de estímulo 
que possam vir a ser adotadas no país, (v) a potencial 
escalada do conﬂito no Oriente Médio e suas 
implicações 
para 
a 
trajetória 
de 
preços 
de 
commodities.
No Brasil, estamos especialmente atentos: (i) à 
trajetória da inﬂação corrente, em especial ao núcleo 
de inﬂação subjacente de serviços; (ii) às expectativas 
de inﬂação; (iii) às discussões ﬁscais e paraﬁscais; (iv) 
à velocidade da desaceleração da atividade e ao 
comportamento do emprego e salários; e (v) às 
discussões e pesquisas referentes às eleições desse 
ano.
FEV
2026

---

Multimercados 
Macro
No mês, os principais ganhos vieram de posições 
tomadas na inclinação de juros reais, aplicadas no 
juro real, e da posição comprada no ouro. Nas 
estratégias de bolsa e moedas, os ganhos vieram de 
posições compradas em bolsa brasileira e compradas 
numa cesta de moedas emergentes contra moedas 
desenvolvidas. 
As 
perdas 
vieram 
de 
posições 
vendidas em proteção CDX High Yield e aplicadas no 
juro nominal brasileiro. 
Estratégias e Atribuição de Resultados
COPYRIGHT © 2025 - TODOS OS DIREITOS RESERVADOS
No Brasil, mantivemos posições aplicadas em juros 
nominais, tomadas na inclinação de juros reais e 
comprados na bolsa brasileira. Em commodities, 
temos posições compradas em ouro. No mercado 
internacional, temos posições aplicadas no México 
contra os EUA. Na mesa de moedas, estamos 
comprados em uma cesta de emergentes contra 
desenvolvidos.
FEV
20226
MARAÚ
12 MESES
FEV/26
Juros
2,8%
0,4%
Moedas
1,5%
0,0%
Crédito Soberano e Índices
-0,1%
-0,10%
Commodities
1,3%
0,13%
Bolsa
-0,5%
0,03%
Total Operações
5,1%
0,5%
CDI / Txs / Custos
12,4%
0,8%
Maraú
17,5%
1,3%
%CDI
119%
129%
MUTÁ
12 MESES
FEV/26
Juros
5,8%
0,8%
Moedas
3,1%
0,0%
Crédito Soberano e Índices
-0,2%
-0,2%
Commodities
2,7%
0,3%
Bolsa
-1,0%
0,1%
Total Operações
10,4%
0,9%
CDI / Txs / Custos
11,6%
0,7%
Mutá
22,0%
1,6%
%CDI
150%
163%
BAHIA
12 MESES
FEV/26
Juros
1,7%
0,2%
Moedas
0,9%
0,0%
Crédito Soberano e Índices
-0,1%
-0,1%
Commodities
0,8%
0,1%
Bolsa
-0,3%
0,0%
Total Operações
3,1%
0,3%
CDI / Txs / Custos
12,6%
0,9%
Bahia
15,7%
1,2%
%CDI
107%
116%

---

COPYRIGHT © 2025 - TODOS OS DIREITOS RESERVADOS
Multimercados L&S | LB 
e Renda Variável
Comentários do Gestor
Exposição das Carteiras
Contribuições Positivas
--  Mantivemos uma carteira diversiﬁcada ao longo do 
mês com uma média de 26 papéis.  
--  A posição média comprada nos fundos long only 
foi de 97% e no fundo Long Biased foi de 60%.
-- As maiores posições compradas estão nos setores 
de Bancos, Imobiliário e Utilities.
As maiores contribuições positivas vieram dos 
setores Elétrico e Imobiliário. No setor Elétrico, 
Axia e Copel foram destaques:
-- Axia anunciou a intenção de migrar para o Novo 
Mercado, propondo um ratio de troca entre suas 
ações ordinárias e preferenciais;
--  Copel ﬁnalizou sua migração para o Novo Mercado.
As incorporadoras de baixa renda também tiveram 
uma boa performance com aumento do funding 
para o programa Minha Casa Minha Vida e com 
revisões para cima na renda elegível para o 
comprador e no preço teto das unidades. 
Fevereiro foi mais um mês de performance 
excepcional para os mercados emergentes. O ﬂuxo 
para países emergentes já soma mais de 70 bilhões 
de dólares nos últimos meses. Para o Brasil não foi 
diferente: neste início de ano, a compra de ações no 
mercado à vista pelo investidor estrangeiro já 
ultrapassa 40 bilhões de reais. As ações mais 
beneﬁciadas desse ﬂuxo têm sido as de maior 
liquidez e maior capitalização. 
Em relação às commodities, o petróleo teve outro 
mês positivo, subindo perto de 6% nos mercados 
internacionais. O minério de ferro terminou em 
queda de 5% e as cotações de aço fecharam perto da 
estabilidade. O ouro subiu 8%. A celulose ﬁcou “ﬂat” 
no mercado chinês futuro. Nas agrícolas, o açúcar 
terminou o mês zerado, o milho subiu 3% e a soja 
subiu 9%.
O Ibovespa subiu 4,1% e o índice de Small Caps foi 
positivo em 1,9%. Por sua vez, as rentabilidadess dos 
fundos no mês foram:
--  Bahia AM Valuation: +4,5%;
--  Bahia AM Long Biased: +3,3%;
--  Bahia AM Una Equity Hedge: +1,5%.
2026
FEV
Contribuições Negativas
As contribuições negativas ﬁcaram concentradas no 
setor de consumo:
--  Smart Fit teve uma má performance com a venda 
do último pedaço de participação de um acionista 
antigo da companhia e com discussões, ainda que 
qualitativas, sobre o acirramento da competição.

---

ACOMPANHE NOSSAS REDES 
E RECEBA CONTEÚDOS EXCLUSIVOS
ACESSE O NOSSO SITE
WWW.BAHIAASSET.COM.BR
Para demais documentos e informações dos fundos acesse www.bahiaasset.com.br, www.bradescobemdtvm.com.br ou www.intrag.com.br
COPYRIGHT © 2025 - TODOS OS DIREITOS RESERVADOS
CLIQUE AQUI
FEV
2026
¹ A rentabilidade apresentada tem como marco, o início da estratégia atualmente adotada pelo Fundo em 28/12/2012, quando teve início o Bahia AM Maraú FIF CIC Mult RL. Entretanto 
a data de início do Bahia AM FIF CIC Mult RL é 30/05/2008. | O Bahia AM Mutá FIF CIC Mult RL alterou a sua classiﬁcação Anbima de Multimercado Livre para Multimercado Macro em 
06/02/2023. | PL Médio corresponde à média aritmética do PL mensal dos últimos 12 meses. PL Estratégia corresponde à soma dos PLs dos fundos geridos pelas empresas do Bahia 
Asset, agrupados pelo mesmo tipo de estratégia. Para conhecer as estratégias e os fundos que as compõem, entre em contato com bahiaasset@bahiaasset.com.br. | Taxa de 
Administração Global (considerando as taxas de administração global do fundo e dos fundos investidos) / Taxa de Administração Máxima (considerando a taxa de administração global 
do fundo e as máximas dos fundos investidos): Bahia AM FIF CIC Mult RL: 1,5%/1,7% a.a.; Bahia AM Mutá FIF CIC Mult RL, Bahia AM Maraú FIF CIC Mult RL, Bahia AM Valuation FIF CIC 
Ações RL, Bahia AM Long Biased FIF CIC Mult RL, Bahia AM Una EH FIF CI Mult RL: 2,0%/2,2% a.a.; Bahia AM FI RF Referenciado DI: 0,2%/0,25% a.a.; Bahia AM Prev Guará FIFE FIF Mult 
RL: 0,7%/0,7% a.a.; Bahia AM A Prev Ativo FIF CIC RF LP RL: 0,8%/0,9% a.a.; Bahia AM Prev FIFE Ativo FIF RF LP RL: 0,9% a.a. | Taxa de Performance: 20% sobre o que exceder 100% do 
benchmark do fundo: Bahia AM Mutá FIF CIC Mult RL, Bahia AM Maraú FIF CIC Mult RL, Bahia AM FIF CIC Mult RL, Bahia AM Una EH FIF CI Mult RL, Bahia AM A Prev Ativo FIF CIC RF 
LP RL e Bahia AM Prev FIFE Ativo FIF RF LP RL: CDI; Bahia AM Prev Guará FIFE FIF Mult RL: CDI+1% a.a.; Bahia AM Valuation FIF CIC Ações RL: Ibovespa; Bahia AM Long Biased FIF CIC 
Mult RL: IPCA+6% a.a.  Investidores qualiﬁcados: Bahia AM Mutá FIF CIC Mult RL e Bahia AM Una EH FIF CI Mult RL. Todos os demais fundos são para Investidores em geral.
A Bahia AM Renda Fixa Ltda. e a Bahia AM Renda Variável Ltda. não comercializam nem distribuem cotas de fundos de investimento ou qualquer outro ativo ﬁnanceiro. | LEIA A LÂMINA DE INFORMAÇÕES ESSENCIAIS, 
SE HOUVER, O REGULAMENTO, O ANEXO-CLASSE E O APÊNDICE SUBCLASSE, CONFORME O CASO, ANTES DE INVESTIR. A RENTABILIDADE OBTIDA NO PASSADO NÃO REPRESENTA GARANTIA DE RESULTADOS 
FUTUROS. A RENTABILIDADE DIVULGADA NÃO É LÍQUIDA DE IMPOSTOS E, SE FOR O CASO, DE TAXA DE SAÍDA. FUNDOS DE INVESTIMENTO NÃO CONTAM COM GARANTIA DO ADMINISTRADOR, DO GESTOR, DE 
QUALQUER MECANISMO DE SEGURO OU FUNDO GARANTIDOR DE CRÉDITOS - FGC. | Para consultar as demais taxas (gestão, distribuição e/ou taxa de saída, conforme o caso), além de informações como classiﬁcação 
ANBIMA, descrição do objetivo e/ou estratégia, tributação aplicável e documentação dos Fundos, acesse o site do administrador e/ou  www.bahiaasset.com.br/documentos-de-fundos. I Administradora: BEM DTVM Ltda., 
CNPJ: 00.066.670/0001-00, Tel: (11) 3684-9432, www.bradescobemdtvm.com.br, SAC: centralbemdtvm@bradesco.com.br ou 0800 704 8383, Ouvidoria: 0800 727 9933. Administradora: Intrag DTVM Ltda., CNPJ: 
62.418.140/0001-31, Caixa Postal: 03162-971, Tel: (11) 3072-6109, www.intrag.com.br, SAC Itaú: 0800 728 0728, Ouvidoria: 0800 570 0011.
Rentabilidade
dos Fundos
 PL Atual (R$)  
Início
 PL Médio (R$) 
 Status 
MULTIMERCADOS MACRO
Fev/26
2026
2025
Últ. 12 
meses
Desde o 
Início
PL Estratégia
(R$)¹
Bahia AM Mutá FIF CIC Mult RL
1,62%
4,71%
18,65%
22,02%
193,07%
153.882.920
      
2,3 bi
31/05/17
% CDI
163%
217%
130%
150%
177%
127.020.310
          
Aberto
Bahia AM Maraú FIF CIC Mult RL
1,28%
3,41%
15,58%
17,50%
334,42%
282.221.395
      
2,3 bi
28/12/12
% CDI
129%
157%
109%
119%
140%
294.710.143
         
Aberto
Bahia AM FIF CIC Mult RL
1,16%
2,89%
14,44%
15,74%
254,04%
5.518.696
          
2,3 bi
28/12/12²
% CDI
116%
133%
101%
107%
107%
10.852.819
            
Aberto
 PL Atual (R$) 
 Início 
 PL Médio (R$) 
 Status 
MULTIMERCADOS L&S / LB
Fev/26
2026
2025
Últ. 12 
meses
Desde o 
Início
PL Estratégia 
(R$)¹
Bahia AM Una EH FIF CI Mult RL
1,49%
1,53%
-
-
14,32%
47.008.443
      
101,9 mi
30/06/25
% CDI
150%
70%
-
-
147%
36.179.216
            
Aberto
Bahia AM Long Biased FIF CIC Mult RL
3,26%
8,09%
35,81%
40,72%
199,90%
49.854.790
       
101,9 mi
30/12/15
diferencial do IPCA + 6%
2,22%
6,22%
25,27%
30,50%
-0,27%
43.111.670
            
Aberto
 PL Atual (R$) 
 Início 
 PL Médio (R$) 
 Status 
RENDA VARIÁVEL
Fev/26
2026
2025
Últ. 12 
meses
Desde o 
Início
PL Estratégia 
(R$)¹
Bahia AM Valuation FIF CIC Ações RL*
4,53%
16,12%
47,20%
61,87%
347,48%
218.222.839
      
640,2 mi
26/07/10
diferencial do IBOVESPA
0,43%
-1,04%
13,25%
12,01%
163,35%
174.683.031
         
Aberto
 PL Atual (R$) 
 Início 
 PL Médio (R$) 
 Status 
Últ. 12 
meses
Desde o 
Início
 PL Estratégia 
(R$)¹ 
PREVIDÊNCIA
Fev/26
2026
2025
XP | Bahia AM Prev FIFE FI RF Ativo LP
1,30%
3,07%
14,53%
15,97%
48,80%
10.321.897
        
35,4 mi
24/10/22
% CDI
131%
141%
102%
109%
98%
7.731.395
              
Aberto
ITAÚ | Bahia AM A Prev Ativo FIF CIC RF LP RL
1,45%
3,55%
14,56%
16,53%
26,41%
25.076.534
       
35,4 mi
28/05/24
% CDI
145%
163%
102%
113%
109%
12.306.028
           
Aberto
BB | Bahia AM Prev Guará FIFE FIF Mult RL
1,41%
3,70%
15,77%
18,16%
20,68%
51.841.733
         
51,8 mi
29/11/24
% CDI
141%
170%
110%
124%
116%
59.245.712
           
Aberto
 PL Atual (R$) 
 Início 
 PL Médio (R$) 
 Status 
RENDA FIXA
Fev/26
2026
2025
Últ. 12 
meses
Desde o 
Início
 PL Estratégia 
(R$)¹ 
Bahia AM Referenciado DI FIF CI RF Ref DI RL*
0,99%
2,16%
14,11%
14,46%
560,64%
106.652.649
      
106,7 mi
13/02/06
% CDI
99%
100%
99%
99%
94%
139.889.247
         
Aberto
Últ. 12 
meses
INDICADORES
Fev/26
2026
2025
CDI
1,00%
2,17%
14,31%
14,67%
IBOVESPA
4,09%
17,17%
33,95%
49,86%
IPCA + 6%
1,04%
1,87%
10,54%
10,22%
*Clientes institucionais: o fundo observa, no que lhe é aplicável, as Resoluções das EFPCs e RPPSs.