

---

Fonte: Bahia Asset Management | Data: 01/2026
Fonte: Bahia Asset Management | Data: 01/2026
PREÇO DO OURO | US$ POR ONÇA
Comentários do Gestor
COPYRIGHT © 2025 - TODOS OS DIREITOS RESERVADOS
Carta
do Gestor
O mês de janeiro foi marcado por maior volatilidade 
nos preços de commodities e de ativos de risco, em 
meio à intensiﬁcação de tensões geopolíticas 
protagonizadas pelos Estados Unidos. Após a ampla 
repercussão internacional da repressão violenta do 
Irã a protestos civis, o presidente norte-americano 
promoveu o envio de militares para a região e passou 
a ameaçar intervenções no país, condicionando a 
desescalada 
ao 
apaziguamento 
dos 
conﬂitos 
internos e à negociação de um novo acordo nuclear. 
Adicionalmente, o governo dos EUA endureceu o 
discurso em torno da necessidade de controle da 
Groenlândia por razões de segurança nacional e 
sinalizou a possibilidade de elevação tarifária contra 
países europeus que participaram de exercícios 
militares no território, incluindo membros da OTAN. 
Após a Conferência de Davos, os líderes envolvidos 
anunciaram um “framework” para um acordo futuro, 
prevendo 
a 
ampliação 
da 
presença 
militar 
norte-americana e maior vigilância por parte da 
OTAN, sem contemplar transferência de soberania.
No plano de política monetária, o Departamento de 
Justiça dos EUA abriu uma investigação contra o 
presidente do Federal Reserve, sob a alegação de 
potencial má conduta na prestação de informações 
sobre o escopo das obras de renovação da instituição. 
Jerome Powell, que até então não havia se 
pronunciado diretamente sobre os ataques pessoais 
do 
presidente 
norte-americano, 
publicou 
um 
vídeo-resposta. Neste, declarou que o processo era 
um pretexto para intimidar a independência da 
instituição e suas decisões subsequentes. Além disso, 
Donald Trump anunciou a escolha de Kevin Warsh, 
ex-membro do FOMC, como próximo presidente do 
Fed. A escolha minimizou preocupações quanto à 
politização do órgão autônomo. 
JAN
2026
PREÇO DO PETRÓLEO BRENT | US$ POR BARRIL
3000
3500
4000
4500
5000
5500
jul-25
set-25
nov-25
jan-26
55
60
65
70
75
jul-25
set-25
nov-25
jan-26

---

Comentários do Gestor
COPYRIGHT © 2025 - TODOS OS DIREITOS RESERVADOS
Nos Estados Unidos, a taxa de desemprego cedeu 
em dezembro, devolvendo parte da alta dos últimos 
meses. Já os demais indicadores do mercado de 
trabalho apresentaram sinais mistos na margem, 
oscilando 
entre 
estabilização 
e 
afrouxamento 
adicional. Do lado da atividade, estatísticas de 
consumo se mantiveram resilientes, a despeito da 
desaceleração da renda. Por último, a inﬂação de 
dezembro acelerou na margem, após dois números 
artiﬁcialmente fracos devido a problemas de coleta 
durante o “shutdown”. Nesse contexto, o Fed 
manteve 
a 
taxa 
básica 
de 
juros 
inalterada, 
reconhecendo a melhora do mercado de trabalho e 
aﬁrmando que esse já apresenta alguns sinais de 
estabilização.
Na Zona do Euro, a inﬂação seguiu próxima da meta, 
enquanto a atividade econômica e o mercado de 
trabalho continuaram resilientes, com os últimos 
dados indicando crescimento perto do potencial. As 
falas dos membros do ECB ecoaram o discurso de 
estarem “bem-posicionados” para responderem a 
eventuais choques, sem ajustes iminentes na taxa de 
juros em seu cenário central.
Na Ásia, os dados de dezembro da China mostraram 
persistência da fraqueza da atividade doméstica, em 
especial do consumo e do setor imobiliário. Em 
contraste, a produção industrial e as exportações 
continuaram 
resilientes. 
No 
Japão, 
a 
Primeira-Ministra Takaichi dissolveu o parlamento, 
convocando novas eleições, e anunciou a intenção de 
reduzir o imposto sobre alimentos por dois anos. A 
perspectiva de uma liderança mais forte e uma 
postura ﬁscal mais frouxa levou à má performance 
de alguns ativos japoneses, em especial da parte 
longa da curva de juros.
Na elaboração de nossas teses de investimentos, 
reconhecemos o elevado nível de incerteza em 
relação 
aos 
ciclos 
econômicos 
das 
principais 
economias globais. A agenda da administração 
Trump provavelmente ocasionará um rearranjo nas 
cadeias de suprimentos globais e até mesmo de 
alianças geopolíticas vigentes desde o pós-guerra. 
Dessa forma, a reação de cada banco central e 
governo é complexa e altamente incerta.  Nos 
Estados Unidos, o Fed está particularmente atento 
ao mercado de trabalho e ao impacto das tarifas na 
inﬂação. No bloco europeu, consideramos que a 
elevação considerável nos gastos ﬁscais, liderada 
pela Alemanha, deve ocupar o espaço para novos 
afrouxamentos monetários. Consideramos que os 
fatores externos que merecem maior atenção são: (i) 
a implementação e os impactos das políticas 
econômicas e geopolíticas do presidente Donald 
Trump; (ii) a postura dos bancos centrais em relação 
aos próximos passos da política monetária; (iii) a 
retomada da atividade e a evolução da inﬂação nos 
principais blocos econômicos, em particular do 
mercado 
de 
trabalho 
norte-americano; 
(iv) 
a 
atividade na China e novas medidas de estímulo que 
possam vir a ser adotadas no país.
JAN
2026

---

Comentários do Gestor
COPYRIGHT © 2025 - TODOS OS DIREITOS RESERVADOS
No 
Brasil, 
pesquisas 
eleitorais 
mais 
recentes 
reiteraram a competitividade de Flávio Bolsonaro. 
Ainda no cenário político, o ministro Fernando 
Haddad sugeriu a indicação de Guilherme Mello para 
a diretoria do Banco Central, movimento que foi 
interpretado como tentativa de o governo conseguir 
mais inﬂuência sobre o Comitê. 
Quanto aos indicadores econômicos, a PNAD de 
dezembro surpreendeu positivamente pelo segundo 
mês consecutivo, com queda da taxa de desemprego 
e aceleração dos salários na margem, em contraste 
com a geração de vagas mais fraca observada no 
CAGED. Do lado da inﬂação, o dado mais recente 
apresentou ligeira surpresa baixista, com composição 
melhor. Diante desse cenário, o COPOM sinalizou que, 
caso seu cenário central se concretize, irá iniciar um 
ciclo de cortes de juros já na reunião de março. Na 
comunicação, reforçou a intenção de manter a 
política monetária em nível suﬁcientemente restritivo 
para assegurar a convergência da inﬂação à meta, 
indicando 
“serenidade” 
quanto 
ao 
ritmo 
e 
à 
magnitude do ciclo.
No Brasil, estamos especialmente atentos: (i) à 
trajetória da inﬂação corrente, em especial ao núcleo 
de inﬂação subjacente de serviços; (ii) às expectativas 
de inﬂação; (iii) às discussões fiscais e parafiscais; (iv) à 
velocidade da desaceleração da atividade e ao 
comportamento do emprego e salários; e (v) às 
discussões e pesquisas referentes às eleições deste 
ano.
JAN
2026

---

Multimercados 
Macro
No mês, os principais ganhos vieram de posições 
tomadas na inclinação de juros reais e aplicadas no 
juro nominal, na posição comprada em ouro e em 
moedas, compradas no real brasileiro contra o peso 
mexicano e no dólar australiano contra o euro. Nas 
estratégias de bolsa e crédito, os ganhos vieram de 
posições compradas em bolsa norte-americana e 
vendidas em proteção CDX High Yield. As perdas 
vieram 
de 
posições 
aplicadas 
no 
juro 
curto 
norte-americano e no juro sul-africano, bem como 
em posições vendidas em petróleo. 
Estratégias e Atribuição de Resultados
COPYRIGHT © 2025 - TODOS OS DIREITOS RESERVADOS
No Brasil, mantivemos posições aplicadas em juros 
nominais e reais; e tomadas na inclinação de juros 
reais. Em commodities, temos posições compradas 
em ouro; e em bolsa, estamos comprados na bolsa 
norte-americana 
e 
brasileira. 
No 
mercado 
internacional, temos posições aplicadas no México 
contra os EUA, na África do Sul contra os EUA e 
vendidos em proteção do crédito High Yield.
JAN
20226
MARAÚ
12 MESES
JAN/26
Juros
2,6%
0,7%
Moedas
1,5%
0,1%
Crédito Soberano e Índices
0,1%
0,04%
Commodities
1,3%
0,29%
Bolsa
-0,6%
0,04%
Total Operações
4,9%
1,1%
CDI / Txs / Custos
12,2%
1,0%
Maraú
17,1%
2,1%
%CDI
118%
180%
MUTÁ
12 MESES
JAN/26
Juros
5,3%
1,3%
Moedas
3,0%
0,2%
Crédito Soberano e Índices
0,2%
0,1%
Commodities
2,6%
0,6%
Bolsa
-1,2%
0,1%
Total Operações
9,9%
2,2%
CDI / Txs / Custos
11,5%
0,8%
Mutá
21,4%
3,0%
%CDI
147%
261%
BAHIA
12 MESES
JAN/26
Juros
1,6%
0,4%
Moedas
0,9%
0,1%
Crédito Soberano e Índices
0,1%
0,0%
Commodities
0,8%
0,2%
Bolsa
-0,3%
0,0%
Total Operações
3,0%
0,7%
CDI / Txs / Custos
12,5%
1,0%
Bahia
15,4%
1,7%
%CDI
106%
147%

---

COPYRIGHT © 2025 - TODOS OS DIREITOS RESERVADOS
Multimercados L&S | LB 
e Renda Variável
Comentários do Gestor
Exposição das Carteiras
Contribuições Positivas
--  Mantivemos uma carteira diversiﬁcada ao longo do 
mês com uma média de 25 papéis.  
--  A posição média comprada nos fundos long only 
foi de 97% e no fundo Long Biased foi de 56%.
-- As maiores posições compradas estão hoje nos 
setores de bancos, elétrico e imobiliário.
As maiores contribuições positivas vieram do setor 
de Óleo e Gás. Prio acompanhou a performance do 
petróleo nos mercados internacionais além de seguir 
com uma boa recuperação nos números de 
produção e boas perspectivas para antecipação do 
campo de Wahoo. 
O ano teve início marcado por uma sequência de 
desdobramentos 
geopolíticos 
liderados 
pelos 
Estados Unidos. A captura de Nicolás Maduro, as 
tensões em torno da Groenlândia e o conﬂito no Irã 
dominaram o noticiário ao longo do mês. Em termos 
de performance, o destaque ﬁcou com os mercados 
emergentes, 
cujo 
comportamento 
tem 
sido 
fortemente inﬂuenciado pelo ﬂuxo de capital 
estrangeiro. Segundo estudo do JP Morgan, nas 
últimas 13 semanas, a entrada de recursos em países 
emergentes já supera US$ 50 bilhões. No Brasil, o 
movimento não foi diferente e, como novidade 
relevante no cenário doméstico, o Banco Central 
sinalizou a intenção de iniciar o processo de 
ﬂexibilização do aperto monetário já na próxima 
reunião do COPOM, em março.
Em relação às commodities, o petróleo teve um mês 
positivo, subindo perto de 16% nos mercados 
internacionais. O minério de ferro e as cotações de 
aço fecharam ao redor de 1% de queda. O ouro subiu 
15%. A celulose foi negativa em 3% no mercado 
chinês futuro. Nas agrícolas, o açúcar terminou o 
mês em queda de 5%, o milho caiu 3% e a soja subiu 
2%.
2026
JAN
Contribuições Negativas
As contribuições negativas ﬁcaram concentradas no 
setor de Consumo e Imobiliário. Smart Fit teve uma 
performance negativa com piores perspectivas para 
a margem bruta das lojas maduras em 2026. Não 
houve notícias idiossincráticas no setor imobiliário, 
apesar de sua má performance.

---

ACOMPANHE NOSSAS REDES 
E RECEBA CONTEÚDOS EXCLUSIVOS
ACESSE O NOSSO SITE
WWW.BAHIAASSET.COM.BR
Para demais documentos e informações dos fundos acesse www.bahiaasset.com.br, www.bradescobemdtvm.com.br ou www.intrag.com.br
COPYRIGHT © 2025 - TODOS OS DIREITOS RESERVADOS
CLIQUE AQUI
JAN
2026
¹ A rentabilidade apresentada tem como marco, o início da estratégia atualmente adotada pelo Fundo em 28/12/2012, quando teve início o Bahia AM Maraú FIF CIC Mult RL. Entretanto a 
data de início do Bahia AM FIF CIC Mult RL é 30/05/2008. | O Bahia AM Mutá FIF CIC Mult RL alterou a sua classiﬁcação Anbima de Multimercado Livre para Multimercado Macro em 
06/02/2023. | PL Médio corresponde à média aritmética do PL mensal dos últimos 12 meses. PL Estratégia corresponde à soma dos PLs dos fundos geridos pelas empresas do Bahia Asset, 
agrupados pelo mesmo tipo de estratégia. Para conhecer as estratégias e os fundos que as compõem, entre em contato com bahiaasset@bahiaasset.com.br. | Taxa de Administração 
Global (considerando as taxas de administração global do fundo e dos fundos investidos) / Taxa de Administração Máxima (considerando a taxa de administração global do fundo e as 
máximas dos fundos investidos): Bahia AM FIF CIC Mult RL: 1,5%/1,7% a.a.; Bahia AM Mutá FIF CIC Mult RL, Bahia AM Maraú FIF CIC Mult RL, Bahia AM Valuation FIF CIC Ações RL, Bahia AM 
Long Biased FIF CIC Mult RL, Bahia AM Una EH FIF CI Mult RL: 2,0%/2,2% a.a.; Bahia AM FI RF Referenciado DI: 0,2%/0,25% a.a.; Bahia AM Prev Guará FIFE FIF Mult RL: 0,7%/0,7% a.a.; Bahia 
AM A Prev Ativo FIF CIC RF LP RL: 0,8%/0,9% a.a.; Bahia AM Prev FIFE Ativo FIF RF LP RL: 0,9% a.a. | Taxa de Performance: 20% sobre o que exceder 100% do benchmark do fundo: Bahia AM 
Mutá FIF CIC Mult RL, Bahia AM Maraú FIF CIC Mult RL, Bahia AM FIF CIC Mult RL, Bahia AM Una EH FIF CI Mult RL, Bahia AM A Prev Ativo FIF CIC RF LP RL e Bahia AM Prev FIFE Ativo 
FIF RF LP RL: CDI; Bahia AM Prev Guará FIFE FIF Mult RL: CDI+1% a.a.; Bahia AM Valuation FIF CIC Ações RL: Ibovespa; Bahia AM Long Biased FIF CIC Mult RL: IPCA+6% a.a.  Investidores 
qualiﬁcados: Bahia AM Mutá FIF CIC Mult RL e Bahia AM Una EH FIF CI Mult RL. Todos os demais fundos são para Investidores em geral.
A Bahia AM Renda Fixa Ltda. e a Bahia AM Renda Variável Ltda. não comercializam nem distribuem cotas de fundos de investimento ou qualquer outro ativo ﬁnanceiro. | LEIA A LÂMINA DE INFORMAÇÕES ESSENCIAIS, SE 
HOUVER, O REGULAMENTO, O ANEXO-CLASSE E O APÊNDICE SUBCLASSE, CONFORME O CASO, ANTES DE INVESTIR. A RENTABILIDADE OBTIDA NO PASSADO NÃO REPRESENTA GARANTIA DE RESULTADOS 
FUTUROS. A RENTABILIDADE DIVULGADA NÃO É LÍQUIDA DE IMPOSTOS E, SE FOR O CASO, DE TAXA DE SAÍDA. FUNDOS DE INVESTIMENTO NÃO CONTAM COM GARANTIA DO ADMINISTRADOR, DO GESTOR, DE 
QUALQUER MECANISMO DE SEGURO OU FUNDO GARANTIDOR DE CRÉDITOS - FGC. | Para consultar as demais taxas (gestão, distribuição e/ou taxa de saída, conforme o caso), além de informações como classiﬁcação 
ANBIMA, descrição do objetivo e/ou estratégia, tributação aplicável e documentação dos Fundos, acesse o site do administrador e/ou  www.bahiaasset.com.br/documentos-de-fundos. I Administradora: BEM DTVM Ltda., 
CNPJ: 00.066.670/0001-00, Tel: (11) 3684-9432, www.bradescobemdtvm.com.br, SAC: centralbemdtvm@bradesco.com.br ou 0800 704 8383, Ouvidoria: 0800 727 9933. Administradora: Intrag DTVM Ltda., CNPJ: 
62.418.140/0001-31, Caixa Postal: 03162-971, Tel: (11) 3072-6109, www.intrag.com.br, SAC Itaú: 0800 728 0728, Ouvidoria: 0800 570 0011.
 PL Atual (R$)  
Início
 PL Médio (R$)¹ 
 Status 
MULTIMERCADOS MACRO
Dez/25
2025
2024
Últ. 12 
meses
Desde o 
Início
PL Estratégia
(R$)²
 PL Atual (R$) 
 Início 
 PL Médio (R$)¹ 
 Status 
MULTIMERCADOS L&S / LB
Dez/25
2025
2024
Últ. 12 
meses
Desde o 
Início
PL Estratégia 
(R$)²
Rentabilidade
dos Fundos
*Clientes institucionais: o fundo observa, no que lhe é aplicável, as Resoluções das EFPCs e RPPSs.
 PL Atual (R$)  
Início
 PL Médio (R$)¹ 
 Status 
MULTIMERCADOS MACRO
Jan/26
2026
2025
Últ. 12 
meses
Desde o 
Início
PL Estratégia
(R$)²
Bahia AM Mutá FIF CIC Mult RL
3,04%
3,04%
18,65%
21,44%
188,39%
150.978.705
      
2,3 bi
31/05/17
% CDI
261%
261%
130%
147%
176%
124.496.260
         
Aberto
Bahia AM Maraú FIF CIC Mult RL
2,10%
2,10%
15,58%
17,11%
328,91%
278.607.071
     
2,3 bi
28/12/12
% CDI
180%
180%
109%
118%
140%
307.008.331
         
Aberto
Bahia AM FIF CIC Mult RL
1,71%
1,71%
14,44%
15,44%
249,99%
5.460.262
         
2,3 bi
28/12/12³
% CDI
147%
147%
101%
106%
106%
12.696.933
           
Aberto
 PL Atual (R$) 
 Início 
 PL Médio (R$)¹ 
 Status 
MULTIMERCADOS L&S / LB
Jan/26
2026
2025
Últ. 12 
meses
Desde o 
Início
PL Estratégia 
(R$)²
Bahia AM Una EH FIF CI Mult RL
0,03%
0,03%
-
-
12,64%
48.253.612
        
103,1 mi
30/06/25
% CDI
3%
3%
-
-
146%
34.825.563
           
Aberto
Bahia AM Long Biased FIF CIC Mult RL
4,67%
4,67%
35,81%
37,59%
190,43%
48.166.975
        
103,1 mi
30/12/15
diferencial do IPCA + 6%
3,86%
3,86%
25,27%
26,89%
-6,65%
42.186.099
           
Aberto
 PL Atual (R$) 
 Início 
 PL Médio (R$)¹ 
 Status 
RENDA VARIÁVEL
Jan/26
2026
2025
Últ. 12 
meses
Desde o 
Início
PL Estratégia 
(R$)²
Bahia AM Valuation FIF CIC Ações RL*
11,10%
11,10%
47,20%
54,07%
328,10%
205.590.276
     
619,9 mi
26/07/10
diferencial do IBOVESPA
-1,47%
-1,47%
13,25%
11,16%
155,14%
168.392.211
           
Aberto
 PL Atual (R$) 
 Início 
 PL Médio (R$)¹ 
 Status 
Últ. 12 
meses
Desde o 
Início
 PL Estratégia 
(R$)² 
PREVIDÊNCIA
Jan/26
2026
2025
XP | Bahia AM Prev FIFE FI RF Ativo LP
1,74%
1,74%
14,53%
15,65%
46,89%
10.126.980
        
33,4 mi
24/10/22
% CDI
150%
150%
102%
108%
97%
7.268.448
            
Aberto
ITAÚ | Bahia AM A Prev Ativo FIF CIC RF LP RL
2,07%
2,07%
14,56%
16,17%
24,61%
23.248.802
       
33,4 mi
28/05/24
% CDI
178%
178%
102%
111%
107%
10.502.867
           
Aberto
BB | Bahia AM Prev Guará FIFE FIF Mult RL
2,26%
2,26%
15,77%
17,55%
19,01%
51.369.967
        
51,4 mi
29/11/24
% CDI
194%
194%
110%
121%
114%
60.192.334
           
Aberto
 PL Atual (R$) 
 Início 
 PL Médio (R$)¹ 
 Status 
RENDA FIXA
Jan/26
2026
2025
Últ. 12 
meses
Desde o 
Início
 PL Estratégia 
(R$)² 
Bahia AM Referenciado DI FIF CI RF Ref DI RL*
1,17%
1,17%
14,11%
14,32%
554,18%
106.899.511
       
106,9 mi
13/02/06
% CDI
100%
100%
99%
98%
94%
138.451.868
         
Aberto
Últ. 12 
meses
INDICADORES
Jan/26
2026
2025
CDI
1,16%
1,16%
14,31%
14,54%
IBOVESPA
12,56%
12,56%
33,95%
42,90%
IPCA + 6%
0,82%
0,82%
10,54%
10,71%