

---

Fonte: Bahia Asset Management | Data: 05/2026
Fonte: Bahia Asset Management | Data: 05/2026
PREÇO DO PETRÓLEO BRENT | US$ POR BARRIL
Comentários do Gestor
COPYRIGHT © 2025 - TODOS OS DIREITOS RESERVADOS
Carta
do Gestor
O mês de abril foi marcado pela boa performance de 
ativos de risco e elevada volatilidade dos preços do 
petróleo e das curvas de juros globais em meio à 
guerra no Oriente Médio. No início do mês, foi 
negociado um cessar-fogo entre Estados Unidos e 
Irã. Contudo, até o momento, as lideranças nacionais 
não encontraram consenso para uma resolução 
deﬁnitiva do conﬂito, tendo a questão nuclear como 
principal impasse. Como instrumento de barganha, 
as forças armadas americanas instalaram um 
bloqueio naval no Estreito de Ormuz direcionado a 
navios iranianos com o objetivo de afetar o país 
economicamente. 
Em 
resposta, 
o 
Irã 
está 
ameaçando atacar navios de outras nacionalidades 
que tentem cruzar a região, congelando o ﬂuxo no 
Estreito. As negociações continuam em andamento, 
mediadas pelo Paquistão.
Entre os indicadores econômicos norte-americanos, 
a geração de empregos apresentou alta signiﬁcativa 
em março, em parte devido à devolução de impactos 
de greves e do clima, enquanto a taxa de 
desemprego voltou a cair. Além disso, a demanda 
doméstica 
do 
primeiro 
trimestre 
surpreendeu 
positivamente, puxada pela forte expansão de 
investimentos em máquinas e equipamentos e por 
um consumo das famílias ainda robusto. Do lado da 
inﬂação, o núcleo do PCE, principal indicador de 
preços acompanhado pelo Federal Reserve, se 
manteve elevado na margem.
Nesse contexto, o banco central americano, frente à 
incerteza posta pelas tensões geopolíticas, manteve 
posição cautelosa, enfatizando riscos para ambos os 
lados do mandato (desemprego e inﬂação). A 
decisão veio acompanhada de três dissidências, que 
prefeririam ter retirado o viés de afrouxamento de 
ABR
2026
ÍNDICE S&P 500
55
65
75
85
95
105
115
125
jan-26
fev-26
mar-26
abr-26
mai-26
6.300
6.500
6.700
6.900
7.100
7.300
jan-26
fev-26
mar-26
abr-26
mai-26

---

Comentários do Gestor
COPYRIGHT © 2025 - TODOS OS DIREITOS RESERVADOS
juros do forward-guidance. Em sua última coletiva de 
imprensa como presidente do FOMC, Jerome Powell 
sinalizou que o centro do Comitê estava caminhando 
para uma postura mais neutra em relação aos 
próximos passos de política monetária. Ademais, 
Powell anunciou que não deixará o quadro de 
membros do Comitê de Política Monetária após a 
posse de Kevin Warsh, a despeito do arquivamento 
pelo Departamento do Justiça do processo em que 
era réu. 
Na Zona do Euro, o ECB mostrou desconforto 
crescente com a piora dos riscos altistas para a 
inﬂação, sinalizando prontidão para reagir já em 
junho caso não haja melhora do cenário geopolítico. 
No mês, as expectativas de inﬂação das famílias se 
elevaram, ao passo que as projeções de analistas se 
mantiveram ancoradas em horizontes mais longos.
Na China, o PIB surpreendeu positivamente, não 
obstante a grande diferença entre a performance 
dos setores. Enquanto exportações e produção 
industrial seguem ﬁrmes, indicadores ligados à 
demanda doméstica privada mostram debilidade. 
No campo político, a comunicação do Politburo 
sugeriu pouca urgência para qualquer estímulo.
No Brasil, pesquisas eleitorais continuam apontando 
para empate técnico no segundo turno entre Flávio 
Bolsonaro e Lula, com deterioração da aprovação do 
governo. Os indicadores econômicos reﬂetiram 
melhora da atividade no início do ano, com resiliência 
do consumo de itens ligados à renda. Do lado da 
inﬂação, núcleos de comercializáveis têm vindo mais 
elevados que o esperado, a despeito do contexto de 
apreciação cambial recente. 
Em sua última reunião, o Copom seguiu afrouxando 
a política monetária com um corte de 25 bps na taxa 
básica, reconhecendo a piora de riscos em relação à 
guerra e a deterioração das expectativas de inﬂação 
mais longas da pesquisa Focus. A comunicação 
sinalizou que o ciclo de cortes continuará, ainda que 
possivelmente com extensão menor do que a 
antecipada pelos analistas.
Na formulação de nossas teses de investimento, 
partimos do reconhecimento de um ambiente 
global marcado por elevada incerteza, tanto em 
relação ao estágio dos ciclos econômicos nas 
principais economias quanto à evolução das tensões 
geopolíticas. 
A 
agenda 
da 
administração 
norte-americana provavelmente ocasionará um 
rearranjo nas cadeias de suprimentos e até mesmo 
de alianças vigentes desde o pós-guerra. Dessa 
forma, a reação de cada banco central e governo é 
complexa e altamente incerta. Consideramos que os 
fatores externos que merecem maior atenção são: (i) 
a duração e as cicatrizes econômicas decorrentes do 
conﬂito no Oriente Médio; (ii) a implementação e os 
impactos das políticas econômicas e geopolíticas do 
governo Trump; (iii) a postura dos bancos centrais 
diante deste ambiente; (iv) as consequências na 
atividade e a evolução da inﬂação nos principais 
blocos econômicos; (v) a atividade na China e novas 
medidas de estímulo que possam vir a ser adotadas 
no país.
No Brasil, estamos especialmente atentos: (i) aos 
impactos do conﬂito geopolítico e suas implicações 
para a trajetória da inﬂação corrente e para as 
expectativas de inﬂação; (ii) às discussões ﬁscais e 
paraﬁscais; (iii) à velocidade da desaceleração da 
atividade, ao comportamento de emprego e de 
salários; e (iv) às discussões e pesquisas referentes às 
eleições deste ano.
ABR
2026

---

Multimercados 
Macro
Principais ganhos do mês:
--  Posições relativas na curva de juros reais brasileira;
--  Comprado na inﬂação curta brasileira; e
--  Comprado no real contra uma cesta de moedas.
Principais perdas:
--  Aplicado em juros nominais (BR e emergentes);
--  Comprado em ouro; e
--  Comprado no Ibovespa.
Estratégias e Atribuição de Resultados
COPYRIGHT © 2025 - TODOS OS DIREITOS RESERVADOS
Posições Brasil:
--  Aplicado em juros nominais e reais;
--  Posições relativas na curva de juros reais;
--  Vendido em inﬂação; e
--  Comprado no Ibovespa e posções relativas em 
ações.
Posições Internacionais:
--  Comprado no dólar australiano contra o euro; e
--  Comprado em ouro.
ABR
20226
MARAÚ
12 MESES
ABR/26
Juros On
-0,7%
0,0%
Juros Off
-0,7%
-0,1%
Moedas
1,1%
0,2%
Commodities
0,9%
-0,1%
Bolsa
-0,3%
-0,1%
Total Operações
0,4%
-0,1%
CDI / Txs / Custos
12,3%
0,9%
Maraú
12,7%
0,8%
%CDI
85,5%
76,4%
MUTÁ
12 MESES
ABR/26
Juros On
-1,3%
0,0%
Juros Off
-1,4%
-0,2%
Moedas
2,2%
0,3%
Commodities
1,8%
-0,2%
Bolsa
-0,6%
-0,1%
Total Operações
0,7%
-0,1%
CDI / Txs / Custos
11,9%
0,9%
Mutá
12,6%
0,7%
%CDI
85,1%
65,8%
BAHIA
12 MESES
ABR/26
Juros On
-0,3%
0,0%
Juros Off
-0,4%
-0,1%
Moedas
0,7%
0,1%
Commodities
0,5%
0,0%
Bolsa
-0,1%
0,0%
Total Operações
0,3%
0,0%
CDI / Txs / Custos
12,6%
0,9%
Bahia
12,9%
0,9%
%CDI
87,2%
85,2%

---

COPYRIGHT © 2025 - TODOS OS DIREITOS RESERVADOS
Multimercados L&S | LB 
e Renda Variável
Comentários do Gestor
Exposição das Carteiras
Contribuições Positivas
--  Mantivemos uma carteira diversiﬁcada ao longo do 
mês com uma média de 28 papéis.  
--  A posição média comprada nos fundos long only 
foi de 95% e no fundo Long Biased foi de 60%.
-- As maiores posições compradas estão nos setores 
de Bancos, Commodities e Consumo Discricionário.
As maiores contribuições positivas vieram dos 
setores de Saúde e Commodities: 
-- A Bradesco Saúde teve uma forte alta no mês 
impulsionada por revisões de estimativas de lucro e 
recomendação de compra de uma séria de casas de 
análise;
-- Já em Commodities, Gerdau reportou resultado 
acima das expectativas, com margens de Brasil 
sendo o destaque positivo.
Abril foi um mês de alta volatilidade, novamente 
dominado pelo conﬂito no Oriente Médio e seus 
efeitos sobre os mercados globais. O Estreito de 
Ormuz 
permaneceu 
bloqueado 
ao 
longo 
de 
praticamente todo o mês, sustentando o preço do 
petróleo 
Brent 
acima 
de 
US$ 
100/barril 
e 
alimentando preocupações persistentes com a 
inﬂação 
global. 
O 
Ibovespa 
apresentou 
comportamentos distintos dentro do mês. Na 
primeira quinzena, impulsionado por forte ﬂuxo 
estrangeiro e pela expectativa de um acordo entre 
EUA e Irã, o índice chegou a ﬂertar com a marca 
inédita dos 200 mil pontos. Na segunda metade do 
mês, a persistência das indeﬁnições geopolíticas e a 
alta do preço do petróleo reverteram o otimismo. No 
fronte monetário, o Copom reduziu a Selic para 
14,50% ao ano, em corte de 25 bps amplamente 
esperado pelo mercado, mas acompanhado de 
comunicado com tom cauteloso diante das pressões 
inﬂacionárias ligadas ao preço do petróleo.
Em relação as commodities, o destaque ﬁcou 
novamente para o petróleo subindo 15% nos 
mercados 
internacionais. 
O 
minério 
de 
ferro 
terminou em alta de 2% e as cotações de aço 
fecharam entre 2% e 4% de alta. O ouro caiu 1%. A 
celulose caiu 2% no mercado chinês futuro. Nas 
agrícolas, o açúcar caiu 7% enquanto o milho e a soja 
subiram 1%. 
O Ibovespa caiu 0,1% e o índice de Small Caps foi 
negativo em 3,2%. Por sua vez, a rentabilidades dos 
fundos no mês foram:
--  Bahia AM Valuation: 0,8%;
--  Bahia AM Long Biased: 2,9%;
--  Bahia AM Una Equity Hedge: 3,5%.
2026
ABR
Contribuições Negativas
As contribuições negativas ﬁcaram concentradas no 
setor Imobiliário:
-- A piora no ambiente inﬂacionário, a variação acima 
do esperado do INCC de abril e o feedback das 
empresas sobre preocupação com alta no preço dos 
materiais de construção ﬁzeram com que as 
incorporadoras de baixa renda devolvessem uma 
parte da alta do ano.

---

ACOMPANHE NOSSAS REDES 
E RECEBA CONTEÚDOS EXCLUSIVOS
ACESSE O NOSSO SITE
WWW.BAHIAASSET.COM.BR
Para demais documentos e informações dos fundos acesse www.bahiaasset.com.br, www.bradescobemdtvm.com.br ou www.intrag.com.br
COPYRIGHT © 2025 - TODOS OS DIREITOS RESERVADOS
CLIQUE AQUI
ABR
2026
¹ A rentabilidade apresentada tem como marco, o início da estratégia atualmente adotada pelo Fundo em 28/12/2012, quando teve início o Bahia AM Maraú FIF CIC Mult RL. Entretanto a data de início do 
Bahia AM FIF CIC Mult RL é 30/05/2008. | ² Até 19/03/2026, o BAHIA AM UNA EH FIF CI Mult RL operava como classe única. Em 20/03/2026, foi constituída a Subclasse Condominial e o PL indicado reﬂete 
exclusivamente esta subclasse. | O Bahia AM Mutá FIF CIC Mult RL alterou a sua classiﬁcação Anbima de Multimercado Livre para Multimercado Macro em 06/02/2023. | PL Médio corresponde à média 
aritmética do PL mensal dos últimos 12 meses. PL Estratégia corresponde à soma dos PLs dos fundos geridos pelas empresas do Bahia Asset, agrupados pelo mesmo tipo de estratégia. Para conhecer as 
estratégias e os fundos que as compõem, entre em contato com bahiaasset@bahiaasset.com.br. | Taxa de Administração Global (considerando as taxas de administração global do fundo e dos fundos 
investidos) / Taxa de Administração Máxima (considerando a taxa de administração global do fundo e as máximas dos fundos investidos): Bahia AM FIF CIC Mult RL: 1,5%/1,7% a.a.; Bahia AM Mutá FIF CIC 
Mult RL, Bahia AM Maraú FIF CIC Mult RL, Bahia AM Valuation FIF CIC Ações RL, Bahia AM Long Biased FIF CIC Mult RL, Bahia AM Una EH FIF CI Mult RL: 2,0%/2,2% a.a.; Bahia AM FI RF Referenciado DI: 
0,2%/0,25% a.a.; Bahia AM Prev Guará FIFE FIF Mult RL: 0,7%/0,7% a.a.; Bahia AM A Prev Ativo FIF CIC RF LP RL: 0,8%/0,9% a.a.; Bahia AM Prev FIFE Ativo FIF RF LP RL: 0,9% a.a. | Taxa de Performance: 20% 
sobre o que exceder 100% do benchmark do fundo: Bahia AM Mutá FIF CIC Mult RL, Bahia AM Maraú FIF CIC Mult RL, Bahia AM FIF CIC Mult RL, Bahia AM Una EH FIF CI Mult RL, Bahia AM A Prev Ativo FIF 
CIC RF LP RL e Bahia AM Prev FIFE Ativo FIF RF LP RL: CDI; Bahia AM Prev Guará FIFE FIF Mult RL: CDI+1% a.a.; Bahia AM Valuation FIF CIC Ações RL: Ibovespa; Bahia AM Long Biased FIF CIC Mult RL: 
IPCA+6% a.a.  Investidores qualiﬁcados: Bahia AM Mutá FIF CIC Mult RL e Bahia AM Una EH FIF CI Mult RL. Todos os demais fundos são para Investidores em geral.
A Bahia AM Renda Fixa Ltda. e a Bahia AM Renda Variável Ltda. não comercializam nem distribuem cotas de fundos de investimento ou qualquer outro ativo ﬁnanceiro. | LEIA A LÂMINA DE INFORMAÇÕES ESSENCIAIS, SE HOUVER, O 
REGULAMENTO, O ANEXO-CLASSE E O APÊNDICE SUBCLASSE, CONFORME O CASO, ANTES DE INVESTIR. A RENTABILIDADE OBTIDA NO PASSADO NÃO REPRESENTA GARANTIA DE RESULTADOS FUTUROS. A RENTABILIDADE DIVULGADA 
NÃO É LÍQUIDA DE IMPOSTOS E, SE FOR O CASO, DE TAXA DE SAÍDA. FUNDOS DE INVESTIMENTO NÃO CONTAM COM GARANTIA DO ADMINISTRADOR, DO GESTOR, DE QUALQUER MECANISMO DE SEGURO OU FUNDO GARANTIDOR DE 
CRÉDITOS - FGC. | Para consultar as demais taxas (gestão, distribuição e/ou taxa de saída, conforme o caso), além de informações como classiﬁcação ANBIMA, descrição do objetivo e/ou estratégia, tributação aplicável e documentação dos 
Fundos, acesse o site do administrador e/ou  www.bahiaasset.com.br/documentos-de-fundos. I Administradora: BEM DTVM Ltda., CNPJ: 00.066.670/0001-00, Tel: (11) 3684-9432, www.bradescobemdtvm.com.br, SAC: 
centralbemdtvm@bradesco.com.br ou 0800 704 8383, Ouvidoria: 0800 727 9933. Administradora: Intrag DTVM Ltda., CNPJ: 62.418.140/0001-31, Caixa Postal: 03162-971, Tel: (11) 3072-6109, www.intrag.com.br, SAC Itaú: 0800 728 0728, Ouvidoria: 0800 
570 0011.
Rentabilidade
dos Fundos
 PL Atual (R$)  
Início
 PL Médio (R$) 
 Status 
MULTIMERCADOS MACRO
Abr/26
2026
2025
Últ. 12 
meses
Desde o 
Início
PL Estratégia
(R$)
Bahia AM Mutá FIF CIC Mult RL
0,72%
2,67%
18,65%
12,62%
187,35%
151.140.026
       
2,3 bi
31/05/17
% CDI
66%
59%
130%
85%
165%
132.979.952
         
Aberto
Bahia AM Maraú FIF CIC Mult RL
0,83%
3,32%
15,58%
12,67%
334,03%
279.559.057
     
2,3 bi
28/12/12
% CDI
76%
73%
109%
85%
136%
287.474.347
        
Aberto
Bahia AM FIF CIC Mult RL
0,93%
3,74%
14,44%
12,94%
256,95%
5.527.794
         
2,3 bi
28/12/12¹
% CDI
85%
82%
101%
87%
104%
7.243.030
            
Aberto
 PL Atual (R$) 
 Início 
 PL Médio (R$) 
 Status 
MULTIMERCADOS L&S / LB
Abr/26
2026
2025
Últ. 12 
meses
Desde o 
Início
PL Estratégia 
(R$)
Bahia AM Una EH FIF CI Mult RL - Sub Cond.²
3,46%
6,07%
-
-
19,44%
46.539.959
       
117,0 mi
30/06/25
% CDI
317%
134%
-
-
158%
25.496.240
          
Aberto
Bahia AM Long Biased FIF CIC Mult RL
2,92%
9,69%
35,81%
36,00%
204,34%
49.628.643
       
117,0 mi
30/12/15
diferencial do IPCA + 6%
1,78%
5,16%
25,27%
25,36%
-3,66%
44.824.335
          
Aberto
 PL Atual (R$) 
 Início 
 PL Médio (R$) 
 Status 
RENDA VARIÁVEL
Abr/26
2026
2025
Últ. 12 
meses
Desde o 
Início
PL Estratégia 
(R$)
Bahia AM Valuation FIF CIC Ações RL*
0,79%
15,61%
47,20%
47,36%
345,50%
219.674.042
      
639,5 mi
26/07/10
diferencial do IBOVESPA
0,86%
-0,65%
13,25%
8,67%
163,58%
185.540.936
         
Aberto
 PL Atual (R$) 
 Início 
 PL Médio (R$) 
 Status 
Últ. 12 
meses
Desde o 
Início
 PL Estratégia 
(R$) 
PREVIDÊNCIA
Abr/26
2026
2025
XP | Bahia AM Prev FIFE FI RF Ativo LP
1,05%
3,42%
14,53%
12,79%
49,31%
9.594.848
         
36,1 mi
24/10/22
% CDI
97%
75%
102%
86%
92%
8.512.141
               
Aberto
ITAÚ | Bahia AM A Prev Ativo FIF CIC RF LP RL
1,10%
3,04%
14,56%
11,88%
25,79%
26.553.695
        
36,1 mi
28/05/24
% CDI
100%
67%
102%
80%
95%
15.862.623
           
Aberto
BB | Bahia AM Prev Guará FIFE FIF Mult RL
1,10%
4,33%
15,77%
15,26%
21,42%
53.095.307
       
53,1 mi
29/11/24
% CDI
101%
95%
110%
103%
104%
57.421.971
            
Aberto
 PL Atual (R$) 
 Início 
 PL Médio (R$) 
 Status 
RENDA FIXA
Abr/26
2026
2025
Últ. 12 
meses
Desde o 
Início
 PL Estratégia 
(R$) 
Bahia AM Referenciado DI FIF CI RF Ref DI RL*
1,06%
4,54%
14,11%
14,69%
576,01%
133.686.916
       
133,7 mi
13/02/06
% CDI
97%
100%
99%
99%
94%
139.864.266
         
Aberto
Últ. 12 
meses
INDICADORES
Abr/26
2026
2025
CDI
1,09%
4,54%
14,31%
14,83%
IBOVESPA
-0,08%
16,26%
33,95%
38,69%
IPCA + 6%
1,14%
4,52%
10,54%
10,64%
*Clientes institucionais: o fundo observa, no que lhe é aplicável, as Resoluções das EFPCs e RPPSs.