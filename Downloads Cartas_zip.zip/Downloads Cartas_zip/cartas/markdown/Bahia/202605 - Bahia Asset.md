

---

Fonte: Bahia Asset Management | Data: 05/2026
Fonte: Bahia Asset Management | Data: 05/2026
PREÇO DO PETRÓLEO BRENT | US$/BARRIL
Comentários do Gestor
COPYRIGHT © 2025 - TODOS OS DIREITOS RESERVADOS
Carta
do Gestor
Em meio aos desdobramentos do conﬂito no Oriente 
Médio, o mês de maio foi marcado pela boa 
performance de ativos de risco, repreciﬁcação da 
curva de juros norte-americana e queda dos preços 
do petróleo. Apesar da continuidade do cessar-fogo, 
o Estreito de Ormuz seguiu com baixo ﬂuxo de 
travessia de navios, afetando as cadeias globais. A 
comunicação recente dos Estados Unidos e do Irã 
sugere que um memorando está sendo ﬁnalizado 
com o objetivo de reabrir o Estreito enquanto outras 
demandas, 
como 
a 
questão 
nuclear 
e 
o 
descongelamento 
de 
ativos 
iranianos, 
serão 
endereçadas posteriormente. 
Nos Estados Unidos, os dados de atividade e 
mercado de trabalho continuaram sugerindo uma 
economia resiliente. O relatório de emprego mostrou 
geração saudável de vagas, ainda que acompanhada 
por leve alta da taxa de desemprego. Do lado da 
atividade, as vendas do varejo vieram um pouco mais 
fortes que o esperado, enquanto o consumo não 
apresentou 
grandes 
desvios. 
A 
inﬂação 
norte-americana, por sua vez, continua rodando 
acima da meta. O núcleo do PCE, principal indicador 
de preços acompanhado pelo Federal Reserve, veio 
em patamar elevado pelo quinto mês consecutivo. 
Apesar disso, as expectativas de inﬂação do mercado 
e as medidas pelo NY Fed permaneceram bem 
comportadas, o que ajuda a limitar uma deterioração 
mais ampla da percepção inﬂacionária. 
Nesse contexto, frente à incerteza das tensões 
geopolíticas, a comunicação do Federal Reserve 
assumiu tom um pouco mais cauteloso. A ata do 
FOMC indicou que a maioria dos membros estaria 
disposta a elevar a taxa de juros caso a inﬂação 
permaneça elevada, enquanto alguns membros 
considerariam cortes caso a inﬂação volte a convergir 
MAI
2026
ÍNDICE S&P 500
60
70
80
90
100
110
120
jan-26
fev-26
mar-26
abr-26
mai-26
jun-26
6.300
6.550
6.800
7.050
7.300
7.550
jan-26
fev-26
mar-26
abr-26
mai-26
jun-26

---

Comentários do Gestor
COPYRIGHT © 2025 - TODOS OS DIREITOS RESERVADOS
à meta ou o mercado de trabalho enfraqueça de 
forma mais aguda. Finalmente, tivemos a cerimônia 
de posse de Kevin Warsh como presidente do Fed, 
que presidirá sua primeira reunião do FOMC em 
junho. 
Na Zona do Euro, o PMI indicou desaceleração da 
atividade, concentrada no setor de serviços. Do lado 
da inﬂação, o núcleo ﬁcou acima do esperado na 
leitura preliminar, o que deve preocupar a ala mais 
hawk do comitê de política monetária, o qual está 
especialmente 
atento 
a 
potenciais 
efeitos 
secundários da alta de preços de energia. Já as 
expectativas de inﬂação medidas pelo ECB não 
mostraram aceleração adicional na margem e se 
mantiveram ancoradas em horizontes mais longos. 
Na China, os indicadores de atividade e crédito 
vieram 
abaixo 
do 
esperado, 
sugerindo 
uma 
economia com crescimento moderado.  Além disso, 
o encontro entre os presidentes Xi Jinping e Donald 
Trump em Pequim teve foco na estabilidade 
diplomática entre os países, porém sem grandes 
avanços nas suas divergências comerciais, como por 
exemplo as tarifas.
No Brasil, as pesquisas eleitorais passaram a apontar 
maior intenção de voto em Lula contra Flávio 
Bolsonaro, em meio à divulgação de áudios 
envolvendo Flávio e Daniel Vorcaro. Os dados de 
atividade seguiram fortes na margem, com PIB um 
pouco acima do esperado e demanda doméstica 
robusta. Os dados de emprego vieram mistos, com 
desemprego um pouco menor, mas criação de vagas 
mais fraca que o esperado. Do lado da inﬂação, os 
núcleos – tanto o de comercializáveis quanto o de 
serviços – vieram elevados novamente. 
Em sua comunicação, o Banco Central seguiu com 
um 
discurso 
mais 
cauteloso, 
reforçando 
a 
preocupação com a inﬂação corrente e, 
principalmente, 
com 
a 
desancoragem 
das 
expectativas em horizontes mais longos. No entanto, 
manteve-se a indicação de continuidade do ciclo, 
ainda que em menor magnitude, como reforçado 
pela 
ata, 
enquanto 
Galípolo 
reiterou 
que 
a 
autoridade monetária está ainda mais vigilante, sem 
trazer 
novidades 
relevantes 
sobre 
o 
forward 
guidance.
Na formulação de nossas teses de investimento, 
partimos do reconhecimento de um ambiente 
global marcado por elevada incerteza, tanto em 
relação ao estágio dos ciclos econômicos nas 
principais economias quanto à evolução das tensões 
geopolíticas. 
A 
agenda 
da 
administração 
norte-americana provavelmente ocasionará um 
rearranjo nas cadeias de suprimentos e até mesmo 
de alianças vigentes desde o pós-guerra. Dessa 
forma, a reação de cada banco central e governo é 
complexa e altamente incerta. Consideramos que os 
fatores externos que merecem maior atenção são: (i) 
a duração do conﬂito no Oriente Médio e suas 
cicatrizes econômicas; (ii) a implementação e os 
impactos das políticas econômicas e da geopolítica 
do presidente Donald Trump; (iii) a postura dos 
bancos centrais diante deste ambiente; (iv) as 
consequências na atividade e a evolução da inﬂação 
nos principais blocos econômicos; (v) a atividade na 
China e novas medidas de estímulo que possam vir a 
ser adotadas no país. 
No Brasil, estamos especialmente atentos: (i) aos 
impactos do conﬂito geopolítico e suas implicações 
para a trajetória da inﬂação corrente, bem como das 
expectativas de inﬂação; (ii) às discussões ﬁscais e 
paraﬁscais; (iii) à velocidade da desaceleração da 
atividade e ao comportamento de emprego e 
salários; e (iv) às discussões e pesquisas referentes às 
eleições deste ano.
MAI
2026

---

Multimercados 
Macro
Principais ganhos do mês:
--  Vendido no dólar norte-americano; e
--  Posições relativas compradas no rand sul-africano 
contra a libra esterlina.
Principais perdas:
--  Aplicado em juros reais e nominais (BR);
--  Vendido em inﬂação implícita (BR); e
--  Comprado no Ibovespa.
Estratégias e Atribuição de Resultados
COPYRIGHT © 2025 - TODOS OS DIREITOS RESERVADOS
Posições Brasil:
--  Aplicado em juros reais;
--  Posições relativas na curva de juros reais; e
--  Posições relativas em ações brasileiras.
Posições Internacionais:
--  Aplicado em juros do Canadá e da África do Sul 
contra a Zona do Euro;
--  Comprado no euro contra a libra esterlina;
--  Comprado em bolsa (EUA);
--  Comprado em petróleo; e
--  Posições relativas compradas de milho americano 
contra o milho brasileiro.
MAI
20226
MARAÚ
12 MESES
MAI/26
Juros On
-1,6%
-0,4%
Juros Off
-0,5%
0,0%
Moedas
1,5%
0,1%
Commodities
0,8%
-0,1%
Bolsa
-0,3%
-0,1%
Total Operações
-0,2%
-0,4%
CDI / Txs / Custos
12,3%
0,9%
Maraú
12,1%
0,5%
%CDI
81,6%
50,5%
MUTÁ
12 MESES
MAI/26
Juros On
-3,1%
-0,7%
Juros Off
-1,1%
0,1%
Moedas
3,0%
0,2%
Commodities
1,5%
-0,1%
Bolsa
-0,7%
-0,2%
Total Operações
-0,4%
-0,7%
CDI / Txs / Custos
11,9%
0,9%
Mutá
11,5%
0,2%
%CDI
77,5%
15,1%
BAHIA
12 MESES
MAI/26
Juros On
-0,9%
-0,2%
Juros Off
-0,3%
0,0%
Moedas
0,9%
0,1%
Commodities
0,5%
0,0%
Bolsa
-0,2%
-0,1%
Total Operações
0,0%
-0,2%
CDI / Txs / Custos
12,6%
0,9%
Bahia
12,6%
0,7%
%CDI
84,7%
65,5%

---

COPYRIGHT © 2025 - TODOS OS DIREITOS RESERVADOS
Multimercados L&S | LB 
e Renda Variável
Comentários do Gestor
Exposição das Carteiras
Contribuições Positivas
--  Mantivemos uma carteira diversiﬁcada ao longo do 
mês com uma média de 28 papéis.  
--  A posição média comprada nos fundos long only 
foi de 97% e no fundo Long Biased foi de 64%.
-- As maiores posições compradas estão nos setores 
de Bancos, Elétrico e Imobiliário.
As maiores contribuições positivas vieram das 
incorporadoras de baixa renda: 
-- Tenda e Cury tiveram uma boa performance, com a 
divulgação de resultados do primeiro trimestre 
trazendo boas notícias: margens e VSO mais altos e 
mais geração de caixa. O impacto da guerra nos 
preços de materiais já foi incorporado pelo mercado, 
que agora passou a focar mais no operacional das 
empresas..
Maio foi um mês de correção para o mercado 
brasileiro, pressionado por uma saída de capital 
estrangeiro que começou em meados de abril, 
reﬂexo de uma rotação global de volta para ativos de 
tecnologia nos Estados Unidos e na Ásia. Os ruídos 
do calendário eleitoral e o debate em torno da escala 
6x1 agravaram o quadro, acrescentando incerteza 
sobre o custo das empresas e o ambiente 
regulatório.
Em relação as commodities, o petróleo segue com 
bastante volatilidade e caiu em torno de 12% nos 
mercados internacionais. O minério de ferro teve 
queda de 2% e as cotações de aço fecharam entre 1% 
e 4% de alta. O ouro caiu 2%. A celulose caiu 2% no 
mercado chinês futuro. Nas agrícolas, o açúcar caiu 
4%, o milho 6% e a soja 1%.
O Ibovespa caiu 7,2% e o índice de Small Caps foi 
negativo em 3,7%. Por sua vez, a rentabilidades dos 
fundos no mês foram:
--  Bahia AM Valuation: -7,5%;
--  Bahia AM Long Biased: -6,1%;
--  Bahia AM Una Equity Hedge: -0,4%.
2026
MAI
Contribuições Negativas
As contribuições negativas ﬁcaram concentradas no 
setor de Saúde:
-- Bradesco Saúde teve uma má performance, apesar 
de divulgar resultado acima do esperado. O ﬂuxo de 
vendedor estrangeiro segue pesando na ação. .
-- Raia Drogasil também tem sido afetada pelo ﬂuxo 
estrangeiro, porém discussões como o aumento do 
comércio ilegal de GLP-1 e ﬁm da escala 6x1 são 
questões idiossincráticas negativas relevantes para a 
empresa.

---

ACOMPANHE NOSSAS REDES 
E RECEBA CONTEÚDOS EXCLUSIVOS
ACESSE O NOSSO SITE
WWW.BAHIAASSET.COM.BR
Para demais documentos e informações dos fundos acesse www.bahiaasset.com.br, www.bradescobemdtvm.com.br ou www.intrag.com.br
COPYRIGHT © 2025 - TODOS OS DIREITOS RESERVADOS
CLIQUE AQUI
MAI
2026
¹ A rentabilidade apresentada tem como marco, o início da estratégia atualmente adotada pelo Fundo em 28/12/2012, quando teve início o Bahia AM Maraú FIF CIC Mult RL. Entretanto a data de início do 
Bahia AM FIF CIC Mult RL é 30/05/2008. | ² Até 19/03/2026, o BAHIA AM UNA EH FIF CI Mult RL operava como classe única. Em 20/03/2026, foi constituída a Subclasse Condominial e o PL indicado reﬂete 
exclusivamente esta subclasse. | O Bahia AM Mutá FIF CIC Mult RL alterou a sua classiﬁcação Anbima de Multimercado Livre para Multimercado Macro em 06/02/2023. | PL Médio corresponde à média 
aritmética do PL mensal dos últimos 12 meses. PL Estratégia corresponde à soma dos PLs dos fundos geridos pelas empresas do Bahia Asset, agrupados pelo mesmo tipo de estratégia. Para conhecer as 
estratégias e os fundos que as compõem, entre em contato com bahiaasset@bahiaasset.com.br. | Taxa de Administração Global (considerando as taxas de administração global do fundo e dos fundos 
investidos) / Taxa de Administração Máxima (considerando a taxa de administração global do fundo e as máximas dos fundos investidos): Bahia AM FIF CIC Mult RL: 1,5%/1,7% a.a.; Bahia AM Mutá FIF CIC 
Mult RL, Bahia AM Maraú FIF CIC Mult RL, Bahia AM Valuation FIF CIC Ações RL, Bahia AM Long Biased FIF CIC Mult RL, Bahia AM Una EH FIF CI Mult RL: 2,0%/2,2% a.a.; Bahia AM FI RF Referenciado DI: 
0,2%/0,25% a.a.; Bahia AM Prev Guará FIFE FIF Mult RL: 0,7%/0,7% a.a.; Bahia AM A Prev Ativo FIF CIC RF LP RL: 0,8%/0,9% a.a.; Bahia AM Prev FIFE Ativo FIF RF LP RL: 0,9% a.a. | Taxa de Performance: 20% 
sobre o que exceder 100% do benchmark do fundo: Bahia AM Mutá FIF CIC Mult RL, Bahia AM Maraú FIF CIC Mult RL, Bahia AM FIF CIC Mult RL, Bahia AM Una EH FIF CI Mult RL, Bahia AM A Prev Ativo FIF 
CIC RF LP RL e Bahia AM Prev FIFE Ativo FIF RF LP RL: CDI; Bahia AM Prev Guará FIFE FIF Mult RL: CDI+1% a.a.; Bahia AM Valuation FIF CIC Ações RL: Ibovespa; Bahia AM Long Biased FIF CIC Mult RL: 
IPCA+6% a.a.  Investidores qualiﬁcados: Bahia AM Mutá FIF CIC Mult RL e Bahia AM Una EH FIF CI Mult RL. Todos os demais fundos são para Investidores em geral.
A Bahia AM Renda Fixa Ltda. e a Bahia AM Renda Variável Ltda. não comercializam nem distribuem cotas de fundos de investimento ou qualquer outro ativo ﬁnanceiro. | LEIA A LÂMINA DE INFORMAÇÕES ESSENCIAIS, SE HOUVER, O 
REGULAMENTO, O ANEXO-CLASSE E O APÊNDICE SUBCLASSE, CONFORME O CASO, ANTES DE INVESTIR. A RENTABILIDADE OBTIDA NO PASSADO NÃO REPRESENTA GARANTIA DE RESULTADOS FUTUROS. A RENTABILIDADE DIVULGADA 
NÃO É LÍQUIDA DE IMPOSTOS E, SE FOR O CASO, DE TAXA DE SAÍDA. FUNDOS DE INVESTIMENTO NÃO CONTAM COM GARANTIA DO ADMINISTRADOR, DO GESTOR, DE QUALQUER MECANISMO DE SEGURO OU FUNDO GARANTIDOR DE 
CRÉDITOS - FGC. | Para consultar as demais taxas (gestão, distribuição e/ou taxa de saída, conforme o caso), além de informações como classiﬁcação ANBIMA, descrição do objetivo e/ou estratégia, tributação aplicável e documentação dos 
Fundos, acesse o site do administrador e/ou  www.bahiaasset.com.br/documentos-de-fundos. I Administradora: BEM DTVM Ltda., CNPJ: 00.066.670/0001-00, Tel: (11) 3684-9432, www.bradescobemdtvm.com.br, SAC: 
centralbemdtvm@bradesco.com.br ou 0800 704 8383, Ouvidoria: 0800 727 9933. Administradora: Intrag DTVM Ltda., CNPJ: 62.418.140/0001-31, Caixa Postal: 03162-971, Tel: (11) 3072-6109, www.intrag.com.br, SAC Itaú: 0800 728 0728, Ouvidoria: 0800 
570 0011.
Rentabilidade
dos Fundos
PL (R$ mi)
Master (R$ mi)
Início
PL Médio
Estratégia
 Status 
MULTIMERCADOS MACRO
Mai/26
2026
2025
Últ. 12 
meses
Desde o 
Início
Bahia AM Mutá FIF CIC Mult RL
0,16%
2,84%
18,65%
11,48%
187,81%
151
262
31/05/17
% CDI
15%
50%
130%
77%
162%
136
2.282
Aberto
Bahia AM Maraú FIF CIC Mult RL
0,54%
3,88%
15,58%
12,09%
336,39%
280
1.041
28/12/12
% CDI
51%
68%
109%
82%
135%
285
2.282
Aberto
Bahia AM FIF CIC Mult RL
0,70%
4,46%
14,44%
12,55%
259,46%
5
36
28/12/12¹
% CDI
65%
79%
101%
85%
104%
6
2.282
Aberto
PL (R$ mi)
Master (R$ mi)
 Início 
PL Médio
Estratégia
 Status 
MULTIMERCADOS L&S / LB
Mai/26
2026
2025
Últ. 12 
meses
Desde o 
Início
Bahia AM Una EH FIF CI Mult RL - Sub Cond.²
-0,38%
5,67%
-
-
18,98%
54
72
30/06/25
% CDI
-
100%
-
-
141%
34
126
Aberto
Bahia AM Long Biased FIF CIC Mult RL
-6,11%
2,99%
35,81%
22,53%
185,75%
47
54
30/12/15
diferencial do IPCA + 6%
-7,08%
-2,56%
25,27%
11,61%
-25,26%
45
126
Aberto
PL (R$ mi)
Master (R$ mi)
 Início 
PL Médio
Estratégia
 Status 
RENDA VARIÁVEL
Mai/26
2026
2025
Últ. 12 
meses
Desde o 
Início
Bahia AM Valuation FIF CIC Ações RL*
-7,48%
6,97%
47,20%
29,45%
312,19%
204
382
26/07/10
diferencial do IBOVESPA
-0,25%
-0,89%
13,25%
4,00%
150,64%
189
553
Aberto
PL (R$ mi)
Master (R$ mi)
 Início 
PL Médio
Estratégia
 Status 
PREVIDÊNCIA
Mai/26
2026
2025
Últ. 12 
meses
Desde o 
Início
XP | Bahia AM Prev FIFE FI RF Ativo LP
0,62%
4,07%
14,53%
11,91%
50,24%
10
10
24/10/22
% CDI
58%
72%
102%
80%
91%
9
34
Aberto
ITAÚ | Bahia AM A Prev Ativo FIF CIC RF LP RL
0,42%
3,48%
14,56%
10,52%
26,32%
24
24
28/05/24
% CDI
39%
61%
102%
71%
93%
17
34
Aberto
BB | Bahia AM Prev Guará FIFE FIF Mult RL
0,66%
5,02%
15,77%
14,64%
22,22%
55
55
29/11/24
% CDI
62%
89%
110%
99%
101%
57
55
Aberto
PL (R$ mi)
Master (R$ mi)
 Início 
PL Médio
Estratégia
 Status 
Últ. 12 
meses
Desde o 
Início
RENDA FIXA
Mai/26
2026
2025
Bahia AM Referenciado DI FIF CI RF Ref DI RL*
1,05%
5,64%
14,11%
14,65%
583,12%
146
146
13/02/06
% CDI
98%
100%
99%
99%
94%
141
146
Aberto
INDICADORES
Mai/26
2026
2025
Últ. 12 
meses
CDI
1,07%
5,66%
14,31%
14,82%
IBOVESPA
-7,22%
7,86%
33,95%
25,45%
IPCA + 6%
0,97%
5,54%
10,54%
10,92%
*Clientes institucionais: o fundo observa, no que lhe é aplicável, as Resoluções das EFPCs e RPPSs.