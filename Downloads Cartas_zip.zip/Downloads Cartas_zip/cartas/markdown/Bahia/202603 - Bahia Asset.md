

---

Fonte: Bahia Asset Management | Data: 03/2026
Fonte: Bahia Asset Management | Data: 03/2026
PREÇO DO PETRÓLEO BRENT | US$ POR BARRIL
Comentários do Gestor
COPYRIGHT © 2025 - TODOS OS DIREITOS RESERVADOS
Carta
do Gestor
O mês de março foi marcado por uma repreciﬁcação 
signiﬁcativa dos ativos globais com destaque para 
alta das curvas de juros, má performance de ativos de 
risco e força do dólar americano em meio à guerra 
entre os Estados Unidos e o Irã. O fechamento do 
Estreito de Ormuz tem impacto direto no ﬂuxo físico 
de diversas commodities, em especial energéticas, 
com relevantes consequências macroeconômicas. 
Esse choque inﬂacionário elevou as expectativas de 
aperto monetário em diversas economias, apesar da 
sinalização 
predominantemente 
cautelosa 
dos 
bancos centrais, ancorada em uma postura de 
“aguardar para avaliar” a evolução dos dados. 
Ao longo do mês, as forças armadas americanas e 
israelenses continuaram a bombardear o Irã que, 
após a morte de suas principais lideranças, elegeu o 
ﬁlho do antigo líder supremo Ali Khamenei como seu 
sucessor. Nas últimas semanas, Donald Trump 
demonstrou interesse no enceramento do confronto, 
enviando uma proposta para autoridades iranianas, 
que mantêm demandas até o momento apontadas 
como inaceitáveis pelos americanos. Negociações 
para o ﬁm da guerra e reabertura do Estreito de 
Ormuz 
estão 
em 
andamento, 
ainda 
que 
as 
comunicações de cada um dos governos se 
mostrem inconsistentes e dissonantes. A despeito do 
esforço diplomático, os EUA estão enviando milhares 
de soldados e ativos militares para a região. 
Entre os indicadores econômicos americanos, a 
geração 
de 
empregos 
apresentou 
retração 
signiﬁcativa em fevereiro, em parte devido a 
impactos de greves e do clima, enquanto a taxa de 
desemprego mostrou afrouxamento. Do lado da 
inﬂação, é esperado que o núcleo do PCE, principal 
indicador de inﬂação acompanhado pelo Federal 
Reserve, acelere na margem, especialmente afetado 
MAR
2026
EUA: JURO NOMINAL DE 5 ANOS
50
60
70
80
90
100
110
120
abr-25
jun-25
ago-25
out-25
dez-25
fev-26
abr-26
3,50
3,60
3,70
3,80
3,90
4,00
4,10
jun-25
ago-25
out-25
dez-25
fev-26
abr-26

---

Comentários do Gestor
COPYRIGHT © 2025 - TODOS OS DIREITOS RESERVADOS
pela inﬂação de bens. O banco central, frente à 
incerteza posta pelas tensões geopolíticas, manteve 
posição cautelosa, enfatizando riscos para ambos os 
lados do mandato e sem mudanças relevantes em 
sua mensagem. 
Na Zona do Euro, a inﬂação cheia mostrou aceleração 
na margem, já com efeitos do conﬂito nos preços de 
energia. Na política monetária, o ECB mostrou 
preocupação com as potenciais consequências do 
choque energético e sinalizou que está pronto para 
reagir 
dependendo 
de 
sua 
extensão 
e, 
consequentemente, dos efeitos diretos e indiretos 
sobre a inﬂação doméstica. As comunicações 
posteriores à reunião mostraram divergência entre 
os membros, com alguns indicando possibilidade de 
elevar a taxa de juros já no próximo mês.
Na China, os dados de atividade relativos a janeiro e 
fevereiro vieram melhores do que o antecipado, 
porém com o setor de moradias ainda fraco. No 
campo político, nas “Two Sessions”, um dos eventos 
mais importantes do país, o governo anunciou que 
perseguirá crescimento entre 4,5 e 5,0%, o que era 
amplamente esperado. Por outro lado, indicaram 
estímulos ﬁscais mais contidos.
No Brasil, pesquisas eleitorais apontam para empate 
técnico no segundo turno entre Flávio e Lula, com 
deterioração da aprovação do governo. Além disso, 
dados 
de 
emprego 
mostraram 
desaceleração 
gradual, mas com o mercado de trabalho ainda em 
níveis bastante apertados. O IPCA apresentou 
surpresa 
altista 
relevante, 
porém 
bastante 
concentrada em passagem aérea, um item muito 
volátil. Os impactos do aumento de preços de 
commodities devido à guerra são mais relevantes 
para a dinâmica inﬂacionária à frente. Merecem 
atenção as projeções de inﬂação do Focus um pouco 
mais longas, como as de 2027 e 2028, que já 
apresentaram leve elevação. 
Em sua reunião de política monetária, o Copom 
iniciou o ciclo de afrouxamento com um passo de 25 
bps 
e 
preservou 
a 
opcionalidade 
quanto 
à 
magnitude dos cortes futuros. Em sua comunicação, 
ainda tratou os riscos para a inﬂação como simétricos 
e projetou a inﬂação abaixo do esperado pelos 
participantes do mercado. 
Na formulação de nossas teses de investimento, 
partimos do reconhecimento de um ambiente 
global marcado por elevada incerteza, tanto em 
relação ao estágio dos ciclos econômicos nas 
principais economias quanto à evolução das tensões 
geopolíticas. A agenda da administração americana 
provavelmente ocasionará um rearranjo nas cadeias 
de suprimentos e até mesmo de alianças vigentes 
desde o pós-guerra. Dessa forma, a reação de cada 
banco central e governo é complexa e altamente 
incerta. Consideramos que os fatores externos que 
merecem maior atenção são: (i) a duração e as 
cicatrizes econômicas decorrentes do conﬂito no 
Oriente Médio; (ii) a implementação e os impactos 
das 
políticas 
econômicas 
e 
geopolíticas 
do 
presidente Donald Trump; (iii) a postura dos bancos 
centrais em relação aos próximos passos de política 
monetária diante deste ambiente; (iv) os impactos na 
atividade e a evolução da inﬂação nos principais 
blocos econômicos; (v) a atividade na China e novas 
medidas de estímulo que possam vir a ser adotadas 
no país. 
No Brasil, estamos especialmente atentos: (i) aos 
impactos do conﬂito geopolítico e suas implicações 
para a trajetória da inﬂação corrente e para as 
expectativas de inﬂação; (ii) às discussões ﬁscais e 
paraﬁscais; (iii) à velocidade da desaceleração da 
atividade e ao comportamento de emprego e 
salários; e (iv) às discussões e pesquisas referentes às 
eleições deste ano. 
MAR
2026

---

Multimercados 
Macro
Principais ganhos do mês:
--  Posições relativas em ações;
--  Comprado na inﬂação implícita brasileira;
--  Comprado em proteção de índices de crédito high 
yield; e 
--  Comprado em índices de bolsas brasileira e 
americana.
Principais perdas:
--  Aplicado em juros nominais (BR e emergentes);
--  Tomado na inclinação na curva de juros reais 
brasileira; e
--  Comprado em ouro.
Estratégias e Atribuição de Resultados
COPYRIGHT © 2025 - TODOS OS DIREITOS RESERVADOS
Posições Brasil:
--  Aplicado em juros nominais e reais;
--  Tomadao na inclinação de juros reais;
--  Comprado em bolsa brasileira e posções relativas 
em ações;
--  Tomadas no cupom cambial contra o juro 
americano; e
--  Compradas no real contra uma cesta de moedas.
Posições Internacionais:
--  Vendido no euro e no dólar americano contra 
moedas desenvolvidas;
--  Aplicado no juros no Canadá; e
--  Comprado em ouro.
MAR
20226
MARAÚ
12 MESES
MAR/26
Juros On
0,0%
-1,9%
Juros Off
0,1%
-0,1%
Moedas
1,7%
0,0%
Commodities
1,1%
-0,1%
Bolsa
-0,1%
0,1%
Total Operações
2,7%
-1,9%
CDI / Txs / Custos
12,6%
1,0%
Maraú
15,3%
-0,9%
%CDI
103,4%
-
MUTÁ
12 MESES
MAR/26
Juros On
0,0%
-3,8%
Juros Off
0,2%
-0,1%
Moedas
3,4%
0,0%
Commodities
2,2%
-0,2%
Bolsa
-0,3%
0,2%
Total Operações
5,5%
-3,9%
CDI / Txs / Custos
12,1%
1,2%
Mutá
17,6%
-2,7%
%CDI
118,8%
-
BAHIA
12 MESES
MAR/26
Juros On
0,0%
-1,1%
Juros Off
0,1%
0,0%
Moedas
1,0%
0,0%
Commodities
0,7%
-0,1%
Bolsa
-0,1%
0,1%
Total Operações
1,7%
-1,2%
CDI / Txs / Custos
12,7%
1,1%
Bahia
14,5%
-0,1%
%CDI
97,8%
-

---

COPYRIGHT © 2025 - TODOS OS DIREITOS RESERVADOS
Multimercados L&S | LB 
e Renda Variável
Comentários do Gestor
Exposição das Carteiras
Contribuições Positivas
--  Mantivemos uma carteira diversiﬁcada ao longo do 
mês com uma média de 28 papéis.  
--  A posição média comprada nos fundos long only 
foi de 95% e no fundo Long Biased foi de 57%.
-- As maiores posições compradas estão nos setores 
de Bancos, Commodities e Consumo Discricionário.
As maiores contribuições positivas vieram dos 
setores Elétrico e Energia (Óleo e Gás). 
-- Copel e Eneva foram os foram os destaques do 
Leilão de Reserva de Capacidade colocando projetos 
que não estavam no cenário base do mercado e com 
preços elevados;
-- Além de se beneﬁciar da alta do petróleo, Prio 
colocou em operação no mês de março o campo de 
Wahoo e o volume dos primeiros poços está vindo 
acima das expectativas do mercado.
Março foi um mês de grande volatilidade nos 
mercados globais. O gatilho foi a escalada do conﬂito 
entre Estados Unidos, Israel e Irã, iniciado ao ﬁnal de 
fevereiro com a Operação “Epic Fury”. O trânsito pelo 
Estreito de Ormuz — rota por onde passa cerca de 
20% do petróleo mundial — foi parcialmente 
interrompido para o tráfego comercial. Com queda 
de 
0,7% 
no 
mês, 
o 
Ibovespa 
foi 
exceção 
comparativamente a outras bolsas mundiais. O real 
também apresentou resiliência relativa frente a 
outras 
moedas 
emergentes, 
beneﬁciado 
pela 
posição exportadora de commodities do Brasil. O 
Copom reduziu a Selic para 14,75% ao ano, dando 
início ao ciclo de ﬂexibilização, enquanto o mercado 
revisou para cima as projeções de inﬂação diante do 
choque do petróleo.
Em relação às commodities, o destaque ﬁcou para o 
petróleo subindo 44% nos mercados internacionais. 
O minério de ferro terminou em alta de 8% e as 
cotações de aço fecharam perto da estabilidade. O 
ouro caiu 12% e a celulose 3% no mercado chinês 
futuro. Nas agrícolas, o açúcar subiu 12%, o milho 
subiu 2% e a soja fechou perto da estabilidade.
O Ibovespa caiu 0,7% e o índice de Small Caps foi 
negativo em 5,8%. Por sua vez, a rentabilidades dos 
fundos no mês foram:
--  Bahia AM Valuation: -1,2%;
--  Bahia AM Long Biased: -1,4%;
--  Bahia AM Una Equity Hedge: +1,0%.
2026
MAR
Contribuições Negativas
As contribuições negativas ﬁcaram concentradas no 
setor de Bancos:
-- Os bancos em geral sofreram no mês de março em 
um movimento global de impacto da guerra. Além 
disso, em relação ao ambiente no Brasil, alguns casos 
de empresas muito alavancadas tiveram seu cenário 
de crédito estressado com alguns pedidos de 
recuperação judicial.

---

ACOMPANHE NOSSAS REDES 
E RECEBA CONTEÚDOS EXCLUSIVOS
ACESSE O NOSSO SITE
WWW.BAHIAASSET.COM.BR
Para demais documentos e informações dos fundos acesse www.bahiaasset.com.br, www.bradescobemdtvm.com.br ou www.intrag.com.br
COPYRIGHT © 2025 - TODOS OS DIREITOS RESERVADOS
CLIQUE AQUI
MAR
2026
¹ A rentabilidade apresentada tem como marco, o início da estratégia atualmente adotada pelo Fundo em 28/12/2012, quando teve início o Bahia AM Maraú FIF CIC Mult RL. Entretanto a data de início do 
Bahia AM FIF CIC Mult RL é 30/05/2008. | ² Até 19/03/2026, o BAHIA AM UNA EH FIF CI Mult RL operava como classe única. Em 20/03/2026, foi constituída a Subclasse Condominial e o PL indicado reﬂete 
exclusivamente esta subclasse. | O Bahia AM Mutá FIF CIC Mult RL alterou a sua classiﬁcação Anbima de Multimercado Livre para Multimercado Macro em 06/02/2023. | PL Médio corresponde à média 
aritmética do PL mensal dos últimos 12 meses. PL Estratégia corresponde à soma dos PLs dos fundos geridos pelas empresas do Bahia Asset, agrupados pelo mesmo tipo de estratégia. Para conhecer as 
estratégias e os fundos que as compõem, entre em contato com bahiaasset@bahiaasset.com.br. | Taxa de Administração Global (considerando as taxas de administração global do fundo e dos fundos 
investidos) / Taxa de Administração Máxima (considerando a taxa de administração global do fundo e as máximas dos fundos investidos): Bahia AM FIF CIC Mult RL: 1,5%/1,7% a.a.; Bahia AM Mutá FIF CIC 
Mult RL, Bahia AM Maraú FIF CIC Mult RL, Bahia AM Valuation FIF CIC Ações RL, Bahia AM Long Biased FIF CIC Mult RL, Bahia AM Una EH FIF CI Mult RL: 2,0%/2,2% a.a.; Bahia AM FI RF Referenciado DI: 
0,2%/0,25% a.a.; Bahia AM Prev Guará FIFE FIF Mult RL: 0,7%/0,7% a.a.; Bahia AM A Prev Ativo FIF CIC RF LP RL: 0,8%/0,9% a.a.; Bahia AM Prev FIFE Ativo FIF RF LP RL: 0,9% a.a. | Taxa de Performance: 20% 
sobre o que exceder 100% do benchmark do fundo: Bahia AM Mutá FIF CIC Mult RL, Bahia AM Maraú FIF CIC Mult RL, Bahia AM FIF CIC Mult RL, Bahia AM Una EH FIF CI Mult RL, Bahia AM A Prev Ativo FIF 
CIC RF LP RL e Bahia AM Prev FIFE Ativo FIF RF LP RL: CDI; Bahia AM Prev Guará FIFE FIF Mult RL: CDI+1% a.a.; Bahia AM Valuation FIF CIC Ações RL: Ibovespa; Bahia AM Long Biased FIF CIC Mult RL: 
IPCA+6% a.a.  Investidores qualiﬁcados: Bahia AM Mutá FIF CIC Mult RL e Bahia AM Una EH FIF CI Mult RL. Todos os demais fundos são para Investidores em geral.
A Bahia AM Renda Fixa Ltda. e a Bahia AM Renda Variável Ltda. não comercializam nem distribuem cotas de fundos de investimento ou qualquer outro ativo ﬁnanceiro. | LEIA A LÂMINA DE INFORMAÇÕES ESSENCIAIS, SE HOUVER, O 
REGULAMENTO, O ANEXO-CLASSE E O APÊNDICE SUBCLASSE, CONFORME O CASO, ANTES DE INVESTIR. A RENTABILIDADE OBTIDA NO PASSADO NÃO REPRESENTA GARANTIA DE RESULTADOS FUTUROS. A RENTABILIDADE DIVULGADA 
NÃO É LÍQUIDA DE IMPOSTOS E, SE FOR O CASO, DE TAXA DE SAÍDA. FUNDOS DE INVESTIMENTO NÃO CONTAM COM GARANTIA DO ADMINISTRADOR, DO GESTOR, DE QUALQUER MECANISMO DE SEGURO OU FUNDO GARANTIDOR DE 
CRÉDITOS - FGC. | Para consultar as demais taxas (gestão, distribuição e/ou taxa de saída, conforme o caso), além de informações como classiﬁcação ANBIMA, descrição do objetivo e/ou estratégia, tributação aplicável e documentação dos 
Fundos, acesse o site do administrador e/ou  www.bahiaasset.com.br/documentos-de-fundos. I Administradora: BEM DTVM Ltda., CNPJ: 00.066.670/0001-00, Tel: (11) 3684-9432, www.bradescobemdtvm.com.br, SAC: 
centralbemdtvm@bradesco.com.br ou 0800 704 8383, Ouvidoria: 0800 727 9933. Administradora: Intrag DTVM Ltda., CNPJ: 62.418.140/0001-31, Caixa Postal: 03162-971, Tel: (11) 3072-6109, www.intrag.com.br, SAC Itaú: 0800 728 0728, Ouvidoria: 0800 
570 0011.
Rentabilidade
dos Fundos
 PL Atual (R$)  
Início
 PL Médio (R$) 
 Status 
MULTIMERCADOS MACRO
Fev/26
2026
2025
Últ. 12 
meses
Desde o 
Início
PL Estratégia
(R$)¹
 PL Atual (R$) 
 Início 
 PL Médio (R$) 
 Status 
MULTIMERCADOS L&S / LB
Fev/26
2026
2025
Últ. 12 
meses
Desde o 
Início
PL Estratégia 
(R$)¹
 PL Atual (R$) 
 Início 
 PL Médio (R$) 
 Status 
RENDA VARIÁVEL
Fev/26
2026
2025
Últ. 12 
meses
Desde o 
Início
PL Estratégia 
(R$)¹
 PL Atual (R$) 
 Início 
 PL Médio (R$) 
 Status 
Últ. 12 
meses
Desde o 
Início
 PL Estratégia 
(R$)¹ 
PREVIDÊNCIA
Fev/26
2026
2025
 PL Atual (R$)  
Início
 PL Médio (R$) 
 Status 
MULTIMERCADOS MACRO
Mar/26
2026
2025
Últ. 12 
meses
Desde o 
Início
PL Estratégia
(R$)¹
Bahia AM Mutá FIF CIC Mult RL
-2,65%
1,94%
18,65%
17,57%
185,30%
149.405.285
      
2,3 bi
31/05/17
% CDI
-
57%
130%
119%
166%
129.398.559
         
Aberto
Bahia AM Maraú FIF CIC Mult RL
-0,91%
2,46%
15,58%
15,30%
330,45%
278.747.809
     
2,3 bi
28/12/12
% CDI
-
72%
109%
103%
136%
291.395.232
          
Aberto
Bahia AM FIF CIC Mult RL
-0,11%
2,78%
14,44%
14,47%
253,66%
5.446.995
         
2,3 bi
28/12/12¹
% CDI
-
81%
101%
98%
105%
9.030.598
            
Aberto
 PL Atual (R$) 
 Início 
 PL Médio (R$) 
 Status 
MULTIMERCADOS L&S / LB
Mar/26
2026
2025
Últ. 12 
meses
Desde o 
Início
PL Estratégia 
(R$)
Bahia AM Una EH FIF CI Mult RL - Sub Cond²
0,99%
2,53%
-
-
15,45%
42.039.996
       
109,8 mi
30/06/25
% CDI
81%
74%
-
-
139%
42.039.996
          
Aberto
Bahia AM Long Biased FIF CIC Mult RL
-1,40%
6,58%
35,81%
37,38%
195,71%
48.828.883
      
109,8 mi
30/12/15
diferencial do IPCA + 6%
-2,63%
3,40%
25,27%
27,18%
-8,33%
43.932.197
           
Aberto
 PL Atual (R$) 
 Início 
 PL Médio (R$) 
 Status 
RENDA VARIÁVEL
Mar/26
2026
2025
Últ. 12 
meses
Desde o 
Início
PL Estratégia 
(R$)
Bahia AM Valuation FIF CIC Ações RL*
-1,22%
14,71%
47,20%
55,43%
342,02%
216.346.683
      
632,8 mi
26/07/10
diferencial do IBOVESPA
-0,52%
-1,64%
13,25%
11,51%
159,88%
180.367.484
        
Aberto
 PL Atual (R$) 
 Início 
 PL Médio (R$) 
 Status 
Últ. 12 
meses
Desde o 
Início
 PL Estratégia 
(R$) 
PREVIDÊNCIA
Mar/26
2026
2025
XP | Bahia AM Prev FIFE FI RF Ativo LP
-0,70%
2,34%
14,53%
13,14%
47,75%
9.807.021
         
36,2 mi
24/10/22
% CDI
-
69%
102%
89%
92%
8.133.023
             
Aberto
ITAÚ | Bahia AM A Prev Ativo FIF CIC RF LP RL
-1,57%
1,92%
14,56%
12,45%
24,43%
26.386.959
       
36,2 mi
28/05/24
% CDI
-
56%
102%
84%
95%
14.080.824
          
Aberto
BB | Bahia AM Prev Guará FIFE FIF Mult RL
-0,48%
3,20%
15,77%
15,93%
20,10%
54.743.964
       
54,7 mi
29/11/24
% CDI
-
94%
110%
108%
104%
58.412.581
            
Aberto
 PL Atual (R$) 
 Início 
 PL Médio (R$) 
 Status 
RENDA FIXA
Mar/26
2026
2025
Últ. 12 
meses
Desde o 
Início
 PL Estratégia 
(R$) 
Bahia AM Referenciado DI FIF CI RF Ref DI RL*
1,25%
3,44%
14,11%
14,64%
568,90%
130.826.426
      
130,8 mi
13/02/06
% CDI
103%
101%
99%
99%
94%
140.871.930
         
Aberto
Últ. 12 
meses
INDICADORES
Mar/26
2026
2025
CDI
1,21%
3,41%
14,31%
14,79%
IBOVESPA
-0,70%
16,35%
33,95%
43,91%
IPCA + 6%
1,23%
3,18%
10,54%
10,20%
*Clientes institucionais: o fundo observa, no que lhe é aplicável, as Resoluções das EFPCs e RPPSs.