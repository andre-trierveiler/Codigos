# -*- coding: utf-8 -*-
"""
md_to_blocks.py
---------------
Converte markdown para lista de blocos Notion (sem dependencias externas alem de stdlib).

Suporte: H1-H3, paragrafos, divisores (---), tabelas GFM, listas bullet/numbered,
         negrito (**bold**), italico (*italic*), codigo inline (`code`).

Limites do Notion tratados aqui:
- 2000 chars por rich_text object  -> _split_rt() fatia strings longas
- 100 blocos por chamada append    -> usar batch_blocks() no caller
"""

import re
from typing import Any

_MAX_RT = 2000  # limite Notion por objeto rich_text

# ─────────────────────────────────────────────
# RICH TEXT
# ─────────────────────────────────────────────

def _rt(text: str, bold: bool = False, italic: bool = False, code: bool = False) -> list[dict]:
    """Retorna lista de rich_text objects, fatiando em chunks de <= 2000 chars."""
    if not text:
        return []
    ann: dict[str, Any] = {
        "bold": bold, "italic": italic, "code": code,
        "strikethrough": False, "underline": False, "color": "default",
    }
    result = []
    for i in range(0, len(text), _MAX_RT):
        result.append({"type": "text", "text": {"content": text[i:i+_MAX_RT]}, "annotations": ann})
    return result


_INLINE_RE = re.compile(
    r'(\*\*\*(?P<bi>.+?)\*\*\*)'
    r'|(\*\*(?P<b>.+?)\*\*)'
    r'|(__(?P<b2>.+?)__)'
    r'|(\*(?P<i>.+?)\*)'
    r'|(_(?P<i2>.+?)_)'
    r'|(`(?P<c>.+?)`)',
    re.DOTALL,
)


def _parse_inline(text: str) -> list[dict]:
    """Parseia bold/italic/code inline e retorna lista de rich_text objects."""
    result: list[dict] = []
    last = 0
    for m in _INLINE_RE.finditer(text):
        if m.start() > last:
            result.extend(_rt(text[last:m.start()]))
        if m.group("bi"):
            result.extend(_rt(m.group("bi"), bold=True, italic=True))
        elif m.group("b") or m.group("b2"):
            result.extend(_rt(m.group("b") or m.group("b2"), bold=True))
        elif m.group("i") or m.group("i2"):
            result.extend(_rt(m.group("i") or m.group("i2"), italic=True))
        elif m.group("c"):
            result.extend(_rt(m.group("c"), code=True))
        last = m.end()
    if last < len(text):
        result.extend(_rt(text[last:]))
    return result or _rt("")


# ─────────────────────────────────────────────
# DETECTORES DE LINHA
# ─────────────────────────────────────────────

_H1 = re.compile(r'^# (.+)$')
_H2 = re.compile(r'^## (.+)$')
_H3 = re.compile(r'^#{3,} (.+)$')
_HR = re.compile(r'^[-*_]{3,}\s*$')
_BULLET = re.compile(r'^[ \t]*[-*+] (.+)$')
_ORDERED = re.compile(r'^[ \t]*\d+\. (.+)$')
_TABLE_ROW = re.compile(r'^\|.+\|$')
_TABLE_SEP = re.compile(r'^\|[\s\-:|]+\|$')


def _heading_block(level: int, text: str) -> dict:
    tipo = f"heading_{min(level, 3)}"
    return {
        "type": tipo,
        tipo: {"rich_text": _parse_inline(text.strip()), "color": "default", "is_toggleable": False},
    }


def _paragraph_block(text: str) -> dict:
    return {"type": "paragraph", "paragraph": {"rich_text": _parse_inline(text.strip()), "color": "default"}}


def _divider_block() -> dict:
    return {"type": "divider", "divider": {}}


def _bullet_block(text: str) -> dict:
    return {"type": "bulleted_list_item", "bulleted_list_item": {"rich_text": _parse_inline(text), "color": "default"}}


def _ordered_block(text: str) -> dict:
    return {"type": "numbered_list_item", "numbered_list_item": {"rich_text": _parse_inline(text), "color": "default"}}


# ─────────────────────────────────────────────
# TABELAS
# ─────────────────────────────────────────────

def _parse_table_rows(lines: list[str]) -> list[list[str]]:
    rows = []
    for line in lines:
        if _TABLE_SEP.match(line.strip()):
            continue
        cells = [c.strip() for c in line.strip().strip("|").split("|")]
        rows.append(cells)
    return rows


def _table_to_blocks(rows: list[list[str]]) -> list[dict]:
    if not rows:
        return []
    num_cols = max(len(r) for r in rows)
    children = []
    for row in rows:
        cells = [_parse_inline(cell) for cell in row]
        while len(cells) < num_cols:
            cells.append(_rt(""))
        children.append({"type": "table_row", "table_row": {"cells": cells}})
    return [{
        "type": "table",
        "table": {
            "table_width": num_cols,
            "has_column_header": len(rows) > 1,
            "has_row_header": False,
            "children": children,
        },
    }]


# ─────────────────────────────────────────────
# CONVERSOR PRINCIPAL
# ─────────────────────────────────────────────

def converter_md_para_blocos(texto_md: str) -> list[dict]:
    """
    Converte markdown para lista plana de blocos Notion.
    Caller deve dividir em batches de 100 com batch_blocks().
    """
    if not texto_md or not texto_md.strip():
        return []

    blocos: list[dict] = []
    linhas = texto_md.splitlines()
    i = 0

    while i < len(linhas):
        linha = linhas[i]
        stripped = linha.strip()

        # Linha vazia
        if not stripped:
            i += 1
            continue

        # Heading
        m = _H3.match(stripped)
        if m:
            blocos.append(_heading_block(3, m.group(1)))
            i += 1
            continue
        m = _H2.match(stripped)
        if m:
            blocos.append(_heading_block(2, m.group(1)))
            i += 1
            continue
        m = _H1.match(stripped)
        if m:
            blocos.append(_heading_block(1, m.group(1)))
            i += 1
            continue

        # Divisor
        if _HR.match(stripped):
            blocos.append(_divider_block())
            i += 1
            continue

        # Tabela — coletar todas as linhas contíguas de tabela
        if _TABLE_ROW.match(stripped):
            table_lines = []
            while i < len(linhas) and _TABLE_ROW.match(linhas[i].strip()):
                table_lines.append(linhas[i].strip())
                i += 1
            rows = _parse_table_rows(table_lines)
            if rows:
                blocos.extend(_table_to_blocks(rows))
            continue

        # Lista bullet
        m = _BULLET.match(stripped)
        if m:
            blocos.append(_bullet_block(m.group(1)))
            i += 1
            continue

        # Lista numerada
        m = _ORDERED.match(stripped)
        if m:
            blocos.append(_ordered_block(m.group(1)))
            i += 1
            continue

        # Paragrafo — coletar linhas contíguas (soft-wrap)
        para_lines = []
        while i < len(linhas):
            l = linhas[i].strip()
            if (not l or _HR.match(l) or _TABLE_ROW.match(l)
                    or _H1.match(l) or _H2.match(l) or _H3.match(l)
                    or _BULLET.match(l) or _ORDERED.match(l)):
                break
            para_lines.append(linhas[i])
            i += 1
        texto_para = " ".join(p.strip() for p in para_lines if p.strip())
        if texto_para:
            blocos.append(_paragraph_block(texto_para))

    return blocos


# ─────────────────────────────────────────────
# BATCHING
# ─────────────────────────────────────────────

def batch_blocks(blocos: list[dict], tamanho: int = 100) -> list[list[dict]]:
    """Divide lista de blocos em lotes de ate `tamanho` para API Notion."""
    return [blocos[i:i+tamanho] for i in range(0, len(blocos), tamanho)]


# ─────────────────────────────────────────────
# CLI STANDALONE
# ─────────────────────────────────────────────

if __name__ == "__main__":
    import argparse, json as _json
    from pathlib import Path

    parser = argparse.ArgumentParser()
    parser.add_argument("arquivo_md")
    args = parser.parse_args()

    texto = Path(args.arquivo_md).read_text(encoding="utf-8")
    blocos = converter_md_para_blocos(texto)
    lotes  = batch_blocks(blocos)
    print(f"Total: {len(blocos)} blocos em {len(lotes)} lote(s)")
    print(_json.dumps(blocos[:5], ensure_ascii=False, indent=2))
