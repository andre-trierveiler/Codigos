# -*- coding: utf-8 -*-
"""
classificar.py
--------------
Recebe o texto markdown de uma carta de gestão e retorna metadados
estruturados (CartaMetadata) usando o SDK Anthropic diretamente.

Uso standalone:
    python classificar.py "cartas/markdown/Verde/202605 - Verde Asset.md"
"""

import json
import logging
import os
import time
from datetime import date
from enum import Enum
from pathlib import Path
from typing import Literal

import anthropic
from dotenv import load_dotenv
from pydantic import BaseModel, field_validator

load_dotenv(Path(__file__).parent / ".env")

logger = logging.getLogger(__name__)

# ─────────────────────────────────────────────
# ENUMS — espelham o schema do SKILL_notion.md
# ─────────────────────────────────────────────

class TipoEnum(str, Enum):
    transcricao_externa  = "Transcrição de Reunião Externa"
    transcricao_interna  = "Transcrição de Reunião Interna"
    entrevista           = "Entrevista"
    relatorio            = "Relatório"
    carta_de_gestao      = "Carta de Gestão"
    ata                  = "Ata"
    comunicado           = "Comunicado"
    noticia              = "Notícia"
    podcast              = "Podcast"


class FonteEnum(str, Enum):
    # sell-side / macro
    xp_research          = "XP Research"
    itau_bba             = "Itaú BBA"
    btg_pactual          = "BTG Pactual"
    goldman_sachs        = "Goldman Sachs"
    morgan_stanley       = "Morgan Stanley"
    jp_morgan            = "JP Morgan"
    blackrock            = "BlackRock"
    eurasia_group        = "Eurasia Group"
    gavekal              = "Gavekal"
    dragonomics          = "Dragonomics"
    minfazenda           = "Ministério da Fazenda"
    banco_central        = "Banco Central"
    fmi                  = "FMI"
    interno              = "Interno"
    # gestoras
    verde_asset          = "Verde Asset"
    gavea_investimentos  = "Gaveá Investimentos"
    adam_capital         = "Adam Capital"
    bahia_asset          = "Bahia Asset"
    legacy_capital       = "Legacy Capital"
    armor_capital        = "Armor Capital"
    sparta               = "Sparta"
    jgp                  = "JGP"
    azimut               = "Azimut"
    dynamo               = "Dynamo"
    guepardo             = "Guepardo"
    ibiuna_investimentos = "Ibiuña Investimentos"
    kadima               = "Kadima"
    persevera            = "Persevera"


class TemasEnum(str, Enum):
    macro_global         = "Macro Global"
    politica_monetaria   = "Política Monetária"
    fiscal_brasil        = "Fiscal Brasil"
    geopolitica          = "Geopolítica"
    eleicoes_brasil      = "Eleições Brasil"
    eleicoes_eua         = "Eleições EUA"
    mercado_credito      = "Mercado de Crédito"
    renda_variavel       = "Renda Variável"
    commodities          = "Commodities"
    energia              = "Energia"
    china                = "China"
    europa               = "Europa"
    emergentes           = "Emergentes"
    cambio               = "Câmbio"
    japao                = "Japão"


class MercadosEnum(str, Enum):
    brasil     = "Brasil"
    eua        = "EUA"
    china      = "China"
    europa     = "Europa"
    emergentes = "Emergentes"
    global_    = "Global"


class AtivosEnum(str, Enum):
    brl            = "BRL"
    juros          = "Juros"
    petroleo       = "Petróleo"
    commodities    = "Commodities"
    renda_variavel = "Renda Variável"
    cambio         = "Câmbio"
    ouro           = "Ouro"
    credito        = "Crédito"


# ─────────────────────────────────────────────
# MODELO PYDANTIC
# ─────────────────────────────────────────────

class CartaMetadata(BaseModel):
    titulo:               str
    data:                 date
    tipo:                 Literal["Carta de Gestão"] = "Carta de Gestão"
    fonte:                list[FonteEnum]
    temas:                list[TemasEnum]
    mercados:             list[MercadosEnum]
    ativos:               list[AtivosEnum]
    participantes:        str
    keypoints_md:         str
    conteudo_completo_md: str

    @field_validator("fonte", "temas", "mercados", "ativos", mode="before")
    @classmethod
    def deduplicate(cls, v):
        if isinstance(v, list):
            seen = []
            for item in v:
                if item not in seen:
                    seen.append(item)
            return seen
        return v


# ─────────────────────────────────────────────
# SYSTEM PROMPT
# ─────────────────────────────────────────────

_SYSTEM_PROMPT = """
Você é um analista especializado em cartas de gestão de fundos brasileiros.
Dado o texto markdown de uma carta de gestão, extraia metadados estruturados
e produza keypoints conforme o template abaixo.

## Schema de campos

**tipo**: sempre "Carta de Gestão"

**fonte** (MULTI_SELECT — use apenas valores desta lista):
XP Research · Itaú BBA · BTG Pactual · Goldman Sachs · Morgan Stanley · JP Morgan ·
BlackRock · Eurasia Group · Gavekal · Dragonomics · Ministério da Fazenda ·
Banco Central · FMI · Interno · Verde Asset · Gaveá Investimentos · Adam Capital ·
Bahia Asset · Legacy Capital · Armor Capital · Sparta · JGP · Azimut · Dynamo ·
Guepardo · Ibiuña Investimentos · Kadima · Persevera

**temas** (MULTI_SELECT — use apenas valores desta lista):
Macro Global · Política Monetária · Fiscal Brasil · Geopolítica · Eleições Brasil ·
Eleições EUA · Mercado de Crédito · Renda Variável · Commodities · Energia ·
China · Europa · Emergentes · Câmbio · Japão

**mercados** (MULTI_SELECT — use apenas valores desta lista):
Brasil · EUA · China · Europa · Emergentes · Global

**ativos** (MULTI_SELECT — use apenas valores desta lista):
BRL · Juros · Petróleo · Commodities · Renda Variável · Câmbio · Ouro · Crédito

**participantes**: autores da carta (texto livre)

## Template de keypoints

```markdown
## Tese central
[Argumento principal em 2-4 linhas. Direto, sem introdução.]

## 🔺 Pontos fora da curva
[Apenas o que é distinto do conhecimento geral. Mínimo de introdução, máximo de substância.]

## 📐 Frameworks e regras de bolso
[Modelos analíticos, heurísticas, regras de bolso citados. Com fonte quando possível.]

## 📅 Prazos, números e projeções
[Tabela markdown com dados quantitativos relevantes.]

## ⚡ Condicionais: se X então Y
[Lista de relações causais explícitas ou implícitas no documento.]
```

## Instruções para keypoints
- Começar pela tese central — não pela introdução do documento
- Não destacar o óbvio ou o que está no título
- Priorizar: pontos contraintuitivos, frameworks nomeados, regras de bolso, quotes fortes,
  projeções numéricas, relações causais condicionais
- Para gráficos mencionados: descrever o que mostram + extrair dados visíveis

## Conteúdo completo
Limpe o markdown original: remova cabeçalhos duplicados, rodapés, disclaimers legais,
textos de formatação sem conteúdo. Mantenha todo o conteúdo substantivo.
Tabelas → formato markdown. Seções de disclaimer → omitir completamente.

## Saída
Responda APENAS com um objeto JSON válido, sem código fence, sem texto antes ou depois:
{
  "titulo": "...",
  "data": "YYYY-MM-DD",
  "tipo": "Carta de Gestão",
  "fonte": ["..."],
  "temas": ["..."],
  "mercados": ["..."],
  "ativos": ["..."],
  "participantes": "...",
  "keypoints_md": "...",
  "conteudo_completo_md": "..."
}
""".strip()


# ─────────────────────────────────────────────
# FALLBACK DE ENUM
# ─────────────────────────────────────────────

def _valores_validos(enum_cls) -> list[str]:
    return [e.value for e in enum_cls]


def _fallback_enum(valor: str, enum_cls, campo: str) -> str | None:
    """Tenta casar valor inválido com o mais próximo. Loga e retorna None se sem match."""
    validos = _valores_validos(enum_cls)
    valor_lower = valor.lower()
    for v in validos:
        if valor_lower in v.lower() or v.lower() in valor_lower:
            logger.warning(
                "Fallback enum %s: '%s' → '%s'", campo, valor, v
            )
            return v
    logger.warning(
        "Enum %s: '%s' não encontrado e sem fallback — descartado", campo, valor
    )
    return None


def _sanitizar_enum_lista(valores: list, enum_cls, campo: str) -> list:
    """Filtra lista de strings para apenas valores válidos do enum, com fallback."""
    resultado = []
    for v in valores:
        try:
            resultado.append(enum_cls(v).value)
        except ValueError:
            fb = _fallback_enum(v, enum_cls, campo)
            if fb and fb not in resultado:
                resultado.append(fb)
    return resultado


# ─────────────────────────────────────────────
# CLASSIFICAÇÃO
# ─────────────────────────────────────────────

_MODEL_DEFAULT = "claude-haiku-4-5-20251001"


def classificar(
    gestora_key: str,
    ano: int,
    mes: int,
    texto_md: str,
    max_retries: int = 3,
) -> CartaMetadata:
    """
    Classifica uma carta de gestão e retorna CartaMetadata validado.
    Levanta RuntimeError se todos os retries falharem.
    """
    model = os.environ.get("CLASSIFICAR_MODEL", _MODEL_DEFAULT)
    import httpx
    client = anthropic.Anthropic(
        api_key=os.environ["ANTHROPIC_API_KEY"],
        http_client=httpx.Client(verify=False),
    )

    # Truncar texto muito longo para não explodir tokens (~80k chars ≈ ~20k tokens)
    texto_truncado = texto_md[:80_000] if len(texto_md) > 80_000 else texto_md

    user_msg = (
        f"Gestora: {gestora_key}\n"
        f"Período de referência: {mes:02d}/{ano}\n\n"
        f"---\n\n{texto_truncado}"
    )

    ultimo_erro: Exception | None = None
    for tentativa in range(1, max_retries + 1):
        try:
            resposta = client.messages.create(
                model=model,
                max_tokens=8192,
                system=_SYSTEM_PROMPT,
                messages=[{"role": "user", "content": user_msg}],
            )
            raw = resposta.content[0].text.strip()

            # Remover possível code fence residual
            if raw.startswith("```"):
                raw = raw.split("```")[1]
                if raw.startswith("json"):
                    raw = raw[4:]
            raw = raw.strip()

            dados = json.loads(raw)

            # Sanitizar enums com fallback antes de validar Pydantic
            for campo, enum_cls in [
                ("fonte",    FonteEnum),
                ("temas",    TemasEnum),
                ("mercados", MercadosEnum),
                ("ativos",   AtivosEnum),
            ]:
                if isinstance(dados.get(campo), list):
                    dados[campo] = _sanitizar_enum_lista(dados[campo], enum_cls, campo)

            return CartaMetadata(**dados)

        except anthropic.RateLimitError:
            espera = 2 ** tentativa
            logger.warning("Rate limit — aguardando %ds (tentativa %d/%d)", espera, tentativa, max_retries)
            time.sleep(espera)
            ultimo_erro = None  # vale tentar de novo
        except (json.JSONDecodeError, Exception) as e:
            logger.warning("Classificação falhou tentativa %d/%d: %s", tentativa, max_retries, e)
            ultimo_erro = e
            if tentativa < max_retries:
                time.sleep(2 ** tentativa)

    raise RuntimeError(f"Classificação falhou após {max_retries} tentativas: {ultimo_erro}")


# ─────────────────────────────────────────────
# CLI STANDALONE
# ─────────────────────────────────────────────

if __name__ == "__main__":
    import argparse
    import sys

    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(message)s")

    parser = argparse.ArgumentParser(description="Classificar uma carta de gestão")
    parser.add_argument("arquivo_md", help="Caminho para o arquivo .md")
    parser.add_argument("--gestora", default="Desconhecida")
    parser.add_argument("--ano",  type=int, default=date.today().year)
    parser.add_argument("--mes",  type=int, default=date.today().month)
    args = parser.parse_args()

    texto = Path(args.arquivo_md).read_text(encoding="utf-8")
    try:
        meta = classificar(args.gestora, args.ano, args.mes, texto)
        print(meta.model_dump_json(indent=2))
    except Exception as e:
        print(f"Erro: {e}", file=sys.stderr)
        sys.exit(1)
