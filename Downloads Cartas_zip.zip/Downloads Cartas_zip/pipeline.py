# -*- coding: utf-8 -*-
"""
pipeline.py
-----------
Orquestrador ponta a ponta: download -> MD -> classificacao -> Notion KB -> PDF pasta -> link.

Uso:
    python pipeline.py                              # todas as gestoras
    python pipeline.py --gestoras Verde JGP         # so essas gestoras
    python pipeline.py --desde-ano 2026 --desde-mes 3
    python pipeline.py --skip-notion                # so download + MD, sem Notion
    python pipeline.py --drive                      # tambem sobe no Google Drive
    python pipeline.py --apenas-novas               # pula PDFs ja existentes localmente
"""

import argparse
import asyncio
import csv
import logging
import os
import sys
import traceback
from datetime import datetime
from pathlib import Path

from dotenv import load_dotenv

load_dotenv(Path(__file__).parent / ".env")

# Forcar stdout UTF-8 no Windows
if sys.stdout.encoding and sys.stdout.encoding.lower() not in ("utf-8", "utf8"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)-8s %(name)s - %(message)s",
    datefmt="%H:%M:%S",
)
logger = logging.getLogger("pipeline")
logging.getLogger("httpx").setLevel(logging.WARNING)
logging.getLogger("httpcore").setLevel(logging.WARNING)

from gestoras import GESTORAS, get_links

# Importar Download Cartas.py (nome com espaco)
import importlib.util as _ilu

_spec = _ilu.spec_from_file_location(
    "download_cartas",
    Path(__file__).parent / "Download Cartas.py",
)
_dc = _ilu.module_from_spec(_spec)  # type: ignore
_spec.loader.exec_module(_dc)       # type: ignore

baixar_pdf         = _dc.baixar_pdf
_playwright_html   = _dc._playwright_html
_playwright_pdf    = _dc._playwright_pdf
pdf_para_markdown  = _dc.pdf_para_markdown
html_para_markdown = _dc.html_para_markdown
nome_arquivo       = _dc.nome_arquivo

# Pastas locais absolutas (funciona independente do cwd)
_BASE = Path(__file__).parent
PASTA_LOCAL_PDF = _BASE / "cartas" / "pdf"
PASTA_LOCAL_MD  = _BASE / "cartas" / "markdown"

# ─────────────────────────────────────────────
# CSV LOG
# ─────────────────────────────────────────────

_CSV_COLUNAS = [
    "gestora", "ano", "mes", "arquivo",
    "download", "conversao_md", "classificacao",
    "kb_criada", "pasta_pdf", "link_pdf", "kb_url", "erro",
]


def _abrir_csv_log() -> tuple[Path, csv.DictWriter, object]:
    ts   = datetime.now().strftime("%Y%m%d_%H%M%S")
    path = _BASE / f"pipeline_log_{ts}.csv"
    fh   = open(path, "w", newline="", encoding="utf-8")
    writer = csv.DictWriter(fh, fieldnames=_CSV_COLUNAS)
    writer.writeheader()
    return path, writer, fh


def _linha_log(**kwargs) -> dict:
    linha = {col: "" for col in _CSV_COLUNAS}
    linha.update(kwargs)
    return linha


# ─────────────────────────────────────────────
# FLUXO POR CARTA
# ─────────────────────────────────────────────

async def _processar_carta(
    gestora_key: str,
    url: str,
    ano: int,
    mes: int,
    titulo: str | None,
    skip_notion: bool,
    usar_drive: bool,
    gdrive_service,
    gdrive_folder_pdf: str | None,
    notion,
    manifest: dict,
    pular_download: bool = False,
) -> dict:
    from notion_kb import (
        checar_duplicata, criar_nota_kb, patch_pdf_original,
        registrar_manifest, upload_pasta_pdf,
    )
    from classificar import classificar

    nome_pdf    = nome_arquivo(gestora_key, ano, mes, titulo, "pdf")
    nome_md     = nome_arquivo(gestora_key, ano, mes, titulo, "md")
    pasta_pdf   = PASTA_LOCAL_PDF / gestora_key
    pasta_md    = PASTA_LOCAL_MD  / gestora_key
    caminho_pdf = pasta_pdf / nome_pdf
    caminho_md  = pasta_md  / nome_md

    pasta_pdf.mkdir(parents=True, exist_ok=True)
    pasta_md.mkdir(parents=True, exist_ok=True)

    log = _linha_log(gestora=gestora_key, ano=ano, mes=mes, arquivo=nome_pdf)
    print(f"  -> {nome_pdf}")

    gestora = GESTORAS[gestora_key]

    # ── 1. Download ───────────────────────────
    pdf_ok = False
    html_content = None

    if pular_download and caminho_pdf.exists():
        pdf_ok = True
        log["download"] = "skip (ja existe)"
        print(f"    download pulado (arquivo ja existe)")
    else:
        try:
            if gestora["tipo_url"] == "pdf_direto":
                pdf_ok = baixar_pdf(url, caminho_pdf)
            else:
                html_content = await _playwright_html(url)
                if html_content:
                    pdf_ok = await _playwright_pdf(url, caminho_pdf)
            log["download"] = "ok" if pdf_ok else "fail"
        except Exception as e:
            log["download"] = "fail"
            log["erro"]     = f"download: {e}"
            print(f"    ERRO download: {e}")
            return log

        if not pdf_ok:
            print(f"    nao encontrado")
            return log

    # ── 2. PDF -> Markdown ────────────────────
    md_ok = False
    if pular_download and caminho_md.exists():
        md_ok = True
        log["conversao_md"] = "skip (ja existe)"
    else:
        try:
            if gestora["tipo_url"] == "pagina_web" and html_content:
                md_ok = html_para_markdown(html_content, caminho_md)
            else:
                md_ok = pdf_para_markdown(caminho_pdf, caminho_md)
            log["conversao_md"] = "ok" if md_ok else "fail"
        except Exception as e:
            log["conversao_md"] = "fail"
            log["erro"] = f"md: {e}"
            print(f"    AVISO conversao MD: {e}")

    # ── 3. Google Drive (opcional) ────────────
    if usar_drive and gdrive_service and pdf_ok:
        try:
            _dc.upload_gdrive(gdrive_service, caminho_pdf, gdrive_folder_pdf)
            if md_ok:
                _dc.upload_gdrive(gdrive_service, caminho_md, gdrive_folder_pdf)
            print(f"    Drive OK")
        except Exception as e:
            logger.warning("Drive upload falhou: %s", e)

    if skip_notion:
        log["kb_criada"] = "skip-notion"
        log["pasta_pdf"] = "skip-notion"
        print(f"    OK (sem Notion)")
        return log

    if not md_ok:
        log["erro"]          = (log.get("erro") or "") + " | MD indisponivel"
        log["classificacao"] = "skip"
        log["kb_criada"]     = "skip"
        return log

    # ── 4. Checar duplicata ───────────────────
    if checar_duplicata(manifest, gestora_key, ano, mes):
        log["kb_criada"] = "duplicata"
        print(f"    duplicata - pulando Notion")
        return log

    # ── 5. Classificacao ──────────────────────
    try:
        texto_md = caminho_md.read_text(encoding="utf-8")
        meta = classificar(gestora_key, ano, mes, texto_md)
        log["classificacao"] = "ok"
        print(f"    classificado: {meta.titulo}")
    except Exception as e:
        log["classificacao"] = "fail"
        log["erro"] = f"classif: {e}"
        print(f"    ERRO classificacao: {e}")
        return log

    # ── 6. Criar nota KB ──────────────────────
    kb_page_id = ""
    kb_url     = ""
    try:
        kb_page_id, kb_url = criar_nota_kb(notion, meta)
        log["kb_criada"] = "ok"
        log["kb_url"]    = kb_url
        print(f"    KB criada: {kb_url}")
    except Exception as e:
        log["kb_criada"] = "fail"
        log["erro"] = f"kb: {e}"
        print(f"    ERRO criar KB: {e}")
        return log

    # ── 7. Upload PDF na pasta Notion ─────────
    pasta_page_id = ""
    pasta_url     = ""
    try:
        pasta_page_id, pasta_url = upload_pasta_pdf(
            notion,
            caminho_pdf,
            pasta_nome=gestora["pasta_notion"],
            titulo=meta.titulo,
        )
        log["pasta_pdf"] = "ok"
        log["link_pdf"]  = pasta_url
        print(f"    PDF pasta: {pasta_url}")
    except Exception as e:
        log["pasta_pdf"] = "fail"
        log["erro"] = (log.get("erro") or "") + f" | pasta: {e}"
        print(f"    AVISO upload pasta: {e}")

    # ── 8. Patch PDF Original na nota KB ──────
    if kb_page_id and pasta_url:
        try:
            patch_pdf_original(notion, kb_page_id, pasta_url)
            print(f"    link PDF atualizado na nota")
        except Exception as e:
            log["erro"] = (log.get("erro") or "") + f" | patch: {e}"
            logger.warning("Patch PDF Original falhou: %s", e)

    registrar_manifest(
        manifest, gestora_key, ano, mes,
        kb_page_id=kb_page_id, kb_url=kb_url,
        pasta_page_id=pasta_page_id, pasta_url=pasta_url,
    )

    print(f"    OK")
    return log


# ─────────────────────────────────────────────
# ORQUESTRADOR POR GESTORA
# ─────────────────────────────────────────────

async def processar_gestora(
    gestora_key: str,
    skip_notion: bool,
    usar_drive: bool,
    desde_ano: int | None,
    desde_mes: int | None,
    apenas_novas: bool,
    gdrive_service,
    notion,
    manifest: dict,
    csv_writer: csv.DictWriter,
) -> tuple[int, int, int]:
    gestora = GESTORAS[gestora_key]
    print(f"\n{'─'*60}")
    print(f"  {gestora['nome']} ({gestora['frequencia']})")
    print(f"{'─'*60}")

    gdrive_folder_pdf = None
    if usar_drive and gdrive_service:
        gdrive_root = os.environ.get("GDRIVE_FOLDER_ID", "")
        pasta_gestora     = _dc._gdrive_get_or_create_folder(gdrive_service, gestora["nome"], gdrive_root)
        gdrive_folder_pdf = _dc._gdrive_get_or_create_folder(gdrive_service, "PDF", pasta_gestora)

    ok = skip = erro = 0

    for item in get_links(gestora_key, desde_ano=desde_ano, desde_mes=desde_mes):
        if len(item) == 4:
            url, ano, mes, titulo = item
        else:
            url, ano, mes = item
            titulo = None

        nome_pdf    = nome_arquivo(gestora_key, ano, mes, titulo, "pdf")
        caminho_pdf = PASTA_LOCAL_PDF / gestora_key / nome_pdf
        caminho_md  = PASTA_LOCAL_MD  / gestora_key / nome_arquivo(gestora_key, ano, mes, titulo, "md")

        # --apenas-novas: pula download se arquivo já existe, mas continua para Notion
        arquivo_existe = caminho_pdf.exists() and caminho_md.exists()

        try:
            log = await _processar_carta(
                gestora_key=gestora_key,
                url=url, ano=ano, mes=mes, titulo=titulo,
                skip_notion=skip_notion,
                usar_drive=usar_drive,
                gdrive_service=gdrive_service,
                gdrive_folder_pdf=gdrive_folder_pdf,
                notion=notion,
                manifest=manifest,
                pular_download=apenas_novas and arquivo_existe,
            )
        except Exception as e:
            logger.error("Erro inesperado %s %d/%02d: %s", gestora_key, ano, mes, traceback.format_exc())
            log = _linha_log(gestora=gestora_key, ano=ano, mes=mes, arquivo=nome_pdf, erro=str(e))

        csv_writer.writerow(log)

        if log.get("download") == "fail":
            erro += 1
        elif log.get("kb_criada") == "duplicata":
            skip += 1
        elif log.get("kb_criada") in ("ok", "skip-notion") or (skip_notion and log.get("conversao_md") == "ok"):
            ok += 1
        else:
            erro += 1

    print(f"\n  Resultado: {ok} OK | {skip} puladas | {erro} erros")
    return ok, skip, erro


# ─────────────────────────────────────────────
# MAIN
# ─────────────────────────────────────────────

async def main(
    gestoras_selecionadas: list[str] | None,
    skip_notion: bool,
    usar_drive: bool,
    desde_ano: int | None,
    desde_mes: int | None,
    apenas_novas: bool,
):
    keys = gestoras_selecionadas or list(GESTORAS.keys())
    invalidas = [k for k in keys if k not in GESTORAS]
    if invalidas:
        print(f"Gestoras invalidas: {invalidas}")
        print(f"Disponiveis: {list(GESTORAS.keys())}")
        return

    # Notion
    notion   = None
    manifest = {}
    if not skip_notion:
        try:
            from notion_kb import get_notion_client, sincronizar_schema_fonte, carregar_manifest
            notion = get_notion_client()
            sincronizar_schema_fonte(notion)
            manifest = carregar_manifest()
        except Exception as e:
            print(f"ERRO ao conectar ao Notion: {e}")
            print("  Use --skip-notion para rodar sem Notion.")
            return

    # Google Drive
    gdrive_service = None
    if usar_drive:
        gdrive_root = os.environ.get("GDRIVE_FOLDER_ID", "")
        if not gdrive_root:
            print("GDRIVE_FOLDER_ID nao configurado.")
            return
        print("Autenticando no Google Drive...")
        gdrive_service = _dc._gdrive_service()
        print("  Drive autenticado")

    log_path, csv_writer, csv_fh = _abrir_csv_log()
    print(f"\nLog CSV: {log_path}")

    total_ok = total_skip = total_erro = 0

    try:
        for key in keys:
            ok, skip, erro = await processar_gestora(
                gestora_key=key,
                skip_notion=skip_notion,
                usar_drive=usar_drive,
                desde_ano=desde_ano,
                desde_mes=desde_mes,
                apenas_novas=apenas_novas,
                gdrive_service=gdrive_service,
                notion=notion,
                manifest=manifest,
                csv_writer=csv_writer,
            )
            total_ok   += ok
            total_skip += skip
            total_erro += erro
    finally:
        csv_fh.flush()
        csv_fh.close()
        if not skip_notion and manifest:
            from notion_kb import salvar_manifest
            salvar_manifest(manifest)

    print(f"\n{'='*60}")
    print(f"  Total: {total_ok} OK | {total_skip} puladas | {total_erro} erros")
    print(f"  Log: {log_path}")
    print(f"{'='*60}\n")


# ─────────────────────────────────────────────
# CLI
# ─────────────────────────────────────────────

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Pipeline Cartas de Gestao -> Notion KB")
    parser.add_argument("--gestoras",     nargs="+",           help="Gestoras a processar (ex: Verde JGP)")
    parser.add_argument("--desde-ano",    type=int,            help="Ano de corte (ex: 2026)")
    parser.add_argument("--desde-mes",    type=int,            help="Mes de corte (ex: 3)")
    parser.add_argument("--apenas-novas", action="store_true", help="Pular PDFs ja existentes localmente")
    parser.add_argument("--skip-notion",  action="store_true", help="So download + MD, sem Notion")
    parser.add_argument("--drive",        action="store_true", help="Tambem subir no Google Drive")
    args = parser.parse_args()

    asyncio.run(main(
        gestoras_selecionadas=args.gestoras,
        skip_notion=args.skip_notion,
        usar_drive=args.drive,
        desde_ano=args.desde_ano,
        desde_mes=args.desde_mes,
        apenas_novas=args.apenas_novas,
    ))
