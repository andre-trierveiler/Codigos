# -*- coding: utf-8 -*-
"""
Download Cartas.py
------------------
Download de cartas de gestão em PDF e conversão para Markdown.

Uso rápido:
    python "Download Cartas.py"                         # salva localmente
    python "Download Cartas.py" --drive                 # salva no Google Drive
    python "Download Cartas.py" --gestoras Verde JGP    # só essas gestoras
    python "Download Cartas.py" --desde 2024            # só a partir de 2024
    python "Download Cartas.py" --apenas-novas          # pula arquivos já existentes

Dependências:
    pip install requests tqdm playwright html2text pymupdf google-api-python-client google-auth-httplib2 google-auth-oauthlib
    playwright install chromium
"""

import asyncio
import argparse
import re
import io
import mimetypes
import os
from pathlib import Path
from urllib.parse import urlparse

import fitz                         # PyMuPDF
import html2text
import requests
from tqdm import tqdm
from playwright.async_api import async_playwright, TimeoutError as PlaywrightTimeoutError

from gestoras import GESTORAS, get_links

# ─────────────────────────────────────────────
# CONFIGURAÇÃO
# ─────────────────────────────────────────────

PASTA_LOCAL_PDF = Path("cartas/pdf")
PASTA_LOCAL_MD  = Path("cartas/markdown")

# ID da pasta raiz no Google Drive onde serão criadas subpastas por gestora
GDRIVE_FOLDER_ID = os.environ.get("GDRIVE_FOLDER_ID", "")

# Credenciais OAuth do Google (baixe em console.cloud.google.com)
GDRIVE_CREDENTIALS_FILE = Path(__file__).parent / "gdrive_credentials.json"
GDRIVE_TOKEN_FILE        = Path(__file__).parent / "gdrive_token.json"

# ─────────────────────────────────────────────
# NOMENCLATURA
# ─────────────────────────────────────────────

def _sanitizar(texto: str) -> str:
    return re.sub(r'[<>:"/\\|?*]', "", texto).strip()


def nome_arquivo(gestora_key: str, ano: int, mes: int, titulo: str | None = None, ext: str = "pdf") -> str:
    """
    Retorna: "yyyymm - Nome Gestora - Titulo.ext"
    Exemplo: "202603 - Verde Asset - Carta Mensal.pdf"
    """
    nome_gestora = _sanitizar(GESTORAS[gestora_key]["nome"])
    if titulo:
        titulo_limpo = _sanitizar(titulo)
        return f"{ano}{mes:02d} - {nome_gestora} - {titulo_limpo}.{ext}"
    return f"{ano}{mes:02d} - {nome_gestora}.{ext}"


# ─────────────────────────────────────────────
# DOWNLOAD PDF DIRETO
# ─────────────────────────────────────────────

_SESSION = None

def _get_session() -> requests.Session:
    global _SESSION
    if _SESSION is None:
        import urllib3
        urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
        s = requests.Session()
        s.verify = False  # Windows: evita falha de certificado SSL local
        s.headers.update({
            "User-Agent": (
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                "AppleWebKit/537.36 (KHTML, like Gecko) "
                "Chrome/124.0.0.0 Safari/537.36"
            ),
            "Accept": "application/pdf,application/octet-stream,*/*",
            "Accept-Language": "pt-BR,pt;q=0.9",
        })
        _SESSION = s
    return _SESSION


def baixar_pdf(url: str, destino: Path, timeout: int = 30) -> bool:
    """Tenta baixar um PDF direto. Retorna True se teve sucesso."""
    parsed = urlparse(url)
    try:
        resp = _get_session().get(
            url, stream=True, timeout=timeout,
            headers={"Referer": f"{parsed.scheme}://{parsed.netloc}/"},
        )
        resp.raise_for_status()

        content_type = resp.headers.get("content-type", "")
        if "html" in content_type:
            return False

        total = int(resp.headers.get("content-length", 0))
        with open(destino, "wb") as f, tqdm(
            desc=destino.name, total=total, unit="B",
            unit_scale=True, unit_divisor=1024, leave=False,
        ) as bar:
            for chunk in resp.iter_content(chunk_size=8192):
                if chunk:
                    f.write(chunk)
                    bar.update(len(chunk))
        return True

    except requests.exceptions.HTTPError:
        return False
    except Exception as e:
        print(f"    ⚠ {e}")
        return False


# ─────────────────────────────────────────────
# DOWNLOAD VIA PLAYWRIGHT (páginas web)
# ─────────────────────────────────────────────

async def _playwright_pdf(url: str, destino: Path, timeout: int = 60000) -> bool:
    try:
        async with async_playwright() as p:
            browser = await p.chromium.launch(headless=True)
            page    = await browser.new_page()
            await page.goto(url, wait_until="networkidle", timeout=timeout)
            await page.wait_for_timeout(3000)
            await page.pdf(path=str(destino), format="A4", print_background=True)
            await browser.close()
        return True
    except PlaywrightTimeoutError:
        print(f"    ⚠ Timeout: {url}")
        return False
    except Exception as e:
        print(f"    ⚠ {e}")
        return False


async def _playwright_html(url: str, timeout: int = 60000) -> str | None:
    try:
        async with async_playwright() as p:
            browser = await p.chromium.launch(headless=True)
            page    = await browser.new_page()
            await page.goto(url, wait_until="networkidle", timeout=timeout)
            await page.wait_for_timeout(3000)
            html = await page.content()
            await browser.close()
        return html
    except Exception as e:
        print(f"    ⚠ {e}")
        return None


# ─────────────────────────────────────────────
# CONVERSÃO PDF → MARKDOWN
# ─────────────────────────────────────────────

def pdf_para_markdown(pdf_path: Path, md_path: Path) -> bool:
    try:
        doc = fitz.open(pdf_path)
        linhas = []
        for pagina in doc:
            texto = pagina.get_text().strip()
            if texto:
                linhas.append(f"\n\n---\n\n{texto}")
        doc.close()
        md_path.write_text("".join(linhas), encoding="utf-8")
        return True
    except Exception as e:
        print(f"    ⚠ Erro ao converter PDF→MD: {e}")
        return False


def html_para_markdown(html: str, md_path: Path) -> bool:
    try:
        conv = html2text.HTML2Text()
        conv.ignore_links  = False
        conv.ignore_images = True
        conv.body_width    = 0
        md_path.write_text(conv.handle(html), encoding="utf-8")
        return True
    except Exception as e:
        print(f"    ⚠ Erro ao converter HTML→MD: {e}")
        return False


# ─────────────────────────────────────────────
# GOOGLE DRIVE
# ─────────────────────────────────────────────

def _gdrive_service():
    from google.oauth2.credentials import Credentials
    from google_auth_oauthlib.flow import InstalledAppFlow
    from google.auth.transport.requests import Request
    from googleapiclient.discovery import build

    SCOPES = ["https://www.googleapis.com/auth/drive.file"]
    creds  = None

    if GDRIVE_TOKEN_FILE.exists():
        creds = Credentials.from_authorized_user_file(str(GDRIVE_TOKEN_FILE), SCOPES)

    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            flow  = InstalledAppFlow.from_client_secrets_file(str(GDRIVE_CREDENTIALS_FILE), SCOPES)
            creds = flow.run_local_server(port=0)
        GDRIVE_TOKEN_FILE.write_text(creds.to_json())

    return build("drive", "v3", credentials=creds)


_GDRIVE_FOLDER_CACHE: dict[str, str] = {}

def _gdrive_get_or_create_folder(service, nome: str, parent_id: str) -> str:
    cache_key = f"{parent_id}/{nome}"
    if cache_key in _GDRIVE_FOLDER_CACHE:
        return _GDRIVE_FOLDER_CACHE[cache_key]

    q = (
        f"name='{nome}' and mimeType='application/vnd.google-apps.folder' "
        f"and '{parent_id}' in parents and trashed=false"
    )
    res = service.files().list(q=q, fields="files(id)").execute()
    items = res.get("files", [])
    if items:
        folder_id = items[0]["id"]
    else:
        meta = {
            "name": nome,
            "mimeType": "application/vnd.google-apps.folder",
            "parents": [parent_id],
        }
        folder = service.files().create(body=meta, fields="id").execute()
        folder_id = folder["id"]

    _GDRIVE_FOLDER_CACHE[cache_key] = folder_id
    return folder_id


def upload_gdrive(service, arquivo: Path, folder_id: str) -> str:
    from googleapiclient.http import MediaFileUpload

    mime, _ = mimetypes.guess_type(str(arquivo))
    mime = mime or "application/octet-stream"

    media = MediaFileUpload(str(arquivo), mimetype=mime, resumable=True)
    meta  = {"name": arquivo.name, "parents": [folder_id]}

    f = service.files().create(body=meta, media_body=media, fields="id,webViewLink").execute()
    return f.get("webViewLink", "")


# ─────────────────────────────────────────────
# ORQUESTRADOR PRINCIPAL
# ─────────────────────────────────────────────

async def processar_gestora(
    gestora_key: str,
    usar_drive: bool = False,
    desde_ano: int | None = None,
    desde_mes: int | None = None,
    apenas_novas: bool = False,
    gdrive_service=None,
):
    gestora = GESTORAS[gestora_key]
    print(f"\n{'─'*60}")
    print(f"  {gestora['nome']} ({gestora['frequencia']})")
    print(f"{'─'*60}")

    pasta_pdf = PASTA_LOCAL_PDF / gestora_key
    pasta_md  = PASTA_LOCAL_MD  / gestora_key
    pasta_pdf.mkdir(parents=True, exist_ok=True)
    pasta_md.mkdir(parents=True, exist_ok=True)

    gdrive_folder_pdf = None
    gdrive_folder_md  = None
    if usar_drive and gdrive_service:
        pasta_gestora     = _gdrive_get_or_create_folder(gdrive_service, gestora["nome"], GDRIVE_FOLDER_ID)
        gdrive_folder_pdf = _gdrive_get_or_create_folder(gdrive_service, "PDF",      pasta_gestora)
        gdrive_folder_md  = _gdrive_get_or_create_folder(gdrive_service, "Markdown", pasta_gestora)

    ok = 0
    skip = 0
    erro = 0

    for item in get_links(gestora_key, desde_ano=desde_ano, desde_mes=desde_mes):
        if len(item) == 4:
            url, ano, mes, titulo = item
        else:
            url, ano, mes = item
            titulo = None

        nome_pdf = nome_arquivo(gestora_key, ano, mes, titulo, "pdf")
        nome_md  = nome_arquivo(gestora_key, ano, mes, titulo, "md")
        caminho_pdf = pasta_pdf / nome_pdf
        caminho_md  = pasta_md  / nome_md

        if apenas_novas and caminho_pdf.exists() and caminho_md.exists():
            skip += 1
            continue

        print(f"  ↓ {nome_pdf}")

        # ── Download ─────────────────────────────
        pdf_ok = False
        html_content = None

        if gestora["tipo_url"] == "pdf_direto":
            pdf_ok = baixar_pdf(url, caminho_pdf)
        else:
            # página web: salva PDF via playwright e captura HTML para MD
            html_content = await _playwright_html(url)
            if html_content:
                pdf_ok = await _playwright_pdf(url, caminho_pdf)

        if not pdf_ok:
            print(f"    ✗ Não encontrado")
            erro += 1
            continue

        # ── PDF → Markdown ───────────────────────
        if gestora["tipo_url"] == "pagina_web" and html_content:
            md_ok = html_para_markdown(html_content, caminho_md)
        else:
            md_ok = pdf_para_markdown(caminho_pdf, caminho_md)

        if not md_ok:
            print(f"    ⚠ MD falhou")

        # ── Google Drive ─────────────────────────
        if usar_drive and gdrive_service:
            try:
                upload_gdrive(gdrive_service, caminho_pdf, gdrive_folder_pdf)
                if md_ok:
                    upload_gdrive(gdrive_service, caminho_md, gdrive_folder_md)
                print(f"    ☁ Drive OK")
            except Exception as e:
                print(f"    ⚠ Drive: {e}")

        print(f"    ✓ OK")
        ok += 1

    print(f"\n  Resultado: {ok} baixados · {skip} pulados · {erro} não encontrados")


async def main(
    gestoras_selecionadas: list[str] | None = None,
    usar_drive: bool = False,
    desde_ano: int | None = None,
    desde_mes: int | None = None,
    apenas_novas: bool = False,
):
    keys = gestoras_selecionadas or list(GESTORAS.keys())
    invalidas = [k for k in keys if k not in GESTORAS]
    if invalidas:
        print(f"Gestoras inválidas: {invalidas}")
        print(f"Disponíveis: {list(GESTORAS.keys())}")
        return

    gdrive_service = None
    if usar_drive:
        if not GDRIVE_FOLDER_ID:
            print("⚠ GDRIVE_FOLDER_ID não configurado. Defina a variável de ambiente ou edite o script.")
            return
        if not GDRIVE_CREDENTIALS_FILE.exists():
            print(f"⚠ Arquivo de credenciais não encontrado: {GDRIVE_CREDENTIALS_FILE}")
            return
        print("🔑 Autenticando no Google Drive...")
        gdrive_service = _gdrive_service()
        print("   ✓ Autenticado")

    for key in keys:
        await processar_gestora(
            key,
            usar_drive=usar_drive,
            desde_ano=desde_ano,
            desde_mes=desde_mes,
            apenas_novas=apenas_novas,
            gdrive_service=gdrive_service,
        )

    print(f"\n{'═'*60}")
    print("  Concluído!")
    print(f"{'═'*60}\n")


# ─────────────────────────────────────────────
# CLI
# ─────────────────────────────────────────────

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Download de cartas de gestão")
    parser.add_argument("--drive",        action="store_true", help="Salvar também no Google Drive")
    parser.add_argument("--gestoras",     nargs="+",           help="Gestoras a processar (ex: Verde JGP)")
    parser.add_argument("--desde-ano",    type=int,            help="Ano de corte (ex: 2026)")
    parser.add_argument("--desde-mes",    type=int,            help="Mês de corte junto com --desde-ano (ex: 3)")
    parser.add_argument("--apenas-novas", action="store_true", help="Pular arquivos já existentes localmente")
    args = parser.parse_args()

    asyncio.run(main(
        gestoras_selecionadas=args.gestoras,
        usar_drive=args.drive,
        desde_ano=args.desde_ano,
        desde_mes=args.desde_mes,
        apenas_novas=args.apenas_novas,
    ))
