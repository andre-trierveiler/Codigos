# -*- coding: utf-8 -*-
"""
gestoras.py
-----------
Catálogo de gestoras e geração de listas de URLs de cartas de gestão.

Cada gestora tem:
    nome            : nome usado no nome do arquivo salvo
    frequencia      : "mensal" | "trimestral" | "manual"
    tipo_url        : "pdf_direto" | "pagina_web"
    pasta_notion    : pasta de destino no Notion
    ano_inicio      : primeiro ano do histórico de cartas
    mes_inicio      : primeiro mês do histórico (default 1)
    links_fn        : função geradora de (url, ano, mes) ou (url, ano, mes, titulo)

Para atualizar APENAS as cartas novas a partir de um determinado período, use:
    get_links(gestora_key, desde_ano=2026, desde_mes=3)
"""

from datetime import date
from typing import Generator

# ─────────────────────────────────────────────
# HELPERS DE CALENDÁRIO
# ─────────────────────────────────────────────

MESES_PT = {
    1: "Janeiro", 2: "Fevereiro", 3: "Marco",    4: "Abril",
    5: "Maio",    6: "Junho",     7: "Julho",     8: "Agosto",
    9: "Setembro",10: "Outubro",  11: "Novembro", 12: "Dezembro",
}
MESES_ABREV = {
    1: "Jan", 2: "Fev", 3: "Mar", 4: "Abr",
    5: "Mai", 6: "Jun", 7: "Jul", 8: "Ago",
    9: "Set", 10: "Out", 11: "Nov", 12: "Dez",
}
MESES_ABREV_MIN = {k: v.lower() for k, v in MESES_ABREV.items()}


def meses_no_intervalo(
    ano_inicio: int,
    mes_inicio: int = 1,
    desde_ano: int | None = None,
    desde_mes: int | None = None,
) -> Generator[tuple[int, int], None, None]:
    """
    Gera (ano, mes) de ano_inicio/mes_inicio até hoje.
    Se desde_ano/desde_mes forem fornecidos, pula meses anteriores a esse ponto.
    """
    hoje = date.today()
    corte_ano = desde_ano or ano_inicio
    corte_mes = desde_mes or mes_inicio

    for ano in range(ano_inicio, hoje.year + 1):
        for mes in range(1, 13):
            if ano == ano_inicio and mes < mes_inicio:
                continue
            if ano < corte_ano or (ano == corte_ano and mes < corte_mes):
                continue
            if ano > hoje.year or (ano == hoje.year and mes > hoje.month):
                return
            yield ano, mes


def trimestres_no_intervalo(
    ano_inicio: int,
    desde_ano: int | None = None,
    desde_mes: int | None = None,
) -> Generator[tuple[int, int], None, None]:
    """Gera (ano, mes_fim_trimestre): mar=3, jun=6, set=9, dez=12"""
    for ano, mes in meses_no_intervalo(ano_inicio, desde_ano=desde_ano, desde_mes=desde_mes):
        if mes in (3, 6, 9, 12):
            yield ano, mes


def numero_periodico(ano: int, mes: int, ano_base: int, mes_base: int, numero_base: int, frequencia: int = 4) -> int:
    """Calcula número sequencial de uma carta periódica."""
    diferenca_meses   = (ano - ano_base) * 12 + (mes - mes_base)
    meses_por_periodo = 12 // frequencia
    return numero_base + diferenca_meses // meses_por_periodo


# ─────────────────────────────────────────────
# FUNÇÕES GERADORAS POR GESTORA
# ─────────────────────────────────────────────

def _links_verde(desde_ano=None, desde_mes=None):
    for ano, mes in meses_no_intervalo(1998, desde_ano=desde_ano, desde_mes=desde_mes):
        yield (
            f"https://www.verdeasset.com.br/public/files/rel_gestao/158094/Verde-REL-{ano}_{mes:02d}.pdf",
            ano, mes,
        )


def _links_gavea(desde_ano=None, desde_mes=None):
    for ano, mes in meses_no_intervalo(2015, desde_ano=desde_ano, desde_mes=desde_mes):
        pub_mes = mes + 1 if mes < 12 else 1
        pub_ano = ano if mes < 12 else ano + 1
        yield (
            f"https://www.gaveainvest.com.br/wp-content/uploads/{pub_ano}/{pub_mes:02d}"
            f"/Relatorio-Mensal-GM-{MESES_PT[mes]}-{ano}.pdf",
            ano, mes,
        )


def _links_adam(desde_ano=None, desde_mes=None):
    for ano, mes in meses_no_intervalo(2020, desde_ano=desde_ano, desde_mes=desde_mes):
        pub_mes = mes + 1 if mes < 12 else 1
        pub_ano = ano if mes < 12 else ano + 1
        yield (
            f"https://adamcapital.com.br/wp-content/uploads/{pub_ano}/{pub_mes:02d}"
            f"/Carta-Mensal-{MESES_ABREV[mes]}-{ano}.pdf",
            ano, mes,
        )


def _links_bahia(desde_ano=None, desde_mes=None):
    for ano, mes in meses_no_intervalo(2015, desde_ano=desde_ano, desde_mes=desde_mes):
        pub_mes = mes + 1 if mes < 12 else 1
        pub_ano = ano if mes < 12 else ano + 1
        yield (
            f"https://www.bahiaasset.com.br/wp-content/uploads/{pub_ano}/{pub_mes:02d}"
            f"/carta_do_gestor_{MESES_ABREV_MIN[mes]}{ano % 100:02d}.pdf",
            ano, mes,
        )


def _links_legacy(desde_ano=None, desde_mes=None):
    for ano, mes in meses_no_intervalo(2015, desde_ano=desde_ano, desde_mes=desde_mes):
        yield (
            f"https://www.legacycapital.com.br/wp-content/uploads/{ano}{mes:02d}_Carta-Mensal.pdf",
            ano, mes,
        )


def _links_armor(desde_ano=None, desde_mes=None):
    for ano, mes in meses_no_intervalo(2020, desde_ano=desde_ano, desde_mes=desde_mes):
        pub_mes = mes + 1 if mes < 12 else 1
        pub_ano = ano if mes < 12 else ano + 1
        yield (
            f"https://armorcapital.com.br/wp-content/uploads/{pub_ano}/{pub_mes:02d}"
            f"/{ano}{mes:02d}_CartaMensalArmorCapital.pdf",
            ano, mes,
        )



links_kapitalo = [
    f"https://www.kapitalo.com.br/wp-content/uploads/"
    f"{pasta}/"
    f"Carta-{var0}K10{separador}{MESES_PT[mes]}{var1}{ano}{var2}.pdf"
    for pasta in ["2022/09","2020/02"]
    for ano in range(2026, 2026)
    for mes in range(1, 13)
    for var0 in ["","do-Gestor-","do-Gestor_"]
    for var1 in ["", "-"]
    for var2 in ["", "-1","-VF","-final",'-2','V1','V2','V3']
    for separador in ['-','_']
    if not (ano == 2026 and mes > 6)]

def _links_sparta(desde_ano=None, desde_mes=None):
    for ano, mes in meses_no_intervalo(2025, desde_ano=desde_ano, desde_mes=desde_mes):
        yield (
            f"https://www.sparta.com.br/uploads/CartaMensal_{ano}{mes:02d}.pdf",
            ano, mes,
        )


def _links_jgp(desde_ano=None, desde_mes=None):
    for ano, mes in meses_no_intervalo(2020, desde_ano=desde_ano, desde_mes=desde_mes):
        pub_mes = mes + 1 if mes < 12 else 1
        pub_ano = ano if mes < 12 else ano + 1
        yield (
            f"https://jgp.com.br/wp-content/uploads/{pub_ano}/{pub_mes:02d}"
            f"/JGP_Carta-Macroeconomica_{MESES_ABREV[mes]}{ano % 100:02d}.pdf",
            ano, mes,
        )


def _links_azimut(desde_ano=None, desde_mes=None):
    """URLs de páginas web (não PDF direto) — usa playwright."""
    for ano, mes in meses_no_intervalo(2020, desde_ano=desde_ano, desde_mes=desde_mes):
        yield (
            f"https://media.azimutwealth.com.br/carta-mensal-{MESES_PT[mes]}-{ano}/",
            ano, mes,
        )


def _links_dynamo(desde_ano=None, desde_mes=None):
    """
    Dynamo publica cartas trimestrais numeradas sequencialmente.
    Tenta ±5 números em torno do esperado para cobrir variações.
    URL base: https://www.dynamo.com.br/wp-content/uploads/{ano}/{mes:02d}/Carta-Dynamo-{numero}.pdf
    Referência: carta 128 = abril/2026.
    """
    vistos: set[str] = set()
    for ano, mes in trimestres_no_intervalo(2015, desde_ano=desde_ano, desde_mes=desde_mes):
        numero_esperado = numero_periodico(ano, mes, ano_base=2026, mes_base=4, numero_base=128, frequencia=4)
        for numero in range(numero_esperado - 5, numero_esperado + 6):
            url = f"https://www.dynamo.com.br/wp-content/uploads/{ano}/{mes:02d}/Carta-Dynamo-{numero}.pdf"
            if url not in vistos:
                vistos.add(url)
                yield url, ano, mes


def _links_guepardo(desde_ano=None, desde_mes=None):
    """
    Guepardo publica cartas trimestrais numeradas.
    Formato: Carta-{numero}-Carta-aos-Investidores-{T}T{yy}.pdf
    Referência: carta 116 = 1T25 (março/2025).
    """
    vistos: set[str] = set()
    for ano, mes in trimestres_no_intervalo(2022, desde_ano=desde_ano, desde_mes=desde_mes):
        trimestre = (mes - 1) // 3 + 1
        numero_esperado = numero_periodico(ano, mes, ano_base=2025, mes_base=3, numero_base=116, frequencia=4)
        for numero in range(numero_esperado - 5, numero_esperado + 6):
            url = (
                f"https://www.guepardoinvest.com.br/wp-content/uploads/"
                f"Carta-{numero}-Carta-aos-Investidores-{trimestre}T{ano % 100:02d}.pdf"
            )
            if url not in vistos:
                vistos.add(url)
                yield url, ano, mes


def _links_ibiuna(desde_ano=None, desde_mes=None):
    """
    Ibiuna publica um PDF fixo que é substituído mensalmente.
    Retorna apenas a URL atual — sempre mês corrente.
    """
    hoje = date.today()
    ano, mes = hoje.year, hoje.month
    if desde_ano and (ano < desde_ano or (ano == desde_ano and desde_mes and mes < desde_mes)):
        return
    yield (
        "https://www.ibiunainvest.com.br/wp-content/uploads/fundos/RelatorioMensal_IbiunaHedgeFIFCIC.pdf",
        ano, mes,
    )


def _links_kadima(desde_ano=None, desde_mes=None):
    """Lista manual de trimestres Kadima — atualizar manualmente a cada trimestre."""
    cartas = [
        ("https://cdn-sites-assets.mziq.com/wp-content/uploads/sites/1234/2026/04/Carta-Trimestral-2026_03-2.pdf", 2026, 3),
        ("https://cdn-sites-assets.mziq.com/wp-content/uploads/sites/1234/2026/01/Carta-Trimestral-2025_12-2.pdf", 2025, 12),
        ("https://cdn-sites-assets.mziq.com/wp-content/uploads/sites/1234/2025/10/Carta-Trimestral-2025_10.pdf",   2025, 9),
        ("https://cdn-sites-assets.mziq.com/wp-content/uploads/sites/1234/2025/07/Carta-Trimestral-2025_06.pdf",   2025, 6),
        ("https://cdn-sites-assets.mziq.com/wp-content/uploads/sites/1234/2025/04/Carta-Trimestral-2025_03-3.pdf", 2025, 3),
        ("https://cdn-sites-assets.mziq.com/wp-content/uploads/sites/1234/2025/01/Carta-Trimestral-2024_12.pdf",   2024, 12),
        ("https://cdn-sites-assets.mziq.com/wp-content/uploads/sites/1234/2024/10/Carta-Trimestral-2024_09.pdf",   2024, 9),
        ("https://cdn-sites-assets.mziq.com/wp-content/uploads/sites/1234/2024/06/Carta-Trimestral-2024_06.pdf",   2024, 6),
        ("https://cdn-sites-assets.mziq.com/wp-content/uploads/sites/1234/2024/03/Carta-Trimestral-2024_03.pdf",   2024, 3),
        ("https://cdn-sites-assets.mziq.com/wp-content/uploads/sites/1234/2024/01/Carta-2023_12.pdf",              2023, 12),
        ("https://cdn-sites-assets.mziq.com/wp-content/uploads/sites/1234/2023/10/Carta-2023_09.pdf",              2023, 9),
        ("https://cdn-sites-assets.mziq.com/wp-content/uploads/sites/1234/2023/07/Carta-2023_06-1.pdf",            2023, 6),
        ("https://cdn-sites-assets.mziq.com/wp-content/uploads/sites/1234/2022/12/CARTA_DEZ_22.pdf",               2022, 12),
        ("https://cdn-sites-assets.mziq.com/wp-content/uploads/sites/1234/2022/09/Carta_2022_09.pdf",              2022, 9),
        ("https://cdn-sites-assets.mziq.com/wp-content/uploads/sites/1234/2022/06/CARTA_06_2022.pdf",              2022, 6),
        ("https://cdn-sites-assets.mziq.com/wp-content/uploads/sites/1234/2022/03/Carta_2022_03.pdf",              2022, 3),
        ("https://cdn-sites-assets.mziq.com/wp-content/uploads/sites/1234/2021/12/Carta_2021_12.pdf",              2021, 12),
        ("https://cdn-sites-assets.mziq.com/wp-content/uploads/sites/1234/2021/09/Carta_2021_09.pdf",              2021, 9),
        ("https://cdn-sites-assets.mziq.com/wp-content/uploads/sites/1234/2021/06/Carta_2021_06.pdf",              2021, 6),
        ("https://cdn-sites-assets.mziq.com/wp-content/uploads/sites/1234/2023/07/Carta_2021_03.pdf",              2021, 3),
        ("https://cdn-sites-assets.mziq.com/wp-content/uploads/sites/1234/2020/12/Carta-2020_12-1.pdf",            2020, 12),
        ("https://cdn-sites-assets.mziq.com/wp-content/uploads/sites/1234/2020/09/Carta_2020_09.pdf",              2020, 9),
        ("https://cdn-sites-assets.mziq.com/wp-content/uploads/sites/1234/2020/06/Carta-2020_06.pdf",              2020, 6),
        ("https://cdn-sites-assets.mziq.com/wp-content/uploads/sites/1234/2020/03/Carta_2020_03.pdf",              2020, 3),
        ("https://cdn-sites-assets.mziq.com/wp-content/uploads/sites/1234/2023/07/Carta_2019_09.pdf",              2019, 9),
        ("https://cdn-sites-assets.mziq.com/wp-content/uploads/sites/1234/2023/07/Carta_2019_06.pdf",              2019, 6),
        ("https://cdn-sites-assets.mziq.com/wp-content/uploads/sites/1234/2023/07/Carta_2018_12.pdf",              2018, 12),
        ("https://cdn-sites-assets.mziq.com/wp-content/uploads/sites/1234/2023/07/Carta_2018_09.pdf",              2018, 9),
        ("https://cdn-sites-assets.mziq.com/wp-content/uploads/sites/1234/2023/07/Carta_2018_06.pdf",              2018, 6),
        ("https://cdn-sites-assets.mziq.com/wp-content/uploads/sites/1234/2023/07/Carta_2018_03.pdf",              2018, 3),
        ("https://cdn-sites-assets.mziq.com/wp-content/uploads/sites/1234/2023/07/Carta_2017_12.pdf",              2017, 12),
        ("https://cdn-sites-assets.mziq.com/wp-content/uploads/sites/1234/2023/07/Carta_2017_09.pdf",              2017, 9),
        ("https://cdn-sites-assets.mziq.com/wp-content/uploads/sites/1234/2023/07/Carta_2017_05.pdf",              2017, 5),
        ("https://cdn-sites-assets.mziq.com/wp-content/uploads/sites/1234/2023/06/Carta_2017_03.pdf",              2017, 3),
    ]
    for url, ano, mes in cartas:
        if desde_ano and (ano < desde_ano or (ano == desde_ano and desde_mes and mes < desde_mes)):
            continue
        yield url, ano, mes


def _links_persevera(desde_ano=None, desde_mes=None):
    """URLs de páginas web da Persevera — usa playwright."""
    cartas = [
        ("https://www.persevera.com.br/post/contracorrente",                                                            2026, 5),
        ("https://www.persevera.com.br/post/quando-os-juros-mordem-e-o-cr%C3%A9dito-grita",                            2026, 4),
        ("https://www.persevera.com.br/post/entre-ciclos",                                                              2026, 3),
        ("https://www.persevera.com.br/post/a-estrategia-do-caos",                                                      2026, 2),
        ("https://www.persevera.com.br/post/quando-os-astros-se-alinham",                                               2026, 1),
        ("https://www.persevera.com.br/post/o-padr%C3%A3o-se-repete",                                                  2025, 12),
        ("https://www.persevera.com.br/post/a-parte-turbulenta-do-caminho",                                             2025, 11),
        ("https://www.persevera.com.br/post/teoria-dos-jogos-1",                                                        2025, 10),
        ("https://www.persevera.com.br/post/uma-recessao-orquestrada-1",                                                2025, 9),
        ("https://www.persevera.com.br/post/os-primeiros-dias-de-trump-1",                                              2025, 8),
        ("https://www.persevera.com.br/post/intervindo-no-momento-certo",                                               2025, 7),
        ("https://www.persevera.com.br/post/uma-vitoria-pirrica-1",                                                     2025, 6),
        ("https://www.persevera.com.br/post/brasil-e-o-consenso-pessimista-1",                                          2025, 5),
        ("https://www.persevera.com.br/post/precificados-para-a-perfei%C3%A7%C3%A3o-1",                                2025, 4),
        ("https://www.persevera.com.br/post/primeiras-impress%C3%B5es-1",                                               2025, 3),
        ("https://www.persevera.com.br/post/o-inimigo-agora-%C3%A9-outro-1",                                           2025, 2),
        ("https://www.persevera.com.br/post/foto-boa-filme-ruim-1",                                                     2025, 1),
        ("https://www.persevera.com.br/post/brasil-fora-da-festa-1",                                                    2024, 12),
        ("https://www.persevera.com.br/post/da-refla%C3%A7%C3%A3o-%C3%A0-estagfla%C3%A7%C3%A3o-1",                   2024, 11),
        ("https://www.persevera.com.br/post/do-pouso-suave-%C3%A0-refla%C3%A7%C3%A3o-1",                              2024, 10),
        ("https://www.persevera.com.br/post/importando-o-pouso-suave-exportando-o-fantasma-fiscal-1",                   2024, 9),
        ("https://www.persevera.com.br/post/corte-%C3%A0-vista-1",                                                     2024, 8),
        ("https://www.persevera.com.br/post/ano-novo-ciclo-novo-1",                                                     2024, 1),
        ("https://www.persevera.com.br/post/rally-de-fim-de-ano-1",                                                     2023, 12),
        ("https://www.persevera.com.br/post/nova-meta-fiscal-1",                                                        2023, 7),
        ("https://www.persevera.com.br/post/turbul%C3%AAncia-nos-mercados-1",                                           2023, 6),
        ("https://www.persevera.com.br/post/susto-monet%C3%A1rio-susto-fiscal-1",                                      2023, 5),
        ("https://www.persevera.com.br/post/pousando-suavemente-1",                                                     2023, 4),
        ("https://www.persevera.com.br/post/corte-de-juros-em-agosto-1",                                                2023, 3),
        ("https://www.persevera.com.br/post/infla%C3%A7%C3%A3o-abaixo-de-4-1",                                        2023, 2),
        ("https://www.persevera.com.br/post/reacelera%C3%A7%C3%A3o-desinflacion%C3%A1ria-1",                           2023, 1),
        ("https://www.persevera.com.br/post/o-novo-arcabou%C3%A7o-fiscal-1",                                           2022, 12),
        ("https://www.persevera.com.br/post/o-renascimento-da-renda-fixa-ativa-1",                                     2022, 11),
        ("https://www.persevera.com.br/post/persevera-commodities-1",                                                   2022, 10),
        ("https://www.persevera.com.br/post/o-brasil-sob-nova-dire%C3%A7%C3%A3o-1",                                   2022, 9),
        ("https://www.persevera.com.br/post/heran%C3%A7a-bendita-1",                                                   2022, 8),
        ("https://www.persevera.com.br/post/combatendo-a-infla%C3%A7%C3%A3o-sem-ajuda-das-commodities-1",              2022, 7),
        ("https://www.persevera.com.br/post/persevera-n%C3%AAmesis-6-meses-do-nosso-long-bias-defensivo-1",            2022, 6),
        ("https://www.persevera.com.br/post/commodities-em-uma-recess%C3%A3o-global-1",                                2022, 5),
        ("https://www.persevera.com.br/post/bear-market-bounce-1",                                                      2022, 4),
        ("https://www.persevera.com.br/post/o-retorno-da-histeria-fiscal-1",                                            2022, 3),
        ("https://www.persevera.com.br/post/tsunami-l%C3%A1-e-marola-aqui-1",                                          2022, 2),
        ("https://www.persevera.com.br/post/da-mitologia-ao-mercado-o-persevera-n%C3%AAmesis-1",                       2022, 1),
        ("https://www.persevera.com.br/post/d%C3%B3lar-abaixo-de-r-4-1",                                              2021, 12),
        ("https://www.persevera.com.br/post/a-crise-fiscal-%C3%A9-uma-miragem-1",                                      2021, 11),
        ("https://www.persevera.com.br/post/um-novo-fed-1",                                                             2021, 10),
        ("https://www.persevera.com.br/post/economia-fraca-mercados-fortes-1",                                          2021, 9),
        ("https://www.persevera.com.br/post/o-canto-da-sereia-do-cdi-1",                                               2021, 8),
        ("https://www.persevera.com.br/post/mercado-de-a%C3%A7%C3%B5es-e-as-finan%C3%A7as-comportamentais-1",         2021, 7),
        ("https://www.persevera.com.br/post/um-novo-superciclo-de-commodities-1",                                       2021, 6),
        ("https://www.persevera.com.br/post/super%C3%A1vit-fiscal-%C3%A0-vista-1",                                    2021, 5),
        ("https://www.persevera.com.br/post/um-olhar-alternativo-sobre-o-retorno-das-a%C3%A7%C3%B5es-1",              2021, 4),
        ("https://www.persevera.com.br/post/o-poder-da-sinaliza%C3%A7%C3%A3o-dos-bancos-centrais-1",                  2021, 3),
        ("https://www.persevera.com.br/post/uma-forte-recupera%C3%A7%C3%A3o-no-segundo-trimestre-1",                   2021, 2),
        ("https://www.persevera.com.br/post/a-revolucao-estrutural-da-divida-publica-1",                                2021, 1),
        ("https://www.persevera.com.br/post/estrat%C3%A9gias-para-capturar-os-altos-retornos-das-a%C3%A7%C3%B5es-1", 2020, 12),
        ("https://www.persevera.com.br/post/os-dilemas-da-gest%C3%A3o-de-recursos-1",                                 2020, 11),
    ]
    for url, ano, mes in cartas:
        if desde_ano and (ano < desde_ano or (ano == desde_ano and desde_mes and mes < desde_mes)):
            continue
        yield url, ano, mes


# ─────────────────────────────────────────────
# REGISTRO CENTRAL
# ─────────────────────────────────────────────

GESTORAS: dict[str, dict] = {
    "Verde": {
        "nome":          "Verde Asset",
        "frequencia":    "mensal",
        "tipo_url":      "pdf_direto",
        "pasta_notion":  "Cartas de Gestão",
        "ano_inicio":    1998,
        "mes_inicio":    1,
        "links_fn":      _links_verde,
    },
    "Gavea": {
        "nome":          "Gaveá Investimentos",
        "frequencia":    "mensal",
        "tipo_url":      "pdf_direto",
        "pasta_notion":  "Cartas de Gestão",
        "ano_inicio":    2015,
        "mes_inicio":    1,
        "links_fn":      _links_gavea,
    },
    "Adam": {
        "nome":          "Adam Capital",
        "frequencia":    "mensal",
        "tipo_url":      "pdf_direto",
        "pasta_notion":  "Cartas de Gestão",
        "ano_inicio":    2020,
        "mes_inicio":    1,
        "links_fn":      _links_adam,
    },
    "Bahia": {
        "nome":          "Bahia Asset",
        "frequencia":    "mensal",
        "tipo_url":      "pdf_direto",
        "pasta_notion":  "Cartas de Gestão",
        "ano_inicio":    2015,
        "mes_inicio":    1,
        "links_fn":      _links_bahia,
    },
    "Legacy": {
        "nome":          "Legacy Capital",
        "frequencia":    "mensal",
        "tipo_url":      "pdf_direto",
        "pasta_notion":  "Cartas de Gestão",
        "ano_inicio":    2015,
        "mes_inicio":    1,
        "links_fn":      _links_legacy,
    },
    "Armor": {
        "nome":          "Armor Capital",
        "frequencia":    "mensal",
        "tipo_url":      "pdf_direto",
        "pasta_notion":  "Cartas de Gestão",
        "ano_inicio":    2020,
        "mes_inicio":    1,
        "links_fn":      _links_armor,
    },
    "Sparta": {
        "nome":          "Sparta",
        "frequencia":    "mensal",
        "tipo_url":      "pdf_direto",
        "pasta_notion":  "Cartas de Gestão",
        "ano_inicio":    2025,
        "mes_inicio":    1,
        "links_fn":      _links_sparta,
    },
    "JGP": {
        "nome":          "JGP",
        "frequencia":    "mensal",
        "tipo_url":      "pdf_direto",
        "pasta_notion":  "Cartas de Gestão",
        "ano_inicio":    2020,
        "mes_inicio":    1,
        "links_fn":      _links_jgp,
    },
    "Azimut": {
        "nome":          "Azimut",
        "frequencia":    "mensal",
        "tipo_url":      "pagina_web",
        "pasta_notion":  "Cartas de Gestão",
        "ano_inicio":    2020,
        "mes_inicio":    1,
        "links_fn":      _links_azimut,
    },
    "Dynamo": {
        "nome":          "Dynamo",
        "frequencia":    "trimestral",
        "tipo_url":      "pdf_direto",
        "pasta_notion":  "Cartas de Gestão",
        "ano_inicio":    2015,
        "mes_inicio":    1,
        "links_fn":      _links_dynamo,
    },
    "Guepardo": {
        "nome":          "Guepardo",
        "frequencia":    "trimestral",
        "tipo_url":      "pdf_direto",
        "pasta_notion":  "Cartas de Gestão",
        "ano_inicio":    2022,
        "mes_inicio":    1,
        "links_fn":      _links_guepardo,
    },
    "Ibiuna": {
        "nome":          "Ibiuña Investimentos",
        "frequencia":    "mensal",
        "tipo_url":      "pdf_direto",
        "pasta_notion":  "Cartas de Gestão",
        "ano_inicio":    2024,
        "mes_inicio":    1,
        "links_fn":      _links_ibiuna,
    },
    "Kadima": {
        "nome":          "Kadima",
        "frequencia":    "trimestral",
        "tipo_url":      "pdf_direto",
        "pasta_notion":  "Cartas de Gestão",
        "ano_inicio":    2017,
        "mes_inicio":    3,
        "links_fn":      _links_kadima,
    },
    "Persevera": {
        "nome":          "Persevera",
        "frequencia":    "mensal",
        "tipo_url":      "pagina_web",
        "pasta_notion":  "Cartas de Gestão",
        "ano_inicio":    2020,
        "mes_inicio":    11,
        "links_fn":      _links_persevera,
    },
}


# ─────────────────────────────────────────────
# API PÚBLICA
# ─────────────────────────────────────────────

def get_links(
    gestora_key: str,
    desde_ano: int | None = None,
    desde_mes: int | None = None,
):
    """
    Retorna um gerador de (url, ano, mes) ou (url, ano, mes, titulo) para a gestora.

    Se desde_ano/desde_mes forem omitidos, usa ano_inicio/mes_inicio do cadastro
    (retorna histórico completo).

    Exemplos:
        get_links("Verde")                       # histórico completo desde 1998
        get_links("Verde", desde_ano=2026)       # apenas 2026 em diante
        get_links("Verde", desde_ano=2026, desde_mes=3)  # a partir de março/2026
    """
    gestora = GESTORAS[gestora_key]
    fn = gestora["links_fn"]
    return fn(desde_ano=desde_ano, desde_mes=desde_mes)
