# -*- coding: utf-8 -*-
import fitz
from pathlib import Path

PASTA = Path(r"C:\Users\andre\Downloads\Cartas")

def listar_pdfs(pasta):
    return list(pasta.glob("*.pdf"))

def pdf_para_markdown(pdf_path, pasta_destino=PASTA):
    pdf_path = Path(pdf_path)
    nome_md = pdf_path.stem + ".md"
    caminho_md = Path(pasta_destino) / nome_md
    doc = fitz.open(pdf_path)
    markdown = ""
    for pagina in doc:
        texto = pagina.get_text()
        markdown += f"\n\n# Página {pagina.number + 1}\n\n"
        markdown += texto
    with open(caminho_md, "w", encoding="utf-8") as f:
        f.write(markdown)
    print(f"Markdown salvo: {caminho_md}")

for pdf in listar_pdfs(PASTA):
    pdf_para_markdown(pdf)
