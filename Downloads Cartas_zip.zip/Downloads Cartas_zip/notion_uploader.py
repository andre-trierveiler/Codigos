"""
notion_uploader.py
------------------
Upload em lote de arquivos locais para pastas do Notion.

Fluxo:
1. Preencha o dataframe UPLOAD_QUEUE abaixo com os arquivos que deseja subir
2. Configure sua NOTION_API_KEY
3. Execute: python notion_uploader.py

Dependências:
    pip install notion-client pandas requests tqdm
"""

import os
import mimetypes
import requests
import pandas as pd
from pathlib import Path
from tqdm import tqdm
from notion_client import Client

# ─────────────────────────────────────────────
# CONFIGURAÇÃO
# ─────────────────────────────────────────────

NOTION_API_KEY = os.environ.get("NOTION_API_KEY", "seu_token_aqui")

# IDs das pastas do Notion (copiar da skill SKILL.md)
PASTA_IDS = {
    "Geopolítica":                "36ea8a2f-677c-8130-987c-f8ab0e8b0a83",
    "Política Nacional":          "36ea8a2f-677c-8195-94c3-e07dbca014ea",
    "Eleições":                   "36ea8a2f-677c-81d0-9857-c392f6e9717a",
    "Congresso / Legislativo":    "36ea8a2f-677c-815d-b72c-d5d3eb8194ee",
    "Política Monetária":         "36ea8a2f-677c-81a2-8ccb-e23200ec353d",
    "Atas":                       "36ea8a2f-677c-81bb-be43-f86d7fb35494",
    "Comunicados":                "36ea8a2f-677c-8101-bdc9-c7d74ffe9ea1",
    "Diversos":                   "36ea8a2f-677c-8183-b418-f4724ee7f4c2",
    "Cartas de Gestão":           "36ea8a2f-677c-8198-bc0d-c7d5a4e9d0d2",
    "Gavekal":                    "36ea8a2f-677c-81fc-9e0d-ec35f3c173d1",
    "Relatórios - BR":            "36ea8a2f-677c-81b1-b710-e4ce0f78e526",
    "Relatórios - Internacionais":"36ea8a2f-677c-816d-bba8-cbda838df221",
    "Mercado":                    "36ea8a2f-677c-815a-858e-ce262f654223",
    "Macro Global":               "36ea8a2f-677c-812b-b9ec-e56c14f95687",
}

# ─────────────────────────────────────────────
# FILA DE UPLOAD
# Edite esta lista com seus arquivos.
# arquivo_local : caminho completo no seu computador
# pasta_notion  : nome da pasta (deve estar no dicionário acima)
# titulo        : título que aparecerá na página do Notion (opcional)
# ─────────────────────────────────────────────

UPLOAD_QUEUE = pd.DataFrame([
    # Exemplos — substitua pelos seus arquivos:
    {
        "arquivo_local": "/Users/andre/Documents/relatorios/gavekal_dollar_2024.pdf",
        "pasta_notion":  "Gavekal",
        "titulo":        "Gavekal: Dollar Outlook 2024",
    },
    {
        "arquivo_local": "/Users/andre/Documents/relatorios/xp_macro_maio2026.pdf",
        "pasta_notion":  "Relatórios - BR",
        "titulo":        "XP Research: Macro Maio 2026",
    },
    {
        "arquivo_local": "/Users/andre/Downloads/copom_ata_maio2026.pdf",
        "pasta_notion":  "Atas",
        "titulo":        "Ata Copom — Maio 2026",
    },
])


# ─────────────────────────────────────────────
# FUNÇÕES
# ─────────────────────────────────────────────

def get_notion_client() -> Client:
    if NOTION_API_KEY == "seu_token_aqui":
        raise ValueError(
            "Configure sua NOTION_API_KEY.\n"
            "Opção 1: export NOTION_API_KEY=seu_token no terminal\n"
            "Opção 2: edite a variável NOTION_API_KEY no topo deste script"
        )
    return Client(auth=NOTION_API_KEY)


def criar_pagina_com_arquivo(
    notion: Client,
    arquivo_local: str,
    pasta_notion: str,
    titulo: str | None = None,
) -> dict:
    """
    Cria uma página no Notion dentro da pasta especificada
    e faz upload do arquivo como bloco embed/file.
    """
    caminho = Path(arquivo_local)
    if not caminho.exists():
        raise FileNotFoundError(f"Arquivo não encontrado: {arquivo_local}")

    page_id = PASTA_IDS.get(pasta_notion)
    if not page_id:
        pastas_disponiveis = "\n  ".join(PASTA_IDS.keys())
        raise ValueError(
            f"Pasta '{pasta_notion}' não encontrada.\n"
            f"Pastas disponíveis:\n  {pastas_disponiveis}"
        )

    titulo_final = titulo or caminho.name

    # 1. Criar a página
    pagina = notion.pages.create(
        parent={"page_id": page_id},
        properties={
            "title": {
                "title": [{"text": {"content": titulo_final}}]
            }
        },
    )
    pagina_id = pagina["id"]
    pagina_url = pagina["url"]

    # 2. Fazer upload do arquivo via Notion File Upload API
    mime_type, _ = mimetypes.guess_type(str(caminho))
    mime_type = mime_type or "application/octet-stream"
    tamanho = caminho.stat().st_size

    headers = {
        "Authorization": f"Bearer {NOTION_API_KEY}",
        "Notion-Version": "2022-06-28",
        "Content-Type": "application/json",
    }

    # Iniciar upload
    resp_inicio = requests.post(
        "https://api.notion.com/v1/file_uploads",
        headers=headers,
        json={
            "filename": caminho.name,
            "content_type": mime_type,
            "size": tamanho,
        },
    )
    resp_inicio.raise_for_status()
    upload_id = resp_inicio.json()["id"]
    upload_url = resp_inicio.json()["upload_url"]

    # Enviar o arquivo
    with open(caminho, "rb") as f:
        resp_upload = requests.put(
            upload_url,
            headers={"Content-Type": mime_type},
            data=f,
        )
    resp_upload.raise_for_status()

    # 3. Adicionar bloco de arquivo na página
    notion.blocks.children.append(
        block_id=pagina_id,
        children=[
            {
                "type": "file",
                "file": {
                    "type": "file_upload",
                    "file_upload": {"id": upload_id},
                    "name": caminho.name,
                },
            }
        ],
    )

    return {"titulo": titulo_final, "url": pagina_url, "pagina_id": pagina_id}


def validar_fila(df: pd.DataFrame) -> list[str]:
    """Valida a fila antes de executar uploads. Retorna lista de erros."""
    erros = []
    for i, row in df.iterrows():
        caminho = Path(row["arquivo_local"])
        if not caminho.exists():
            erros.append(f"Linha {i+1}: arquivo não encontrado → {row['arquivo_local']}")
        if row["pasta_notion"] not in PASTA_IDS:
            erros.append(f"Linha {i+1}: pasta inválida → '{row['pasta_notion']}'")
    return erros


def executar_uploads(df: pd.DataFrame) -> pd.DataFrame:
    """Executa todos os uploads e retorna dataframe com resultados."""
    notion = get_notion_client()
    resultados = []

    print(f"\n{'─'*50}")
    print(f"  Iniciando upload de {len(df)} arquivo(s)")
    print(f"{'─'*50}\n")

    for _, row in tqdm(df.iterrows(), total=len(df), desc="Uploading"):
        resultado = {
            "arquivo": Path(row["arquivo_local"]).name,
            "pasta":   row["pasta_notion"],
            "status":  None,
            "url":     None,
            "erro":    None,
        }
        try:
            resp = criar_pagina_com_arquivo(
                notion=notion,
                arquivo_local=row["arquivo_local"],
                pasta_notion=row["pasta_notion"],
                titulo=row.get("titulo"),
            )
            resultado["status"] = "✅ OK"
            resultado["url"]    = resp["url"]
            print(f"  ✅  {resultado['arquivo']} → {row['pasta_notion']}")
            print(f"      {resp['url']}\n")
        except Exception as e:
            resultado["status"] = "❌ Erro"
            resultado["erro"]   = str(e)
            print(f"  ❌  {resultado['arquivo']} → ERRO: {e}\n")

        resultados.append(resultado)

    return pd.DataFrame(resultados)


# ─────────────────────────────────────────────
# EXECUÇÃO
# ─────────────────────────────────────────────

if __name__ == "__main__":

    print("\n📋 Validando fila de upload...")
    erros = validar_fila(UPLOAD_QUEUE)

    if erros:
        print("\n⚠️  Corrija os erros abaixo antes de continuar:\n")
        for e in erros:
            print(f"  • {e}")
        print()
        exit(1)

    print(f"  {len(UPLOAD_QUEUE)} arquivo(s) válido(s). Iniciando...\n")
    resultados = executar_uploads(UPLOAD_QUEUE)

    # Salvar relatório de resultados
    relatorio_path = Path(__file__).parent / "upload_log.csv"
    resultados.to_csv(relatorio_path, index=False)

    ok    = len(resultados[resultados["status"] == "✅ OK"])
    erros = len(resultados[resultados["status"] == "❌ Erro"])

    print(f"{'─'*50}")
    print(f"  Concluído: {ok} OK · {erros} erro(s)")
    print(f"  Log salvo em: {relatorio_path}")
    print(f"{'─'*50}\n")
