# -*- coding: utf-8 -*-
"""
notion_kb.py
------------
Integração com o database central "Repositório de Conhecimento" do Notion.

Funções:
    sincronizar_schema_fonte()  — adiciona as 14 gestoras ao MULTI_SELECT Fonte (roda 1x)
    checar_duplicata()          — lê manifest local, sem query Notion
    criar_nota_kb()             — cria página no database + insere blocos em batches
    upload_pasta_pdf()          — sobe PDF na pasta "Cartas de Gestão"
    patch_pdf_original()        — preenche campo URL "PDF Original" na nota
    salvar_manifest()           — persiste pipeline_manifest.json
"""

import json
import logging
import os
import time
from datetime import datetime
from pathlib import Path

import requests
from dotenv import load_dotenv
from notion_client import Client

from classificar import CartaMetadata
from md_to_blocks import batch_blocks, converter_md_para_blocos

load_dotenv(Path(__file__).parent / ".env")

logger = logging.getLogger(__name__)

# ─────────────────────────────────────────────
# CONSTANTES (do SKILL_notion.md)
# ─────────────────────────────────────────────

DATABASE_ID = "adbce1b0-2102-40f7-8fb1-b05839183af1"

PASTA_IDS = {
    "Geopolítica":                 "36ea8a2f-677c-8130-987c-f8ab0e8b0a83",
    "Política Nacional":           "36ea8a2f-677c-8195-94c3-e07dbca014ea",
    "Eleições":                    "36ea8a2f-677c-81d0-9857-c392f6e9717a",
    "Congresso / Legislativo":     "36ea8a2f-677c-815d-b72c-d5d3eb8194ee",
    "Política Monetária":          "36ea8a2f-677c-81a2-8ccb-e23200ec353d",
    "Atas":                        "36ea8a2f-677c-81bb-be43-f86d7fb35494",
    "Comunicados":                 "36ea8a2f-677c-8101-bdc9-c7d74ffe9ea1",
    "Diversos":                    "36ea8a2f-677c-8183-b418-f4724ee7f4c2",
    "Cartas de Gestão":            "36ea8a2f-677c-8198-bc0d-c7d5a4e9d0d2",
    "Gavekal":                     "36ea8a2f-677c-81fc-9e0d-ec35f3c173d1",
    "Relatórios - BR":             "36ea8a2f-677c-81b1-b710-e4ce0f78e526",
    "Relatórios - Internacionais": "36ea8a2f-677c-816d-bba8-cbda838df221",
    "Mercado":                     "36ea8a2f-677c-815a-858e-ce262f654223",
    "Macro Global":                "36ea8a2f-677c-812b-b9ec-e56c14f95687",
}

# Gestoras novas a adicionar no MULTI_SELECT Fonte do database
_GESTORAS_NOVAS_FONTE = [
    "Verde Asset", "Gaveá Investimentos", "Adam Capital", "Bahia Asset",
    "Legacy Capital", "Armor Capital", "Sparta", "JGP", "Azimut",
    "Dynamo", "Guepardo", "Ibiuña Investimentos", "Kadima", "Persevera",
]

MANIFEST_PATH = Path(__file__).parent / "pipeline_manifest.json"


# ─────────────────────────────────────────────
# CLIENTE NOTION
# ─────────────────────────────────────────────

def get_notion_client() -> Client:
    key = os.environ.get("NOTION_API_KEY", "")
    if not key:
        raise ValueError("NOTION_API_KEY não configurada")
    import httpx
    return Client(auth=key, client=httpx.Client(verify=False))


# ─────────────────────────────────────────────
# SYNC SCHEMA (roda uma vez)
# ─────────────────────────────────────────────

_SCHEMA_SINCRONIZADO = False  # flag de processo — evita chamadas repetidas na mesma execução


def sincronizar_schema_fonte(notion: Client, forcar: bool = False) -> None:
    """
    Adiciona as 14 gestoras como opções do MULTI_SELECT 'Fonte' no database.
    Idempotente: só adiciona opções que ainda não existem.
    """
    global _SCHEMA_SINCRONIZADO
    if _SCHEMA_SINCRONIZADO and not forcar:
        return

    try:
        db = notion.databases.retrieve(DATABASE_ID)
    except Exception as e:
        logger.warning("Não foi possível recuperar o database para sync de schema: %s", e)
        return

    prop_fonte = db.get("properties", {}).get("Fonte", {})
    opcoes_atuais = {
        opt["name"] for opt in prop_fonte.get("multi_select", {}).get("options", [])
    }

    novas = [g for g in _GESTORAS_NOVAS_FONTE if g not in opcoes_atuais]
    if not novas:
        logger.info("Schema Fonte já atualizado — nenhuma gestora nova a adicionar")
        _SCHEMA_SINCRONIZADO = True
        return

    opcoes_existentes = prop_fonte.get("multi_select", {}).get("options", [])
    opcoes_atualizadas = opcoes_existentes + [{"name": g} for g in novas]

    try:
        notion.databases.update(
            DATABASE_ID,
            properties={
                "Fonte": {
                    "multi_select": {"options": opcoes_atualizadas}
                }
            },
        )
        logger.info("Schema Fonte atualizado: adicionadas %d gestoras", len(novas))
    except Exception as e:
        logger.warning("Falha ao atualizar schema Fonte: %s", e)

    _SCHEMA_SINCRONIZADO = True


# ─────────────────────────────────────────────
# MANIFEST
# ─────────────────────────────────────────────

def carregar_manifest() -> dict:
    if MANIFEST_PATH.exists():
        try:
            return json.loads(MANIFEST_PATH.read_text(encoding="utf-8"))
        except Exception:
            pass
    return {}


def salvar_manifest(manifest: dict) -> None:
    MANIFEST_PATH.write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )


def _chave_manifest(gestora_key: str, ano: int, mes: int) -> str:
    return f"{gestora_key}_{ano}{mes:02d}"


def checar_duplicata(manifest: dict, gestora_key: str, ano: int, mes: int) -> bool:
    """True se a carta já foi processada e tem kb_page_id no manifest."""
    chave = _chave_manifest(gestora_key, ano, mes)
    entrada = manifest.get(chave, {})
    return bool(entrada.get("kb_page_id"))


def registrar_manifest(
    manifest: dict,
    gestora_key: str,
    ano: int,
    mes: int,
    kb_page_id: str = "",
    kb_url: str = "",
    pasta_page_id: str = "",
    pasta_url: str = "",
) -> None:
    chave = _chave_manifest(gestora_key, ano, mes)
    manifest[chave] = {
        "kb_page_id":    kb_page_id,
        "kb_url":        kb_url,
        "pasta_page_id": pasta_page_id,
        "pasta_url":     pasta_url,
        "created_at":    datetime.now().isoformat(),
    }


# ─────────────────────────────────────────────
# CRIAR NOTA NO DATABASE KB
# ─────────────────────────────────────────────

def _propriedades_notion(meta: CartaMetadata) -> dict:
    return {
        "Título": {
            "title": [{"text": {"content": meta.titulo[:2000]}}]
        },
        "Data": {
            "date": {"start": meta.data.isoformat()}
        },
        "Tipo": {
            "select": {"name": meta.tipo}
        },
        "Fonte": {
            "multi_select": [{"name": f} for f in meta.fonte]
        },
        "Temas": {
            "multi_select": [{"name": t} for t in meta.temas]
        },
        "Mercados": {
            "multi_select": [{"name": m} for m in meta.mercados]
        },
        "Ativos mencionados": {
            "multi_select": [{"name": a} for a in meta.ativos]
        },
        "Participantes": {
            "rich_text": [{"text": {"content": meta.participantes[:2000]}}]
        },
    }


def _inserir_blocos_em_batches(notion: Client, page_id: str, blocos: list[dict]) -> None:
    """Envia blocos em lotes de 100, respeitando o limite da API Notion."""
    lotes = batch_blocks(blocos)
    for i, lote in enumerate(lotes):
        tentativas = 3
        for t in range(1, tentativas + 1):
            try:
                notion.blocks.children.append(block_id=page_id, children=lote)
                break
            except Exception as e:
                if t == tentativas:
                    logger.error("Falha ao inserir lote %d/%d: %s", i + 1, len(lotes), e)
                    raise
                espera = 2 ** t
                logger.warning("Lote %d falhou (tentativa %d/%d) — aguardando %ds: %s",
                               i + 1, t, tentativas, espera, e)
                time.sleep(espera)


def criar_nota_kb(notion: Client, meta: CartaMetadata) -> tuple[str, str]:
    """
    Cria uma página no database KB com propriedades e conteúdo completo.
    Retorna (page_id, page_url).
    """
    # Montar conteúdo completo: metadados + keypoints + texto completo
    conteudo_md = (
        f"# 📋 Metadados\n\n"
        f"| Campo | Valor |\n"
        f"|---|---|\n"
        f"| Gestora / Fonte | {', '.join(meta.fonte)} |\n"
        f"| Data | {meta.data.isoformat()} |\n"
        f"| Participantes | {meta.participantes} |\n\n"
        f"---\n\n"
        f"# 🎯 Keypoints\n\n{meta.keypoints_md}\n\n"
        f"---\n\n"
        f"# 📄 Conteúdo Completo\n\n{meta.conteudo_completo_md}"
    )

    blocos = converter_md_para_blocos(conteudo_md)

    pagina = notion.pages.create(
        parent={"database_id": DATABASE_ID},
        properties=_propriedades_notion(meta),
    )
    page_id  = pagina["id"]
    page_url = pagina.get("url", "")

    if blocos:
        _inserir_blocos_em_batches(notion, page_id, blocos)

    return page_id, page_url


# ─────────────────────────────────────────────
# UPLOAD PDF NA PASTA
# ─────────────────────────────────────────────

def upload_pasta_pdf(
    notion: Client,
    pdf_path: Path,
    pasta_nome: str = "Cartas de Gestão",
    titulo: str | None = None,
) -> tuple[str, str]:
    """
    Cria página na pasta Notion e faz upload do PDF via File Upload API.
    Retorna (page_id, page_url).
    """
    notion_api_key = os.environ.get("NOTION_API_KEY", "")
    pasta_id = PASTA_IDS.get(pasta_nome)
    if not pasta_id:
        raise ValueError(f"Pasta '{pasta_nome}' não encontrada em PASTA_IDS")

    titulo_final = titulo or pdf_path.name

    # Criar página na pasta
    pagina = notion.pages.create(
        parent={"page_id": pasta_id},
        properties={
            "title": {"title": [{"text": {"content": titulo_final}}]}
        },
    )
    page_id  = pagina["id"]
    page_url = pagina.get("url", "")

    # Upload File API
    import mimetypes
    mime_type, _ = mimetypes.guess_type(str(pdf_path))
    mime_type = mime_type or "application/pdf"
    tamanho   = pdf_path.stat().st_size

    headers_json = {
        "Authorization": f"Bearer {notion_api_key}",
        "Notion-Version": "2022-06-28",
        "Content-Type": "application/json",
    }

    resp_inicio = requests.post(
        "https://api.notion.com/v1/file_uploads",
        headers=headers_json,
        json={"filename": pdf_path.name, "content_type": mime_type, "size": tamanho},
        timeout=30,
    )
    resp_inicio.raise_for_status()
    upload_id  = resp_inicio.json()["id"]
    upload_url = resp_inicio.json()["upload_url"]

    with open(pdf_path, "rb") as f:
        resp_upload = requests.put(
            upload_url,
            headers={"Content-Type": mime_type},
            data=f,
            timeout=120,
        )
    resp_upload.raise_for_status()

    # Adicionar bloco de arquivo na página da pasta
    notion.blocks.children.append(
        block_id=page_id,
        children=[{
            "type": "file",
            "file": {
                "type": "file_upload",
                "file_upload": {"id": upload_id},
                "name": pdf_path.name,
            },
        }],
    )

    return page_id, page_url


# ─────────────────────────────────────────────
# PATCH PDF ORIGINAL NA NOTA KB
# ─────────────────────────────────────────────

def patch_pdf_original(notion: Client, kb_page_id: str, pasta_url: str) -> None:
    """Preenche o campo URL 'PDF Original' na nota do database KB."""
    notion.pages.update(
        page_id=kb_page_id,
        properties={
            "PDF Original": {"url": pasta_url}
        },
    )
