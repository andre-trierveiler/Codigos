from pathlib import Path
import subprocess
import sys
import json
from datetime import datetime
from faster_whisper import WhisperModel
import anthropic

# Localiza yt-dlp na mesma instalação Python que está rodando o script
_scripts = Path(sys.executable).parent / "Scripts"
YTDLP = str(_scripts / "yt-dlp.exe") if (_scripts / "yt-dlp.exe").exists() else "yt-dlp"
print(f"[DEBUG] yt-dlp path: {YTDLP}")

# Localiza ffmpeg via imageio-ffmpeg se não estiver no PATH
try:
    import imageio_ffmpeg
    FFMPEG = imageio_ffmpeg.get_ffmpeg_exe()
except ImportError:
    FFMPEG = None

# =========================
# CONFIGURAÇÕES
# =========================

YOUTUBE_URL = "https://www.youtube.com/watch?v=xn7jm_Mpxso"

MODELO_WHISPER = "medium"  # small, medium, large-v3
IDIOMA = "pt"              # pt, en, es, etc.

ANTHROPIC_API_KEY = ""     # Deixe vazio para usar variável de ambiente ANTHROPIC_API_KEY

# =========================
# PASTAS
# =========================

pasta_saida = (Path(__file__).parent if "__file__" in dir() else Path.cwd()) / "Transcricoes_YouTube"
pasta_saida.mkdir(exist_ok=True)

# =========================
# LER METADADOS DO YOUTUBE
# =========================

print("Lendo metadados do YouTube...")

_ytdlp_base = [YTDLP] + (["--ffmpeg-location", FFMPEG] if FFMPEG else [])

result = subprocess.run(
    _ytdlp_base + ["--dump-json", "--no-playlist", YOUTUBE_URL],
    capture_output=True, text=True, check=True
)

meta = json.loads(result.stdout)

titulo_video = meta.get("title", "Sem título")
autor_video = meta.get("uploader", meta.get("channel", "Desconhecido"))
duracao = meta.get("duration_string", "")
upload_date_raw = meta.get("upload_date", "")
upload_date = (
    f"{upload_date_raw[:4]}-{upload_date_raw[4:6]}-{upload_date_raw[6:]}"
    if len(upload_date_raw) == 8 else upload_date_raw
)

# Nome do arquivo baseado na data de upload e título (sanitizado)
def sanitizar(nome):
    invalidos = r'\/:*?"<>|'
    return "".join(c if c.isalnum() or c in " -_()" and c not in invalidos else "_" for c in nome).strip()

nome_arquivo = sanitizar(f"{upload_date}_{autor_video} - {titulo_video}")[:120]

audio_path = pasta_saida / f"{nome_arquivo}.mp3"
md_path = pasta_saida / f"{nome_arquivo}.md"

print(f"  Título:  {titulo_video}")
print(f"  Autor:   {autor_video}")
print(f"  Duração: {duracao}")

# =========================
# BAIXAR MP3
# =========================

print("Baixando áudio do YouTube...")

subprocess.run(
    _ytdlp_base + ["-x", "--audio-format", "mp3", "-o", str(audio_path.with_suffix(".%(ext)s")), YOUTUBE_URL],
    check=True
)

# =========================
# TRANSCRIÇÃO
# =========================

print("Transcrevendo áudio...")

model = WhisperModel(MODELO_WHISPER, device="cpu", compute_type="int8")

segments, info = model.transcribe(
    str(audio_path),
    language=IDIOMA,
    beam_size=5
)

transcricao_blocos = []
texto_completo_partes = []

for segment in segments:
    inicio = round(segment.start, 2)
    fim = round(segment.end, 2)
    texto = segment.text.strip()
    transcricao_blocos.append({"inicio": inicio, "fim": fim, "texto": texto})
    texto_completo_partes.append(texto)

texto_completo = " ".join(texto_completo_partes)

# =========================
# GERAR RESUMO COM CLAUDE
# =========================

print("Gerando resumo com Claude...")

client = anthropic.Anthropic(api_key=ANTHROPIC_API_KEY or None)

prompt_resumo = f"""Você recebeu a transcrição de um vídeo/podcast do YouTube.

Título: {titulo_video}
Autor/Canal: {autor_video}

Transcrição:
{texto_completo[:15000]}

Por favor, gere:
1. Um resumo executivo de 3 a 5 parágrafos cobrindo os principais temas discutidos.
2. Uma lista de tópicos-chave abordados (bullet points).
3. Os principais insights ou conclusões do conteúdo.

Responda em português e em formato Markdown."""

message = client.messages.create(
    model="claude-sonnet-4-6",
    max_tokens=2048,
    messages=[{"role": "user", "content": prompt_resumo}]
)

resumo_markdown = message.content[0].text

# =========================
# GERAR MARKDOWN FINAL
# =========================

print("Gerando Markdown...")

data_processamento = datetime.now().strftime("%Y-%m-%d %H:%M")

markdown = f"""# {titulo_video}

## Metadados

| Campo | Valor |
|-------|-------|
| Autor / Canal | {autor_video} |
| Data de publicação | {upload_date} |
| Duração | {duracao} |
| URL | {YOUTUBE_URL} |
| Data de processamento | {data_processamento} |
| Modelo Whisper | {MODELO_WHISPER} |
| Idioma detectado | {info.language} |

---

## Resumo

{resumo_markdown}

---

## Transcrição Completa

"""

for bloco in transcricao_blocos:
    markdown += f"**[{bloco['inicio']}s – {bloco['fim']}s]**\n\n{bloco['texto']}\n\n"

md_path.write_text(markdown, encoding="utf-8")

print("\nConcluído!")
print(f"  Markdown salvo em: {md_path}")
