# -*- coding: utf-8 -*-
"""
Created on Mon Jun 15 23:24:34 2026

@author: andre
"""

# -*- coding: utf-8 -*-
"""
Created on Thu May 21 11:05:13 2026

@author: andre
"""

from pathlib import Path
from urllib.parse import urlparse
import requests
from tqdm import tqdm
from playwright.async_api import async_playwright, TimeoutError as PlaywrightTimeoutError
import html2text
import fitz

meses = { 1: "Janeiro",
    2: "Fevereiro",
    3: "Marco",
    4: "Abril",
    5: "Maio",
    6: "Junho",
    7: "Julho",
    8: "Agosto",
    9: "Setembro",
    10: "Outubro",
    11: "Novembro",
    12: "Dezembro"}

meses_2 = { 1: "Jan",
    2: "Fev",
    3: "Mar",
    4: "Abr",
    5: "Mai",
    6: "Jun",
    7: "Jul",
    8: "Ago",
    9: "Set",
    10: "Out",
    11: "Nov",
    12: "Dez"}


meses_3 = { 1: "jan",
    2: "fev",
    3: "mar",
    4: "abr",
    5: "mai",
    6: "jun",
    7: "jul",
    8: "ago",
    9: "set",
    10: "out",
    11: "nov",
    12: "dez"}


def baixar_arquivos(lista_links, pasta_destino="downloads", timeout=30):
    pasta = Path(pasta_destino)
    pasta.mkdir(parents=True, exist_ok=True)

    headers = {
        "User-Agent": (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 (KHTML, like Gecko) "
            "Chrome/124.0.0.0 Safari/537.36"
        ),
        "Accept": "application/pdf,application/octet-stream,*/*",
        "Accept-Language": "pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7",
        "Connection": "keep-alive",
    }

    session = requests.Session()
    session.headers.update(headers)

    for url in lista_links:
        try:
            print(f"\nBaixando: {url}")

            # adiciona referer baseado no próprio domínio
            parsed = urlparse(url)
            referer = f"{parsed.scheme}://{parsed.netloc}/"

            response = session.get(
                url,
                stream=True,
                timeout=timeout,
                headers={"Referer": referer}
            )

            response.raise_for_status()

            nome_arquivo = Path(parsed.path).name or "arquivo_sem_nome.pdf"
            caminho_arquivo = pasta / nome_arquivo

            total = int(response.headers.get("content-length", 0))

            with open(caminho_arquivo, "wb") as f, tqdm(
                desc=nome_arquivo,
                total=total,
                unit="B",
                unit_scale=True,
                unit_divisor=1024,
            ) as bar:
                for chunk in response.iter_content(chunk_size=8192):
                    if chunk:
                        f.write(chunk)
                        bar.update(len(chunk))

            print(f"✅ Salvo em: {caminho_arquivo}")

        except requests.exceptions.HTTPError as e:
            print(f"❌ Erro HTTP ao baixar: {url}")
            print(e)

        except Exception as e:
            print(f"❌ Erro ao baixar: {url}")
            print(e)
            

async def salvar_pagina_pdf(url, pasta_destino="downloads", timeout=90000):
    Path(pasta_destino).mkdir(exist_ok=True)
    nome = Path(urlparse(url).path).name or "pagina.pdf"
    if not nome.endswith(".pdf"):
        nome += ".pdf"
    caminho_pdf = Path(pasta_destino) / nome
    try:
        async with async_playwright() as p:
            browser = await p.chromium.launch(headless=True)
            page = await browser.new_page()
            await page.goto(url, wait_until="commit", timeout=timeout)
            await page.wait_for_timeout(5000)
            await page.pdf(path=str(caminho_pdf), format="A4", print_background=True)
            await browser.close()

        print(f"PDF salvo: {caminho_pdf}")
    except PlaywrightTimeoutError:
        print(f"Timeout ao carregar: {url}")
    except Exception as e:
        print(f"Erro em {url}: {e}")
 

async def salvar_pagina_markdown(url, pasta_destino="downloads", timeout=90000):
    Path(pasta_destino).mkdir(exist_ok=True)
    nome = Path(urlparse(url).path).stem or "pagina"
    caminho_md = Path(pasta_destino) / f"{nome}.md"

    try:
        async with async_playwright() as p:
            browser = await p.chromium.launch(headless=True)
            page = await browser.new_page()
            await page.goto(url, wait_until="commit", timeout=timeout)
            await page.wait_for_timeout(5000)
            html = await page.content()
            await browser.close()

        conversor = html2text.HTML2Text()
        conversor.ignore_links = False
        conversor.ignore_images = True
        conversor.body_width = 0
        markdown = conversor.handle(html)
        with open(caminho_md, "w", encoding="utf-8") as f:
            f.write(markdown)
        print(f"Markdown salvo: {caminho_md}")

    except PlaywrightTimeoutError:
        print(f"Timeout ao carregar: {url}")
    except Exception as e:
        print(f"Erro em {url}: {e}")


def pdf_para_markdown(pdf_path, pasta_destino="downloads"):
    pdf_path = Path(pdf_path)
    nome_md = pdf_path.stem + ".md"
    caminho_md = Path(pasta_destino) / nome_md
    doc = fitz.open(pdf_path)
    markdown = ""
    for pagina in doc:
        texto = pagina.get_text()
        markdown += f"\n\n# Página {pagina.number + 1}\n\n"
        markdown += texto

    with open(caminho_md, "w", encoding="utf-8") as f:
        f.write(markdown)
    print(f"Markdown salvo: {caminho_md}")
    
# =========================
# EXEMPLO DE USO
# =========================


links_verde = [
    f"https://www.verdeasset.com.br/public/files/rel_gestao/158094/Verde-REL-{ano}_{mes:02d}.pdf"
    for ano in range(1998, 2027)
    for mes in range(1, 13)
    if not (ano == 2026 and mes > 5)]


links_gavea = [
    f"https://www.gaveainvest.com.br/wp-content/uploads/{ano}/{mes+1:02d}/Relatorio-Mensal-GM-{meses[mes]}-{ano}.pdf"
    for ano in range(2015, 2027)
    for mes in range(1, 13)
    if not (ano == 2026 and mes > 5)]



links_adam = [
    f"https://adamcapital.com.br/wp-content/uploads/{ano}/{mes+1:02d}/Carta-Mensal-{meses_2[mes]}-{ano}.pdf"
    for ano in range(2020, 2027)
    for mes in range(1, 13)
    if not (ano == 2026 and mes > 5)]


#https://www.bahiaasset.com.br/wp-content/uploads/2026/05/carta_do_gestor_abr26.pdf
links_bahia = [
    (   f"https://www.bahiaasset.com.br/wp-content/uploads/"
        f"{ano if mes < 12 else ano + 1}/"
        f"{mes + 1 if mes < 12 else 1:02d}/"
        f"carta_do_gestor_{meses_2[mes]}{ano % 100:02d}.pdf"
    )
    for ano in range(2015, 2027)
    for mes in range(1, 13)
    if not (ano == 2026 and mes > 5)]

#https://www.legacycapital.com.br/wp-content/uploads/202604_Carta-Mensal.pdf
links_legacy = [
    f"https://www.legacycapital.com.br/wp-content/uploads/{ano}{mes:02d}_Carta-Mensal.pdf"
    for ano in range(2015, 2027)
    for mes in range(1, 13)
    if not (ano == 2026 and mes > 5)]


links_kapitalo = [
    f"https://www.kapitalo.com.br/wp-content/uploads/"
    f"{pasta}/"
    f"Carta-{var0}K10{separador}{meses[mes]}{var1}{ano}{var2}.pdf"
    for pasta in ["2022/09","2020/02"]
    for ano in range(2026, 2026)
    for mes in range(1, 13)
    for var0 in ["","do-Gestor-","do-Gestor_"]
    for var1 in ["", "-"]
    for var2 in ["", "-1","-VF","-final",'-2']
    for separador in ['-','_']
    if not (ano == 2026 and mes > 5)]


links_armor = [
    (   f"https://armorcapital.com.br/wp-content/uploads/"
        f"{ano if mes < 12 else ano + 1}/"
        f"{mes + 1 if mes < 12 else 1:02d}/"
        f"{ano}{mes:02d}_CartaMensalArmorCapital.pdf" )
    for ano in range(2020, 2027)
    for mes in range(1, 13)
    if not (ano == 2026 and mes > 4)]

links_sparta = [
    f"https://www.sparta.com.br/uploads/CartaMensal_{ano}{mes:02d}.pdf"
    for ano in range(2025, 2027)
    for mes in range(1, 13)
    if not (ano == 2026 and mes > 4)]

links_jgp = [
    (    f"https://jgp.com.br/wp-content/uploads/"
        f"{ano if mes < 12 else ano + 1}/"
        f"{mes + 1 if mes < 12 else 1:02d}/"
        f"JGP_Carta-Macroeconomica_{meses_2[mes]}{ano % 100:02d}.pdf"
    )
    for ano in range(2020, 2027)
    for mes in range(1, 13)
    if not (ano == 2026 and mes > 4)]

          
links_ibiuna = "https://www.ibiunainvest.com.br/wp-content/uploads/fundos/RelatorioMensal_IbiunaHedgeFIFCIC.pdf"


links_azimuth = [
    (f"https://media.azimutwealth.com.br/carta-mensal-{meses[mes]}-{ano}/")
    for ano in range(2020, 2027)
    for mes in range(1, 13)
    if not (ano == 2026 and mes > 5)]


def numero_carta_dynamo_trimestral( ano, mes, ano_base=2026,  mes_base=4, numero_base=128):
    diferenca_meses = (ano - ano_base) * 12 + (mes - mes_base)
    diferenca_trimestres = diferenca_meses // 3
    return numero_base + diferenca_trimestres

def numero_periodica( ano, periodo, ano_base, periodo_base, numero_base, frequencia=4):
    diferenca_periodos = ((ano - ano_base) * frequencia + (periodo - periodo_base))
    return numero_base + diferenca_periodos


def numero_periodico(ano, mes, ano_base, mes_base, numero_base, frequencia=4):
    diferenca_meses = ((ano - ano_base) * 12) + (mes - mes_base)
    meses_por_periodo = 12 // frequencia
    diferenca_periodos = diferenca_meses // meses_por_periodo
    return numero_base + diferenca_periodos

links_dynamo = [
    f"https://www.dynamo.com.br/wp-content/uploads/{ano}/{mes:02d}/Carta-Dynamo-{numero_teste}.pdf"
    for ano in range(2020, 2025)
    for mes in range(1, 13)
    for numero_esperado in [numero_periodico(ano, mes=4, ano_base = 2026, mes_base=4, numero_base=128, frequencia=4)]
    # tenta 5 antes e 5 depois
    for numero_teste in range(numero_esperado - 5, numero_esperado + 6)
    if not (ano == 2026 and mes > 5)
]


links_guepardo = list(set([
    f"https://www.guepardoinvest.com.br/wp-content/uploads/Carta-{numero_teste}-Carta-aos-Investidores-{trimestre}T{ano % 100:02d}.pdf"
    for ano in range(2022, 2027)
    for mes in range(1, 13)
    for trimestre in [((mes - 1) // 3) + 1]
    for numero_esperado in [numero_periodico(ano, mes=12, ano_base=2025, mes_base=4, numero_base=116, frequencia=4)]
    for numero_teste in range(numero_esperado - 5, numero_esperado + 6)
    if not (ano == 2026 and trimestre > 2)
]))

from datetime import date, timedelta


from datetime import date, timedelta

data_base = date(2017, 7, 26)
reuniao_base = 208

links_copom = list(dict.fromkeys([
    f"https://www.bcb.gov.br/content/copom/atascopom/Copom{reuniao}-not{data:%Y%m%d}{reuniao}.pdf"
    for reuniao in range(211, 149, -1)
    for data_estimativa in [data_base + timedelta(days=(reuniao - reuniao_base) * 45)]
    for data in [data_estimativa + timedelta(days=d) for d in range(-45, 45)]
    if data.weekday() == 2  # quarta-feira
]))

#https://www.bcb.gov.br/content/ri/relatorioinflacao/{ano}{mes:02d}/rpm{ano}{mes:02d}p.pdf
links_rpm =  list(set([
    f"https://www.bcb.gov.br/content/ri/relatorioinflacao/{ano}{mes:02d}/rpm{ano}{mes:02d}p.pdf"
    for ano in range(2024, 2027)
    for mes in range(1, 13)
    if not (ano == 2026 and mes > 5)
]))

links_rpm_box =  list(set([
    f"https://www.bcb.gov.br/content/ri/relatorioinflacao/{ano}{mes:02d}/rpm{ano}{mes:02d}b{count}p.pdf"
    for ano in range(2024, 2027)
    for mes in range(1, 13)
    if not (ano == 2026 and mes > 5)
    for count in range(1,13)
]))





for link in list(links_kinea):
    await salvar_pagina_pdf(link, pasta_destino="downloads", timeout=20000)
    await salvar_pagina_markdown(link, pasta_destino="downloads",timeout=20000)
    
    

baixar_arquivos(links_rpm)          

for link in list(links_azimuth):
    await salvar_pagina_pdf(link, pasta_destino="downloads", timeout=20000)
    await salvar_pagina_markdown(link, pasta_destino="downloads",timeout=20000)


#salvar_pagina_pdf("https://media.azimutwealth.com.br/carta-mensal-Maio-2026/", pasta_destino="downloads", timeout=20000)
#salvar_pagina_markdown("https://media.azimutwealth.com.br/carta-mensal-Maio-2026/", pasta_destino="downloads",timeout=20000) 




    
    ################################################################################ 
    ################################################################################
    ################################ HISTORICOS ####################################
    ################################################################################
    ################################################################################
    
comunicados = {

    "Copom eleva a taxa Selic para 5,25% a.a. - 240ª reunião - agosto 2021": "https://www.bcb.gov.br/controleinflacao/comunicadoscopom/17494",
    "Copom eleva a taxa Selic para 4,25% a.a. - 239ª reunião - junho 2021": "https://www.bcb.gov.br/controleinflacao/comunicadoscopom/17465",
    "Copom eleva a taxa Selic para 3,50% a.a. - 238ª reunião - maio 2021": "https://www.bcb.gov.br/controleinflacao/comunicadoscopom/17440",
    "Copom eleva a taxa Selic para 2,75% a.a. - 237ª reunião - março 2021": "https://www.bcb.gov.br/controleinflacao/comunicadoscopom/17403",
    "Copom mantém a taxa Selic em 2,00% a.a. - 236ª reunião - janeiro 2021": "https://www.bcb.gov.br/controleinflacao/comunicadoscopom/17369",
    "Copom mantém a taxa Selic em 2,00% a.a. - 235ª reunião - dezembro 2020": "https://www.bcb.gov.br/controleinflacao/comunicadoscopom/17333",
    "Copom mantém a taxa Selic em 2,00% a.a. - 234ª reunião - outubro 2020": "https://www.bcb.gov.br/controleinflacao/comunicadoscopom/17285",
    "Copom mantém a taxa Selic em 2,00% a.a. - 233ª reunião - setembro 2020": "https://www.bcb.gov.br/controleinflacao/comunicadoscopom/17252",
    "Copom reduz a taxa Selic para 2,00% a.a. - 232ª reunião - agosto 2020": "https://www.bcb.gov.br/controleinflacao/comunicadoscopom/17220",
    "Copom reduz a taxa Selic para 2,25% a.a. - 231ª reunião - junho 2020": "https://www.bcb.gov.br/controleinflacao/comunicadoscopom/17183",
    "Copom reduz a taxa Selic para 3,00% a.a. - 230ª reunião - maio 2020": "https://www.bcb.gov.br/controleinflacao/comunicadoscopom/17152",
    "Copom reduz a taxa Selic para 3,75% a.a. - 229ª reunião - março 2020": "https://www.bcb.gov.br/controleinflacao/comunicadoscopom/17106",
    "Copom reduz taxa Selic para 4,25% a.a. - 228ª reunião - fevereiro 2020": "https://www.bcb.gov.br/controleinflacao/comunicadoscopom/17071",
    "Copom reduz taxa Selic para 4,50% a.a. - 227ª reunião - dezembro 2019": "https://www.bcb.gov.br/controleinflacao/comunicadoscopom/17029",
    "Copom reduz taxa Selic para 5,00% a.a. - 226ª reunião - outubro 2019": "https://www.bcb.gov.br/controleinflacao/comunicadoscopom/16974",
    "Copom reduz taxa Selic para 5,50% a.a. - 225ª reunião - setembro 2019": "https://www.bcb.gov.br/controleinflacao/comunicadoscopom/16938",
    "Copom reduz taxa Selic para 6,00% a.a. - 224ª reunião - julho 2019": "https://www.bcb.gov.br/controleinflacao/comunicadoscopom/16885",
    "Copom mantém taxa Selic em 6,50% a.a. - 223ª reunião - junho 2019": "https://www.bcb.gov.br/controleinflacao/comunicadoscopom/16849",
    "Copom mantém taxa Selic em 6,50 % a.a. - 222ª reunião - maio 2019": "https://www.bcb.gov.br/controleinflacao/comunicadoscopom/16815",
    "Copom mantém taxa Selic em 6,50 % ao ano - 221ª reunião - março 2019": "https://www.bcb.gov.br/controleinflacao/comunicadoscopom/16762",
    "Copom mantém taxa Selic em 6,50 % a.a. - 220ª reunião - fevereiro 2019": "https://www.bcb.gov.br/controleinflacao/comunicadoscopom/16730",
    "Copom mantém taxa Selic em 6,50% a.a. - 219ª reunião - dezembro 2018": "https://www.bcb.gov.br/controleinflacao/comunicadoscopom/16697",
    "Copom mantém taxa Selic em 6,50 % a.a. - 218ª reunião - outubro 2018": "https://www.bcb.gov.br/controleinflacao/comunicadoscopom/16595",
    "Copom mantém taxa Selic em 6,50% a.a. - 217ª reunião - setembro 2018": "https://www.bcb.gov.br/controleinflacao/comunicadoscopom/16569",
    "Copom mantém taxa Selic em 6,50% a.a. - 216ª reunião - agosto 2018": "https://www.bcb.gov.br/controleinflacao/comunicadoscopom/16538",
    "Copom mantém taxa Selic em 6,50% a.a. - 215ª reunião - junho 2018": "https://www.bcb.gov.br/controleinflacao/comunicadoscopom/16512",
    "Copom mantém taxa Selic em 6,50% a.a. - 214ª reunião - maio 2018": "https://www.bcb.gov.br/controleinflacao/comunicadoscopom/16475",
    "Copom reduz taxa Selic para 6,50% ao ano - 213ª reunião - março 2018": "https://www.bcb.gov.br/controleinflacao/comunicadoscopom/16417",
    "Copom reduz a taxa Selic para 6,75% ao ano - 212ª reunião - fevereiro 2018": "https://www.bcb.gov.br/controleinflacao/comunicadoscopom/16381",
    "Copom reduz a taxa Selic para 7,00% ao ano - 211ª reunião - dezembro 2017": "https://www.bcb.gov.br/controleinflacao/comunicadoscopom/16326",
    "Copom reduz a taxa Selic para 7,50% ao ano - 210ª reunião - outubro 2017": "https://www.bcb.gov.br/controleinflacao/comunicadoscopom/16274",
    "Copom reduz a taxa Selic para 8,25% ao ano - 209ª reunião - setembro 2017": "https://www.bcb.gov.br/controleinflacao/comunicadoscopom/16243",
    "Copom reduz a taxa Selic para 9,25% ao ano - 208ª reunião - julho 2017": "https://www.bcb.gov.br/controleinflacao/comunicadoscopom/16188",
    "Copom reduz a taxa Selic para 10,25% ao ano - 207ª reunião - maio 2017": "https://www.bcb.gov.br/controleinflacao/comunicadoscopom/16135",
    "Copom reduz a taxa Selic para 11,25% ao ano - 206ª reunião - abril 2017": "https://www.bcb.gov.br/controleinflacao/comunicadoscopom/16098",
    "Copom reduz a taxa Selic para 12,25% ao ano - 205ª reunião - fevereiro 2017": "https://www.bcb.gov.br/controleinflacao/comunicadoscopom/16027",
    "Copom reduz a taxa Selic para 13,00% ao ano - 204ª reunião - janeiro 2017": "https://www.bcb.gov.br/controleinflacao/comunicadoscopom/15989",
    "Copom reduz a taxa Selic para 13,75% ao ano - 203ª reunião - novembro 2016": "https://www.bcb.gov.br/controleinflacao/comunicadoscopom/21094",
    "Copom reduz a taxa Selic para 14,00% ao ano - 202ª reunião - outubro 2016": "https://www.bcb.gov.br/controleinflacao/comunicadoscopom/21093",
    "Nota à Imprensa - 201ª reunião - agosto 2016": "https://www.bcb.gov.br/controleinflacao/comunicadoscopom/15961",
    "Nota à Imprensa - 200ª reunião - julho 2016": "https://www.bcb.gov.br/controleinflacao/comunicadoscopom/15960",
    "Nota à Imprensa - 199ª reunião - junho 2016": "https://www.bcb.gov.br/controleinflacao/comunicadoscopom/15959",
    "Nota à Imprensa - 198ª reunião - abril 2016": "https://www.bcb.gov.br/controleinflacao/comunicadoscopom/15958",
    "Nota à Imprensa - 197ª reunião - março 2016": "https://www.bcb.gov.br/controleinflacao/comunicadoscopom/15957",
    "Nota à Imprensa - 196ª reunião - janeiro 2016": "https://www.bcb.gov.br/controleinflacao/comunicadoscopom/15956",
}

atas = {
  "198ª Reunião - abril 2016": "https://www.bcb.gov.br/publicacoes/atascopom/27042016",
  "197ª Reunião - março 2016": "https://www.bcb.gov.br/publicacoes/atascopom/02032016",
  "196ª Reunião - janeiro 2016": "https://www.bcb.gov.br/publicacoes/atascopom/20012016",
  "195ª Reunião - novembro 2015": "https://www.bcb.gov.br/publicacoes/atascopom/25112015",
  "194ª Reunião - outubro 2015": "https://www.bcb.gov.br/publicacoes/atascopom/21102015",
  "193ª Reunião - setembro 2015": "https://www.bcb.gov.br/publicacoes/atascopom/02092015",
  "192ª Reunião - julho 2015": "https://www.bcb.gov.br/publicacoes/atascopom/29072015",
  "191ª Reunião - junho 2015": "https://www.bcb.gov.br/publicacoes/atascopom/03062015",
  "190ª Reunião - abril 2015": "https://www.bcb.gov.br/publicacoes/atascopom/29042015",
  "189ª Reunião - março 2015": "https://www.bcb.gov.br/publicacoes/atascopom/04032015",
  "188ª Reunião - janeiro 2015": "https://www.bcb.gov.br/publicacoes/atascopom/21012015",
  "187ª Reunião - dezembro 2014": "https://www.bcb.gov.br/publicacoes/atascopom/03122014",
  "186ª Reunião - outubro 2014": "https://www.bcb.gov.br/publicacoes/atascopom/29102014",
  "185ª Reunião - setembro 2014": "https://www.bcb.gov.br/publicacoes/atascopom/03092014",
  "184ª Reunião - julho 2014": "https://www.bcb.gov.br/publicacoes/atascopom/16072014",
  "183ª Reunião - maio 2014": "https://www.bcb.gov.br/publicacoes/atascopom/28052014",
  "182ª Reunião - abril 2014": "https://www.bcb.gov.br/publicacoes/atascopom/02042014",
  "181ª Reunião - fevereiro 2014": "https://www.bcb.gov.br/publicacoes/atascopom/26022014",
  "180ª Reunião - janeiro 2014": "https://www.bcb.gov.br/publicacoes/atascopom/15012014",
  "179ª Reunião - novembro 2013": "https://www.bcb.gov.br/publicacoes/atascopom/27112013",
  "178ª Reunião - outubro 2013": "https://www.bcb.gov.br/publicacoes/atascopom/09102013",
  "177ª Reunião - agosto 2013": "https://www.bcb.gov.br/publicacoes/atascopom/28082013",
  "176ª Reunião - julho 2013": "https://www.bcb.gov.br/publicacoes/atascopom/10072013",
  "175ª Reunião - maio 2013": "https://www.bcb.gov.br/publicacoes/atascopom/29052013",
  "174ª Reunião - abril 2013": "https://www.bcb.gov.br/publicacoes/atascopom/17042013",
  "173ª Reunião - março 2013": "https://www.bcb.gov.br/publicacoes/atascopom/06032013",
  "172ª Reunião - janeiro 2013": "https://www.bcb.gov.br/publicacoes/atascopom/16012013",
  "171ª Reunião - novembro 2012": "https://www.bcb.gov.br/publicacoes/atascopom/28112012",
  "170ª Reunião - outubro 2012": "https://www.bcb.gov.br/publicacoes/atascopom/10102012",
  "169ª Reunião - agosto 2012": "https://www.bcb.gov.br/publicacoes/atascopom/29082012",
  "168ª Reunião - julho 2012": "https://www.bcb.gov.br/publicacoes/atascopom/11072012",
  "167ª Reunião - maio 2012": "https://www.bcb.gov.br/publicacoes/atascopom/30052012",
  "166ª Reunião - abril 2012": "https://www.bcb.gov.br/publicacoes/atascopom/18042012",
  "165ª Reunião - março 2012": "https://www.bcb.gov.br/publicacoes/atascopom/07032012",
  "164ª Reunião - janeiro 2012": "https://www.bcb.gov.br/publicacoes/atascopom/18012012",
  "163ª Reunião - novembro 2011": "https://www.bcb.gov.br/publicacoes/atascopom/30112011",
  "162ª Reunião - outubro 2011": "https://www.bcb.gov.br/publicacoes/atascopom/19102011",
  "161ª Reunião - agosto 2011": "https://www.bcb.gov.br/publicacoes/atascopom/31082011",
  "160ª Reunião - julho 2011": "https://www.bcb.gov.br/publicacoes/atascopom/20072011",
  "159ª Reunião - junho 2011": "https://www.bcb.gov.br/publicacoes/atascopom/08062011",
  "158ª Reunião - abril 2011": "https://www.bcb.gov.br/publicacoes/atascopom/20042011",
  "157ª Reunião - março 2011": "https://www.bcb.gov.br/publicacoes/atascopom/02032011",
  "156ª Reunião - janeiro 2011": "https://www.bcb.gov.br/publicacoes/atascopom/19012011",
  "155ª Reunião - dezembro 2010": "https://www.bcb.gov.br/publicacoes/atascopom/08122010",
  "154ª Reunião - outubro 2010": "https://www.bcb.gov.br/publicacoes/atascopom/20102010",
  "153ª Reunião - setembro 2010": "https://www.bcb.gov.br/publicacoes/atascopom/01092010",
  "152ª Reunião - julho 2010": "https://www.bcb.gov.br/publicacoes/atascopom/21072010",
  "151ª Reunião - junho 2010": "https://www.bcb.gov.br/publicacoes/atascopom/09062010",
  "150ª Reunião - abril 2010": "https://www.bcb.gov.br/publicacoes/atascopom/28042010",
  "149ª Reunião - março 2010": "https://www.bcb.gov.br/publicacoes/atascopom/17032010",
  "148ª Reunião - janeiro 2010": "https://www.bcb.gov.br/publicacoes/atascopom/27012010",
  "147ª Reunião - dezembro 2009": "https://www.bcb.gov.br/publicacoes/atascopom/09122009",
  "146ª Reunião - outubro 2009": "https://www.bcb.gov.br/publicacoes/atascopom/21102009",
  "145ª Reunião - setembro 2009": "https://www.bcb.gov.br/publicacoes/atascopom/02092009",
  "144ª Reunião - julho 2009": "https://www.bcb.gov.br/publicacoes/atascopom/22072009",
  "143ª Reunião - junho 2009": "https://www.bcb.gov.br/publicacoes/atascopom/10062009",
  "142ª Reunião - abril 2009": "https://www.bcb.gov.br/publicacoes/atascopom/29042009",
  "141ª Reunião - março 2009": "https://www.bcb.gov.br/publicacoes/atascopom/11032009",
  "140ª Reunião - janeiro 2009": "https://www.bcb.gov.br/publicacoes/atascopom/21012009",
  "139ª Reunião - dezembro 2008": "https://www.bcb.gov.br/publicacoes/atascopom/10122008",
  "138ª Reunião - outubro 2008": "https://www.bcb.gov.br/publicacoes/atascopom/29102008",
  "137ª Reunião - setembro 2008": "https://www.bcb.gov.br/publicacoes/atascopom/10092008",
  "136ª Reunião - julho 2008": "https://www.bcb.gov.br/publicacoes/atascopom/23072008",
  "135ª Reunião - junho 2008": "https://www.bcb.gov.br/publicacoes/atascopom/04062008",
  "134ª Reunião - abril 2008": "https://www.bcb.gov.br/publicacoes/atascopom/16042008",
  "133ª Reunião - março 2008": "https://www.bcb.gov.br/publicacoes/atascopom/05032008",
  "132ª Reunião - janeiro 2008": "https://www.bcb.gov.br/publicacoes/atascopom/23012008",
  "131ª Reunião - dezembro 2007": "https://www.bcb.gov.br/publicacoes/atascopom/05122007",
  "130ª Reunião - outubro 2007": "https://www.bcb.gov.br/publicacoes/atascopom/17102007",
  "129ª Reunião - setembro 2007": "https://www.bcb.gov.br/publicacoes/atascopom/05092007",
  "128ª Reunião - julho 2007": "https://www.bcb.gov.br/publicacoes/atascopom/18072007",
  "127ª Reunião - junho 2007": "https://www.bcb.gov.br/publicacoes/atascopom/06062007",
  "126ª Reunião - abril 2007": "https://www.bcb.gov.br/publicacoes/atascopom/18042007",
  "125ª Reunião - março 2007": "https://www.bcb.gov.br/publicacoes/atascopom/07032007",
  "124ª Reunião - janeiro 2007": "https://www.bcb.gov.br/publicacoes/atascopom/24012007",
  "123ª Reunião - novembro 2006": "https://www.bcb.gov.br/publicacoes/atascopom/29112006",
  "122ª Reunião - outubro 2006": "https://www.bcb.gov.br/publicacoes/atascopom/18102006",
  "121ª Reunião - agosto 2006": "https://www.bcb.gov.br/publicacoes/atascopom/02082006",
  "120ª Reunião - julho 2006": "https://www.bcb.gov.br/publicacoes/atascopom/19072006",
  "119ª Reunião - maio 2006": "https://www.bcb.gov.br/publicacoes/atascopom/31052006",
  "118ª Reunião - abril 2006": "https://www.bcb.gov.br/publicacoes/atascopom/19042006",
  "117ª Reunião - março 2006": "https://www.bcb.gov.br/publicacoes/atascopom/08032006",
  "116ª Reunião - janeiro 2006": "https://www.bcb.gov.br/publicacoes/atascopom/18012006",
  "115ª Reunião - dezembro 2005": "https://www.bcb.gov.br/publicacoes/atascopom/14122005",
  "114ª Reunião - novembro 2005": "https://www.bcb.gov.br/publicacoes/atascopom/23112005",
  "113ª Reunião - outubro 2005": "https://www.bcb.gov.br/publicacoes/atascopom/19102005",
  "112ª Reunião - setembro 2005": "https://www.bcb.gov.br/publicacoes/atascopom/07092005",
  "111ª Reunião - agosto 2005": "https://www.bcb.gov.br/publicacoes/atascopom/17082005",
  "110ª Reunião - julho 2005": "https://www.bcb.gov.br/publicacoes/atascopom/20072005",
  "109ª Reunião - junho 2005": "https://www.bcb.gov.br/publicacoes/atascopom/08062005",
  "108ª Reunião - maio 2005": "https://www.bcb.gov.br/publicacoes/atascopom/18052005",
  "107ª Reunião - abril 2005": "https://www.bcb.gov.br/publicacoes/atascopom/20042005",
  "106ª Reunião - março 2005": "https://www.bcb.gov.br/publicacoes/atascopom/16032005",
  "105ª Reunião - fevereiro 2005": "https://www.bcb.gov.br/publicacoes/atascopom/02022005",
  "104ª Reunião - janeiro 2005": "https://www.bcb.gov.br/publicacoes/atascopom/19012005",
  "103ª Reunião - dezembro 2004": "https://www.bcb.gov.br/publicacoes/atascopom/15122004",
  "102ª Reunião - novembro 2004": "https://www.bcb.gov.br/publicacoes/atascopom/17112004",
  "101ª Reunião - outubro 2004": "https://www.bcb.gov.br/publicacoes/atascopom/20102004",
  "100ª Reunião - setembro 2004": "https://www.bcb.gov.br/publicacoes/atascopom/15092004",
  "99ª Reunião - agosto 2004": "https://www.bcb.gov.br/publicacoes/atascopom/18082004",
  "98ª Reunião - julho 2004": "https://www.bcb.gov.br/publicacoes/atascopom/21072004",
  "97ª Reunião - junho 2004": "https://www.bcb.gov.br/publicacoes/atascopom/16062004",
  "96ª Reunião - maio 2004": "https://www.bcb.gov.br/publicacoes/atascopom/05052004",
  "95ª Reunião - abril 2004": "https://www.bcb.gov.br/publicacoes/atascopom/21042004",
  "94ª Reunião - março 2004": "https://www.bcb.gov.br/publicacoes/atascopom/17032004",
  "93ª Reunião - fevereiro 2004": "https://www.bcb.gov.br/publicacoes/atascopom/04022004",
  "92ª Reunião - janeiro 2004": "https://www.bcb.gov.br/publicacoes/atascopom/21012004",
  "91ª Reunião - dezembro 2003": "https://www.bcb.gov.br/publicacoes/atascopom/17122003",
  "90ª Reunião - novembro 2003": "https://www.bcb.gov.br/publicacoes/atascopom/19112003",
  "89ª Reunião - outubro 2003": "https://www.bcb.gov.br/publicacoes/atascopom/22102003",
  "88ª Reunião - setembro 2003": "https://www.bcb.gov.br/publicacoes/atascopom/17092003",
  "87ª Reunião - agosto 2003": "https://www.bcb.gov.br/publicacoes/atascopom/20082003",
  "86ª Reunião - julho 2003": "https://www.bcb.gov.br/publicacoes/atascopom/23072003",
  "85ª Reunião - junho 2003": "https://www.bcb.gov.br/publicacoes/atascopom/18062003",
  "84ª Reunião - maio 2003": "https://www.bcb.gov.br/publicacoes/atascopom/21052003",
  "83ª Reunião - abril 2003": "https://www.bcb.gov.br/publicacoes/atascopom/23042003",
  "82ª Reunião - março 2003": "https://www.bcb.gov.br/publicacoes/atascopom/19032003",
  "81ª Reunião - fevereiro 2003": "https://www.bcb.gov.br/publicacoes/atascopom/19022003",
  "80ª Reunião - janeiro 2003": "https://www.bcb.gov.br/publicacoes/atascopom/22012003",
  "79ª Reunião - dezembro 2002": "https://www.bcb.gov.br/publicacoes/atascopom/18122002",
  "78ª Reunião - novembro 2002": "https://www.bcb.gov.br/publicacoes/atascopom/20112002",
  "77ª Reunião - outubro 2002": "https://www.bcb.gov.br/publicacoes/atascopom/23102002",
  "76ª Reunião - outubro 2002": "https://www.bcb.gov.br/publicacoes/atascopom/14102002",
  "75ª Reunião - setembro 2002": "https://www.bcb.gov.br/publicacoes/atascopom/18092002",
  "74ª Reunião - agosto 2002": "https://www.bcb.gov.br/publicacoes/atascopom/21082002",
  "73ª Reunião - julho 2002": "https://www.bcb.gov.br/publicacoes/atascopom/24072002",
  "72ª Reunião - junho 2002": "https://www.bcb.gov.br/publicacoes/atascopom/19062002",
  "71ª Reunião - maio 2002": "https://www.bcb.gov.br/publicacoes/atascopom/22052002",
  "70ª Reunião - abril 2002": "https://www.bcb.gov.br/publicacoes/atascopom/24042002",
  "69ª Reunião - março 2002": "https://www.bcb.gov.br/publicacoes/atascopom/20032002",
  "68ª Reunião - fevereiro 2002": "https://www.bcb.gov.br/publicacoes/atascopom/20022002",
  "67ª Reunião - janeiro 2002": "https://www.bcb.gov.br/publicacoes/atascopom/23012002",
  "66ª Reunião - dezembro 2001": "https://www.bcb.gov.br/publicacoes/atascopom/19122001",
  "65ª Reunião - novembro 2001": "https://www.bcb.gov.br/publicacoes/atascopom/21112001",
  "64ª Reunião - outubro 2001": "https://www.bcb.gov.br/publicacoes/atascopom/17102001",
  "63ª Reunião - setembro 2001": "https://www.bcb.gov.br/publicacoes/atascopom/19092001",
  "62ª Reunião - agosto 2001": "https://www.bcb.gov.br/publicacoes/atascopom/22082001",
  "61ª Reunião - julho 2001": "https://www.bcb.gov.br/publicacoes/atascopom/18072001",
  "60ª Reunião - junho 2001": "https://www.bcb.gov.br/publicacoes/atascopom/20062001",
  "59ª Reunião - maio 2001": "https://www.bcb.gov.br/publicacoes/atascopom/23052001",
  "58ª Reunião - abril 2001": "https://www.bcb.gov.br/publicacoes/atascopom/18042001",
  "57ª Reunião - março 2001": "https://www.bcb.gov.br/publicacoes/atascopom/21032001",
  "56ª Reunião - fevereiro 2001": "https://www.bcb.gov.br/publicacoes/atascopom/14022001",
  "55ª Reunião - janeiro 2001": "https://www.bcb.gov.br/publicacoes/atascopom/17012001",
  "54ª Reunião - dezembro 2000": "https://www.bcb.gov.br/publicacoes/atascopom/20122000",
  "53ª Reunião - novembro 2000": "https://www.bcb.gov.br/publicacoes/atascopom/22112000",
  "52ª Reunião - outubro 2000": "https://www.bcb.gov.br/publicacoes/atascopom/18102000",
  "51ª Reunião - setembro 2000": "https://www.bcb.gov.br/publicacoes/atascopom/20092000",
  "50ª Reunião - agosto 2000": "https://www.bcb.gov.br/publicacoes/atascopom/23082000",
  "49ª Reunião - julho 2000": "https://www.bcb.gov.br/publicacoes/atascopom/19072000",
  "48ª Reunião - junho 2000": "https://www.bcb.gov.br/publicacoes/atascopom/21062000",
  "47ª Reunião - maio 2000": "https://www.bcb.gov.br/publicacoes/atascopom/17052000",
  "46ª Reunião - abril 2000": "https://www.bcb.gov.br/publicacoes/atascopom/19042000",
  "45ª Reunião - março 2000": "https://www.bcb.gov.br/publicacoes/atascopom/22032000",
  "44ª Reunião - fevereiro 2000": "https://www.bcb.gov.br/publicacoes/atascopom/16022000",
  "43ª Reunião - janeiro 2000": "https://www.bcb.gov.br/publicacoes/atascopom/19012000",
  "42ª Reunião - dezembro 1999": "https://www.bcb.gov.br/publicacoes/atascopom/22121999",
  "41ª Reunião - novembro 1999": "https://www.bcb.gov.br/publicacoes/atascopom/10111999",
  "40ª Reunião - outubro 1999": "https://www.bcb.gov.br/publicacoes/atascopom/06101999",
  "39ª Reunião (Extraordinária) - setembro 1999": "https://www.bcb.gov.br/publicacoes/atascopom/04091999",
  "38ª Reunião - setembro 1999": "https://www.bcb.gov.br/publicacoes/atascopom/01091999",
  "37ª Reunião - julho 1999": "https://www.bcb.gov.br/publicacoes/atascopom/28071999",
  "36ª Reunião - junho 1999": "https://www.bcb.gov.br/publicacoes/atascopom/23061999",
  "35ª Reunião - maio 1999": "https://www.bcb.gov.br/publicacoes/atascopom/19051999",
  "34ª Reunião - abril 1999": "https://www.bcb.gov.br/publicacoes/atascopom/14041999",
  "33ª Reunião - março 1999": "https://www.bcb.gov.br/publicacoes/atascopom/24031999",
  "32ª Reunião - janeiro 1999": "https://www.bcb.gov.br/publicacoes/atascopom/14011999",
  "31ª Reunião - dezembro 1998": "https://www.bcb.gov.br/publicacoes/atascopom/16121998",
  "30ª Reunião - novembro 1998": "https://www.bcb.gov.br/publicacoes/atascopom/11111998",
  "29ª Reunião - outubro 1998": "https://www.bcb.gov.br/publicacoes/atascopom/07101998",
  "28ª Reunião (Extraordinária) - setembro 1998": "https://www.bcb.gov.br/publicacoes/atascopom/10091998",
  "27ª Reunião - setembro 1998": "https://www.bcb.gov.br/publicacoes/atascopom/02091998",
  "26ª Reunião - julho 1998": "https://www.bcb.gov.br/publicacoes/atascopom/22071998",
  "25ª Reunião - junho 1998": "https://www.bcb.gov.br/publicacoes/atascopom/24061998",
  "24ª Reunião - maio 1998": "https://www.bcb.gov.br/publicacoes/atascopom/27051998",
  "23ª Reunião - abril 1998": "https://www.bcb.gov.br/publicacoes/atascopom/22041998",
  "22ª Reunião - março 1998": "https://www.bcb.gov.br/publicacoes/atascopom/04031998",
  "21ª Reunião - janeiro 1998": "https://www.bcb.gov.br/publicacoes/atascopom/28011998",
}

cartas_persevera = {
    "Contracorrente": "https://www.persevera.com.br/post/contracorrente",
    "Quando os juros mordem e o crédito grita": "https://www.persevera.com.br/post/quando-os-juros-mordem-e-o-cr%C3%A9dito-grita",
    "Entre ciclos": "https://www.persevera.com.br/post/entre-ciclos",
    "A estratégia do caos": "https://www.persevera.com.br/post/a-estrategia-do-caos",
    "Quando os astros se alinham": "https://www.persevera.com.br/post/quando-os-astros-se-alinham",
    "O padrão se repete": "https://www.persevera.com.br/post/o-padr%C3%A3o-se-repete",
    "A parte turbulenta do caminho": "https://www.persevera.com.br/post/a-parte-turbulenta-do-caminho",
    "Teoria dos Jogos": "https://www.persevera.com.br/post/teoria-dos-jogos-1",
    "Uma recessão orquestrada?": "https://www.persevera.com.br/post/uma-recessao-orquestrada-1",
    "Os primeiros dias de Trump": "https://www.persevera.com.br/post/os-primeiros-dias-de-trump-1",
    "Intervindo no momento certo": "https://www.persevera.com.br/post/intervindo-no-momento-certo",
    "Uma vitória pírrica": "https://www.persevera.com.br/post/uma-vitoria-pirrica-1",
    "Brasil e o consenso pessimista": "https://www.persevera.com.br/post/brasil-e-o-consenso-pessimista-1",
    "Precificados para a perfeição": "https://www.persevera.com.br/post/precificados-para-a-perfei%C3%A7%C3%A3o-1",
    "Primeiras impressões": "https://www.persevera.com.br/post/primeiras-impress%C3%B5es-1",
    "O inimigo agora é outro": "https://www.persevera.com.br/post/o-inimigo-agora-%C3%A9-outro-1",
    "Foto boa, filme ruim": "https://www.persevera.com.br/post/foto-boa-filme-ruim-1",
    "Brasil fora da festa": "https://www.persevera.com.br/post/brasil-fora-da-festa-1",
    "Da reflação à estagflação?": "https://www.persevera.com.br/post/da-refla%C3%A7%C3%A3o-%C3%A0-estagfla%C3%A7%C3%A3o-1",
    "Do pouso suave à reflação?": "https://www.persevera.com.br/post/do-pouso-suave-%C3%A0-refla%C3%A7%C3%A3o-1",
    "Importando o pouso suave, exportando o fantasma fiscal": "https://www.persevera.com.br/post/importando-o-pouso-suave-exportando-o-fantasma-fiscal-1",
    "Corte à vista!": "https://www.persevera.com.br/post/corte-%C3%A0-vista-1",
    "Ano novo, ciclo novo?": "https://www.persevera.com.br/post/ano-novo-ciclo-novo-1",
    "Rally de fim de ano?": "https://www.persevera.com.br/post/rally-de-fim-de-ano-1",
    "Nova Meta Fiscal": "https://www.persevera.com.br/post/nova-meta-fiscal-1",
    "Turbulência nos Mercados": "https://www.persevera.com.br/post/turbul%C3%AAncia-nos-mercados-1",
    "Susto Monetário, Susto Fiscal": "https://www.persevera.com.br/post/susto-monet%C3%A1rio-susto-fiscal-1",
    "Pousando Suavemente": "https://www.persevera.com.br/post/pousando-suavemente-1",
    "Corte de Juros em Agosto": "https://www.persevera.com.br/post/corte-de-juros-em-agosto-1",
    "Inflação abaixo de 4%": "https://www.persevera.com.br/post/infla%C3%A7%C3%A3o-abaixo-de-4-1",
    "Reaceleração Desinflacionária?": "https://www.persevera.com.br/post/reacelera%C3%A7%C3%A3o-desinflacion%C3%A1ria-1",
    "O Novo Arcabouço Fiscal": "https://www.persevera.com.br/post/o-novo-arcabou%C3%A7o-fiscal-1",
    "O Renascimento da Renda Fixa Ativa": "https://www.persevera.com.br/post/o-renascimento-da-renda-fixa-ativa-1",
    "Persevera Commodities": "https://www.persevera.com.br/post/persevera-commodities-1",
    "O Brasil sob nova direção": "https://www.persevera.com.br/post/o-brasil-sob-nova-dire%C3%A7%C3%A3o-1",
    "Herança bendita": "https://www.persevera.com.br/post/heran%C3%A7a-bendita-1",
    "Combatendo a inflação sem ajuda das commodities": "https://www.persevera.com.br/post/combatendo-a-infla%C3%A7%C3%A3o-sem-ajuda-das-commodities-1",
    "Persevera Nêmesis - 6 meses do nosso long bias defensivo": "https://www.persevera.com.br/post/persevera-n%C3%AAmesis-6-meses-do-nosso-long-bias-defensivo-1",
    "Commodities em uma recessão global": "https://www.persevera.com.br/post/commodities-em-uma-recess%C3%A3o-global-1",
    "Bear market bounce": "https://www.persevera.com.br/post/bear-market-bounce-1",
    "O retorno da histeria fiscal": "https://www.persevera.com.br/post/o-retorno-da-histeria-fiscal-1",
    "Tsunami lá e marola aqui?": "https://www.persevera.com.br/post/tsunami-l%C3%A1-e-marola-aqui-1",
    "Da mitologia ao mercado: O Persevera Nêmesis": "https://www.persevera.com.br/post/da-mitologia-ao-mercado-o-persevera-n%C3%AAmesis-1",
    "Dólar abaixo de R$4": "https://www.persevera.com.br/post/d%C3%B3lar-abaixo-de-r-4-1",
    "A crise fiscal é uma miragem?": "https://www.persevera.com.br/post/a-crise-fiscal-%C3%A9-uma-miragem-1",
    "Um novo Fed?": "https://www.persevera.com.br/post/um-novo-fed-1",
    "Economia fraca, mercados fortes?": "https://www.persevera.com.br/post/economia-fraca-mercados-fortes-1",
    "O canto da sereia do CDI": "https://www.persevera.com.br/post/o-canto-da-sereia-do-cdi-1",
    "Mercado de Ações e as Finanças Comportamentais": "https://www.persevera.com.br/post/mercado-de-a%C3%A7%C3%B5es-e-as-finan%C3%A7as-comportamentais-1",
    "Um novo superciclo de commodities?": "https://www.persevera.com.br/post/um-novo-superciclo-de-commodities-1",
    "Superávit fiscal à vista": "https://www.persevera.com.br/post/super%C3%A1vit-fiscal-%C3%A0-vista-1",
    "Um olhar alternativo sobre o retorno das ações": "https://www.persevera.com.br/post/um-olhar-alternativo-sobre-o-retorno-das-a%C3%A7%C3%B5es-1",
    "O poder da sinalização dos Bancos Centrais": "https://www.persevera.com.br/post/o-poder-da-sinaliza%C3%A7%C3%A3o-dos-bancos-centrais-1",
    "Uma forte recuperação no segundo trimestre": "https://www.persevera.com.br/post/uma-forte-recupera%C3%A7%C3%A3o-no-segundo-trimestre-1",
    "A revolução estrutural da dívida pública": "https://www.persevera.com.br/post/a-revolucao-estrutural-da-divida-publica-1",
    "Estratégias para capturar os altos retornos das ações": "https://www.persevera.com.br/post/estrat%C3%A9gias-para-capturar-os-altos-retornos-das-a%C3%A7%C3%B5es-1",
    "Os dilemas da gestão de recursos": "https://www.persevera.com.br/post/os-dilemas-da-gest%C3%A3o-de-recursos-1",
}




links_kapitalo = [
    f"https://www.kapitalo.com.br/wp-content/uploads/2022/09/Carta-do-Gestor-K10-{meses[mes]}{ano}.pdf"
    for ano in range(2025, 2027)
    for mes in range(1, 13)
    if not (ano == 2026 and mes > 5)]

links_kapitalo = [
    f"https://www.kapitalo.com.br/wp-content/uploads/2022/09/Carta-do-Gestor-K10-{meses[mes]}{ano}-1.pdf"
    for ano in range(2025, 2027)
    for mes in range(1, 13)
    if not (ano == 2026 and mes > 5)
]

links_kapitalo = [
    f"https://www.kapitalo.com.br/wp-content/uploads/2022/09/Carta-do-Gestor-K10-{meses[mes]}{ano}-1.pdf"
    for ano in range(2025, 2027)
    for mes in range(1, 13)
    if not (ano == 2026 and mes > 5)
]

links_kapitalo = [
    f"https://www.kapitalo.com.br/wp-content/uploads/{ano}/{mes:02d}/kapitalo_cartamensal_K10_{meses[mes]}.pdf"
    for ano in range(2020, 2025)
    for mes in range(1, 13)
    if not (ano == 2026 and mes > 5)
]

kadima = [
    "https://cdn-sites-assets.mziq.com/wp-content/uploads/sites/1234/2026/04/Carta-Trimestral-2026_03-2.pdf",
    "https://cdn-sites-assets.mziq.com/wp-content/uploads/sites/1234/2026/01/Carta-Trimestral-2025_12-2.pdf",
    "https://cdn-sites-assets.mziq.com/wp-content/uploads/sites/1234/2025/10/Carta-Trimestral-2025_10.pdf",
    "https://cdn-sites-assets.mziq.com/wp-content/uploads/sites/1234/2025/07/Carta-Trimestral-2025_06.pdf",
    "https://cdn-sites-assets.mziq.com/wp-content/uploads/sites/1234/2025/04/Carta-Trimestral-2025_03-3.pdf",
    "https://cdn-sites-assets.mziq.com/wp-content/uploads/sites/1234/2025/01/Carta-Trimestral-2024_12.pdf",
    "https://cdn-sites-assets.mziq.com/wp-content/uploads/sites/1234/2024/10/Carta-Trimestral-2024_09.pdf",
    "https://cdn-sites-assets.mziq.com/wp-content/uploads/sites/1234/2024/06/Carta-Trimestral-2024_06.pdf",
    "https://cdn-sites-assets.mziq.com/wp-content/uploads/sites/1234/2024/03/Carta-Trimestral-2024_03.pdf",
    "https://cdn-sites-assets.mziq.com/wp-content/uploads/sites/1234/2024/01/Carta-2023_12.pdf",
    "https://cdn-sites-assets.mziq.com/wp-content/uploads/sites/1234/2023/10/Carta-2023_09.pdf",
    "https://cdn-sites-assets.mziq.com/wp-content/uploads/sites/1234/2023/07/Carta-2023_06-1.pdf",
    "https://cdn-sites-assets.mziq.com/wp-content/uploads/sites/1234/2022/12/CARTA_DEZ_22.pdf",
    "https://cdn-sites-assets.mziq.com/wp-content/uploads/sites/1234/2022/09/Carta_2022_09.pdf",
    "https://cdn-sites-assets.mziq.com/wp-content/uploads/sites/1234/2022/06/CARTA_06_2022.pdf",
    "https://cdn-sites-assets.mziq.com/wp-content/uploads/sites/1234/2022/03/Carta_2022_03.pdf",
    "https://cdn-sites-assets.mziq.com/wp-content/uploads/sites/1234/2021/12/Carta_2021_12.pdf",
    "https://cdn-sites-assets.mziq.com/wp-content/uploads/sites/1234/2021/09/Carta_2021_09.pdf",
    "https://cdn-sites-assets.mziq.com/wp-content/uploads/sites/1234/2021/06/Carta_2021_06.pdf",
    "https://cdn-sites-assets.mziq.com/wp-content/uploads/sites/1234/2023/07/Carta_2021_03.pdf",
    "https://cdn-sites-assets.mziq.com/wp-content/uploads/sites/1234/2020/12/Carta-2020_12-1.pdf",
    "https://cdn-sites-assets.mziq.com/wp-content/uploads/sites/1234/2020/09/Carta_2020_09.pdf",
    "https://cdn-sites-assets.mziq.com/wp-content/uploads/sites/1234/2020/06/Carta-2020_06.pdf",
    "https://cdn-sites-assets.mziq.com/wp-content/uploads/sites/1234/2020/03/Carta_2020_03.pdf",
    "https://cdn-sites-assets.mziq.com/wp-content/uploads/sites/1234/2023/07/Carta_2019_09.pdf",
    "https://cdn-sites-assets.mziq.com/wp-content/uploads/sites/1234/2023/07/Carta_2019_06.pdf",
    "https://cdn-sites-assets.mziq.com/wp-content/uploads/sites/1234/2023/07/Carta_2018_12.pdf",
    "https://cdn-sites-assets.mziq.com/wp-content/uploads/sites/1234/2023/07/Carta_2018_09.pdf",
    "https://cdn-sites-assets.mziq.com/wp-content/uploads/sites/1234/2023/07/Carta_2018_06.pdf",
    "https://cdn-sites-assets.mziq.com/wp-content/uploads/sites/1234/2023/07/Carta_2018_03.pdf",
    "https://cdn-sites-assets.mziq.com/wp-content/uploads/sites/1234/2023/07/Carta_2017_12.pdf",
    "https://cdn-sites-assets.mziq.com/wp-content/uploads/sites/1234/2023/07/Carta_2017_09.pdf",
    "https://cdn-sites-assets.mziq.com/wp-content/uploads/sites/1234/2023/07/Carta_2017_05.pdf",
    "https://cdn-sites-assets.mziq.com/wp-content/uploads/sites/1234/2023/06/Carta_2017_03.pdf"
]



"""
links_rpm2 =  list(set([
    f"https://www.bcb.gov.br/content/ri/relatorioinflacao/{ano}{mes:02d}/RELINF{ano}{mes:02d}-ri{ano}{mes:02d}P.pdf"
    for ano in range(2000, 2027)
    for mes in range(1, 13)
    if not (ano == 2026 and mes > 5)
]))

https://www.bcb.gov.br/content/ri/relatorioinflacao/{ano}{mes:02d}/rpm{ano}{mes:02d}b{count}p.pdf
links_rpm3 =  list(set([
    f"https://www.bcb.gov.br/content/ri/relatorioinflacao/{ano}{mes:02d}/rpm{ano}{mes:02d}b{count}p.pdf"
    for ano in range(2024, 2027)
    for mes in range(1, 13)
    for count in range(1,13)
    if not (ano == 2026 and mes > 5)
]))

links_rpm4=  list(set([
    f"https://www.bcb.gov.br/content/ri/relatorioinflacao/{ano}{mes:02d}/RELINF{ano}12-ri{ano}{mes:02d}b{count}p.pdf"

    for ano in range(2000, 2027)
    for mes in range(1, 13)
    for count in range(1,13)
    if not (ano == 2026 and mes > 5)
]))
"""

links_kinea = [

  "https://www.kinea.com.br/blog/carta-do-gestor-era-uma-vez-em-hollywood/",
  "https://www.kinea.com.br/blog/kinea-insights-parasita-consumidor-brasileiro-classe-media/",
  "https://www.kinea.com.br/blog/carta-do-gestor-ira-petroleo-escassez-ativos-mercados-globais/",
  "https://www.kinea.com.br/blog/insights-duna-petroleo-geografia-e-poder/",
  "https://www.kinea.com.br/blog/carta-do-gestor-estreito-ormuz-impacto-mercados-globais/",
  "https://www.kinea.com.br/blog/kinea-insights-o-exterminador-do-futuro/",
  "https://www.kinea.com.br/blog/carta-do-gestor-games-of-thrones/",
  "https://www.kinea.com.br/blog/kinea-insights-amnesia/",
  "https://www.kinea.com.br/blog/carta-do-gestor-capitao-america/",
  "https://www.kinea.com.br/blog/kinea-insights-whiplash/",
  "https://www.kinea.com.br/blog/carta-do-gestor-cartas-a-um-jovem-poeta/",
  "https://www.kinea.com.br/blog/kinea-insights-the-hidden-side-of-artificial-intelligence/",
  "https://www.kinea.com.br/blog/kinea-insights-o-lado-oculto-da-inteligencia-artificial/",
  "https://www.kinea.com.br/blog/carta-do-gestor-a-iliada/",
  "https://www.kinea.com.br/blog/kinea-insights-eu-robo/",
  "https://www.kinea.com.br/blog/carta-do-gestor-o-fim-da-historia-e-o-ultimo-homem/",
  "https://www.kinea.com.br/blog/kinea-insights-chinatown/",
  "https://www.kinea.com.br/blog/carta-do-gestor-a-odisseia/",
  "https://www.kinea.com.br/blog/kinea-insights-velocidade-maxima-investimentos-inteligencia-artificial/",
  "https://www.kinea.com.br/blog/carta-do-gestor-grandes-esperancas/",
  "https://www.kinea.com.br/blog/kinea-insights-matrix-reloaded/",
  "https://www.kinea.com.br/blog/carta-do-gestor-clube-da-luta/",
  "https://www.kinea.com.br/blog/kinea-insights-1984/",
  "https://www.kinea.com.br/blog/carta-do-gestor-sun-tzu-a-arte-da-guerra/",
  "https://www.kinea.com.br/blog/kinea-insights-interestelar/",
  "https://www.kinea.com.br/blog/carta-do-gestor-o-dia-depois-de-amanha/",
  "https://www.kinea.com.br/blog/kinea-insights-era-uma-vez-na-america/",
  "https://www.kinea.com.br/blog/carta-do-gestor-apocalypse-now/",
  "https://www.kinea.com.br/blog/kinea-insights-fundacao/",
  "https://www.kinea.com.br/blog/carta-trimestral-de-acoes-positioning/",
  "https://www.kinea.com.br/blog/carta-do-gestor-o-imperio-contra-ataca/",
  "https://www.kinea.com.br/blog/kinea-insights-gladiador/",
  "https://www.kinea.com.br/blog/carta-do-gestor-tudo-em-todo-lugar/",
  "https://www.kinea.com.br/blog/kinea-insights-o-senhor-dos-aneis/",
  "https://www.kinea.com.br/blog/carta-do-gestor-fahrenheit-451/",
  "https://www.kinea.com.br/blog/kinea-insights-o-feitico-do-tempo/",
  "https://www.kinea.com.br/blog/carta-acoes-investindo-por-expectativas/",
  "https://www.kinea.com.br/blog/carta-do-gestor-tempo-perdido/",
  "https://www.kinea.com.br/blog/kinea-insights-as-quatro-estacoes/",
  "https://www.kinea.com.br/blog/carta-do-gestor-o-conde-de-monte-cristo/",
  "https://www.kinea.com.br/blog/kinea-insights-hotel-california/",
  "https://www.kinea.com.br/blog/carta-do-gestor-o-alquimista/",
  "https://www.kinea.com.br/blog/kinea-insights-vidas-secas/",
  "https://www.kinea.com.br/blog/carta-de-acoes-dividendos-recompras/",
  "https://www.kinea.com.br/blog/carta-do-gestor-gran-torino/",
  "https://www.kinea.com.br/blog/kinea-insights-as-invasoes-barbaras/",
  "https://www.kinea.com.br/blog/carta-do-gestor-rashomon/",
  "https://www.kinea.com.br/blog/kinea-insights-frankenstein-o-monstro-fiscal-brasileiro/",
  "https://www.kinea.com.br/blog/carta-do-gestor-007/",
  "https://www.kinea.com.br/blog/kinea-insights-la-dolce-vita/",
  "https://www.kinea.com.br/blog/carta-acoes-o-home-bias-e-a-beleza-da-diversificacao-de-investimentos/",
  "https://www.kinea.com.br/blog/carta-do-gestor-onde-os-fracos-nao-tem-vez/",
  "https://www.kinea.com.br/blog/kinea-insights-matrix/",
  "https://www.kinea.com.br/blog/carta-do-gestor-beleza-americana/",
  "https://www.kinea.com.br/blog/kinea-insights-top-gun-maverick/",
  "https://www.kinea.com.br/blog/carta-do-gestor-a-origem/",
  "https://www.kinea.com.br/blog/kinea-insights-a-metamorfose-industria/",
  "https://www.kinea.com.br/blog/carta-do-gestor-cai-o-pano-banco/",
  "https://www.kinea.com.br/blog/kinea-insights-os-miseraveis-saneamento-basico/",
 
]